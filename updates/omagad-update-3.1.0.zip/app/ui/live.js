/* LIVEAGAD : une timeline DaVinci d'une date → des dizaines de clips verticaux du set, montés et exportés tout seuls. */
(function () {
  const { $, $$, esc, fmt } = VC;
  const L = VC.L = { lid: null, data: null, job: null, list: [] };
  const LEN = [['mix', 'Mélange (15 à 45 s)'], ['short', 'Courts (≈ 15 s)'], ['medium', 'Moyens (≈ 30 s)'], ['long', 'Longs (≈ 45 s)']];
  const CAMS = [['all', 'Multicam + chaque caméra'], ['multi', 'Multicam seulement'], ['single', 'Une caméra par clip']];
  const COUNTS = [20, 30, 50, 75, 100, 150, 200];
  const S = () => VC.S.state.settings;

  VC.screens.live = async function () {
    $('#view').innerHTML = '<div class="live"><section class="lv-side" id="lvSide"></section><section class="lv-main" id="lvMain"></section></div>';
    try {
      const r = await VC.api('/api/live'); L.list = r.items;
      if (r.running) { L.lid = r.running.lid; L.job = r.running.job; }
    } catch (e) { L.list = []; }
    if (L.lid && !L.list.find(x => x.id === L.lid)) L.lid = null;
    await loadCurrent();
    if (L.job) follow(L.job);
  };

  async function loadCurrent() {
    L.data = null;
    if (L.lid) { try { L.data = await VC.api('/api/live/' + L.lid); } catch (e) { L.lid = null; } }
    paint();
  }

  /* ---------- Import d'une timeline ---------- */
  VC.liveImport = async function (path) {
    try {
      const r = await VC.api('/api/live/import', { path });
      L.lid = r.lid; VC.sound('ready');
      if (VC.S.view === 'live') { const x = await VC.api('/api/live'); L.list = x.items; await loadCurrent(); }
    } catch (e) { VC.toast(e.message, 7000); VC.sound('error'); }
  };
  async function pick() {
    if (!VC.native() || !window.pywebview.api.pick_timeline) return VC.toast('Glisse ta timeline (.xml ou .fcpxml) dans la fenêtre d\'OMAGAD.');
    const p = await window.pywebview.api.pick_timeline(); if (p) VC.liveImport(p);
  }

  /* ---------- Affichage ---------- */
  function paint() {
    const side = $('#lvSide'), main = $('#lvMain'); if (!side) return;
    const d = L.data;
    if (!d) {
      side.innerHTML = '<div class="lv-drop" id="lvDrop"><div class="lv-drop-ico">' + EQ + '</div><h2>Dépose la timeline de ta date</h2>' +
        '<p class="hint">Dans DaVinci : <b>Fichier ▸ Exporter ▸ Timeline…</b> puis <b>FCPXML</b> ou <b>FCP 7 XML</b>. Les caméras sont les pistes vidéo (V1, V2…), elles doivent être synchronisées.</p>' +
        '<button class="btn primary big" type="button" id="lvPick">Choisir la timeline</button></div>' + recents();
      main.innerHTML = '<div class="lv-empty"><b>Comment ça marche</b><ol class="hint"><li>OMAGAD écoute ton set : tempo, montées, drops, passages les plus forts.</li>' +
        '<li>Pour chaque moment fort, il monte plusieurs clips : multicam coupé sur les mesures, chaque caméra seule, versions courtes et longues, zooms sur le drop.</li>' +
        '<li>Le cadre suit le sujet (recadrage vertical automatique), le son est mis au niveau des réseaux.</li>' +
        '<li>Tout est exporté dans un dossier au nom de la date : 1.mp4, 2.mp4… du meilleur au moins bon.</li></ol></div>';
      $('#lvPick').onclick = pick;
      bindRecents();
      return;
    }
    const tl = d.timeline, st = S(), running = !!L.job;
    const done = d.clips.filter(c => c.state === 'done').length;
    side.innerHTML = '<div class="lv-card"><div class="lv-head"><button class="icon-btn" type="button" id="lvBack" title="Autres timelines"><svg viewBox="0 0 20 20" width="16" height="16"><path d="M12.5 5l-5 5 5 5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
      '<input type="text" id="lvName" value="' + esc(d.name) + '" maxlength="80" title="Nom de la date (et du dossier d\'export)"></div>' +
      '<div class="lv-facts"><span><b>' + fmt(tl.duration) + '</b> de timeline</span><span><b>' + tl.cams.length + '</b> caméra' + (tl.cams.length > 1 ? 's' : '') + '</span>' +
      '<span><b>' + tl.files + '</b> rushes</span>' + (d.analysis ? '<span><b>' + Math.round(d.analysis.bpm) + '</b> BPM</span><span><b>' + d.analysis.drops.length + '</b> drops</span>' : '') + '</div>' +
      '<div class="lv-cams">' + tl.cams.map(c => '<span class="lv-cam"><i style="width:' + Math.round(c.cover * 100) + '%"></i>' + esc(c.name) + ' · ' + c.items + ' plan' + (c.items > 1 ? 's' : '') + '</span>').join('') + '</div>' +
      (tl.ignored_tracks ? '<p class="hint" style="margin:0">' + tl.ignored_tracks + ' piste(s) ignorée(s) (logos, images, pistes presque vides).</p>' : '') +
      (tl.missing.length ? '<div class="ff-warn"><b>' + tl.missing.length + ' rush(es) introuvable(s)</b><span class="hint">Ils ont été déplacés depuis le montage. Choisis le dossier où ils se trouvent (les sous-dossiers sont fouillés).</span>' +
        '<button class="btn small primary" type="button" id="lvRelink">Retrouver les rushes</button></div>' : '') +
      '</div>' +
      '<div class="lv-card"><span class="label">Clips à fabriquer</span>' +
      '<div class="field"><label for="lvCount">Nombre de clips</label><select id="lvCount">' + COUNTS.map(n => '<option value="' + n + '"' + ((st.live_count || 100) === n ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></div>' +
      '<div class="field"><label for="lvLen">Durée</label><select id="lvLen">' + LEN.map(o => '<option value="' + o[0] + '"' + ((st.live_length || 'mix') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></div>' +
      '<div class="field"><label for="lvCams">Caméras</label><select id="lvCams"' + (tl.cams.length < 2 ? ' disabled' : '') + '>' + CAMS.map(o => '<option value="' + o[0] + '"' + ((st.live_cams || 'all') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></div>' +
      '<label class="check"><input type="checkbox" id="lvPunch"' + (st.live_punch !== false ? ' checked' : '') + '> Zooms « punch » sur le drop et les mesures</label>' +
      '<label class="check"><input type="checkbox" id="lvTrack"' + (st.live_tracking !== false ? ' checked' : '') + '> Recadrage automatique sur le sujet</label>' +
      '<div class="field"><label for="lvOut">Dossier d\'export</label><div class="path"><input type="text" id="lvOut" value="' + esc(st.out_dir) + '"><button class="btn small" type="button" id="lvDir">Parcourir</button></div>' +
      '<span class="hint" id="lvPath"></span></div></div>' +
      '<div class="lv-run"><div id="lvProg"' + (running ? '' : ' hidden') + '><div class="bar-prog"><i id="lvBar"></i></div><div class="hint" id="lvMsg"></div></div>' +
      '<button class="btn ' + (running ? 'danger' : 'primary') + ' big" type="button" id="lvGo"' + (tl.missing.length && !running ? ' disabled' : '') + '>' +
      (running ? 'Arrêter' : done && done < d.clips.length ? 'Reprendre l\'export' : done ? 'Tout refaire et exporter' : 'Générer et exporter') + '</button>' +
      (d.out_dir && done ? '<button class="btn ghost" type="button" id="lvOpen">Ouvrir le dossier (' + done + ' clips)</button>' : '') + '</div>';
    main.innerHTML = '<div class="lv-graph"><div class="lv-gh"><b>Énergie du set</b><span class="hint">' + (d.analysis ? '<i class="lg-drop"></i> drops · <i class="lg-clip"></i> clips' : 'S\'affiche après l\'analyse') + '</span></div><canvas id="lvCanvas"></canvas></div>' +
      '<div class="lv-grid-head"><b>Clips</b><span class="hint" id="lvCount2"></span></div><div class="lv-grid" id="lvGrid"></div>';
    bindSide(); drawGraph(); paintGrid();
  }

  function recents() {
    if (!L.list.length) return '';
    return '<div class="lv-recents"><span class="label">Dates récentes</span>' + L.list.map(x =>
      '<div class="lv-rec" data-lid="' + x.id + '">' + (x.thumb ? '<img src="/livethumb/' + x.id + '/' + x.thumb + '.jpg" alt="">' : '<span class="lv-rec-ph">' + EQ + '</span>') +
      '<div><b>' + esc(x.name) + '</b><span class="hint">' + fmt(x.duration) + ' · ' + x.cams + ' cam · ' + x.clips + ' clips</span></div>' +
      '<button class="icon-btn" type="button" data-del="' + x.id + '" title="Supprimer">×</button></div>').join('') + '</div>';
  }
  function bindRecents() {
    $$('.lv-rec').forEach(el => el.onclick = async e => {
      const del = e.target.closest('[data-del]');
      if (del) {
        e.stopPropagation();
        if (!await VC.confirm('Supprimer cette date ?', 'L\'analyse et la liste des clips sont effacées. Les clips déjà exportés et tes rushes ne sont pas touchés.', 'Supprimer')) return;
        await VC.api('/api/live/delete', { lid: del.dataset.del }); return VC.screens.live();
      }
      L.lid = el.dataset.lid; loadCurrent();
    });
  }

  function opts() {
    return { count: +$('#lvCount').value, length: $('#lvLen').value, cams: $('#lvCams').value, punch: $('#lvPunch').checked,
      tracking: $('#lvTrack').checked, out_dir: $('#lvOut').value.trim() };
  }
  function pathHint() {
    const el = $('#lvPath'); if (!el) return;
    const name = ($('#lvName').value || 'set').replace(/[\\/:*?"<>|]+/g, '-');
    el.textContent = ($('#lvOut').value || S().out_dir).replace(/^\/Users\/[^/]+/, '~').replace(/\/$/, '') + '/' + name + '/1.mp4, 2.mp4…';
  }
  function bindSide() {
    $('#lvBack').onclick = () => { if (L.job) return VC.toast('Une génération est en cours.'); L.lid = null; VC.screens.live(); };
    $('#lvName').onchange = e => { VC.api('/api/live/rename', { lid: L.lid, name: e.target.value }); L.data.name = e.target.value; pathHint(); };
    $('#lvName').onkeydown = e => e.stopPropagation();
    const save = () => VC.saveSettings({ live_count: +$('#lvCount').value, live_length: $('#lvLen').value, live_cams: $('#lvCams').value,
      live_punch: $('#lvPunch').checked, live_tracking: $('#lvTrack').checked });
    ['#lvCount', '#lvLen', '#lvCams', '#lvPunch', '#lvTrack'].forEach(s => $(s).onchange = save);
    $('#lvOut').oninput = pathHint;
    $('#lvDir').onclick = async () => { if (!VC.native()) return; const d = await window.pywebview.api.pick_folder($('#lvOut').value); if (d) { $('#lvOut').value = d; pathHint(); } };
    pathHint();
    const rl = $('#lvRelink');
    if (rl) rl.onclick = async () => {
      if (!VC.native()) return;
      const f = await window.pywebview.api.pick_folder(''); if (!f) return;
      const r = await VC.api('/api/live/relink', { lid: L.lid, folder: f });
      VC.toast(r.found + ' rush(es) retrouvé(s)' + (r.missing ? ', ' + r.missing + ' encore introuvable(s)' : ''), 5000);
      loadCurrent();
    };
    $('#lvGo').onclick = async () => {
      if (L.job) { await VC.api('/api/cancel/' + L.job, {}); return; }
      try { const r = await VC.api('/api/live/run', { lid: L.lid, opts: opts() }); L.job = r.job; paint(); follow(r.job); }
      catch (e) { VC.toast(e.message, 6000); }
    };
    const op = $('#lvOpen'); if (op) op.onclick = () => VC.api('/api/reveal', { path: L.data.out_dir });
  }

  /* ---------- Suivi de la génération ---------- */
  let lastRefresh = 0;
  async function follow(job) {
    try {
      const j = await VC.poll(job, async x => {
        const bar = $('#lvBar'), msg = $('#lvMsg');
        if (bar) bar.style.width = Math.round((x.progress || 0) * 100) + '%';
        if (msg) msg.textContent = x.message || '';
        if (Date.now() - lastRefresh > 2500 && L.lid && VC.S.view === 'live') {
          lastRefresh = Date.now();
          try { const d = await VC.api('/api/live/' + L.lid); if (!L.data || d.analysis && !L.data.analysis) { L.data = d; paint(); } else { L.data = d; paintGrid(); drawGraph(); } } catch (e) { /* suivant */ }
        }
      });
      L.job = null;
      if (j.error) { VC.toast(j.error, 8000); VC.sound('error'); }
      else { VC.toast(VC.t(j.message || 'Terminé'), 5000); VC.sound('done'); }
    } catch (e) { L.job = null; }
    if (VC.S.view === 'live') loadCurrent();
  }

  /* ---------- Grille des clips ---------- */
  function paintGrid() {
    const g = $('#lvGrid'); if (!g || !L.data) return;
    const cl = L.data.clips, done = cl.filter(c => c.state === 'done').length;
    $('#lvCount2').textContent = cl.length ? done + ' / ' + cl.length + ' exportés' : '';
    g.innerHTML = cl.length ? cl.map(c => '<div class="lv-clip ' + (c.state || 'wait') + '" data-n="' + c.n + '" title="' + esc(c.error || c.label) + '">' +
      '<div class="lv-th">' + (c.state === 'done' ? '<img loading="lazy" src="/livethumb/' + L.lid + '/' + c.n + '.jpg?v=' + (c.file ? c.file.length : 0) + '" alt="">' : '') +
      '<span class="lv-n">' + c.n + '</span>' + (c.state === 'error' ? '<span class="lv-st err">!</span>' : c.state === 'done' ? '' : '<span class="lv-st">…</span>') + '</div>' +
      '<div class="lv-lab">' + esc(c.label) + '</div></div>').join('')
      : '<div class="lv-empty"><b>Prêt</b><span class="hint">Règle le nombre de clips à gauche, puis « Générer et exporter ». Tu peux laisser tourner : tout se fait seul.</span></div>';
    g.onclick = e => { const el = e.target.closest('.lv-clip.done'); if (!el) return; const c = cl.find(x => x.n === +el.dataset.n); if (c) VC.play(c.file, c.n + ' · ' + c.label); };
  }

  /* ---------- Courbe d'énergie ---------- */
  function drawGraph() {
    const cv = $('#lvCanvas'); if (!cv || !L.data) return;
    const an = L.data.analysis, dpr = devicePixelRatio || 1, w = cv.clientWidth, h = cv.clientHeight;
    cv.width = w * dpr; cv.height = h * dpr;
    const g = cv.getContext('2d'); g.scale(dpr, dpr); g.clearRect(0, 0, w, h);
    const dur = L.data.timeline.duration || 1, X = t => t / dur * w;
    for (const c of L.data.clips || []) { g.fillStyle = c.state === 'done' ? 'rgba(61,220,151,.16)' : 'rgba(80,140,255,.12)'; g.fillRect(X(c.t0), 0, Math.max(1, X(c.t1) - X(c.t0)), h); }
    if (an && an.curve) {
      const cur = an.curve, n = cur.length;
      const grad = g.createLinearGradient(0, 0, 0, h); grad.addColorStop(0, 'rgba(80,150,255,.95)'); grad.addColorStop(1, 'rgba(29,86,207,.15)');
      g.beginPath(); g.moveTo(0, h);
      for (let i = 0; i < n; i++) g.lineTo(i / (n - 1) * w, h - Math.min(1.2, cur[i]) / 1.2 * (h - 8));
      g.lineTo(w, h); g.closePath(); g.fillStyle = grad; g.fill();
      g.fillStyle = '#ff5c6c';
      for (const dd of an.drops) g.fillRect(X(dd.t) - 1, 0, 2, h);
    } else {
      g.fillStyle = 'rgba(255,255,255,.04)'; g.fillRect(0, h / 2, w, 1);
    }
  }
  addEventListener('resize', () => { if (VC.S.view === 'live') drawGraph(); });

  const EQ = '<svg viewBox="0 0 48 48" width="48" height="48"><g fill="currentColor"><rect x="5" y="20" width="5" height="16" rx="2"/><rect x="14" y="10" width="5" height="26" rx="2"/><rect x="23" y="16" width="5" height="20" rx="2"/><rect x="32" y="6" width="5" height="30" rx="2"/><rect x="41" y="22" width="2.5" height="14" rx="1"/></g><rect x="3" y="39" width="42" height="3" rx="1.5" fill="currentColor" opacity=".4"/></svg>';
})();
