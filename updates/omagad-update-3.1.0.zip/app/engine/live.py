"""Module LIVEAGAD : à partir d'une timeline DaVinci (set de DJ filmé à 1 ou plusieurs caméras),
fabrique automatiquement des dizaines de clips verticaux qui « tapent » : drops, montées, moments les plus intenses.

1. lecture de la timeline (FCP 7 XML ou FCPXML exportés par DaVinci) : caméras = pistes vidéo, son = pistes audio ;
2. mixage du son de la timeline, puis analyse : tempo, mesures, drops, passages les plus énergiques ;
3. plan : pour chaque moment fort, plusieurs versions (multicam coupé sur les mesures, chaque caméra seule,
   versions courtes / longues, zooms « punch » sur le drop) ;
4. rendu 1080×1920 avec recadrage automatique sur le sujet, son normalisé pour les réseaux.
"""
import json
import math
import re
import shutil
import subprocess
import time
import uuid
import wave
from pathlib import Path
from urllib.parse import unquote, urlparse
import xml.etree.ElementTree as ET

from . import autocrop, edit, media, render
from .config import DATA
from .media import NOWIN

LIVE = DATA / "live"
W, H = 1080, 1920
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".psd", ".bmp", ".gif", ".heic", ".webp", ".exr", ".dpx"}
AUDIO_EXT = {".wav", ".aif", ".aiff", ".mp3", ".m4a", ".aac", ".flac", ".ogg", ".caf"}
SR = 11025          # analyse du son
HOP = 256           # ≈ 23 ms


# ====================================================================== lecture de la timeline
def _path_from_url(u):
    if not u:
        return None
    u = u.strip()
    p = urlparse(u)
    if p.scheme in ("file", ""):
        path = unquote(p.path or u)
        if re.match(r"^/[A-Za-z]:/", path):  # file:///C:/… (Windows)
            path = path[1:]
        return path
    return None


def _xrate(el, default=25.0):
    r = el.find("rate") if el is not None else None
    if r is None:
        return default
    tb = float(r.findtext("timebase") or default)
    return tb * 1000 / 1001 if (r.findtext("ntsc") or "").upper() == "TRUE" else tb


def _parse_xmeml(root):
    seq = root.find(".//sequence")
    if seq is None:
        raise ValueError("Aucune timeline trouvée dans ce fichier XML.")
    srate = _xrate(seq)
    files = {}
    for f in root.iter("file"):
        fid = f.get("id")
        if fid and f.find("pathurl") is not None:
            files[fid] = {"path": _path_from_url(f.findtext("pathurl")), "name": f.findtext("name") or ""}

    def items_of(track, kind):
        out = []
        if (track.findtext("enabled") or "TRUE").upper() == "FALSE":
            return out
        for ci in track.findall("clipitem"):
            if (ci.findtext("enabled") or "TRUE").upper() == "FALSE":
                continue
            f = ci.find("file")
            if f is None:
                continue
            info = files.get(f.get("id")) or {}
            path = info.get("path")
            if not path:
                continue
            crate = _xrate(ci, srate)
            try:
                st, en = int(float(ci.findtext("start"))), int(float(ci.findtext("end")))
                a, b = int(float(ci.findtext("in"))), int(float(ci.findtext("out")))
            except (TypeError, ValueError):
                continue
            if st < 0:
                st = en - (b - a)
            if en < 0:
                en = st + (b - a)
            if en <= st:
                continue
            lvl = 1.0
            for p in ci.iter("parameter"):
                if (p.findtext("parameterid") or "") == "level":
                    try:
                        lvl = float(p.findtext("value"))
                    except (TypeError, ValueError):
                        pass
            out.append({"t0": st / srate, "t1": en / srate, "src": path, "in": a / crate, "name": ci.findtext("name") or info.get("name"),
                        "level": lvl, "ch": int(float(ci.findtext("sourcetrack/trackindex") or 1)) if kind == "audio" else 0})
        return out

    vt = [items_of(t, "video") for t in seq.findall("media/video/track")]
    at = [items_of(t, "audio") for t in seq.findall("media/audio/track")]
    return {"kind": "xml", "name": seq.findtext("name") or "Timeline", "fps": srate, "video": vt, "audio": at}


def _t(s):
    """Temps FCPXML (« 1001/30000s », « 12s ») en secondes."""
    if not s:
        return 0.0
    s = s.strip().rstrip("s")
    if "/" in s:
        a, b = s.split("/")
        return float(a) / float(b)
    return float(s)


def _parse_fcpxml(root):
    assets, fmts = {}, {}
    for f in root.iter("format"):
        fmts[f.get("id")] = f
    for a in root.iter("asset"):
        src = a.get("src")
        mr = a.find("media-rep")
        if not src and mr is not None:
            src = mr.get("src")
        assets[a.get("id")] = {"path": _path_from_url(src), "start": _t(a.get("start")), "video": a.get("hasVideo", "1") == "1",
                               "audio": a.get("hasAudio", "0") == "1", "name": a.get("name") or ""}
    seq = root.find(".//sequence")
    if seq is None:
        raise ValueError("Aucune timeline trouvée dans ce fichier FCPXML.")
    spine = seq.find("spine")
    fps = 25.0
    f = fmts.get(seq.get("format"))
    if f is not None and f.get("frameDuration"):
        fps = 1.0 / max(1e-6, _t(f.get("frameDuration")))
    base = _t(seq.get("tcStart"))
    video, audio = {}, []
    clipish = {"asset-clip", "clip", "video", "audio", "ref-clip", "sync-clip", "mc-clip", "gap", "title"}

    def add(lane, t0, t1, asset_id, src_in, want_v=True, want_a=True, name=None):
        a = assets.get(asset_id)
        if not a or not a["path"] or t1 <= t0:
            return
        item = {"t0": t0, "t1": t1, "src": a["path"], "in": src_in - a["start"], "name": name or a["name"], "level": 1.0, "ch": 0}
        if a["video"] and want_v and lane >= 0:
            video.setdefault(lane, []).append(item)
        if a["audio"] and want_a:
            audio.append(dict(item))

    def vol(el):
        av = el.find("adjust-volume")
        if av is None or not av.get("amount"):
            return 1.0
        try:
            return 10 ** (float(av.get("amount").replace("dB", "")) / 20)
        except ValueError:
            return 1.0

    def walk(el, abs0, lane):
        st, dur = _t(el.get("start")), _t(el.get("duration"))
        if el.get("enabled") == "0":
            return
        if el.tag == "asset-clip":
            lv = vol(el)
            add(lane, abs0, abs0 + dur, el.get("ref"), st, want_a=lv > 0.01, name=el.get("name"))
            if audio and lv != 1.0 and audio[-1]["t0"] == abs0:
                audio[-1]["level"] = lv
        elif el.tag == "clip":
            for ch in el:
                if ch.tag in ("video", "audio") and ch.get("ref"):
                    voff, vst = _t(ch.get("offset")), _t(ch.get("start"))
                    # temps local du clip -> temps du média
                    add(lane, abs0, abs0 + dur, ch.get("ref"), st - voff + vst, want_v=ch.tag == "video", want_a=True, name=el.get("name"))
        elif el.tag == "sync-clip":
            inner = el.find("spine")
            for ch in (inner if inner is not None else []):
                walk(ch, abs0 + (_t(ch.get("offset")) - st), lane)
        # éléments connectés (pistes du dessus / du dessous)
        for ch in el:
            if ch.tag in clipish and ch.get("lane") is not None:
                walk(ch, abs0 + (_t(ch.get("offset")) - st), int(ch.get("lane")))

    for el in (spine if spine is not None else []):
        walk(el, _t(el.get("offset")) - base, 0)
    vt = [video[k] for k in sorted(video)]
    # les pistes audio « dédiées » sont les éléments sur les voies négatives : on les garde tous (comme dans DaVinci)
    proj = root.find(".//project")
    return {"kind": "fcpxml", "name": proj.get("name") if proj is not None and proj.get("name") else "Timeline",
            "fps": fps, "video": vt, "audio": [audio]}


def parse_timeline(path):
    path = Path(path)
    if path.is_dir():  # paquet .fcpxmld
        inner = path / "Info.fcpxml"
        if not inner.exists():
            raise ValueError("Ce dossier ne contient pas de timeline FCPXML.")
        path = inner
    try:
        root = ET.parse(str(path)).getroot()
    except ET.ParseError as e:
        raise ValueError("Fichier de timeline illisible (%s)." % e)
    if root.tag == "xmeml":
        tl = _parse_xmeml(root)
    elif root.tag == "fcpxml":
        tl = _parse_fcpxml(root)
    else:
        raise ValueError("Ce fichier n'est pas une timeline DaVinci (.xml ou .fcpxml).")
    return organize(tl, path)


def organize(tl, path=None):
    """Caméras = pistes vidéo avec de la vraie vidéo (les logos et images posés par-dessus sont ignorés)."""
    dur = 0.0
    for tr in tl["video"] + tl["audio"]:
        for it in tr:
            dur = max(dur, it["t1"])
    cams, ignored = [], 0
    for k, tr in enumerate(tl["video"]):
        vids = [it for it in tr if Path(it["src"]).suffix.lower() not in IMAGE_EXT | AUDIO_EXT]
        cover = sum(it["t1"] - it["t0"] for it in vids)
        if not vids or cover < max(5.0, dur * 0.08):
            ignored += 1 if tr else 0
            continue
        cams.append({"index": len(cams), "name": "Caméra %d (V%d)" % (len(cams) + 1, k + 1), "track": k + 1,
                     "items": sorted(vids, key=lambda x: x["t0"]), "cover": round(cover / max(1, dur), 3)})
    # son : pistes audio (sans doublons gauche/droite du même fichier), sinon le son des caméras
    seen, aud = set(), []
    for tr in tl["audio"]:
        for it in tr:
            key = (it["src"], round(it["t0"], 2), round(it["in"], 2))
            if key in seen or Path(it["src"]).suffix.lower() in IMAGE_EXT:
                continue
            seen.add(key)
            aud.append(it)
    if not aud and cams:
        aud = [dict(it) for it in cams[0]["items"]]
    files = sorted({it["src"] for c in cams for it in c["items"]} | {it["src"] for it in aud})
    missing = [f for f in files if not Path(f).exists()]
    return {"name": tl.get("name") or (Path(path).stem if path else "Timeline"), "kind": tl["kind"], "fps": round(tl["fps"], 3),
            "duration": round(dur, 3), "cams": cams, "audio": sorted(aud, key=lambda x: x["t0"]), "files": files,
            "missing": missing, "ignored_tracks": ignored, "source": str(path) if path else None}


def relink(tl, folder):
    """Rushes déplacés : on les retrouve par leur nom dans un dossier (et ses sous-dossiers)."""
    folder = Path(folder).expanduser()
    names = {}
    for p in folder.rglob("*"):
        if p.is_file():
            names.setdefault(p.name.lower(), str(p))
    found = 0
    mapping = {}
    for f in tl["missing"]:
        q = names.get(Path(f).name.lower())
        if q:
            mapping[f] = q
            found += 1
    for c in tl["cams"]:
        for it in c["items"]:
            it["src"] = mapping.get(it["src"], it["src"])
    for it in tl["audio"]:
        it["src"] = mapping.get(it["src"], it["src"])
    tl["files"] = sorted({it["src"] for c in tl["cams"] for it in c["items"]} | {it["src"] for it in tl["audio"]})
    tl["missing"] = [f for f in tl["files"] if not Path(f).exists()]
    return found


# ====================================================================== son de la timeline
def _run_ff(cmd, job=None):
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, **NOWIN)
    if job is not None:
        job["proc"] = p
    _, err = p.communicate()
    if job is not None:
        job["proc"] = None
    if p.returncode != 0:
        if job is not None and job.get("cancel"):
            raise InterruptedError("Annulé.")
        raise RuntimeError("ffmpeg : " + (err or b"").decode("utf-8", "replace").strip()[-300:])


def build_mix(tl, d, job=None, on_progress=lambda f: None):
    """Mixe le son de la timeline (comme on l'entend dans DaVinci) : mix.m4a (rendu) et analyse.wav (11 kHz mono)."""
    items = [it for it in tl["audio"] if Path(it["src"]).exists()]
    if not items:
        raise RuntimeError("Aucun son lisible dans la timeline (rushes introuvables ?).")
    has_audio = {}
    for it in items:
        if it["src"] not in has_audio:
            try:
                has_audio[it["src"]] = Path(it["src"]).suffix.lower() in AUDIO_EXT or media.probe(it["src"])["has_audio"]
            except Exception:
                has_audio[it["src"]] = False
    items = [it for it in items if has_audio.get(it["src"])]
    if not items:
        raise RuntimeError("Les rushes de la timeline n'ont pas de son.")
    dur = tl["duration"]
    fmt = "aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo"
    parts, chunk = [], 48
    for c0 in range(0, len(items), chunk):
        group = items[c0:c0 + chunk]
        cmd = [media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error"]
        graph = ""
        for k, it in enumerate(group):
            cmd += ["-ss", "%.3f" % max(0.0, it["in"]), "-t", "%.3f" % (it["t1"] - it["t0"]), "-i", it["src"]]
            ms = int(round(it["t0"] * 1000))
            graph += "[%d:a:0]%s,adelay=%d|%d,volume=%.3f[a%d];" % (k, fmt, ms, ms, it.get("level", 1.0), k)
        graph += "".join("[a%d]" % k for k in range(len(group)))
        graph += "amix=inputs=%d:normalize=0:duration=longest,apad,atrim=0:%.3f[out]" % (len(group), dur) if len(group) > 1 else \
            "apad,atrim=0:%.3f[out]" % dur
        out = d / ("mix-%d.wav" % (c0 // chunk))
        _run_ff(cmd + ["-filter_complex", graph, "-map", "[out]", "-c:a", "pcm_s16le", str(out)], job)
        parts.append(out)
        on_progress(min(0.9, (c0 + chunk) / len(items)))
    src = parts[0]
    if len(parts) > 1:
        cmd = [media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error"]
        for p in parts:
            cmd += ["-i", str(p)]
        src = d / "mix-all.wav"
        _run_ff(cmd + ["-filter_complex", "amix=inputs=%d:normalize=0:duration=longest" % len(parts), "-c:a", "pcm_s16le", str(src)], job)
    _run_ff([media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(src), "-c:a", "aac", "-b:a", "256k", str(d / "mix.m4a")], job)
    _run_ff([media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(src), "-ac", "1", "-ar", str(SR),
             "-c:a", "pcm_s16le", str(d / "analyse.wav")], job)
    for p in parts + [d / "mix-all.wav"]:
        try:
            p.unlink()
        except OSError:
            pass
    on_progress(1.0)


# ====================================================================== analyse du set
def _smooth(x, n):
    import numpy as np
    if n <= 1:
        return x
    k = np.ones(int(n)) / int(n)
    return np.convolve(x, k, mode="same")


def analyse(d):
    """Tempo, grille des temps, drops et passages les plus intenses."""
    import numpy as np
    with wave.open(str(d / "analyse.wav"), "rb") as w:
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    nfft = 1024
    nfr = max(1, (len(x) - nfft) // HOP)
    fr = SR / HOP
    win = np.hanning(nfft).astype(np.float32)
    freqs = np.fft.rfftfreq(nfft, 1 / SR)
    bass_b = freqs < 150
    high_b = freqs > 2500
    rms, bass, high, flux, bflux = (np.zeros(nfr, np.float32) for _ in range(5))
    prev = None
    step = 4096
    for s0 in range(0, nfr, step):
        idx = np.arange(s0, min(nfr, s0 + step))
        frames = np.lib.stride_tricks.as_strided(x[idx[0] * HOP:], shape=(len(idx), nfft), strides=(HOP * 4, 4)).copy()
        mag = np.abs(np.fft.rfft(frames * win, axis=1)).astype(np.float32)
        lm = np.log1p(mag * 10)
        rms[idx] = np.sqrt((frames ** 2).mean(axis=1))
        bass[idx] = mag[:, bass_b].mean(axis=1)
        high[idx] = mag[:, high_b].mean(axis=1)
        dif = np.diff(np.vstack([lm[:1] if prev is None else prev[None, :], lm]), axis=0)
        dif = np.maximum(dif, 0)
        flux[idx] = dif.mean(axis=1)
        bflux[idx] = dif[:, bass_b].mean(axis=1)
        prev = lm[-1]
    dur = nfr / fr

    # --- tempo (DJ : on privilégie 115-140 BPM)
    onset = flux - _smooth(flux, int(fr))
    onset = np.maximum(onset, 0)
    seg = onset[: int(min(len(onset), fr * 600))] if len(onset) > fr * 30 else onset
    best, bpm = -1, 125.0
    if len(seg) > fr * 8:
        seg = seg - seg.mean()
        ac = np.correlate(seg[: int(fr * 120)], seg[: int(fr * 120)], mode="full")[int(min(len(seg), fr * 120)) - 1:] \
            if len(seg) > fr * 120 else np.correlate(seg, seg, mode="full")[len(seg) - 1:]
        for b in np.arange(85.0, 180.0, 0.25):
            lag = 60.0 / b * fr
            i = int(round(lag))
            if i + 2 >= len(ac):
                continue
            v = ac[i] + 0.5 * ac[min(len(ac) - 1, 2 * i)] + 0.25 * ac[min(len(ac) - 1, 4 * i)]
            v *= 1.0 + 0.25 * math.exp(-((b - 127.0) / 12.0) ** 2)
            if v > best:
                best, bpm = v, float(b)
        # affinage : on aligne une grille sur tout le passage analysé (précision au centième de BPM)
        on_full = onset[: int(min(len(onset), fr * 900))]
        t_on = np.nonzero(on_full > np.percentile(on_full, 90))[0] / fr
        w_on = on_full[on_full > np.percentile(on_full, 90)]
        if len(t_on) > 20:
            bestv, bestb = -1, bpm
            for b in np.arange(bpm - 1.5, bpm + 1.5, 0.02):
                ph = 2 * np.pi * t_on / (60.0 / b)
                v = abs((w_on * np.exp(1j * ph)).sum())
                if v > bestv:
                    bestv, bestb = v, float(b)
            bpm = bestb
    period = 60.0 / bpm

    # --- énergie
    eb = _smooth(bass, int(fr * 1.0))
    el = _smooth(rms, int(fr * 2.0))
    eh = _smooth(high, int(fr * 1.0))
    nb = eb / (np.percentile(eb, 95) + 1e-9)
    nl = el / (np.percentile(el, 95) + 1e-9)

    # --- drops : la basse revient fort après une montée / un break
    drops = []
    a_n, b_n, gap = int(fr * 6), int(fr * 2.5), int(fr * 0.6)
    pref = np.cumsum(np.concatenate([[0.0], bass.astype(np.float64)]))

    def mean(i0, i1):
        i0, i1 = max(0, i0), min(len(bass), i1)
        return (pref[i1] - pref[i0]) / max(1, i1 - i0)
    lvl60 = np.percentile(eb, 55)
    hop_i = int(fr * 0.25)
    cand = []
    for i in range(a_n, len(bass) - b_n, hop_i):
        before, after = mean(i - a_n, i - gap), mean(i, i + b_n)
        if after < lvl60:
            continue
        r = after / (before + 1e-6)
        if r > 1.9:
            rise = float(eh[max(0, i - int(fr * 4)): i].mean() / (eh[max(0, i - int(fr * 12)): max(1, i - int(fr * 4))].mean() + 1e-6))
            cand.append((r * (1 + 0.15 * min(2.0, max(0.0, rise - 1))), i, r))
    cand.sort(reverse=True)
    taken = []
    for sc, i, r in cand:
        if all(abs(i - j) > fr * 20 for j in taken):
            taken.append(i)
            # cale le drop sur le coup de basse le plus fort à ±0,6 s
            w0, w1 = max(0, i - int(fr * 0.6)), min(len(bflux), i + int(fr * 0.6))
            k = int(w0 + np.argmax(bflux[w0:w1])) if w1 > w0 else i
            drops.append({"t": round(k / fr, 3), "score": round(float(math.log(max(1.01, sc)) * 2 + nl[min(len(nl) - 1, k + int(fr * 2))]), 3),
                          "ratio": round(float(r), 2)})
        if len(drops) >= 120:
            break

    # --- passages les plus intenses (pour les sets sans gros drop)
    intens = 0.6 * nb + 0.4 * nl
    peaks = []
    span = int(fr * 16)
    si = _smooth(intens, span)
    edge = int(fr * 10)
    order = np.argsort(-si[edge:len(si) - edge]) + edge if len(si) > 3 * edge else np.argsort(-si)
    for i in order[::max(1, int(fr))]:
        i = int(i)
        if all(abs(i - int(p["t"] * fr)) > fr * 24 for p in peaks) and all(abs(i - int(dd["t"] * fr)) > fr * 12 for dd in drops):
            peaks.append({"t": round(i / fr, 3), "score": round(float(si[i]) * 1.6, 3)})
        if len(peaks) >= 80:
            break

    # courbe pour l'interface (2 points par seconde)
    step_c = max(1, int(fr / 2))
    curve = [round(float(v), 3) for v in np.clip(intens[::step_c], 0, 1.5)]
    return {"bpm": round(bpm, 2), "period": period, "duration": round(dur, 2), "drops": drops, "peaks": peaks, "curve": curve,
            "curve_rate": fr / step_c, "_onset": None}


def beat_grid(d, t, period, span=16):
    """Phase locale des temps autour de t (les DJ dérivent un peu) : renvoie l'heure du temps le plus proche de t."""
    import numpy as np
    try:
        with wave.open(str(d / "analyse.wav"), "rb") as w:
            w.setpos(max(0, int((t - span * period) * SR)))
            n = int(2 * span * period * SR)
            x = np.frombuffer(w.readframes(n), dtype=np.int16).astype(np.float32) / 32768.0
        t_start = max(0.0, t - span * period)
    except Exception:
        return t
    if len(x) < SR:
        return t
    env = np.abs(x)
    k = max(1, int(SR * 0.01))
    env = np.convolve(env, np.ones(k) / k, mode="same")
    on = np.maximum(np.diff(env, prepend=env[0]), 0)
    best, ph = -1, 0.0
    for p in np.linspace(0, period, 48, endpoint=False):
        idx = (np.arange(p, len(on) / SR, period) * SR).astype(int)
        idx = idx[idx < len(on)]
        v = on[idx].sum()
        if v > best:
            best, ph = v, p
    beats = t_start + ph + period * np.round((t - t_start - ph) / period)
    return float(beats)


# ====================================================================== plan des clips
LENGTHS = {"short": [(4, 4)], "medium": [(8, 8)], "long": [(8, 24)], "mix": [(8, 8), (4, 4), (8, 16), (4, 12)]}


def plan(tl, an, d, count=100, length="mix", cams_mode="all", punch=True):
    """Liste des clips à fabriquer : les meilleurs moments, en plusieurs versions (caméras, durées, zooms)."""
    period = an["period"]
    bar = 4 * period
    ncam = len(tl["cams"])
    moments = [dict(kind="drop", t=x["t"], score=x["score"]) for x in an["drops"]] + \
              [dict(kind="peak", t=x["t"], score=x["score"] * 0.8) for x in an["peaks"]]
    moments.sort(key=lambda m: -m["score"])
    dur = tl["duration"]
    lens = LENGTHS.get(length, LENGTHS["mix"])
    styles = []
    if ncam >= 2 and cams_mode in ("all", "multi"):
        styles.append(("multicam", None))
    if cams_mode in ("all", "single") or ncam < 2:
        styles += [("cam", k) for k in range(ncam)]
    if not styles:
        styles = [("cam", 0)]
    variants = [(s, L) for L in lens for s in styles]
    out, used = [], set()
    rounds = 0
    while len(out) < count and rounds < len(variants) + 2 and moments:
        for m in moments:
            if len(out) >= count:
                break
            if rounds >= len(variants):
                break
            (style, cam), (pre, post) = variants[(rounds + hash(round(m["t"])) % len(variants)) % len(variants)]
            anchor = beat_grid(d, m["t"], period) if m["kind"] == "drop" else beat_grid(d, m["t"] - 8 * bar / 2, period)
            t0 = anchor - pre * bar if m["kind"] == "drop" else anchor
            t1 = anchor + post * bar if m["kind"] == "drop" else anchor + (pre + post) * bar
            t0, t1 = max(0.0, t0), min(dur, t1)
            if t1 - t0 < 6:
                continue
            key = (round(t0), round(t1), style, cam)
            if key in used:
                continue
            shots = _shots(tl, t0, t1, anchor if m["kind"] == "drop" else None, bar, style, cam)
            if not shots:
                continue
            used.add(key)
            zooms = []
            if punch:
                if m["kind"] == "drop":
                    zooms = [round(anchor - t0 + b * bar, 3) for b in range(0, int((t1 - anchor) / bar) + 1, 2)]
                    zooms[0:1] = [round(anchor - t0, 3)]
                else:
                    zooms = [round(b * bar * 2, 3) for b in range(int((t1 - t0) / (bar * 2)) + 1)]
            label = ("Drop" if m["kind"] == "drop" else "Énergie") + " " + _fmt(m["t"]) + " · " + \
                ("multicam" if style == "multicam" else tl["cams"][cam]["name"].split(" (")[0].lower()) + " · " + "%d s" % round(t1 - t0)
            out.append({"id": "c%03d" % (len(out) + 1), "kind": m["kind"], "t": m["t"], "t0": round(t0, 3), "t1": round(t1, 3),
                        "style": style, "cam": cam, "shots": shots, "zooms": zooms, "score": m["score"], "label": label,
                        "drop_rel": round(anchor - t0, 3) if m["kind"] == "drop" else None})
        rounds += 1
    out.sort(key=lambda c: (-c["score"], c["t0"]))
    for k, c in enumerate(out):
        c["n"] = k + 1
    return out


def _fmt(t):
    t = int(t)
    return "%d:%02d:%02d" % (t // 3600, t // 60 % 60, t % 60) if t >= 3600 else "%d:%02d" % (t // 60, t % 60)


def _covering(cam, t0, t1):
    """Morceaux de [t0, t1] couverts par une caméra : [(a, b, item)]."""
    out = []
    for it in cam["items"]:
        a, b = max(t0, it["t0"]), min(t1, it["t1"])
        if b - a > 0.04:
            out.append((a, b, it))
    return out


def _shots(tl, t0, t1, drop, bar, style, cam):
    """Plans du clip : (début, fin, caméra), en coupant sur les mesures pour le multicam."""
    cams = tl["cams"]
    if not cams:
        return []
    cuts = [t0]
    if style == "multicam":
        t = t0
        while t < t1 - 0.5:
            step = 2 * bar if (drop is not None and t < drop) else 4 * bar
            nxt = t + step
            if drop is not None and t < drop < nxt:
                nxt = drop  # on change de caméra pile sur le drop
            cuts.append(min(t1, nxt))
            t = nxt
    cuts.append(t1)
    cuts = sorted(set(round(c, 3) for c in cuts if t0 <= c <= t1))
    shots, k = [], 0
    for a, b in zip(cuts, cuts[1:]):
        if b - a < 0.2:
            continue
        want = (cam or 0) if style != "multicam" else k % len(cams)
        k += 1
        order = [want] + [j for j in range(len(cams)) if j != want]
        pos = a
        while pos < b - 0.04:  # si la caméra voulue n'a rien à cet endroit, on prend une autre
            seg = None
            for j in order:
                cov = [c for c in _covering(cams[j], pos, b) if c[0] <= pos + 0.04]
                if cov:
                    seg = (j, cov[0])
                    break
            if seg is None:
                nxt = min([c[0] for j in order for c in _covering(cams[j], pos, b)] or [b])
                if nxt <= pos + 0.04:
                    return []  # trou dans la timeline : clip abandonné
                return []
            j, (sa, sb, it) = seg
            shots.append([round(pos, 3), round(sb, 3), j])
            pos = sb
    return shots


# ====================================================================== rendu
class Tracker:
    """Recadrage automatique par morceaux de 10 s de rush (réutilisé entre les clips)."""

    def __init__(self, d):
        self.d = d
        self.cache = {}
        self.info = {}
        f = d / "tracking.json"
        try:
            self.cache = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
        except ValueError:
            self.cache = {}

    def save(self):
        try:
            (self.d / "tracking.json").write_text(json.dumps(self.cache), encoding="utf-8")
        except OSError:
            pass

    def probe(self, src):
        if src not in self.info:
            self.info[src] = media.probe(src)
        return self.info[src]

    def keys(self, src, s0, s1):
        """Positions du cadre (0-1) entre s0 et s1 (temps du rush), relatives à s0."""
        info = self.probe(src)
        if info["height"] >= info["width"]:
            return []
        out = []
        c0, c1 = int(s0 // 10), int(s1 // 10)
        for c in range(c0, c1 + 1):
            k = "%s|%d" % (src, c)
            if k not in self.cache:
                try:
                    r = autocrop.track(src, info, c * 10.0, min(info["duration"], c * 10.0 + 10.0))
                    self.cache[k] = r.get("keys") or []
                except Exception:
                    self.cache[k] = []
            for t, v in self.cache[k]:
                ta = c * 10.0 + float(t)
                if s0 - 0.5 <= ta <= s1 + 0.5:
                    out.append([round(ta - s0, 3), float(v)])
        out.sort()
        return out


def _zexpr(zooms, offset, length, drop_rel):
    """Zoom en expression ffmpeg de t (t = temps du plan, offset = début du plan dans le clip)."""
    T = "(t+%.3f)" % offset
    parts = ["1+0.05*%s/%.3f" % (T, max(1.0, length))]  # léger zoom avant continu
    for z in zooms:
        amp = 0.14 if (drop_rel is not None and abs(z - drop_rel) < 0.05) else 0.07
        parts.append("%.3f*if(gte(%s,%.3f),exp(-(%s-%.3f)/0.32),0)" % (amp, T, z, T, z))
    return "+".join(parts)


def render_clip(tl, d, clip, out_path, tracker, opts, job=None, on_progress=lambda f: None):
    length = clip["t1"] - clip["t0"]
    cmd = [media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-progress", "pipe:1", "-nostats"]
    graph, labels, n_in = "", [], 0
    for (a, b, j) in clip["shots"]:
        for (sa, sb, it) in _covering(tl["cams"][j], a, b):
            src_in = it["in"] + (sa - it["t0"])
            dur = sb - sa
            info = tracker.probe(it["src"])
            keys = tracker.keys(it["src"], src_in, src_in + dur) if opts.get("tracking", True) else []
            fx = edit.crop_fx_expr({"auto": True, "keys": keys}) if len(keys) >= 2 else \
                ("%.4f" % keys[0][1] if keys else "0.5")
            s0 = max(W / info["width"], H / info["height"])
            z = _zexpr(clip.get("zooms") or [], sa - clip["t0"], length, clip.get("drop_rel"))
            cmd += ["-ss", "%.3f" % max(0.0, src_in), "-t", "%.3f" % dur, "-i", it["src"]]
            graph += ("[%d:v:0]fps=30,setpts=PTS-STARTPTS,scale=w='trunc(iw*%.5f*(%s)/2)*2':h=-2:eval=frame,"
                      "crop=%d:%d:x='(iw-%d)*(%s)':y='(ih-%d)*0.5',setsar=1,format=yuv420p[v%d];"
                      % (n_in, s0, z, W, H, W, fx, H, n_in))
            labels.append("[v%d]" % n_in)
            n_in += 1
    if not labels:
        raise RuntimeError("Aucune image pour ce clip.")
    graph += "".join(labels) + "concat=n=%d:v=1:a=0[vc];[vc]trim=duration=%.3f,setpts=PTS-STARTPTS[v];" % (len(labels), length)
    cmd += ["-ss", "%.3f" % clip["t0"], "-t", "%.3f" % length, "-i", str(d / "mix.m4a")]
    graph += ("[%d:a:0]aresample=48000,afade=t=in:d=0.04,afade=t=out:st=%.3f:d=0.35%s[a]"
              % (n_in, max(0.0, length - 0.35), ",loudnorm=I=-14:TP=-1.5:LRA=11" if opts.get("loudnorm", True) else ""))
    cmd += ["-filter_complex", graph, "-map", "[v]", "-map", "[a]", "-t", "%.3f" % length] + render.video_encoder(opts) + \
        ["-r", "30", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", str(out_path)]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **NOWIN)
    if job is not None:
        job["proc"] = p
    for raw in p.stdout:
        line = raw.decode("utf-8", "replace")
        if line.startswith("out_time_us="):
            try:
                on_progress(min(1.0, int(line.split("=")[1]) / 1e6 / length))
            except ValueError:
                pass
    err = p.stderr.read()
    p.wait()
    if job is not None:
        job["proc"] = None
    if p.returncode != 0:
        if job is not None and job.get("cancel"):
            raise InterruptedError("Annulé.")
        raise RuntimeError("ffmpeg : " + err.decode("utf-8", "replace").strip()[-400:])


def thumb(video, out):
    try:
        subprocess.run([media.FFMPEG, "-y", "-loglevel", "error", "-ss", "1.2", "-i", str(video), "-frames:v", "1",
                        "-vf", "scale=270:-2", "-q:v", "4", str(out)], capture_output=True, timeout=60, **NOWIN)
    except Exception:
        pass


# ====================================================================== projets
def new_project(tl):
    lid = uuid.uuid4().hex[:8]
    d = LIVE / lid
    d.mkdir(parents=True, exist_ok=True)
    p = {"id": lid, "name": tl["name"], "created": time.time(), "timeline": tl, "analysis": None, "clips": [], "out_dir": None}
    save(lid, p)
    return lid


def pdir(lid):
    if not re.match(r"^[a-f0-9]{8}$", lid or ""):
        raise ValueError("Projet inconnu.")
    return LIVE / lid


def load(lid):
    return json.loads((pdir(lid) / "live.json").read_text(encoding="utf-8"))


def save(lid, p):
    f = pdir(lid) / "live.json"
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(p, ensure_ascii=False), encoding="utf-8")
    tmp.replace(f)


def summaries():
    out = []
    if not LIVE.exists():
        return out
    for d in LIVE.iterdir():
        try:
            p = json.loads((d / "live.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        tl = p["timeline"]
        out.append({"id": p["id"], "name": p["name"], "created": p.get("created", 0), "duration": tl["duration"], "cams": len(tl["cams"]),
                    "clips": sum(1 for c in p.get("clips") or [] if c.get("state") == "done"), "out_dir": p.get("out_dir"),
                    "thumb": next((c["n"] for c in p.get("clips") or [] if c.get("state") == "done"), None)})
    out.sort(key=lambda x: -x["created"])
    return out


def delete(lid):
    shutil.rmtree(pdir(lid), ignore_errors=True)
