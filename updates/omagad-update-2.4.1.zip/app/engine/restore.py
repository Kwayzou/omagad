"""Restauration poussée du son saturé (utilisée par SONAGAD).

Deux traitements, appliqués seulement à partir du moment où le son sature :
1. Reconstruction des crêtes : chaque passage « collé » au plafond (même étalé par la compression AAC d'un MP4)
   est remplacé par une courbe lisse (spline cubique d'Hermite) qui prolonge le signal autour.
2. Égaliseur d'appariement : la saturation ajoute du grésillement dans les aigus et écrase le bas.
   On compare le timbre de la partie saturée à celui du début propre du set et on corrige l'écart
   (lissé par tiers d'octave et borné, pour ne pas dénaturer la musique).
Tout est traité en flux, morceau par morceau : un set de plusieurs heures ne remplit pas la mémoire.
"""
import numpy as np

SR = 48000
NFIR = 4096                      # longueur du filtre (phase linéaire, retard NFIR/2)
LOOK = 8192                      # contexte de chaque côté pour la reconstruction des crêtes (2 trames)
FORCE = {"rapide": (1.5, 30, 0.6), "maximale": (1.5, 60, 0.8)}  # (dB sous le plafond, itérations, force de l'égaliseur)


# ---------- 1. Reconstruction des crêtes ----------
FRAME, HOP, STEP = 4096, 1024, 8


def declip(x, thr, iters=60, maxgain=4.0, batch=512):
    """Reconstruction parcimonieuse cohérente (famille SPADE / IHT), trames traitées en lot.
    Dans chaque trame qui contient des crêtes écrêtées, on cherche le signal le plus « simple » en fréquence
    qui garde à l'identique les échantillons sains et dépasse le plafond là où le son était collé.
    x : (n, canaux) float ; thr : plafond par canal."""
    out = np.empty_like(x)
    for c in range(x.shape[1]):
        out[:, c] = _declip1(x[:, c], float(thr[c]), iters, maxgain, batch)
    return out


def _declip1(x, thr, iters, maxgain, batch):
    N, hop = FRAME, HOP
    n = len(x)
    if not (np.abs(x) >= thr).any():
        return x.copy()
    xp = np.concatenate([np.zeros(N), x, np.zeros(2 * N)])
    m = np.abs(xp) >= thr
    starts = np.arange(0, len(xp) - N + 1, hop)
    w = np.hanning(N + 1)[:N]
    out = np.zeros_like(xp)
    norm = np.zeros_like(xp)
    cm = np.concatenate(([0], np.cumsum(m)))
    has = (cm[starts + N] - cm[starts]) > 0
    for st in starts[~has]:
        out[st:st + N] += xp[st:st + N] * w
        norm[st:st + N] += w
    sel = starts[has]
    ar = np.arange(N)
    for b0 in range(0, len(sel), batch):
        st = sel[b0:b0 + batch]
        ii = st[:, None] + ar[None, :]
        y = xp[ii]
        mm = m[ii]
        pos, neg, rel = mm & (y > 0), mm & (y < 0), ~mm
        xx = y.copy()
        hi, lo = np.maximum(y, thr * maxgain), np.minimum(y, -thr * maxgain)
        for it in range(iters):
            k = min(STEP * (it + 1), N)
            Z = np.fft.rfft(xx, 2 * N, axis=1)
            mag = np.abs(Z)
            kth = -np.partition(-mag, k - 1, axis=1)[:, k - 1:k]
            Z[mag < kth] = 0
            xh = np.fft.irfft(Z, 2 * N, axis=1)[:, :N]
            xx = np.where(rel, y, np.where(pos, np.clip(xh, y, hi), np.clip(xh, lo, y)))
        for j, s0 in enumerate(st):
            out[s0:s0 + N] += xx[j] * w
            norm[s0:s0 + N] += w
    res = np.where(norm > 1e-6, out / np.maximum(norm, 1e-9), xp)
    return res[N:N + n]


def clip_threshold(seg, below_db):
    """Plafond de la partie saturée (par canal), moins une marge pour attraper les crêtes étalées."""
    p = np.percentile(np.abs(seg), 99.5, axis=0)
    return p * 10 ** (-below_db / 20)


# ---------- 2. Égaliseur d'appariement ----------
def spectrum(x, n=8192):
    x = x.mean(axis=1)
    hop = n // 2
    w = np.hanning(n)
    frames = (len(x) - n) // hop
    if frames < 4:
        return None
    acc = np.zeros(n // 2 + 1)
    for i in range(0, frames, max(1, frames // 400)):               # au plus ~400 trames
        acc += np.abs(np.fft.rfft(x[i * hop:i * hop + n] * w)) ** 2
    return acc


def match_fir(clean, dirty, strength):
    """Filtre (phase linéaire) qui donne au son « dirty » le timbre moyen du son « clean »."""
    a, b = spectrum(clean), spectrum(dirty)
    if a is None or b is None:
        return None
    f = np.fft.rfftfreq(8192, 1 / SR)
    diff = 10 * np.log10((a + 1e-12) / (b + 1e-12))
    # lissage par tiers d'octave
    lf = np.log2(np.maximum(f, 1.0))
    sm = np.empty_like(diff)
    for i in range(len(f)):
        sel = np.abs(lf - lf[i]) <= 1 / 6
        sm[i] = diff[sel].mean()
    band = (f >= 200) & (f <= 4000)
    sm -= np.median(sm[band])                                      # forme seulement : le niveau est géré à part
    sm = np.clip(sm * strength, -10.0, 4.0)
    sm[(f < 30) | (f > 18000)] = 0.0
    sm = np.convolve(sm, np.ones(9) / 9, mode="same")
    fg = np.fft.rfftfreq(NFIR, 1 / SR)
    H = 10 ** (np.interp(fg, f, sm) / 20)
    h = np.roll(np.fft.irfft(H, n=NFIR), NFIR // 2) * np.hanning(NFIR)
    return h.astype(np.float64), {"freq": [float(x) for x in fg[::16]], "db": [round(float(x), 2) for x in np.interp(fg, f, sm)[::16]]}


# ---------- 3. Traitement en flux ----------
class Restorer:
    """Reçoit l'audio d'origine par morceaux (n, 2), rend l'audio restauré, même longueur au total."""

    def __init__(self, start, drop_db, fade, thr, fir, t_offset=0.0, iters=60):
        self.t0 = max(0.0, start - fade / 2)
        self.fade = max(0.5, fade)
        self.g = 10 ** (-abs(drop_db) / 20)
        self.thr = thr
        self.iters = iters
        self.fir = fir
        self.dc_from = max(0.0, start - 10)                       # reconstruction 10 s avant, par sécurité
        self.off = t_offset
        self.left = np.zeros((0, 2))                                # contexte déjà rendu (pour la spline)
        self.carry = np.zeros((0, 2))                               # anticipation pas encore rendue
        self.in_pos = 0                                             # échantillons d'origine sortis de l'étage 1
        self.d = NFIR // 2 if fir is not None else 0
        self.hw = np.zeros((NFIR - 1, 2)) if fir is not None else None   # historique de l'étage filtre (mouillé)
        self.hd = np.zeros((NFIR - 1, 2)) if fir is not None else None   # historique (sec)
        self.out_pos = -self.d                                      # temps (en échantillons) du prochain son rendu
        if fir is not None:
            self.Hk = {}

    def _stage1(self, chunk, final=False):
        buf = np.concatenate([self.left, self.carry, chunk])
        nl = len(self.left)
        end = len(buf) if final else max(nl, len(buf) - LOOK)
        raw = buf[nl:end]
        # temps absolu du premier échantillon de raw
        t_raw = self.in_pos / SR + self.off
        if len(raw) and t_raw + len(raw) / SR > self.dc_from:
            fixed = declip(buf, self.thr, self.iters)[nl:end]
            k = int(max(0, (self.dc_from - t_raw) * SR))
            if k:
                fixed[:k] = raw[:k]
        else:
            fixed = raw.copy()
        self.left = buf[max(0, end - LOOK):end]
        self.carry = buf[end:]
        self.in_pos += len(raw)
        return raw, fixed

    def _conv(self, hist, x):
        seg = np.concatenate([hist, x])
        n = len(seg)
        nf = 1 << int(np.ceil(np.log2(n + NFIR)))
        if nf not in self.Hk:
            self.Hk[nf] = np.fft.rfft(self.fir, nf)
        y = np.fft.irfft(np.fft.rfft(seg, nf, axis=0) * self.Hk[nf][:, None], nf, axis=0)[NFIR - 1:n]
        return y, seg[-(NFIR - 1):]

    def _weights(self, n):
        t = (self.out_pos + np.arange(n)) / SR + self.off
        return np.clip((t - self.t0) / self.fade, 0.0, 1.0)[:, None]

    def process(self, chunk, final=False):
        raw, fixed = self._stage1(chunk, final)
        if self.fir is not None:
            if final:  # vide le filtre
                raw = np.concatenate([raw, np.zeros((self.d, 2))])
                fixed = np.concatenate([fixed, np.zeros((self.d, 2))])
            wet, self.hw = self._conv(self.hw, fixed)
            seg = np.concatenate([self.hd, raw])
            dry = seg[NFIR - 1 - self.d:len(seg) - self.d]
            self.hd = seg[-(NFIR - 1):]
        else:
            wet, dry = fixed, raw
        w = self._weights(len(wet))
        out = (dry * (1 - w) + wet * w) * (1 + (self.g - 1) * w)
        skip = max(0, -self.out_pos)
        self.out_pos += len(out)
        return out[skip:]
