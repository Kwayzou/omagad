/* Accueil : choix du module (Clipagad, et un second module à venir). */
(function () {
  const { $ } = VC;
  VC.screens.home = function () {
    $('#view').innerHTML = '<div class="home">' +
      '<button type="button" class="mod mod-clip" id="modClip">' +
      '<span class="mod-glow"></span>' +
      '<img src="/ui/logo.png" alt="" class="mod-logo" width="132" height="132">' +
      '<span class="mod-name">CLIPAGAD</span>' +
      '<span class="mod-sub">Tes vlogs transformés en clips verticaux pour TikTok, Reels et Shorts</span>' +
      '<span class="btn primary big mod-go">Ouvrir</span></button>' +
      '<div class="mod mod-soon" aria-disabled="true">' +
      '<span class="mod-q"><svg viewBox="0 0 64 64" width="64" height="64"><path d="M23 24a9 9 0 1 1 13.5 7.8C33.6 33.5 32 35.4 32 39v2" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><circle cx="32" cy="50" r="3.4" fill="currentColor"/></svg></span>' +
      '<span class="mod-name">Coming soon…</span>' +
      '<span class="mod-sub">Un nouveau module arrive bientôt dans OMAGAD</span></div>' +
      '</div>';
    $('#modClip').onclick = () => { VC.sound('tick'); VC.go('import'); };
    VC._homeReady && VC._homeReady();
  };
})();
