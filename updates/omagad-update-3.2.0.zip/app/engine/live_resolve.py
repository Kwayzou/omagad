"""LIVEAGAD ↔ DaVinci Resolve.

- Récupérer : un script placé dans DaVinci (Espace de travail ▸ Scripts) exporte la timeline ouverte
  (et le nom des pistes : BOOTH, FOH, CROWD…) dans un dossier que LIVEAGAD surveille.
- Renvoyer : chaque clip devient une timeline verticale 1080×1920 dans DaVinci (mêmes rushes, mêmes coupes,
  cadrage et zoom appliqués), rangées dans un dossier du Media Pool, pour retoucher comme d'habitude.
"""
import re
import subprocess
import sys
from pathlib import Path
from xml.sax.saxutils import escape

from . import davinci
from .config import DATA
from .davinci import RESOLVE_SCRIPTS, _lua_str, _Rate, _url

INBOX = DATA / "davinci-inbox"
SEND_SCRIPT = "OMAGAD - Envoyer la timeline a LIVEAGAD.lua"
IMPORT_SCRIPT = "OMAGAD - Importer les clips LIVEAGAD.lua"


def send_script():
    INBOX.mkdir(parents=True, exist_ok=True)
    return """-- OMAGAD : envoie la timeline ouverte dans DaVinci vers LIVEAGAD (Espace de travail > Scripts)
local INBOX = %s
local resolve = nil
if Resolve then resolve = Resolve() end
if (not resolve) and bmd then resolve = bmd.scriptapp("Resolve") end
if not resolve then print("OMAGAD : DaVinci Resolve introuvable") return end
local project = resolve:GetProjectManager():GetCurrentProject()
local tl = project and project:GetCurrentTimeline()
if not tl then print("OMAGAD : ouvre d'abord la timeline de ta date") return end
local name = ((project:GetName() or "Projet") .. " - " .. (tl:GetName() or "Timeline")):gsub('[\\\\/:*?"<>|]', '-')
local base = INBOX .. "/" .. name
-- noms des pistes vidéo (BOOTH, FOH, CROWD…) : LIVEAGAD s'en sert pour deviner le rôle des caméras
local f = io.open(base .. ".pistes.txt", "w")
if f then
  for i = 1, (tl:GetTrackCount("video") or 0) do
    f:write(i .. "\\t" .. (tl:GetTrackName("video", i) or "") .. "\\t" .. tostring(tl:GetIsTrackEnabled("video", i)) .. "\\n")
  end
  f:close()
end
local ok = false
if resolve.EXPORT_FCP_7_XML then ok = tl:Export(base .. ".xml", resolve.EXPORT_FCP_7_XML, resolve.EXPORT_NONE or 0) end
if (not ok) and resolve.EXPORT_FCPXML_1_10 then ok = tl:Export(base .. ".fcpxml", resolve.EXPORT_FCPXML_1_10, resolve.EXPORT_NONE or 0) end
if (not ok) and resolve.EXPORT_FCPXML_1_9 then ok = tl:Export(base .. ".fcpxml", resolve.EXPORT_FCPXML_1_9, resolve.EXPORT_NONE or 0) end
if ok then print("OMAGAD : timeline envoyée à LIVEAGAD (" .. name .. ")") else print("OMAGAD : export impossible, exporte la timeline à la main (Fichier > Exporter > Timeline)") end
""" % _lua_str(str(INBOX))


def install_send_script():
    if sys.platform != "darwin":
        return False
    try:
        RESOLVE_SCRIPTS.mkdir(parents=True, exist_ok=True)
        (RESOLVE_SCRIPTS / SEND_SCRIPT).write_text(send_script(), encoding="utf-8")
        return True
    except OSError:
        return False


def run_in_resolve(script_text, name, wait=20):
    """Lance un script dans DaVinci déjà ouvert (scripting externe, DaVinci Studio réglé sur « Local »)."""
    fus = davinci.find_fuscript()
    if not fus:
        return None
    f = DATA / name
    f.write_text(script_text, encoding="utf-8")
    try:
        out = subprocess.run([fus, "-l", "lua", str(f)], capture_output=True, text=True, timeout=wait).stdout
    except Exception:
        return None
    return out


def inbox():
    """Timelines envoyées par DaVinci, en attente d'import."""
    INBOX.mkdir(parents=True, exist_ok=True)
    out = []
    for f in sorted(INBOX.iterdir(), key=lambda p: p.stat().st_mtime):
        if f.suffix.lower() in (".xml", ".fcpxml"):
            out.append(f)
    return out


def track_names(timeline_file):
    f = Path(str(timeline_file).rsplit(".", 1)[0] + ".pistes.txt")
    names = {}
    try:
        for line in f.read_text(encoding="utf-8").splitlines():
            parts = line.split("\t")
            if len(parts) >= 2 and parts[0].isdigit():
                names[int(parts[0])] = parts[1]
    except OSError:
        pass
    return names


def consume(f):
    """Range la timeline importée (pour ne pas l'importer deux fois)."""
    done = INBOX / "importees"
    done.mkdir(exist_ok=True)
    for p in (Path(f), Path(str(f).rsplit(".", 1)[0] + ".pistes.txt")):
        if p.exists():
            try:
                p.replace(done / p.name)
            except OSError:
                pass


# ---------------------------------------------------------------- renvoyer les clips dans DaVinci
def build_send_back(p, clips, out_root, tracker=None):
    """Un fichier XML par clip (timeline verticale) + un script qui les importe tous dans DaVinci."""
    tl = p["timeline"]
    R = _Rate(tl.get("fps") or 25)
    safe = re.sub(r'[\\/:*?"<>|]+', "-", p["name"]).strip() or "set"
    folder = Path(out_root).expanduser() / safe / "DaVinci"
    folder.mkdir(parents=True, exist_ok=True)
    W, H = 1080, 1920
    infos = {}

    def info(src):
        if src not in infos:
            try:
                infos[src] = tracker.probe(src) if tracker else davinci.media.probe(src)
            except Exception:
                infos[src] = {"width": 1920, "height": 1080, "duration": 36000}
        return infos[src]

    files, rows = {}, []
    for c in clips:
        fid_n = [0]
        done_files = set()

        def file_el(src):
            fid = files.setdefault(src, "f%d" % (len(files) + 1))
            if fid in done_files:
                return '<file id="%s"/>' % fid
            done_files.add(fid)
            inf = info(src)
            return ('<file id="%s"><name>%s</name><pathurl>%s</pathurl>%s<duration>%d</duration><media><video><samplecharacteristics>'
                    '<width>%d</width><height>%d</height></samplecharacteristics></video><audio><channelcount>2</channelcount></audio></media></file>'
                    % (fid, escape(Path(src).name), _url(src), R.xml(), R.f(inf.get("duration") or 36000), inf["width"], inf["height"]))
        v, a, frames, pos = [], [], [], 0
        from .live import _covering
        for (sa, sb, j) in c["shots"]:
            for (xa, xb, it) in _covering(tl["cams"][j], sa, sb):
                fin = R.f(it["in"] + (xa - it["t0"]))
                ln = R.f(xb - xa)
                if ln <= 0:
                    continue
                fid_n[0] += 1
                v.append('<clipitem id="v%d"><name>%s</name><enabled>TRUE</enabled>%s<start>%d</start><end>%d</end><in>%d</in><out>%d</out>%s</clipitem>'
                         % (fid_n[0], escape(Path(it["src"]).stem), R.xml(), pos, pos + ln, fin, fin + ln, file_el(it["src"])))
                inf = info(it["src"])
                fx = 0.5
                if tracker is not None and inf["width"] > inf["height"]:
                    ks = tracker.keys(it["src"], it["in"] + (xa - it["t0"]), it["in"] + (xb - it["t0"]))
                    if ks:
                        fx = sum(k[1] for k in ks) / len(ks)
                sw = inf["width"] * max(W / inf["width"], H / inf["height"])
                frames.append({"pan": round((sw - W) * (0.5 - fx), 1), "zoom": 1.0})
                pos += ln
        total = pos
        for it in tl["audio"]:
            xa, xb = max(c["t0"], it["t0"]), min(c["t1"], it["t1"])
            if xb - xa <= 0.04:
                continue
            fin, st = R.f(it["in"] + (xa - it["t0"])), R.f(xa - c["t0"])
            ln = min(R.f(xb - xa), total - st)
            if ln <= 0:
                continue
            fid_n[0] += 1
            a.append('<clipitem id="a%d"><name>%s</name><enabled>TRUE</enabled>%s<start>%d</start><end>%d</end><in>%d</in><out>%d</out>%s'
                     '<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack></clipitem>'
                     % (fid_n[0], escape(Path(it["src"]).stem), R.xml(), st, st + ln, fin, fin + ln, file_el(it["src"])))
        markers = ""
        if c.get("drop_rel") is not None:
            markers = '<marker><name>Drop</name><comment></comment><in>%d</in><out>-1</out></marker>' % R.f(c["drop_rel"])
        name = "%d - %s" % (c["n"], c["label"])
        fmt = ("<format><samplecharacteristics>%s<width>%d</width><height>%d</height><anamorphic>FALSE</anamorphic>"
               "<pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></format>" % (R.xml(), W, H))
        xml = ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="5"><sequence id="s%d"><name>%s</name><duration>%d</duration>%s'
               "<media><video>%s<track>%s</track></video><audio><numOutputChannels>2</numOutputChannels><track>%s</track></audio></media>%s</sequence></xmeml>\n"
               % (c["n"], escape(name), total, R.xml(), fmt, "".join(v), "".join(a), markers))
        f = folder / ("%03d.xml" % c["n"])
        f.write_text(xml, encoding="utf-8")
        rows.append((f, name, frames))
    script = import_script(p["name"], rows)
    (folder / IMPORT_SCRIPT).write_text(script, encoding="utf-8")
    installed = False
    if sys.platform == "darwin":
        try:
            RESOLVE_SCRIPTS.mkdir(parents=True, exist_ok=True)
            (RESOLVE_SCRIPTS / IMPORT_SCRIPT).write_text(script, encoding="utf-8")
            installed = True
        except OSError:
            pass
    return {"folder": str(folder), "count": len(rows), "installed": installed, "script": script}


def import_script(name, rows):
    items = ",\n".join("  { xml = %s, name = %s, frames = { %s } }" % (
        _lua_str(f), _lua_str(n), ", ".join("{pan=%s, zoom=%s}" % (fr["pan"], fr["zoom"]) for fr in frames)) for f, n, frames in rows)
    return """-- OMAGAD : importe les clips LIVEAGAD dans le projet ouvert (une timeline verticale par clip)
local FOLDER = %s
local CLIPS = {
%s
}
local resolve = nil
if Resolve then resolve = Resolve() end
if (not resolve) and bmd then resolve = bmd.scriptapp("Resolve") end
if not resolve then print("OMAGAD : DaVinci Resolve introuvable") return end
local project = resolve:GetProjectManager():GetCurrentProject()
if not project then print("OMAGAD : ouvre un projet d'abord") return end
local mp = project:GetMediaPool()
local root = mp:GetRootFolder()
local sub = mp:AddSubFolder(root, "LIVEAGAD - " .. FOLDER .. " " .. os.date("%%H.%%M"))
if sub then mp:SetCurrentFolder(sub) end
local n = 0
for _, c in ipairs(CLIPS) do
  local tl = mp:ImportTimelineFromFile(c.xml, { timelineName = c.name, importSourceClips = true })
  if tl then
    n = n + 1
    project:SetCurrentTimeline(tl)
    tl:SetSetting("useCustomSettings", "1")
    tl:SetSetting("timelineResolutionWidth", "1080")
    tl:SetSetting("timelineResolutionHeight", "1920")
    tl:SetSetting("timelineInputResMismatchBehavior", "scaleToFill")
    local items = tl:GetItemListInTrack("video", 1) or {}
    for i, it in ipairs(items) do
      local f = c.frames[i]
      if f then it:SetProperty("Pan", f.pan); it:SetProperty("ZoomX", f.zoom); it:SetProperty("ZoomY", f.zoom) end
    end
  end
end
resolve:OpenPage("edit")
print("OMAGAD : " .. n .. " clips LIVEAGAD importés (prête)")
""" % (_lua_str(name), items)
