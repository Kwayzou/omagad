/* Écran Export, façon page « Deliver » de DaVinci Resolve :
   réglages de rendu à gauche, visionneuse au centre, file de rendu à droite, clips en bas.
   + export de la timeline pour DaVinci Resolve (XML, SRT, sons) et ouverture automatique. */
(function () {
  const { $, $$, esc, fmt } = VC;
  const CHECK = '<svg viewBox="0 0 16 16"><path d="M3 8.5l3 3 7-7" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const ICO = {
    custom: '<svg viewBox="0 0 24 24"><path d="M4 7h10M18 7h2M4 17h4M12 17h8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="16" cy="7" r="2.2" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="10" cy="17" r="2.2" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
    tiktok: '<svg viewBox="0 0 24 24"><path d="M14 3v11.5a3.5 3.5 0 11-3.5-3.5M14 3c.5 2.6 2.4 4.4 5 4.6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    reels: '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4 9h16M9 4l2.5 5M14 4l2.5 5" stroke="currentColor" stroke-width="1.6"/><path d="M10.5 12.5v4l3.5-2z" fill="currentColor"/></svg>',
    shorts: '<svg viewBox="0 0 24 24"><path d="M15.5 3.8l-7 3.8a3.6 3.6 0 003.4 6.3l-1.3.7a3.6 3.6 0 103.4 6.3l7-3.8a3.6 3.6 0 00-3.4-6.3l1.3-.7a3.6 3.6 0 00-3.4-6.3z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M10.5 9.8v4.4l3.8-2.2z" fill="currentColor"/></svg>',
    draft: '<svg viewBox="0 0 24 24"><path d="M13 3L5 14h6l-1 7 8-11h-6z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    davinci: '<svg viewBox="0 0 24 24"><circle cx="12" cy="7.5" r="3.6" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="7.5" cy="15.5" r="3.6" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="16.5" cy="15.5" r="3.6" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>'
  };
  const PRESETS = [
    ['custom', 'Personnalisé', null],
    ['tiktok', 'TikTok', { resolution: 1080, quality: 'high', loudnorm: true }],
    ['reels', 'Reels', { resolution: 1080, quality: 'high', loudnorm: true }],
    ['shorts', 'Shorts', { resolution: 1080, quality: 'high', loudnorm: true }],
    ['draft', 'Aperçu rapide', { resolution: 720, quality: 'light', loudnorm: true }]
  ];
  let pick = null, results = {}, queue = [], running = null, focus = null, tab = 'video', preset = 'tiktok', dv = null;

  VC.screens.export = function () {
    const p = VC.S.project, s = VC.S.state.settings;
    if (!pick || pick.pid !== p.id) {
      const ok = p.moments.filter(m => m.status === 'ok');
      pick = { pid: p.id, ids: new Set((ok.length ? ok : p.moments.filter(m => m.status !== 'skip')).map(m => m.id)) };
      results = {}; queue = []; focus = null; dv = null;
    }
    if (!focus || !p.moments.find(m => m.id === focus)) focus = (p.moments.find(m => pick.ids.has(m.id)) || p.moments[0] || {}).id;
    $('#view').innerHTML = '<div class="deliver">' +
      // ---- Réglages de rendu
      '<section class="dv-panel dv-settings"><header class="dv-head"><h3>Réglages de rendu</h3></header>' +
      '<div class="dv-body"><div id="ffBox"></div>' +
      (p.source_missing ? '<div class="ff-warn"><b>Vidéo d\'origine introuvable</b><span class="hint">Elle a été déplacée ou renommée. Retrouve-la pour pouvoir exporter.</span><button class="btn small primary" type="button" id="btnRelink">Retrouver la vidéo</button></div>' : '') +
      '<div class="dv-presets" id="presets">' + PRESETS.map(x => '<button type="button" data-p="' + x[0] + '"><span class="pi">' + ICO[x[0]] + '</span><span>' + x[1] + '</span></button>').join('') + '</div>' +
      '<div class="dv-row"><span class="dv-l">Emplacement</span><div class="path"><input type="text" id="outDir" value="' + esc(s.out_dir) + '"><button class="btn small" type="button" id="btnDir">Parcourir</button></div></div>' +
      '<div class="dv-row"><label class="dv-l" for="prjName">Projet</label><input type="text" id="prjName" maxlength="80" value="' + esc(p.name) + '"></div>' +
      '<div class="dv-row"><span class="dv-l">Dossier</span><label class="check"><input type="checkbox" id="exFolder"' + (s.export_folder !== false ? ' checked' : '') + '> Créer un dossier au nom du projet</label></div>' +
      '<div class="dv-row"><label class="dv-l" for="exNaming">Noms</label><select id="exNaming"><option value="number">1, 2, 3…</option><option value="project">Projet 1, Projet 2…</option><option value="hook">1 - accroche…</option></select></div>' +
      '<div class="dv-path hint" id="exPath"></div>' +
      '<div class="dv-tabs" id="dvTabs"><button type="button" data-t="video">Vidéo</button><button type="button" data-t="audio">Audio</button><button type="button" data-t="file">Fichier</button></div>' +
      '<div class="dv-tab" data-t="video">' +
      '<div class="dv-row"><span class="dv-l">Format</span><span class="dv-v">MP4</span></div>' +
      '<div class="dv-row"><span class="dv-l">Codec</span><span class="dv-v">H.264</span></div>' +
      '<div class="dv-row"><label class="dv-l" for="enc">Encodeur</label><select id="enc"><option value="h264_videotoolbox">Puce du Mac (rapide)</option><option value="libx264">Processeur (compatible partout)</option></select></div>' +
      '<div class="dv-row"><span class="dv-l">Résolution</span><div class="seg" id="segRes"><button type="button" data-v="1080">1080 × 1920</button><button type="button" data-v="720">720 × 1280</button></div></div>' +
      '<div class="dv-row"><span class="dv-l">Images/s</span><span class="dv-v">30</span></div>' +
      '<div class="dv-row"><span class="dv-l">Qualité</span><div class="seg" id="segQ"><button type="button" data-v="high">Haute</button><button type="button" data-v="medium">Moyenne</button><button type="button" data-v="light">Légère</button></div></div></div>' +
      '<div class="dv-tab" data-t="audio">' +
      '<div class="dv-row"><span class="dv-l">Codec</span><span class="dv-v">AAC · 192 kb/s · 48 kHz</span></div>' +
      '<label class="check"><input type="checkbox" id="loud"> Volume normalisé pour les réseaux</label><span class="hint">−14 LUFS, le niveau attendu par TikTok, Instagram et YouTube.</span></div>' +
      '<div class="dv-tab" data-t="file">' +
      '<label class="check"><input type="checkbox" id="capTxt"> Enregistrer la description en .txt</label>' +
      '<button class="btn small" type="button" id="btnOpenDir">Ouvrir le dossier</button></div>' +
      '</div><footer class="dv-foot"><button class="btn" type="button" id="btnAddQueue">Ajouter à la file de rendu</button></footer></section>' +
      // ---- Visionneuse
      '<section class="dv-viewer"><header class="dv-head"><h3 id="vwTitle"></h3><span class="hint mono" id="vwTc"></span>' +
      '<label class="vw-name" title="Nom du fichier de ce clip"><span class="hint">Fichier</span><input type="text" id="vwName" maxlength="80"><span class="hint">.mp4</span></label></header>' +
      '<div class="dv-screen" id="vwScreen"></div>' +
      '<div class="dv-transport"><button class="icon-btn" type="button" id="vwPrev" title="Clip précédent"><svg viewBox="0 0 20 20"><path d="M12.5 5l-5 5 5 5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
      '<span class="hint" id="vwPos"></span><button class="icon-btn" type="button" id="vwNext" title="Clip suivant"><svg viewBox="0 0 20 20"><path d="M7.5 5l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div></section>' +
      // ---- File de rendu + DaVinci
      '<section class="dv-panel dv-queue"><header class="dv-head"><h3>File de rendu</h3><span class="hint" id="qCount"></span><button class="btn small ghost" type="button" id="btnClearQ">Vider</button></header>' +
      '<div class="dv-body" id="qList"></div>' +
      '<div class="dv-resolve"><div class="dv-resolve-head"><span class="pi">' + ICO.davinci + '</span><b>DaVinci Resolve</b></div>' +
      '<span class="hint">Les clips choisis en timeline verticale 1080 × 1920 : moments bout à bout, sons, médias, accroches en marqueurs et sous-titres en .srt.</span>' +
      '<div class="dv-resolve-btns"><button class="btn small" type="button" id="btnXml">Exporter la timeline (.xml)</button>' +
      '<button class="btn small primary" type="button" id="btnResolve">Ouvrir dans DaVinci</button></div><div class="hint" id="dvMsg"></div></div>' +
      '<footer class="dv-foot"><button class="btn primary big" type="button" id="btnExport">Tout rendre</button></footer></section>' +
      // ---- Clips
      '<section class="dv-strip"><header class="dv-head"><h3>Clips</h3>' +
      '<div class="seg small" id="selSeg"><button type="button" data-sel="ok">Validés</button><button type="button" data-sel="all">Tous</button><button type="button" data-sel="none">Aucun</button></div>' +
      '<span class="hint" id="sumTxt"></span></header><div class="dv-clips" id="exGrid"></div></section></div>';

    // réglages
    const seg = (id, key) => { const el = $('#' + id); const mark = () => $$('button', el).forEach(b => b.setAttribute('aria-pressed', String(String(VC.S.state.settings[key]) === b.dataset.v)));
      mark(); el.onclick = async e => { const b = e.target.closest('button'); if (!b) return; await VC.saveSettings({ [key]: key === 'resolution' ? +b.dataset.v : b.dataset.v }); preset = 'custom'; mark(); marks(); }; };
    seg('segRes', 'resolution'); seg('segQ', 'quality');
    $('#enc').value = s.encoder; $('#enc').onchange = e => VC.saveSettings({ encoder: e.target.value });
    $('#loud').checked = s.loudnorm; $('#loud').onchange = e => { preset = 'custom'; VC.saveSettings({ loudnorm: e.target.checked }).then(marks); };
    $('#capTxt').checked = s.captions_txt; $('#capTxt').onchange = e => VC.saveSettings({ captions_txt: e.target.checked });
    $('#outDir').onchange = e => VC.saveSettings({ out_dir: e.target.value.trim() });
    $('#btnDir').onclick = async () => {
      if (!VC.native()) return $('#outDir').focus();
      const d = await window.pywebview.api.pick_folder($('#outDir').value); if (d) { $('#outDir').value = d; VC.saveSettings({ out_dir: d }); }
    };
    $('#btnOpenDir').onclick = () => VC.api('/api/reveal', { path: $('#outDir').value }).catch(e => VC.toast(e.message));
    $('#presets').onclick = async e => {
      const b = e.target.closest('[data-p]'); if (!b) return;
      const pr = PRESETS.find(x => x[0] === b.dataset.p); preset = pr[0];
      if (pr[2]) { await VC.saveSettings(pr[2]); VC.screens.export(); } else marks();
    };
    $('#dvTabs').onclick = e => { const b = e.target.closest('[data-t]'); if (b) { tab = b.dataset.t; marks(); } };
    $('#btnAddQueue').onclick = addToQueue;
    $('#exNaming').value = s.export_naming || 'number';
    $('#exNaming').onchange = e => VC.saveSettings({ export_naming: e.target.value }).then(() => { pathHint(); renderViewer(); });
    $('#exFolder').onchange = e => VC.saveSettings({ export_folder: e.target.checked }).then(pathHint);
    $('#prjName').onchange = e => { const v = e.target.value.trim(); if (!v) { e.target.value = p.name; return; } p.name = v; $('#projName').textContent = v; VC.api('/api/save/' + p.id, { name: v }); pathHint(); renderViewer(); };
    $('#outDir').addEventListener('input', pathHint);
    $('#vwName').onchange = e => { const m = p.moments.find(x => x.id === focus); if (!m) return; m.export_name = e.target.value.trim().replace(/\.mp4$/i, '') || null; VC.commit(true); renderViewer(); renderClips(); };
    $('#vwName').onkeydown = e => { e.stopPropagation(); if (e.key === 'Enter') e.target.blur(); };
    pathHint();
    // file de rendu
    $('#btnExport').onclick = () => running ? cancel() : renderAll();
    $('#btnClearQ').onclick = () => { if (running) return; queue = queue.filter(j => j.state === 'run'); renderQueue(); };
    $('#qList').onclick = e => {
      const del = e.target.closest('[data-delq]'); if (del) { queue = queue.filter(j => j.id !== del.dataset.delq || j.state === 'run'); return renderQueue(); }
      const row = e.target.closest('[data-clip]'); if (row) { focus = row.dataset.clip; renderAllViews(); }
      const rv = e.target.closest('[data-reveal]'); if (rv) { e.stopPropagation(); VC.api('/api/reveal', { path: rv.dataset.reveal }); }
    };
    // DaVinci
    $('#btnXml').onclick = () => toResolve(false);
    $('#btnResolve').onclick = () => toResolve(true);
    // clips
    $('#selSeg').onclick = e => {
      const b = e.target.closest('[data-sel]'); if (!b) return; const k = b.dataset.sel;
      pick.ids = new Set(p.moments.filter(m => k === 'all' || (k === 'ok' && m.status === 'ok')).map(m => m.id)); renderClips();
    };
    $('#exGrid').onclick = e => {
      const c = e.target.closest('.dv-clip'); if (!c) return;
      if (e.target.closest('.ck')) { pick.ids.has(c.dataset.id) ? pick.ids.delete(c.dataset.id) : pick.ids.add(c.dataset.id); return renderClips(); }
      focus = c.dataset.id; renderAllViews();
    };
    $('#exGrid').ondblclick = e => { const c = e.target.closest('.dv-clip'); if (c) { pick.ids.has(c.dataset.id) ? pick.ids.delete(c.dataset.id) : pick.ids.add(c.dataset.id); renderClips(); } };
    $('#vwPrev').onclick = () => stepFocus(-1); $('#vwNext').onclick = () => stepFocus(1);
    const rl = $('#btnRelink'); if (rl) rl.onclick = async () => { if (await VC.relink(p.id)) VC.screens.export(); };
    ffBox(); marks(); renderAllViews();
  };

  function marks() {
    const s = VC.S.state.settings;
    if (preset !== 'custom') { const pr = PRESETS.find(x => x[0] === preset); if (pr && pr[2] && (s.resolution !== pr[2].resolution || s.quality !== pr[2].quality)) preset = 'custom'; }
    $$('#presets [data-p]').forEach(b => b.classList.toggle('on', b.dataset.p === preset));
    $$('#dvTabs [data-t]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.t === tab)));
    $$('.dv-tab').forEach(t => t.hidden = t.dataset.t !== tab);
  }
  /* Noms des fichiers : comme le serveur (clip_filename) */
  const safe = (x, fb) => (String(x || '').replace(/\n/g, ' ').replace(/[\\/:*?"<>|\x00-\x1f]+/g, '-').replace(/^[ .-]+|[ .-]+$/g, '').slice(0, 80)) || fb;
  VC.clipName = function (m) {
    const p = VC.S.project, sel = p.moments.filter(x => pick.ids.has(x.id)), i = sel.indexOf(m), n = VC.S.state.settings.export_naming || 'number';
    if ((m.export_name || '').trim()) return safe(m.export_name, 'clip');
    if (i < 0) return '';
    if (n === 'hook') return (i + 1) + ' - ' + safe(m.hook, 'clip');
    if (n === 'project') return safe(p.name, 'clip') + ' ' + (i + 1);
    return String(i + 1);
  };
  function pathHint() {
    const el = $('#exPath'); if (!el) return;
    const p = VC.S.project, s = VC.S.state.settings, dir = ($('#outDir').value || s.out_dir).replace(/\/$/, '');
    const first = p.moments.filter(x => pick.ids.has(x.id)).slice(0, 3).map(m => VC.clipName(m) + '.mp4');
    el.innerHTML = '<span>' + esc(dir.replace(/^\/Users\/[^/]+/, '~') + '/' + (s.export_folder !== false ? safe(p.name, 'vlog') + '/' : '')) + '</span><b>' + esc(first.join(', ') + (first.length ? '…' : '')) + '</b>';
  }
  function renderAllViews() { renderClips(); renderViewer(); renderQueue(); }
  function stepFocus(d) {
    const ms = VC.S.project.moments, i = ms.findIndex(m => m.id === focus);
    const n = ms[Math.max(0, Math.min(ms.length - 1, i + d))]; if (n) { focus = n.id; renderAllViews(); }
  }

  /* ffmpeg sans libass : proposer d'installer la version complète */
  function ffBox() {
    const st = VC.S.state, box = $('#ffBox'); if (!box) return;
    if (st.ffmpeg_ass) { box.innerHTML = ''; return; }
    box.innerHTML = '<div class="ff-warn"><b>Un composant manque pour l\'export</b>' +
      '<span class="hint">Le ffmpeg installé sur ton Mac est une version allégée qui ne sait pas incruster l\'accroche et les sous-titres. ' +
      'OMAGAD peut installer la version complète (ffmpeg-full) : 5 à 15 minutes, une seule fois.</span>' +
      (st.brew ? '<button class="btn primary" type="button" id="btnFF">Installer ffmpeg complet</button>'
        : '<span class="hint">Homebrew est introuvable. Dans le Terminal : <span class="mono">brew install ffmpeg-full</span></span>') +
      '<div id="ffProg" hidden><div class="bar-prog"><i id="ffBar"></i></div><div class="hint mono" id="ffMsg" style="margin-top:6px;word-break:break-all"></div></div>' +
      '<button class="btn small ghost" type="button" id="btnFFCheck">Déjà installé ? Vérifier</button></div>';
    const b = $('#btnFF');
    if (b) b.onclick = async () => {
      b.disabled = true; b.textContent = 'Installation en cours...'; $('#ffProg').hidden = false;
      try {
        const r = await VC.api('/api/install-ffmpeg', {});
        const j = await VC.poll(r.job, j => { $('#ffBar').style.width = Math.round(j.progress * 100) + '%'; $('#ffMsg').textContent = j.message || ''; });
        if (j.error) throw new Error(j.error);
        VC.S.state = await VC.api('/api/state'); VC.toast('ffmpeg complet installé : tu peux exporter.', 5000); ffBox(); renderQueue();
      } catch (e) { $('#ffMsg').textContent = e.message; b.disabled = false; b.textContent = 'Réessayer'; }
    };
    $('#btnFFCheck').onclick = async () => {
      const r = await VC.api('/api/ffmpeg-recheck', {}); VC.S.state = await VC.api('/api/state');
      VC.toast(r.libass ? 'ffmpeg complet trouvé : tu peux exporter.' : 'Toujours la version allégée de ffmpeg.'); ffBox(); renderQueue();
    };
  }

  /* ---------- Clips (bande du bas, comme la timeline de la page Deliver) ---------- */
  function renderClips() {
    const p = VC.S.project, grid = $('#exGrid'); if (!grid) return;
    let tc = 0;
    grid.innerHTML = p.moments.map((m, i) => {
      const on = pick.ids.has(m.id), r = results[m.id], st = m.status || 'todo', d = m.t1 - m.t0;
      const start = tc; if (on) tc += d;
      const stt = r ? (r.state === 'done' ? '<span class="cs ok">✓</span>' : r.state === 'error' ? '<span class="cs err">!</span>' : r.state === 'run' ? '<span class="cs run">' + Math.round((r.progress || 0) * 100) + '%</span>' : '') : '';
      return '<div class="dv-clip' + (on ? ' on' : '') + (m.id === focus ? ' focus' : '') + '" data-id="' + m.id + '" title="' + esc((m.hook || '').replace(/\n/g, ' ')) + '">' +
        '<div class="n mono">' + String(i + 1).padStart(2, '0') + '</div>' +
        '<div class="th" style="background-image:url(/thumb/' + p.id + '/' + m.id + '?t=' + (m.t0 + 1.5).toFixed(1) + ')"><span class="ck">' + CHECK + '</span>' + stt + '</div>' +
        '<div class="cm"><span class="cn" title="' + esc(on ? VC.clipName(m) + '.mp4' : '') + '">' + esc(on ? VC.clipName(m) : '—') + '</span><span class="mono">' + fmt(d) + '</span></div>' +
        '<span class="dot ' + st + '"></span></div>';
    }).join('') || '<div class="empty">Aucun moment.</div>';
    pathHint();
    const sel = p.moments.filter(m => pick.ids.has(m.id));
    $('#sumTxt').textContent = sel.length + ' clip' + (sel.length > 1 ? 's' : '') + ' · ' + fmt(sel.reduce((a, m) => a + m.t1 - m.t0, 0));
    $$('#selSeg [data-sel]').forEach(b => b.setAttribute('aria-pressed', 'false'));
    const f = $('.dv-clip.focus'); if (f) f.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }

  /* ---------- Visionneuse ---------- */
  function renderViewer() {
    const p = VC.S.project, m = p.moments.find(x => x.id === focus), scr = $('#vwScreen'); if (!scr) return;
    if (!m) { scr.innerHTML = '<div class="empty">Aucun moment.</div>'; return; }
    const i = p.moments.indexOf(m), r = results[m.id], st = VC.style(m);
    $('#vwTitle').textContent = (m.hook || 'Moment ' + (i + 1)).replace(/\n/g, ' ');
    const nm = $('#vwName'); if (nm && document.activeElement !== nm) { nm.value = (m.export_name || '').trim(); const keep = m.export_name; m.export_name = ''; nm.placeholder = VC.clipName(m) || '—'; m.export_name = keep; }
    $('#vwTc').textContent = fmt(m.t0) + ' → ' + fmt(m.t1) + ' · ' + fmt(m.t1 - m.t0);
    $('#vwPos').textContent = (i + 1) + ' / ' + p.moments.length;
    if (r && r.state === 'done' && r.file) {
      scr.innerHTML = '<div class="dv-phone"><video src="/file?path=' + encodeURIComponent(r.file) + '" controls playsinline></video></div>';
    } else {
      scr.innerHTML = '<div class="dv-phone" style="background-image:url(/thumb/' + p.id + '/' + m.id + '?t=' + (m.t0 + 1.5).toFixed(1) + ')">' +
        '<div class="hk" style="font-family:' + esc(VC.cssFont(st.hook_font)) + ';color:' + esc(st.hook_color) + '">' + esc(m.hook || '').replace(/\n/g, '<br>') + '</div>' +
        '<span class="dv-badge">' + (r ? (r.state === 'run' ? 'Rendu…' : r.state === 'error' ? 'Échec' : 'En attente') : 'Pas encore rendu') + '</span></div>';
    }
  }

  /* ---------- File de rendu ---------- */
  function addToQueue() {
    const p = VC.S.project, s = VC.S.state.settings, ids = p.moments.filter(m => pick.ids.has(m.id)).map(m => m.id);
    if (!ids.length) return VC.toast('Sélectionne au moins un clip en bas.');
    queue.push({ id: 'j' + Date.now(), n: queue.length + 1, ids, state: 'wait', preset: (PRESETS.find(x => x[0] === preset) || PRESETS[0])[1],
      opts: { out_dir: $('#outDir').value.trim() || s.out_dir, resolution: s.resolution, quality: s.quality, encoder: s.encoder, loudnorm: s.loudnorm, captions_txt: s.captions_txt } });
    renderQueue(); VC.toast(ids.length + ' clip(s) ajouté(s) à la file de rendu', 1800);
  }
  function renderQueue() {
    const list = $('#qList'); if (!list) return;
    const p = VC.S.project, byId = Object.fromEntries(p.moments.map((m, i) => [m.id, [m, i]]));
    list.innerHTML = queue.length ? queue.map(j => {
      const done = j.ids.filter(id => results[id] && results[id].state === 'done').length;
      const prog = j.state === 'done' ? 1 : j.state === 'run' ? j.ids.reduce((a, id) => a + ((results[id] || {}).progress || 0), 0) / j.ids.length : 0;
      return '<div class="dv-job ' + j.state + '"><div class="jh"><b>Tâche ' + j.n + '</b><span class="hint">' + esc(j.preset) + '</span>' +
        (j.state !== 'run' ? '<button class="x" type="button" data-delq="' + j.id + '" title="Retirer">×</button>' : '') + '</div>' +
        '<div class="hint">' + j.ids.length + ' clip' + (j.ids.length > 1 ? 's' : '') + ' · ' + j.opts.resolution + 'p · H.264 · ' + esc(j.opts.out_dir.split('/').pop() || j.opts.out_dir) + '</div>' +
        '<div class="bar-prog"><i style="width:' + Math.round(prog * 100) + '%"></i></div>' +
        '<div class="jstate hint">' + ({ wait: 'En attente', run: 'Rendu… ' + done + ' / ' + j.ids.length, done: 'Terminé · ' + done + ' / ' + j.ids.length, cancel: 'Annulé', error: 'Échec' }[j.state] || '') + '</div>' +
        (j.state !== 'wait' ? '<div class="jclips">' + j.ids.map(id => { const r = results[id] || {}, mi = byId[id]; if (!mi) return '';
          return '<div class="jc" data-clip="' + id + '"><span class="mono">' + String(mi[1] + 1).padStart(2, '0') + '</span><span class="t">' + esc((mi[0].hook || '').replace(/\n/g, ' ')) + '</span>' +
            (r.state === 'done' ? '<button type="button" class="lk" data-reveal="' + esc(r.file) + '">Finder</button>' : r.state === 'error' ? '<span class="err" title="' + esc(r.error || '') + '">Échec</span>' : r.state === 'run' ? '<span class="mono hint">' + Math.round((r.progress || 0) * 100) + '%</span>' : '') + '</div>'; }).join('') + '</div>' : '') +
        '</div>';
    }).join('') : '<div class="dv-empty"><b>Aucune tâche</b><span class="hint">Choisis tes clips en bas, puis « Ajouter à la file de rendu ». « Tout rendre » ajoute la sélection automatiquement.</span></div>';
    const waiting = queue.filter(j => j.state === 'wait').length;
    $('#qCount').textContent = queue.length ? queue.length + ' tâche' + (queue.length > 1 ? 's' : '') : '';
    const b = $('#btnExport');
    b.textContent = running ? 'Arrêter le rendu' : waiting ? 'Tout rendre (' + waiting + ')' : 'Tout rendre';
    b.classList.toggle('primary', !running); b.classList.toggle('danger', !!running);
    b.disabled = !running && (!VC.S.state.ffmpeg || !VC.S.state.ffmpeg_ass || (!waiting && !pick.ids.size));
  }
  async function renderAll() {
    if (!queue.some(j => j.state === 'wait')) addToQueue();
    VC.commit(true);
    for (const j of queue) {
      if (j.state !== 'wait') continue;
      j.state = 'run'; j.ids.forEach(id => { results[id] = { state: 'wait', progress: 0 }; });
      renderAllViews();
      try {
        const r = await VC.api('/api/export', { pid: VC.S.project.id, ids: j.ids, opts: j.opts });
        running = r.job; renderQueue();
        const res = await VC.poll(running, x => { x.items.forEach(it => { results[it.id] = Object.assign(results[it.id] || {}, it); }); if ($('#qList')) { renderQueue(); renderClips(); } });
        res.items.forEach(it => { results[it.id] = Object.assign(results[it.id] || {}, it); });
        const ok = res.items.filter(i => i.state === 'done').length;
        j.state = res.cancel || /annul/i.test(res.message || '') ? 'cancel' : ok ? 'done' : 'error';
        if (res.error) VC.toast(res.error, 6000);
      } catch (e) { j.state = 'error'; VC.toast(e.message, 6000); }
      running = null;
      if ($('#qList')) renderAllViews();
      if (j.state === 'cancel') break;
    }
    const done = Object.values(results).filter(r => r.state === 'done').length;
    if (done) VC.toast(done + ' clip(s) exporté(s)', 4000);
  }
  async function cancel() { if (running) await VC.api('/api/cancel/' + running, {}); }

  /* ---------- DaVinci Resolve ---------- */
  async function toResolve(open) {
    const p = VC.S.project, ids = p.moments.filter(m => pick.ids.has(m.id)).map(m => m.id), msg = $('#dvMsg');
    if (!ids.length) return VC.toast('Sélectionne au moins un clip en bas.');
    if (open && !VC.S.state.davinci) return VC.toast('DaVinci Resolve n\'est pas installé sur ce Mac. Utilise « Exporter la timeline (.xml) ».', 6000);
    VC.commit(true);
    const bx = $('#btnXml'), br = $('#btnResolve'); bx.disabled = br.disabled = true;
    msg.textContent = open ? 'Ouverture de DaVinci Resolve…' : 'Création de la timeline…';
    try {
      const r = await VC.api('/api/davinci', { pid: p.id, ids, open, out_dir: $('#outDir').value.trim() });
      const j = await VC.poll(r.job, x => { if (x.message && $('#dvMsg')) $('#dvMsg').textContent = x.message; });
      if (j.error) throw new Error(j.error);
      dv = j.result;
      if (!$('#dvMsg')) return;
      if (!open) {
        msg.innerHTML = 'Timeline créée : ' + dv.clips + ' clips. <button type="button" class="lk" id="dvReveal">Afficher dans le Finder</button>';
        VC.toast('Timeline DaVinci prête', 2500);
      } else if (dv.auto) {
        msg.textContent = 'La timeline est ouverte dans DaVinci Resolve.'; VC.toast('Timeline ouverte dans DaVinci', 3000);
      } else {
        msg.innerHTML = '<b>DaVinci est ouvert.</b> Ouvre (ou crée) un projet, puis menu <b>Espace de travail ▸ Scripts ▸ OMAGAD - Importer la timeline</b> : la timeline se monte toute seule.' +
          ' <button type="button" class="lk" id="dvReveal">Fichiers</button>';
      }
      const rv = $('#dvReveal'); if (rv) rv.onclick = () => VC.api('/api/reveal', { path: dv.xml });
    } catch (e) { if ($('#dvMsg')) msg.textContent = e.message; }
    if ($('#btnXml')) { bx.disabled = br.disabled = false; }
  }
})();
