/* Écran Montage : liste des moments, aperçu 9:16, transport. L'inspecteur et la timeline sont dans leurs fichiers. */
(function () {
  const { $, $$, esc, fmt, clamp } = VC;
  const ICON = {
    play: '<svg viewBox="0 0 20 20"><path d="M6 4l11 6-11 6z" fill="currentColor"/></svg>',
    pause: '<svg viewBox="0 0 20 20"><path d="M5 4h3.5v12H5zM11.5 4H15v12h-3.5z" fill="currentColor"/></svg>',
    prev: '<svg viewBox="0 0 20 20"><path d="M5 4v12M16 4L8 10l8 6z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    next: '<svg viewBox="0 0 20 20"><path d="M15 4v12M4 4l8 6-8 6z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    replay: '<svg viewBox="0 0 20 20"><path d="M4 10a6 6 0 106-6H7M7 1L4 4l3 3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    safe: '<svg viewBox="0 0 20 20"><rect x="5" y="2" width="10" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M5 5h10M5 14h10" stroke="currentColor" stroke-width="1.6"/></svg>'
  };
  let raf = 0, lastSub = null, lastHook = null, bgCtx = null, showSafe = false;

  VC.cur = () => (VC.S.project && VC.S.project.moments.find(m => m.id === VC.S.sel)) || null;
  VC.vid = () => $('#pv');

  VC.screens.montage = function () {
    const p = VC.S.project;
    if (!p.moments.find(m => m.id === VC.S.sel)) VC.S.sel = (p.moments.find(m => m.status === 'todo') || p.moments[0] || {}).id || null;
    const COLL = '<svg viewBox="0 0 20 20" width="15" height="15"><path d="M12 5l-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    $('#view').innerHTML = '<div class="montage"><div class="workspace">' +
      '<aside class="side"><button class="rail" type="button" data-rail="left" title="Afficher les moments"><span>Moments</span></button>' +
      '<div class="side-head"><div class="top"><span class="title">Moments</span><span class="hint" id="revCount"></span><button class="icon-btn small" type="button" data-collapse="left" title="Réduire">' + COLL + '</button></div>' +
      '<div class="review-prog"><div class="bar-prog"><i id="revBar"></i></div></div>' +
      '<div class="seg" id="filter"><button type="button" data-f="all">Tous</button><button type="button" data-f="todo">À vérifier</button><button type="button" data-f="ok">Validés</button></div></div>' +
      '<div class="mlist" id="mlist"></div>' +
      '<div class="side-foot"><button class="btn small" type="button" id="btnAdd" title="Créer un moment à la position de lecture (A)">+ Moment ici</button><button class="btn small ghost" type="button" id="btnRedetect">Rechercher à nouveau</button></div></aside>' +
      '<div class="split v" data-split="left" title="Glisser pour redimensionner, double-clic pour réduire"></div>' +
      '<section class="stage"><div class="phone-wrap" id="phoneWrap"><div class="phone" id="phone"><canvas class="bg" id="bg" width="36" height="64"></canvas>' +
      '<video id="pv" playsinline preload="auto" src="/media/' + p.id + '/preview"></video>' +
      '<div class="ov-media" id="ovMedia"></div><div class="ov" id="ovSub"></div><div class="ov" id="ovHook"></div><div class="safe" id="safe" hidden><i class="t"></i><i class="b"></i><i class="r"></i></div></div></div>' +
      '<div class="transport"><div class="row"><span class="time" id="tRead">0:00.0 / 0:00.0</span><span class="spacer"></span>' +
      '<button class="icon-btn" type="button" id="btnPrev" title="Moment précédent (↑)">' + ICON.prev + '</button>' +
      '<button class="icon-btn play" type="button" id="btnPlay" title="Lecture (Espace)">' + ICON.play + '</button>' +
      '<button class="icon-btn" type="button" id="btnNext" title="Moment suivant (↓)">' + ICON.next + '</button><span class="spacer"></span>' +
      '<button class="icon-btn" type="button" id="btnReplay" title="Revoir depuis le début">' + ICON.replay + '</button>' +
      '<button class="icon-btn" type="button" id="btnSafe" title="Zones cachées par TikTok">' + ICON.safe + '</button></div>' +
      '<input type="range" id="scrub" min="0" max="1000" value="0" aria-label="Position dans le moment">' +
      '<div class="verdict"><button class="btn ok" type="button" id="btnOk">✓ Valider <span class="hint mono">V</span></button><button class="btn" type="button" id="btnSkip">Écarter <span class="hint mono">X</span></button></div></div></section>' +
      '<div class="split v" data-split="right" title="Glisser pour redimensionner, double-clic pour réduire"></div>' +
      '<aside class="inspector" id="inspector"></aside></div>' +
      '<div class="split h" data-split="tl" title="Glisser pour agrandir la timeline"></div>' +
      '<section class="dock" id="dock"></section></div>';
    bgCtx = $('#bg').getContext('2d');
    const v = VC.vid();
    v.addEventListener('loadedmetadata', layoutVideo); VC.onVideoReady(v);
    v.addEventListener('loadedmetadata', () => { const want = +(VC.S.project.info || {}).duration || 0; if (want && v.duration && isFinite(v.duration) && v.duration < want - 2) fixPreview(); });
    fetch('/api/preview-status/' + p.id).then(r => r.json()).then(r => { if (!r.ok) fixPreview(); }).catch(() => {});
    v.addEventListener('play', () => { const b = $('#btnPlay'); if (b) b.innerHTML = ICON.pause; });
    v.addEventListener('pause', () => { const b = $('#btnPlay'); if (b) b.innerHTML = ICON.play; VC.stopMusic && VC.stopMusic(); });
    new ResizeObserver(layoutVideo).observe($('#phone'));
    $('#btnPlay').onclick = togglePlay;
    $('#btnPrev').onclick = () => step(-1);
    $('#btnNext').onclick = () => step(1);
    $('#btnReplay').onclick = () => { const m = VC.cur(); if (m) VC.seek(m.t0, true); };
    $('#btnSafe').onclick = () => { showSafe = !showSafe; $('#safe').hidden = !showSafe; $('#btnSafe').style.color = showSafe ? 'var(--cyan)' : ''; };
    $('#scrub').oninput = e => { const m = VC.cur(); VC.cancelSeek(); if (m) v.currentTime = m.t0 + e.target.value / 1000 * (m.t1 - m.t0); };
    $('#btnOk').onclick = () => verdict('ok');
    $('#btnSkip').onclick = () => verdict('skip');
    $('#btnAdd').onclick = addHere;
    $('#btnRedetect').onclick = () => VC.redetect();
    $('#filter').onclick = e => { const b = e.target.closest('[data-f]'); if (b) { VC.S.filter = b.dataset.f; renderList(); } };
    $('#mlist').onclick = e => { const c = e.target.closest('.mcard'); if (c) VC.select(c.dataset.id, true); };
    VC.buildTimeline($('#dock'));
    VC.initSplitters($('.montage'));
    $('.side').addEventListener('click', e => { if (e.target.closest('[data-collapse="left"], [data-rail="left"]')) VC.toggleSide('left'); });
    VC.refresh = () => { if (!VC.cur()) VC.S.sel = (p.moments[0] || {}).id || null; renderList(); VC.renderInspector(); VC.drawTimeline(); applyMoment(false); };
    renderList(); VC.renderInspector(); VC.select(VC.S.sel, false);
    cancelAnimationFrame(raf); raf = requestAnimationFrame(tick);
  };
  VC.leaveMontage = function () { cancelAnimationFrame(raf); raf = 0; const v = VC.vid(); if (v) v.pause(); VC.onKey = null; };

  /* ---------- Liste ---------- */
  function renderList() {
    const p = VC.S.project, box = $('#mlist'); if (!box) return;
    const f = VC.S.filter, list = p.moments.filter(m => f === 'all' || m.status === f || (f === 'todo' && !m.status));
    $$('#filter button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.f === f)));
    const ok = p.moments.filter(m => m.status === 'ok').length, done = p.moments.filter(m => m.status && m.status !== 'todo').length;
    $('#revCount').textContent = ok + ' validés / ' + p.moments.length;
    $('#revBar').style.width = (p.moments.length ? done / p.moments.length * 100 : 0) + '%';
    box.innerHTML = list.length ? list.map(m => {
      const st = m.status || 'todo', lab = { todo: 'À vérifier', ok: 'Validé', skip: 'Écarté' }[st];
      return '<div class="mcard' + (m.id === VC.S.sel ? ' sel' : '') + (st === 'skip' ? ' skip' : '') + '" data-id="' + m.id + '">' +
        '<div class="th" style="background-image:url(/thumb/' + p.id + '/' + m.id + '?t=' + (m.t0 + 1.5).toFixed(1) + ')"></div>' +
        '<div class="body"><div class="hk">' + esc(m.hook || '(sans accroche)') + '</div><div class="tm">' + fmt(m.t0) + ' → ' + fmt(m.t1) + ' · ' + Math.round(m.t1 - m.t0) + ' s</div>' +
        '<div class="row"><span class="badge ' + st + '">' + lab + '</span>' + (m.score ? '<span class="badge">' + m.score + '/10</span>' : '') + '</div></div></div>';
    }).join('') : '<div class="empty">' + (p.moments.length ? 'Aucun moment dans ce filtre.' : 'Aucun moment. Place la lecture sur la timeline et clique sur « + Moment ici ».') + '</div>';
    const m = VC.cur();
    $('#btnOk').classList.toggle('on', !!m && m.status === 'ok'); $('#btnOk').disabled = $('#btnSkip').disabled = !m;
  }
  VC.renderList = renderList;

  /* Aperçu incomplet (ex. app fermée pendant sa création) : on le refait, sans perdre le montage */
  let fixing = false;
  async function fixPreview() {
    if (fixing) return; fixing = true;
    const pid = VC.S.project.id;
    let bar = document.getElementById('pvFix');
    if (!bar) { bar = document.createElement('div'); bar.id = 'pvFix'; bar.className = 'pv-fix'; const st = $('.stage'); if (st) st.prepend(bar); }
    const paint = f => { bar.innerHTML = '<b>' + esc(VC.t('Aperçu incomplet : reconstruction en cours')) + '</b><span class="hint">' + esc(VC.t('La vidéo d\'aperçu s\'arrêtait avant la fin du vlog. Tu peux continuer, la lecture complète revient dans un instant.')) + '</span><div class="bar-prog"><i style="width:' + Math.round(f * 100) + '%"></i></div>'; };
    paint(0);
    try {
      const r = await VC.api('/api/preview-fix/' + pid, {});
      const j = await VC.poll(r.job, x => paint(x.progress || 0));
      if (j.error) throw new Error(j.error);
      const v = VC.vid();
      if (v && VC.S.project && VC.S.project.id === pid) { const t = v.currentTime; v.src = '/media/' + pid + '/preview?v=' + Date.now(); v.load(); VC.seek(t); }
      bar.remove(); VC.toast(VC.t('Aperçu réparé : tout le vlog est lisible'), 3000);
    } catch (e) { bar.innerHTML = '<b>' + esc(e.message) + '</b>'; }
    fixing = false;
  }

  /* Déplacement fiable de la lecture : WebKit ignore parfois un saut (vidéo pas encore prête,
     saut pendant un autre saut…). On vérifie qu'il a bien eu lieu et on recommence sinon. */
  let seekWant = null, seekTries = 0, seekTimer = 0;
  VC.seek = function (t, play) {
    const v = VC.vid(); if (!v) return;
    seekWant = Math.max(0, t); seekTries = 0; clearTimeout(seekTimer);
    const go = () => { if (seekWant != null && v.readyState >= 1) { try { v.currentTime = seekWant; } catch (e) { /* réessayé plus bas */ } } };
    const verify = () => {
      if (seekWant == null || VC.vid() !== v) return;
      if (v.readyState >= 1 && !v.seeking && Math.abs(v.currentTime - seekWant) < .35) { seekWant = null; return; }
      if (++seekTries > 60) { seekWant = null; return; }
      if (!v.seeking) go();
      seekTimer = setTimeout(verify, 150);
    };
    go(); seekTimer = setTimeout(verify, 120);
    VC.resetSfx && VC.resetSfx();
    if (play) v.play().catch(() => {});
  };
  VC.seekPending = () => seekWant != null;
  VC.cancelSeek = () => { seekWant = null; clearTimeout(seekTimer); };
  VC.onVideoReady = v => v.addEventListener('loadedmetadata', () => { if (seekWant != null) { try { v.currentTime = seekWant; } catch (e) {} } });

  VC.select = function (id, play, at) {
    if (!$('#phone')) return;
    VC.S.sel = id; VC.S.item = null; lastHook = lastSub = null;
    const om = $('#ovMedia'); if (om) { om.innerHTML = ''; for (const k in mediaEls) delete mediaEls[k]; }
    renderList(); VC.renderInspector(); VC.drawTimeline(); applyMoment(true);
    const m = VC.cur(), v = VC.vid();
    VC.S.free = false;
    if (m && v) { VC.seek(at != null ? at : m.t0, play); if (at == null && VC.revealInTimeline) VC.revealInTimeline(m); }
    const c = $('.mcard.sel'); if (c) c.scrollIntoView({ block: 'nearest' });
  };
  function step(d) {
    const ms = VC.S.project.moments, i = ms.findIndex(m => m.id === VC.S.sel);
    const n = ms[clamp(i + d, 0, ms.length - 1)]; if (n) VC.select(n.id, true);
  }
  function verdict(st) {
    const m = VC.cur(); if (!m) return;
    m.status = m.status === st ? 'todo' : st; VC.commit(true); renderList(); VC.drawTimeline();
    if (m.status !== 'todo') {
      const next = VC.S.project.moments.find(x => (x.status || 'todo') === 'todo');
      if (next) setTimeout(() => VC.select(next.id, true), 250); else VC.toast('Tous les moments sont vérifiés. Passe à l\'export !');
    }
  }
  function addHere() {
    const p = VC.S.project, v = VC.vid(), t = v.currentTime || 0;
    const n = Math.max(0, ...p.moments.map(m => parseInt(String(m.id).slice(1), 10) || 0)) + 1;
    const m = { id: 'm' + n, t0: Math.round(t * 10) / 10, t1: Math.round(Math.min(p.info.duration, t + 30) * 10) / 10, score: 0, hook: '', emphasis: '', reason: '',
      caption: '', status: 'todo', export: true, source: 'manual', subs: null, style: VC.clone(VC.S.state.settings.style), frame: { mode: 'fill', fx: .5, fy: .5, zoom: 1, punch: true } };
    p.moments.push(m); p.moments.sort((a, b) => a.t0 - b.t0); VC.commit(true);
    VC.S.filter = 'all'; VC.select(m.id, false); VC.toast('Moment ajouté : écris son accroche à droite.');
  }
  VC.addHere = addHere;
  function togglePlay() {
    const v = VC.vid(), m = VC.cur(); if (!v) return;
    if (v.paused) { if (m && !VC.S.free && !VC.seekPending() && (v.currentTime < m.t0 - .05 || v.currentTime >= m.t1 - .05)) VC.seek(m.t0); v.play().catch(() => {}); } else v.pause();
  }
  VC.togglePlay = togglePlay;
  VC.stepMoment = step;
  VC.verdict = verdict;
  VC.setInOut = function (which) {
    const v = VC.vid(), m = VC.cur(); if (!m || !v) return;
    if (which === 'in') m.t0 = Math.round(clamp(v.currentTime, 0, m.t1 - 3) * 100) / 100; else m.t1 = Math.round(clamp(v.currentTime, m.t0 + 3, VC.S.project.info.duration) * 100) / 100;
    VC.commit(); VC.refresh();
  };
  function onKey(e) {
    const v = VC.vid(), m = VC.cur();
    if (e.key === ' ') { e.preventDefault(); togglePlay(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); step(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); step(-1); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); v.currentTime += e.shiftKey ? 5 : 1; }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); v.currentTime -= e.shiftKey ? 5 : 1; }
    else if (e.key === 'v' || e.key === 'V') verdict('ok');
    else if (e.key === 'x' || e.key === 'X') verdict('skip');
    else if (e.key === 'a' || e.key === 'A') addHere();
    else if ((e.key === 'i' || e.key === 'I') && m) { m.t0 = Math.round(clamp(v.currentTime, 0, m.t1 - 3) * 10) / 10; if (!m.subs) lastSub = null; VC.commit(); VC.refresh(); }
    else if ((e.key === 'o' || e.key === 'O') && m) { m.t1 = Math.round(clamp(v.currentTime, m.t0 + 3, VC.S.project.info.duration) * 10) / 10; VC.commit(); VC.refresh(); }
    else if (e.key === '+' || e.key === '=') VC.zoomTimeline(1 / 1.5);
    else if (e.key === '-') VC.zoomTimeline(1.5);
    else if ((e.key === 'Delete' || e.key === 'Backspace') && VC.S.item) { e.preventDefault(); VC.deleteItem(); }
  }

  /* ---------- Aperçu ---------- */
  function layoutVideo() {
    const v = VC.vid(), ph = $('#phone'), m = VC.cur(); if (!v || !ph || !v.videoWidth) return;
    const cw = ph.clientWidth, ch = ph.clientHeight, vw = v.videoWidth, vh = v.videoHeight, fr = (m && m.frame) || {};
    const rel = m ? (v.currentTime || 0) - m.t0 : 0, z = (fr.zoom || 1) * (m ? VC.zoomAt(m, rel) : 1);
    let w, h, x, y;
    if (fr.mode === 'blur') { w = cw * (fr.zoom || 1); h = w * vh / vw; x = (cw - w) / 2; y = (ch - h) / 2; }
    else { const s = Math.max(cw / vw, ch / vh) * z; w = vw * s; h = vh * s; x = -(w - cw) * VC.fxAt(m, rel); y = -(h - ch) * (fr.fy == null ? .5 : fr.fy); }
    v.style.width = w + 'px'; v.style.height = h + 'px'; v.style.left = x + 'px'; v.style.top = y + 'px';
    $('#bg').hidden = fr.mode !== 'blur';
  }
  VC.layoutVideo = layoutVideo;
  const px = n => (n / 1080 * 100).toFixed(3) + 'cqw';
  /* Lueur intérieure : filtre SVG (comme le rendu final) ; lueur extérieure : ombres floues */
  function setGlowFilter(kind, st, k) {
    const f = document.getElementById('fx-' + kind); if (!f) return false;
    const on = st[k + 'glow'] && !st[k + 'box'] && (st[k + 'glow_mode'] === 'in' || st[k + 'glow_mode'] === 'both');
    if (!on) return false;
    const ph = $('#phone'), scale = ph ? ph.clientWidth / 1080 : .33;
    f.querySelector('feGaussianBlur').setAttribute('stdDeviation', Math.max(.5, +st[k + 'glow_size'] * .45 * scale));
    f.querySelector('feFlood').setAttribute('flood-color', st[k + 'glow_color']);
    f.querySelector('feFlood').setAttribute('flood-opacity', Math.min(1, +st[k + 'glow_opacity']));
    return true;
  }
  function styleOv(el, kind, st) {
    const k = kind === 'hook' ? 'hook_' : 'sub_';
    const box = st[k + 'box'];
    el.className = 'ov' + (box ? ' boxed' : '');
    el.style.top = (st[k + 'y'] * 100) + '%';
    el.style.fontFamily = VC.cssFont(st[k + 'font']);
    el.style.fontWeight = st[k + 'bold'] ? '800' : '400';
    el.style.fontStyle = st[k + 'italic'] ? 'italic' : 'normal';
    el.style.letterSpacing = px(+st[k + 'spacing'] || 0);
    el.style.lineHeight = kind === 'hook' ? String(1.12 * (+st.hook_line || 1)) : '';
    el.style.fontSize = px(st[k + 'size']);
    el.style.color = st[k + 'color'];
    el.style.webkitTextStroke = box ? '0' : px(st[k + 'outline'] * 2) + ' ' + st[k + 'outline_color'];
    const shadows = [];
    if (!box && st[k + 'shadow']) { const d = px(+st[k + 'shadow_dist'] || 0); shadows.push(d + ' ' + d + ' ' + px(Math.max(1, (+st[k + 'shadow_dist'] || 0) * .7)) + ' ' + hexA(st[k + 'shadow_color'], +st[k + 'shadow_opacity'])); }
    if (!box && st[k + 'glow'] && st[k + 'glow_mode'] !== 'in') { const g = +st[k + 'glow_size'], c = hexA(st[k + 'glow_color'], Math.min(1, +st[k + 'glow_opacity'])); [.5, 1, 1.6, 2.4].forEach(f => shadows.push('0 0 ' + px(g * f) + ' ' + c)); }
    el.style.textShadow = shadows.length ? shadows.join(', ') : 'none';
    el.style.filter = setGlowFilter(kind, st, k) ? 'url(#fx-' + kind + ')' : 'none';
    el.style.background = box ? hexA(st[k + 'box_color'], .87) : 'none';
    el.style.textTransform = st[k + 'upper'] ? 'uppercase' : 'none';
  }
  function hexA(h, a) { const n = parseInt((h || '#000000').slice(1), 16); return 'rgba(' + (n >> 16) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + a + ')'; }
  const norm = t => t.toUpperCase().replace(/[^\p{L}\p{N}]/gu, '');
  function drawHook(m, st, rel) {
    const el = $('#ovHook'), secs = +st.hook_secs;
    if (!m.hook || rel < 0 || rel >= secs) { if (lastHook !== '') { el.innerHTML = ''; lastHook = ''; } return; }
    const key = JSON.stringify([m.hook, m.emphasis, st]);
    if (key !== lastHook) {
      lastHook = key; styleOv(el, 'hook', st);
      const emph = new Set((m.emphasis || '').split(/\s+/).map(norm).filter(Boolean));
      let i = 0;
      const lines = m.hook.split('\n').map(line => line.split(/\s+/).filter(Boolean).map(w => '<span class="w" data-i="' + (i++) + '" style="' +
          (emph.has(norm(w)) ? 'color:' + st.hook_emph_color + ';' : '') + '">' + esc(w) + '</span>').join(' '));
      el.innerHTML = '<span class="hook-inner">' + lines.join('<br>') + '</span>';
    }
    const inner = el.firstChild; if (!inner) return;
    const ms = rel * 1000, tr = VC.hookTransform(st, ms, secs * 1000);
    inner.style.transform = 'translate(' + px(tr.dx) + ',' + px(tr.dy) + ') scale(' + tr.sc.toFixed(4) + ') rotate(' + (-tr.rot).toFixed(2) + 'deg)';
    inner.style.opacity = tr.al.toFixed(3);
    if (st.hook_words) $$('.w', el).forEach(w => { w.style.visibility = ms >= 120 + w.dataset.i * 140 ? 'visible' : 'hidden'; });
  }
  /* Effets sonores pendant l'aperçu */
  const sounds = {};
  function playSfx(id, vol, offset) {
    const s = (VC.S.state.sfx || []).find(x => x.id === id); if (!s || !(vol > 0)) return;
    const a = sounds[id] = sounds[id] || new Audio(s.url);
    try { a.currentTime = Math.max(0, offset || 0); a.volume = Math.min(1, vol); a.play().catch(() => {}); } catch (e) {}
  }
  VC.playSfx = playSfx;
  let prevRel = null;
  function sfxTick(v, m, rel) {
    if (v.paused) { prevRel = rel < .05 ? -1 : rel; return; }
    if (prevRel !== null && rel >= prevRel && rel - prevRel < .5) {
      for (const it of VC.sfxOf(m)) {
        if (prevRel < it.at && rel >= it.at && it.at >= 0) playSfx(it.sound, +it.vol, rel - it.at);
        else if (it.at < 0 && prevRel < 0 && rel >= 0 && -it.at < VC.sfxDur(it.sound)) playSfx(it.sound, +it.vol, -it.at + rel);  // son commencé avant le clip
      }
    }
    prevRel = rel;
  }
  /* Musique de fond : suit la vidéo, baisse automatiquement quand tu parles */
  let musicEl = null, musicGain = 1;
  function speakingAt(t) {
    const w = VC.S.project.words || []; let lo = 0, hi = w.length - 1;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (w[mid].e < t - .15) lo = mid + 1; else if (w[mid].s > t + .15) hi = mid - 1; else return true; }
    return false;
  }
  function musicTick(v, m, rel) {
    const mu = m.music;
    if (!mu || !mu.file || v.paused || rel < 0 || rel > m.t1 - m.t0) { if (musicEl && !musicEl.paused) musicEl.pause(); return; }
    const url = '/music/' + encodeURIComponent(mu.file);
    if (!musicEl) { musicEl = new Audio(); musicEl.preload = 'auto'; }
    if (!musicEl.src.endsWith(url)) musicEl.src = url;
    const target = (+mu.from || 0) + rel;
    if (Math.abs(musicEl.currentTime - target) > .35) { try { musicEl.currentTime = target; } catch (e) {} }
    const want = mu.duck !== false && speakingAt(v.currentTime) ? (+mu.duck_level || .25) : 1;
    musicGain += (want - musicGain) * .15;
    const fade = Math.min(1, rel / .5, (m.t1 - m.t0 - rel) / .8);
    musicEl.volume = Math.max(0, Math.min(1, (+mu.vol || .5) * musicGain * Math.max(0, fade)));
    if (musicEl.paused) musicEl.play().catch(() => {});
  }
  VC.stopMusic = () => { if (musicEl) musicEl.pause(); };

  /* Photos et vidéos ajoutées par-dessus */
  const mediaEls = {};
  function drawMedia(m, v, rel) {
    const box = $('#ovMedia'); if (!box) return;
    const active = new Set();
    for (const it of m.media || []) {
      if (rel < it.at || rel >= it.at + it.dur) continue;
      const key = it.file + '|' + it.mode; active.add(key);
      let el = mediaEls[key];
      if (!el || !el.isConnected) {
        el = mediaEls[key] = document.createElement(it.kind === 'image' ? 'img' : 'video');
        el.src = '/pmedia/' + VC.S.project.id + '/' + it.file; if (it.kind === 'video') { el.muted = true; el.playsInline = true; el.preload = 'auto'; }
        box.appendChild(el);
      }
      el.className = it.mode === 'pip' ? 'pip' : 'full';
      if (it.mode === 'pip') { el.style.width = (it.scale || .45) * 100 + '%'; el.style.left = (it.x == null ? .5 : it.x) * 100 + '%'; el.style.top = (it.y == null ? .3 : it.y) * 100 + '%'; }
      else { el.style.width = el.style.left = el.style.top = ''; }
      el.hidden = false;
      if (it.kind === 'video') {
        const target = (it.from || 0) + rel - it.at;
        if (Math.abs(el.currentTime - target) > (v.paused ? .04 : .3)) { try { el.currentTime = target; } catch (e) {} }
        if (v.paused && !el.paused) el.pause(); if (!v.paused && el.paused) el.play().catch(() => {});
      }
    }
    for (const k in mediaEls) if (!active.has(k)) { const el = mediaEls[k]; if (!el.hidden) { el.hidden = true; if (el.pause) el.pause(); } }
  }
  VC.resetSfx = () => { prevRel = -1; };
  function drawSubs(m, st, t) {
    const el = $('#ovSub');
    let html = '', start = 0;
    const hr = t - m.t0 - VC.hookAt(m), hookOn = (m.hook || '').trim() && hr >= 0 && hr < +st.hook_secs;
    if (st.sub_on && !(hookOn && st.sub_hide_hook !== false)) {
      const chunks = VC.chunksOf(m);
      const ch = chunks.find((c, i) => { const end = c.words.length ? Math.max(c.e, c.words[c.words.length - 1].e) + .12 : c.e; const nx = chunks[i + 1]; return t >= c.s && t < Math.min(end, nx ? nx.s : 1e9); });
      if (ch && t < m.t1) {
        const ws = ch.words; let k = ws.findIndex((w, i) => t >= w.s && t < (ws[i + 1] ? ws[i + 1].s : 1e9));
        if (k < 0) k = 0;
        start = ws.length ? ws[0].s : ch.s;
        html = ws.map((w, i) => {
          if (st.sub_hl === 'none' || i !== k) return esc(w.w);
          return '<span class="w" style="color:' + st.sub_hl_color + (st.sub_hl === 'pop' ? ';transform:scale(1.12)' : '') + '">' + esc(w.w) + '</span>';
        }).join(' ');
      }
    }
    const key = html + '|' + JSON.stringify(st);
    if (key !== lastSub) { lastSub = key; styleOv(el, 'sub', st); el.innerHTML = html ? '<span class="sub-inner">' + html + '</span>' : ''; el.style.visibility = html ? 'visible' : 'hidden'; }
    const inner = el.firstChild;
    if (inner) { const a = VC.subAnim(st.sub_anim || 'none', (t - start) * 1000); inner.style.transform = 'translateY(' + px(a.dy) + ') scale(' + a.sc.toFixed(3) + ')'; inner.style.opacity = a.al.toFixed(3); }
  }
  function applyMoment() { lastHook = lastSub = null; layoutVideo(); }
  VC.applyMoment = applyMoment;
  VC.invalidate = () => { lastHook = lastSub = null; };

  function tick() {
    if (!$('#phone')) { raf = 0; VC.stopMusic && VC.stopMusic(); return; }
    raf = requestAnimationFrame(tick);
    const v = VC.vid(), m = VC.cur(); if (!v) return;
    const t = v.currentTime || 0;
    if (m) {
      if (VC.S.free && t >= m.t0 && t < m.t1) VC.S.free = false;   // la lecture libre est revenue dans le moment
      if (!v.paused && t >= m.t1 && !VC.seekPending() && !VC.S.free) { VC.seek(m.t0); prevRel = -1; }
      const st = VC.style(m);
      drawHook(m, st, t - m.t0 - VC.hookAt(m)); drawSubs(m, st, t);
      sfxTick(v, m, t - m.t0); musicTick(v, m, t - m.t0); drawMedia(m, v, t - m.t0);
      if (m.frame && ((m.frame.auto && m.frame.keys) || (m.frame.zcfg && m.frame.zcfg.on))) layoutVideo();
      if (document.activeElement !== $('#scrub')) $('#scrub').value = Math.round(clamp((t - m.t0) / (m.t1 - m.t0), 0, 1) * 1000);
      $('#tRead').textContent = fmt(clamp(t - m.t0, 0, 1e6), true) + ' / ' + fmt(m.t1 - m.t0, true);
      if (m.frame && m.frame.mode === 'blur' && v.readyState >= 2 && v.videoWidth) { const sw = Math.min(v.videoWidth, v.videoHeight * 9 / 16); bgCtx.drawImage(v, (v.videoWidth - sw) / 2, 0, sw, v.videoHeight, 0, 0, 36, 64); }
    } else { $('#ovHook').innerHTML = ''; $('#ovSub').innerHTML = ''; $('#ovMedia').innerHTML = ''; $('#tRead').textContent = fmt(t, true); }
    VC.timelineTick && VC.timelineTick(t);
  }
})();
