/* Mises à jour : bouton dans la barre du haut + panneau (version actuelle, dernière, vérifiée, nouveautés).
   OMAGAD repère les fichiers omagad-update-*.zip (Téléchargements, Bureau, dossier « mises-a-jour »). */
(function () {
  const { $, esc } = VC;
  const pop = $('#popUpdate'), btn = $('#btnUpdate');
  let available = null, checkedAt = 0, busy = false, pickedResult = null;
  const DOWN = '<svg viewBox="0 0 20 20" width="14" height="14"><path d="M10 4v9M6 9.5l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const CHECK = '<svg viewBox="0 0 20 20" width="14" height="14"><path d="M5 10.5l3.2 3.2L15 7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function ago(t) {
    if (!t) return 'jamais';
    const s = Math.round((Date.now() - t) / 1000);
    if (s < 45) return 'à l\'instant';
    if (s < 3600) return 'il y a ' + Math.max(1, Math.round(s / 60)) + ' min';
    if (s < 86400) return 'il y a ' + Math.round(s / 3600) + ' h';
    return 'il y a ' + Math.round(s / 86400) + ' j';
  }
  async function check() {
    try { const r = await VC.api('/api/updates'); available = r.found[0] || null; } catch (e) { available = null; }
    checkedAt = Date.now();
    paintPill();
    if (!pop.hidden) render();
    return available;
  }
  VC.checkUpdates = check;
  function paintPill() {
    const has = !!available;
    btn.classList.toggle('has-update', has);
    $('#updLabel').textContent = has ? 'Mise à jour disponible' : 'v' + VC.S.state.version;
    btn.querySelector('.upd-ico').innerHTML = has ? DOWN : CHECK;
    $('#updDot').hidden = !has;
  }
  function render() {
    const s = VC.S.state, cur = s.version + (s.updated ? '' : '');
    const head = available
      ? '<div class="pop-head"><span class="pop-ico red">' + DOWN + '</span><div><h3>Mise à jour ' + esc(available.version) + ' disponible</h3><p>Une nouvelle version d\'OMAGAD a été trouvée dans tes Téléchargements.</p></div></div>'
      : '<div class="pop-head"><span class="pop-ico ok">' + CHECK + '</span><div><h3>OMAGAD est à jour</h3><p>Quand je t\'envoie une mise à jour, télécharge-la : elle apparaîtra ici.</p></div></div>';
    const card = '<div class="pop-card"><div><span>Actuelle</span><b>' + esc(cur) + '</b></div><div><span>Dernière</span><b>' + esc(available ? available.version : s.version) + '</b></div>' +
      '<div><span>Vérifiée</span><b>' + ago(checkedAt) + '</b></div></div>';
    const notes = available ? '<div class="pop-notes"><h4>Nouveautés</h4>' + (available.notes ? '<pre>' + esc(available.notes.replace(/^OMAGAD [\d.]+\s*\n?/, '')) + '</pre>' : '<p class="hint">Aucune note pour cette version.</p>') + '</div>' : '';
    const status = busy ? '<div class="pop-status"><span class="spinner"></span>' + esc(busy) + '</div>' : '';
    const acts = available
      ? '<div class="pop-actions"><button class="btn" type="button" data-a="check">Vérifier à nouveau</button><span class="sp"></span><button class="btn" type="button" data-a="later">Plus tard</button><button class="btn primary" type="button" data-a="go">Mettre à jour</button></div>'
      : '<div class="pop-actions"><button class="btn" type="button" data-a="check">Vérifier à nouveau</button><span class="sp"></span><button class="btn primary" type="button" data-a="later">Fermer</button></div>';
    const more = '<div class="pop-more"><button class="link" type="button" data-a="file">Installer un fichier…</button>' + (s.updated ? '<button class="link" type="button" data-a="reset">Revenir à la version d\'origine</button>' : '') + '</div>';
    pop.innerHTML = '<div class="pop-arrow"></div>' + head + card + notes + status + (busy ? '' : acts + more);
  }
  function open() { VC.closePopovers('popUpdate'); render(); pop.hidden = false; check(); }
  VC.closePopovers = function (except) { ['popUpdate', 'popAccount'].forEach(id => { if (id !== except) $('#' + id).hidden = true; }); };
  btn.onclick = e => { e.stopPropagation(); if (pop.hidden) open(); else pop.hidden = true; };
  document.addEventListener('mousedown', e => { if (!e.target.closest('.popover, .pill, dialog')) VC.closePopovers(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') VC.closePopovers(); });

  async function restart() {
    busy = 'Redémarrage d\'OMAGAD…'; render();
    if (VC.commit) VC.commit(true);
    await VC.sleep(500);
    if (VC.native()) await window.pywebview.api.restart();
    else { busy = 'Installée : ferme et rouvre OMAGAD.'; render(); }
  }
  async function install(path, url) {
    busy = url ? 'Téléchargement de la mise à jour…' : 'Installation de la mise à jour…'; render();
    try { await VC.api('/api/update', url && !path ? { url } : { path }); await restart(); }
    catch (e) { busy = false; render(); VC.toast(e.message, 6000); }
  }
  VC.installUpdate = path => { open(); return install(path); };
  pop.onclick = async e => {
    const a = (e.target.closest('[data-a]') || {}).dataset; if (!a) return;
    if (a.a === 'check') { await check(); render(); }
    else if (a.a === 'later') pop.hidden = true;
    else if (a.a === 'go' && available) install(available.path, available.url);
    else if (a.a === 'file') {
      if (!VC.native()) return VC.toast('Le choix de fichier fonctionne dans l\'application OMAGAD.');
      const p = await window.pywebview.api.pick_zip(); if (p) install(p);
    } else if (a.a === 'reset') {
      if (!await VC.confirm('Revenir à la version d\'origine ?', 'Les mises à jour installées seront retirées. Tes projets ne sont pas touchés.', 'Revenir')) return;
      await VC.api('/api/update-reset', {}); restart();
    }
  };

  /* Tout fichier glissé dans la fenêtre arrive ici (chemin réel fourni par l'app) */
  VC.dropPath = function (path) {
    if (/\.zip$/i.test(path)) return VC.installUpdate(path);
    if (/\.(wav|mp3|m4a|aiff?|caf|ogg|flac)$/i.test(path) && VC.importSound) return VC.importSound(path);
    if (/\.(ttf|otf)$/i.test(path)) return VC.api('/api/font-import', { path }).then(r => { VC.S.state.fonts = r.fonts; VC.loadFonts(); VC.toast('Police « ' + r.family + ' » ajoutée'); });
    if (VC.S.view === 'import' && VC.importPath) return VC.importPath(path);
  };
  VC.dropPaths = function (paths) {
    const vids = paths.filter(p => /\.(mp4|mov|m4v|mkv|webm|avi|mts)$/i.test(p));
    if (vids.length && VC.queueVideos) { if (VC.S.view !== 'import') VC.go('import'); return VC.queueVideos(vids); }
    paths.forEach(p => VC.dropPath(p));
  };
  const boot = VC.boot;
  VC.boot = async function () {
    await boot();
    paintPill();
    const a = await check();
    if (a) VC.toast('OMAGAD ' + a.version + ' est disponible : clique sur « Mise à jour disponible » en haut à droite.', 6000);
    setInterval(check, 60000);
    setInterval(() => { if (!pop.hidden && !busy) render(); }, 30000);
  };
  void pickedResult;
})();
