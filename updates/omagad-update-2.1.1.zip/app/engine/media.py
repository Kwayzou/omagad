"""Appels ffmpeg / ffprobe : infos, audio, aperçu léger, forme d'onde, vignettes."""
import array
import functools
import json
import re
import os
import shutil
import subprocess
import sys
import wave

# Une app Mac lancée depuis le Finder n'hérite pas du PATH du terminal : on ajoute les emplacements courants.
for _p in ("/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin"):
    if os.path.isdir(_p) and _p not in os.environ.get("PATH", ""):
        os.environ["PATH"] = os.environ.get("PATH", "") + os.pathsep + _p

NOWIN = {"creationflags": 0x08000000} if os.name == "nt" else {}


# ---------- Choix du ffmpeg ----------
# OMAGAD n'a besoin d'aucun module particulier (les textes sont dessinés par l'app) : n'importe quel ffmpeg convient.
# Ordre : celui embarqué dans l'app, celui du paquet Python imageio-ffmpeg, puis ceux du système.
FFMPEG, HAS_ASS = "ffmpeg", True
_ENCODERS = None


def _candidates():
    out = [os.environ.get("OMAGAD_FFMPEG", "")]
    rt = os.environ.get("OMAGAD_RUNTIME")
    if rt:
        out.append(os.path.join(rt, "bin", "ffmpeg"))
    try:
        import imageio_ffmpeg
        out.append(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        pass
    out += ["/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg", "/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg",
            shutil.which("ffmpeg") or ""]
    return [c for c in out if c]


@functools.lru_cache(maxsize=16)
def _works(binary):
    try:
        return subprocess.run([binary, "-hide_banner", "-version"], capture_output=True, timeout=20, **NOWIN).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def detect_ffmpeg():
    global FFMPEG, _ENCODERS
    _ENCODERS = None
    for c in _candidates():
        if os.path.isfile(c) and _works(c):
            FFMPEG = c
            return {"ffmpeg": c, "libass": True}
    FFMPEG = "ffmpeg"
    return {"ffmpeg": None, "libass": True}


def have_ffmpeg():
    return os.path.isfile(FFMPEG) and _works(FFMPEG)


def encoders():
    global _ENCODERS
    if _ENCODERS is None:
        try:
            out = subprocess.run([FFMPEG, "-hide_banner", "-encoders"], capture_output=True, text=True, timeout=20, **NOWIN).stdout
            _ENCODERS = {l.split()[1] for l in out.splitlines() if len(l.split()) > 1 and l.startswith(" V")}
        except (OSError, subprocess.SubprocessError):
            _ENCODERS = set()
    return _ENCODERS


def brew_path():
    for b in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew"):
        if os.path.isfile(b):
            return b
    return shutil.which("brew")


detect_ffmpeg()


def run(cmd, **kw):
    return subprocess.run(cmd, check=True, **NOWIN, **kw)


def probe(path):
    """Infos de la vidéo lues dans la sortie de « ffmpeg -i » (pas besoin de ffprobe)."""
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", str(path)], capture_output=True, text=True, **NOWIN)
    txt = r.stderr
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", txt)
    if not m:
        raise ValueError("Impossible de lire cette vidéo.")
    duration = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    vline = next((l for l in txt.splitlines() if re.search(r"Stream #.*Video:", l) and "attached pic" not in l), None)
    if not vline:
        raise ValueError("Aucune piste vidéo dans ce fichier.")
    sz = re.search(r",\s*(\d{2,5})x(\d{2,5})", vline)
    w, h = int(sz.group(1)), int(sz.group(2))
    rot = re.search(r"rotation of (-?[\d.]+) degrees", txt) or re.search(r"rotate\s*:\s*(-?\d+)", txt)
    if rot and abs(int(float(rot.group(1)))) % 180 == 90:
        w, h = h, w
    has_audio = bool(re.search(r"Stream #.*Audio:", txt))
    return {"duration": duration, "width": w, "height": h, "has_audio": has_audio}


def probe_audio_duration(path):
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", str(path)], capture_output=True, text=True, **NOWIN)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr)
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.5


def extract_audio(src, wav_path):
    run([FFMPEG, "-y", "-loglevel", "error", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000",
         "-c:a", "pcm_s16le", str(wav_path)])


def start_preview(src, out_path, progress=False):
    """Copie 540p H.264 : lisible partout (même si l'original est en HEVC ou ProRes).
    Images à cadence fixe (30 i/s) et horodatage remis à zéro : sinon certaines vidéos de téléphone
    (cadence variable, piste qui ne commence pas à 0) ne se lisent plus après un moment dans la fenêtre Mac."""
    enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "28"] if "libx264" in encoders() else ["-c:v", "mpeg4", "-q:v", "6"]
    cmd = [FFMPEG, "-y", "-loglevel", "error"] + (["-progress", "pipe:1", "-nostats"] if progress else []) + [
        "-i", str(src), "-map", "0:v:0", "-map", "0:a:0?", "-vf", "scale=-2:540,fps=30"] + enc + [
        "-pix_fmt", "yuv420p", "-g", "30", "-c:a", "aac", "-b:a", "96k", "-ar", "48000", "-ac", "2",
        "-af", "aresample=async=1:first_pts=0", "-avoid_negative_ts", "make_zero", "-movflags", "+faststart", str(out_path)]
    return subprocess.Popen(cmd, stdout=subprocess.PIPE if progress else subprocess.DEVNULL, stderr=subprocess.PIPE, **NOWIN)


def waveform(wav_path, per_sec=200):
    """Vraie forme d'onde : crête et niveau moyen (RMS) tous les 1/200 s, en octets base64 (0-255)."""
    import base64
    with wave.open(str(wav_path), "rb") as wf:
        sr, n, ch = wf.getframerate(), wf.getnframes(), wf.getnchannels()
        raw = wf.readframes(n)
    hop = max(1, sr // per_sec)
    try:
        import numpy as np
        a = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
        if ch > 1:
            a = a.reshape(-1, ch).mean(axis=1)
        m = len(a) // hop
        blk = a[:m * hop].reshape(m, hop) if m else np.zeros((0, hop), np.float32)
        peak = np.abs(blk).max(axis=1) if m else np.zeros(0)
        rms = np.sqrt((blk * blk).mean(axis=1)) if m else np.zeros(0)
        top = float(np.percentile(peak, 99.5)) if m else 1.0
        enc = lambda v: base64.b64encode(np.clip(v / max(top, 1.0) * 255, 0, 255).astype(np.uint8).tobytes()).decode()
        return {"v": 2, "per_sec": per_sec, "peak": enc(peak), "rms": enc(rms * 1.6)}
    except ImportError:
        a = array.array("h", raw)
        if sys.byteorder == "big":
            a.byteswap()
        step = hop * max(1, ch)
        peak, rms = [], []
        for i in range(0, len(a) - step + 1, step):
            seg = a[i:i + step:2]
            peak.append(max(abs(x) for x in seg))
            rms.append((sum(x * x for x in seg) / len(seg)) ** 0.5)
        top = sorted(peak)[int(len(peak) * 0.995)] if peak else 1
        enc = lambda v: base64.b64encode(bytes(min(255, int(x / max(top, 1) * 255)) for x in v)).decode()
        return {"v": 2, "per_sec": per_sec, "peak": enc(peak), "rms": enc([x * 1.6 for x in rms])}


def thumbnail(src, t, out_path):
    run([FFMPEG, "-y", "-loglevel", "error", "-ss", "%.2f" % max(0, t), "-i", str(src), "-frames:v", "1",
         "-vf", "scale=-2:360", "-q:v", "5", str(out_path)])
