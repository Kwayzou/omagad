"""Export vers DaVinci Resolve : timeline XML (FCP 7 « xmeml », lue par Resolve), sous-titres SRT,
sons et médias copiés à côté, et script Lua qui importe tout dans Resolve en un clic.

Pistes : V1 = moments du vlog bout à bout, V2 = photos/vidéos ajoutées, A1 = son du vlog, A2+ = effets sonores.
Les accroches sont posées en marqueurs (et dans accroches.srt).
"""
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import quote
from xml.sax.saxutils import escape

from . import anim, edit, media, overlay, sfx
from .config import DATA, DEFAULT_STYLE, MUSIC

W, H = 1080, 1920
RESOLVE_SCRIPTS = Path.home() / "Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility"
SCRIPT_NAME = "OMAGAD - Importer la timeline.lua"
FUSCRIPT = [
    "/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fuscript",
    "/Applications/DaVinci Resolve Studio/DaVinci Resolve.app/Contents/Libraries/Fusion/fuscript",
]


def source_fps(path):
    """Images par seconde de la vidéo d'origine (lu dans « ffmpeg -i »)."""
    try:
        r = subprocess.run([media.FFMPEG, "-hide_banner", "-i", str(path)], capture_output=True, text=True, **media.NOWIN)
        for line in r.stderr.splitlines():
            if re.search(r"Stream #.*Video:", line) and "attached pic" not in line:
                m = re.search(r"([\d.]+) fps", line) or re.search(r"([\d.]+) tbr", line)
                if m:
                    return float(m.group(1))
    except Exception:
        pass
    return 30.0


def rate_of(fps):
    """(timebase entier, ntsc, fps réel) comme l'attend le XML."""
    for real, base in ((23.976, 24), (29.97, 30), (59.94, 60), (47.952, 48), (119.88, 120)):
        if abs(fps - real) < 0.02:
            return base, True, base * 1000 / 1001
    base = int(round(fps)) or 30
    return base, False, float(base)


def _url(p):
    return "file://localhost" + quote(str(Path(p).resolve()))


def _srt_time(t):
    t = max(0.0, t)
    ms = int(round(t * 1000))
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def _write_srt(path, cues):
    out = []
    for i, (a, b, text) in enumerate(cues, 1):
        out.append("%d\n%s --> %s\n%s\n" % (i, _srt_time(a), _srt_time(b), text))
    path.write_text("\n".join(out), encoding="utf-8")


def _lua_str(s):
    return "[==[" + str(s).replace("]==]", "] ==]") + "]==]"


class _Rate:
    def __init__(self, fps):
        self.base, self.ntsc, self.real = rate_of(fps)

    def f(self, sec):
        return int(round(sec * self.real))

    def xml(self):
        return "<rate><timebase>%d</timebase><ntsc>%s</ntsc></rate>" % (self.base, "TRUE" if self.ntsc else "FALSE")


def build(project, src, moments, out_root, media_dir=None):
    """Crée le dossier DaVinci et renvoie {folder, xml, srt, script, name}."""
    info = project["info"]
    name = "OMAGAD - %s" % project["name"]
    safe = re.sub(r'[\\/:*?"<>|]+', "-", project["name"]).strip() or "vlog"
    folder = Path(out_root).expanduser() / ("%s - DaVinci" % safe)
    (folder / "sons").mkdir(parents=True, exist_ok=True)
    R = _Rate(source_fps(src))
    src_frames = R.f(info["duration"])
    vw, vh = int(info.get("width", 1920)), int(info.get("height", 1080))

    def file_el(fid, path, dur_frames, done, kind="video", w=None, h=None):
        if fid in done:
            return '<file id="%s"/>' % fid
        done.add(fid)
        med = ""
        if kind in ("video", "image"):
            med += "<video><samplecharacteristics>%s<width>%d</width><height>%d</height></samplecharacteristics></video>" % (R.xml(), w or vw, h or vh)
        if kind in ("video", "audio"):
            med += "<audio><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics><channelcount>2</channelcount></audio>"
        return ('<file id="%s"><name>%s</name><pathurl>%s</pathurl>%s<duration>%d</duration><media>%s</media></file>'
                % (fid, escape(Path(path).name), _url(path), R.xml(), dur_frames, med))

    v1, v2, a1, sfx_tracks, markers, music = [], [], [], [], [], []
    subs_cues, hook_cues, frames = [], [], []
    done_files = set()
    cursor = 0  # en images
    n = 0
    for k, m in enumerate(moments):
        st = dict(DEFAULT_STYLE)
        st.update(anim.migrate(m.get("style")) or {})
        t0, t1 = float(m["t0"]), float(m["t1"])
        fi, fo = R.f(t0), R.f(t1)
        length = fo - fi
        if length <= 0:
            continue
        n += 1
        start, end = cursor, cursor + length
        sec0 = start / R.real
        cid = "clip-%d" % n
        clip_name = escape((m.get("hook") or "Moment %d" % n).replace("\n", " ")[:80])
        v1.append('<clipitem id="v-%s"><name>%s</name><enabled>TRUE</enabled><duration>%d</duration>%s<start>%d</start><end>%d</end><in>%d</in><out>%d</out>%s'
                  '<link><linkclipref>v-%s</linkclipref><mediatype>video</mediatype><trackindex>1</trackindex><clipindex>%d</clipindex></link>'
                  '<link><linkclipref>a-%s</linkclipref><mediatype>audio</mediatype><trackindex>1</trackindex><clipindex>%d</clipindex></link></clipitem>'
                  % (cid, clip_name, src_frames, R.xml(), start, end, fi, fo, file_el("vlog", src, src_frames, done_files), cid, n, cid, n))
        a1.append('<clipitem id="a-%s"><name>%s</name><enabled>TRUE</enabled><duration>%d</duration>%s<start>%d</start><end>%d</end><in>%d</in><out>%d</out>%s'
                  '<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>'
                  '<link><linkclipref>v-%s</linkclipref><mediatype>video</mediatype><trackindex>1</trackindex><clipindex>%d</clipindex></link>'
                  '<link><linkclipref>a-%s</linkclipref><mediatype>audio</mediatype><trackindex>1</trackindex><clipindex>%d</clipindex></link></clipitem>'
                  % (cid, clip_name, src_frames, R.xml(), start, end, fi, fo, '<file id="vlog"/>', cid, n, cid, n))
        # cadrage : zoom + décalage horizontal (appliqués par le script Lua)
        fr = m.get("frame") or {}
        zoom = min(3.0, max(1.0, float(fr.get("zoom", 1.0))))
        fx = float(fr.get("fx", 0.5))
        if fr.get("auto") and fr.get("keys"):
            ks = [float(v) for _, v in fr["keys"]]
            fx = sum(ks) / len(ks)
        sw = vw * max(W / vw, H / vh) * zoom
        frames.append({"zoom": round(zoom, 4), "pan": round((sw - W) * (0.5 - min(1, max(0, fx))), 1),
                       "blur": fr.get("mode") == "blur"})
        # accroche : marqueur + SRT
        hook = (m.get("hook") or "").strip()
        if hook:
            ha = edit.hook_at(m)
            markers.append('<marker><name>%s</name><comment>%s</comment><in>%d</in><out>-1</out></marker>'
                           % (escape(hook.replace("\n", " ")[:120]), escape((m.get("caption") or "")[:400]), start + R.f(ha)))
            hook_cues.append((sec0 + ha, sec0 + min(t1 - t0, ha + float(st.get("hook_secs", 3.5))), hook))
        # sous-titres du moment
        if st.get("sub_on", True):
            words = project.get("words") or []
            for ch in m.get("subs") or overlay.make_chunks(words, t0, t1, int(st.get("sub_words", 3))):
                ws = [w["w"] for w in ch.get("words", []) if (w.get("w") or "").strip()]
                a, b = max(t0, float(ch["s"])), min(t1, float(ch["e"]))
                if ws and b > a:
                    txt = " ".join(ws)
                    subs_cues.append((sec0 + a - t0, sec0 + b - t0, txt.upper() if st.get("sub_upper") else txt))
        # effets sonores (un son peut démarrer avant le moment)
        for s in edit.effective_sfx(m, st):
            p = sfx.path_of(s.get("sound"))
            if not p:
                continue
            dst = folder / "sons" / p.name
            if not dst.exists():
                shutil.copy2(p, dst)
            sd = max(1, R.f(sfx.duration(p)))
            at = R.f(float(s.get("at", 0)))
            s_start, s_in = start + at, 0
            if s_start < 0:
                s_in, s_start = -s_start, 0
            s_end = start + at + sd
            if s_end <= s_start:
                continue
            lvl = max(0.0, float(s.get("vol", 0.7)))
            tr = next((i for i, t in enumerate(sfx_tracks) if t["free"] <= s_start), None)
            if tr is None:
                sfx_tracks.append({"free": 0, "items": []})
                tr = len(sfx_tracks) - 1
            sfx_tracks[tr]["free"] = s_end
            fid = "sfx-" + re.sub(r"\W+", "-", p.stem)
            sfx_tracks[tr]["items"].append(
                '<clipitem id="%s-%d-%d"><name>%s</name><enabled>TRUE</enabled><duration>%d</duration>%s<start>%d</start><end>%d</end><in>%d</in><out>%d</out>%s'
                '<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>'
                '<filter><effect><name>Audio Levels</name><effectid>audiolevels</effectid><effectcategory>audiolevels</effectcategory><effecttype>audiolevels</effecttype><mediatype>audio</mediatype>'
                '<parameter><parameterid>level</parameterid><name>Level</name><valuemin>0</valuemin><valuemax>3.98109</valuemax><value>%.4f</value></parameter></effect></filter></clipitem>'
                % (fid, n, len(sfx_tracks[tr]["items"]), escape(p.stem), sd, R.xml(), s_start, s_end, s_in, s_in + (s_end - s_start),
                   file_el(fid, dst, sd, done_files, "audio"), lvl))
        # musique de fond (la baisse sous la voix se refait dans DaVinci : Fairlight > Ducking)
        mu = m.get("music") or {}
        mp = (MUSIC / mu["file"]) if mu.get("file") else None
        if mp and mp.exists():
            (folder / "musique").mkdir(exist_ok=True)
            dst = folder / "musique" / ((re.sub(r'[\\/:*?"<>|]+', "-", mu.get("name") or "musique") or "musique") + mp.suffix)
            if not dst.exists():
                shutil.copy2(mp, dst)
            mdur = R.f(float(mu.get("dur") or 600))
            fin = R.f(float(mu.get("from", 0)))
            music.append('<clipitem id="mu-%d"><name>%s</name><enabled>TRUE</enabled><duration>%d</duration>%s<start>%d</start><end>%d</end><in>%d</in><out>%d</out>%s'
                         '<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>'
                         '<filter><effect><name>Audio Levels</name><effectid>audiolevels</effectid><effectcategory>audiolevels</effectcategory><effecttype>audiolevels</effecttype><mediatype>audio</mediatype>'
                         '<parameter><parameterid>level</parameterid><name>Level</name><valuemin>0</valuemin><valuemax>3.98109</valuemax><value>%.4f</value></parameter></effect></filter></clipitem>'
                         % (n, escape(dst.stem), mdur, R.xml(), start, end, fin, fin + length,
                            file_el("mu-" + re.sub(r"\W+", "-", dst.stem), dst, mdur, done_files, "audio"), float(mu.get("vol", 0.5))))
        # photos et vidéos ajoutées
        for j, it in enumerate(m.get("media") or []):
            if not media_dir or not it.get("file"):
                continue
            p = Path(media_dir) / it["file"]
            if not p.exists():
                continue
            (folder / "medias").mkdir(exist_ok=True)
            dst = folder / "medias" / p.name
            if not dst.exists():
                shutil.copy2(p, dst)
            at, d = max(0.0, float(it.get("at", 0))), float(it.get("dur", 3))
            a_, b_ = start + R.f(at), min(end, start + R.f(at + d))
            if b_ <= a_:
                continue
            kind = "image" if it.get("kind") == "image" else "video"
            fin = R.f(float(it.get("from", 0))) if kind == "video" else 0
            mdur = (b_ - a_) + fin if kind == "video" else max(b_ - a_, 1)
            v2.append('<clipitem id="md-%d-%d"><name>%s</name><enabled>TRUE</enabled><duration>%d</duration>%s<start>%d</start><end>%d</end><in>%d</in><out>%d</out>%s</clipitem>'
                      % (n, j, escape(p.name), mdur, R.xml(), a_, b_, fin, fin + (b_ - a_),
                         file_el("md-" + re.sub(r"\W+", "-", p.name), dst, mdur, done_files, kind)))
        cursor = end
    if not n:
        raise RuntimeError("Aucun moment à mettre dans la timeline.")

    fmt = ("<format><samplecharacteristics>%s<width>%d</width><height>%d</height><anamorphic>FALSE</anamorphic>"
           "<pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></format>" % (R.xml(), W, H))
    vtracks = "<track>%s</track>" % "".join(v1) + ("<track>%s</track>" % "".join(v2) if v2 else "")
    atracks = "<track>%s</track>" % "".join(a1) + "".join("<track>%s</track>" % "".join(t["items"]) for t in sfx_tracks)
    if music:
        atracks += "<track>%s</track>" % "".join(music)
    xml = ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="5"><sequence id="omagad">'
           "<name>%s</name><duration>%d</duration>%s"
           "<timecode>%s<string>01:00:00:00</string><frame>%d</frame><displayformat>NDF</displayformat></timecode>"
           "<media><video>%s%s</video><audio><numOutputChannels>2</numOutputChannels>%s</audio></media>%s</sequence></xmeml>\n"
           % (escape(name), cursor, R.xml(), R.xml(), 3600 * R.base, fmt, vtracks, atracks, "".join(markers)))
    xml_path = folder / ("%s.xml" % safe)
    xml_path.write_text(xml, encoding="utf-8")
    srt_path = folder / "sous-titres.srt"
    _write_srt(srt_path, subs_cues)
    hooks_path = folder / "accroches.srt"
    _write_srt(hooks_path, hook_cues)
    fps_txt = {23.976: "23.976", 29.97: "29.97", 59.94: "59.94"}.get(round(R.real, 3), str(R.base))
    script = lua_script(xml_path, name, [srt_path, hooks_path], frames, fps_txt)
    script_path = folder / SCRIPT_NAME
    script_path.write_text(script, encoding="utf-8")
    installed = install_script(script)
    return {"folder": str(folder), "xml": str(xml_path), "srt": str(srt_path), "script": str(script_path),
            "installed": installed, "name": name, "clips": n}


def lua_script(xml_path, name, srts, frames, fps):
    rows = ",\n".join("  {zoom=%s, pan=%s}" % (f["zoom"], f["pan"]) for f in frames)
    return """-- OMAGAD : importe la dernière timeline exportée dans DaVinci Resolve.
-- Dans DaVinci : Espace de travail > Scripts > OMAGAD - Importer la timeline
local XML = %s
local NAME = %s
local FPS = %s
local SRT = { %s }
local FRAMES = {
%s
}
local resolve = nil
if Resolve then resolve = Resolve() end
if (not resolve) and bmd then resolve = bmd.scriptapp("Resolve") end
if not resolve then print("OMAGAD : DaVinci Resolve introuvable") return end
local pm = resolve:GetProjectManager()
local project = nil
if OMAGAD_NEW_PROJECT then
  project = pm:LoadProject(NAME) or pm:CreateProject(NAME)
  if project then
    project:SetSetting("timelineResolutionWidth", "1080")
    project:SetSetting("timelineResolutionHeight", "1920")
    project:SetSetting("timelineFrameRate", FPS)
    project:SetSetting("timelinePlaybackFrameRate", FPS)
  end
end
project = project or pm:GetCurrentProject()
if not project then print("OMAGAD : ouvre un projet dans DaVinci puis relance le script") return end
local mp = project:GetMediaPool()
local tlname = NAME .. " " .. os.date("%%H.%%M.%%S")
local tl = mp:ImportTimelineFromFile(XML, { timelineName = tlname, importSourceClips = true })
if not tl then print("OMAGAD : import impossible de " .. XML) return end
project:SetCurrentTimeline(tl)
tl:SetSetting("useCustomSettings", "1")
tl:SetSetting("timelineResolutionWidth", "1080")
tl:SetSetting("timelineResolutionHeight", "1920")
tl:SetSetting("timelineInputResMismatchBehavior", "scaleToFill")
local items = tl:GetItemListInTrack("video", 1) or {}
for i, it in ipairs(items) do
  local f = FRAMES[i]
  if f then
    it:SetProperty("ZoomX", f.zoom)
    it:SetProperty("ZoomY", f.zoom)
    it:SetProperty("Pan", f.pan)
  end
end
pcall(function() mp:ImportMedia(SRT) end)
resolve:OpenPage("edit")
print("OMAGAD : timeline « " .. tlname .. " » prête")
""" % (_lua_str(xml_path), _lua_str(name), _lua_str(fps), ", ".join(_lua_str(s) for s in srts), rows)


def install_script(script):
    """Place le script dans le menu Scripts de DaVinci (marche aussi avec la version gratuite)."""
    if sys.platform != "darwin":
        return False
    try:
        RESOLVE_SCRIPTS.mkdir(parents=True, exist_ok=True)
        (RESOLVE_SCRIPTS / SCRIPT_NAME).write_text(script, encoding="utf-8")
        return True
    except OSError:
        return False


def find_fuscript():
    for p in FUSCRIPT:
        if os.path.exists(p):
            return p
    try:
        r = subprocess.run(["mdfind", "kMDItemCFBundleIdentifier == 'com.blackmagic-design.DaVinciResolve*'"],
                           capture_output=True, text=True, timeout=5)
        for app in r.stdout.splitlines():
            p = Path(app) / "Contents/Libraries/Fusion/fuscript"
            if p.exists():
                return str(p)
    except Exception:
        pass
    return None


def installed():
    if sys.platform != "darwin":
        return False
    if find_fuscript():
        return True
    return any(Path(p).exists() for p in ("/Applications/DaVinci Resolve", "/Applications/DaVinci Resolve Studio"))


def open_in_resolve(script_path, on_step, wait=150):
    """Ouvre DaVinci, puis tente l'import automatique (scripting externe : réglage « Local » dans DaVinci).
    Renvoie True si la timeline a été importée toute seule."""
    if sys.platform != "darwin":
        raise RuntimeError("DaVinci Resolve s'ouvre automatiquement seulement sur Mac.")
    r = subprocess.run(["open", "-a", "DaVinci Resolve"], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("DaVinci Resolve n'est pas installé sur ce Mac.")
    fus = find_fuscript()
    if not fus:
        return False
    wrapper = Path(DATA) / "davinci-run.lua"
    wrapper.write_text("OMAGAD_NEW_PROJECT = true\ndofile(%s)\n" % _lua_str(script_path), encoding="utf-8")
    probe = Path(DATA) / "davinci-probe.lua"
    probe.write_text('local r = bmd.scriptapp("Resolve")\nif r and r:GetProjectManager() then print("OMAGAD_OK") end\n', encoding="utf-8")
    t0, seen = time.time(), None
    while time.time() - t0 < wait:
        running = subprocess.run(["pgrep", "-f", "DaVinci Resolve.app/Contents/MacOS"], capture_output=True).returncode == 0
        if running and seen is None:
            seen = time.time()
        if seen and time.time() - seen > 45:
            return False  # DaVinci est ouvert mais refuse le pilotage externe (version gratuite ou réglage « Aucun »)
        on_step("Ouverture de DaVinci Resolve…", min(0.9, (time.time() - t0) / 60))
        if running:
            try:
                out = subprocess.run([fus, "-l", "lua", str(probe)], capture_output=True, text=True, timeout=15).stdout
            except Exception:
                out = ""
            if "OMAGAD_OK" in out:
                time.sleep(2)
                on_step("Import de la timeline…", 0.95)
                try:
                    out = subprocess.run([fus, "-l", "lua", str(wrapper)], capture_output=True, text=True, timeout=120).stdout
                except Exception:
                    out = ""
                return "prête" in out
        time.sleep(3)
    return False
