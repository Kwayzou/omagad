#!/bin/bash
# Lanceur d'OMAGAD.app — autonome : rien à installer à la main.
# Au premier lancement, l'app télécharge dans son propre dossier une copie portable de Python,
# ses composants et ffmpeg. Ensuite elle fonctionne hors ligne, et l'app peut être copiée sur un autre Mac.
export PATH="/usr/bin:/bin:/usr/sbin:/sbin"
CONTENTS="$(cd "$(dirname "$0")/.." && pwd)"
BUNDLE="$(cd "$CONTENTS/.." && pwd)"
BUILTIN="$CONTENTS/Resources/app"
BASE="$HOME/Library/Application Support"
SUPPORT="$BASE/OMAGAD"
if [ ! -d "$SUPPORT" ] && [ -d "$BASE/Vlog Clips" ]; then mv "$BASE/Vlog Clips" "$SUPPORT"; fi
mkdir -p "$SUPPORT"
LOG="$SUPPORT/lancement.log"
echo "--- $(date) $(uname -m)" >> "$LOG"
ARCH="$(uname -m)"; [ "$ARCH" = "arm64" ] && PBS_ARCH="aarch64" || PBS_ARCH="x86_64"

ask() { osascript -e "button returned of (display dialog \"$1\" with title \"OMAGAD\" buttons {\"Quitter\", \"$2\"} default button 2 with icon caution)" 2>/dev/null; }
note() { osascript -e "display notification \"$1\" with title \"OMAGAD\"" >/dev/null 2>&1; echo "$1" >> "$LOG"; }
fail() {
  r=$(ask "$1\n\nDétails : $LOG" "Ouvrir le journal")
  [ "$r" = "Ouvrir le journal" ] && open -a TextEdit "$LOG"
  exit 1
}
ver() { [ -f "$1/VERSION" ] && cat "$1/VERSION" || echo 0; }

# Le moteur s'installe dans l'app elle-même (portable) ; sinon (app non déplacée dans Applications) dans le dossier de données.
RUNTIME="$CONTENTS/Resources/runtime-$ARCH"
# moteur fourni dans l'installateur (.dmg) : on retire la quarantaine de téléchargement, une seule fois
if [ -d "$RUNTIME/python" ] && [ ! -f "$RUNTIME/.unquarantined" ]; then
  xattr -dr com.apple.quarantine "$CONTENTS/Resources" 2>/dev/null; touch "$RUNTIME/.unquarantined" 2>/dev/null
fi
if [ -x "$RUNTIME/python/bin/python3" ] && ls "$RUNTIME"/.deps-* >/dev/null 2>&1; then
  :  # moteur déjà prêt dans l'app (même si l'app est en lecture seule)
elif [[ "$BUNDLE" == *"/AppTranslocation/"* ]] || ! mkdir -p "$RUNTIME" 2>/dev/null || [ ! -w "$RUNTIME" ]; then
  RUNTIME="$SUPPORT/runtime-$ARCH"
  mkdir -p "$RUNTIME"
  [[ "$BUNDLE" == *"/AppTranslocation/"* ]] && note "Astuce : glisse OMAGAD dans le dossier Applications."
fi
PY="$RUNTIME/python/bin/python3"

# Version du code à lancer : la mise à jour installée si elle est plus récente que celle livrée avec l'app
APPDIR="$BUILTIN"
if [ -f "$SUPPORT/app/app.py" ]; then
  newest=$(printf '%s\n%s\n' "$(ver "$SUPPORT/app")" "$(ver "$BUILTIN")" | sort -V | tail -1)
  [ "$newest" = "$(ver "$SUPPORT/app")" ] && APPDIR="$SUPPORT/app"
fi
echo "version $(ver "$APPDIR") — moteur $RUNTIME" >> "$LOG"

# 1. Python portable (python-build-standalone), une seule fois
if [ ! -x "$PY" ]; then
  note "Première ouverture : installation du moteur (5 à 10 minutes, une seule fois). OMAGAD s'ouvrira tout seul."
  TMP="$RUNTIME/.dl"; rm -rf "$TMP"; mkdir -p "$TMP"
  URL=$(curl -fsSL --retry 3 "https://api.github.com/repos/astral-sh/python-build-standalone/releases/latest" 2>>"$LOG" \
        | grep -o '"browser_download_url": *"[^"]*"' | grep -o 'https://[^"]*' \
        | grep -E "cpython-3\.12\.[0-9]+\+[0-9]+-${PBS_ARCH}-apple-darwin-install_only(_stripped)?\.tar\.gz$" | head -1)
  for u in "$URL" \
    "https://github.com/astral-sh/python-build-standalone/releases/download/20241016/cpython-3.12.7+20241016-${PBS_ARCH}-apple-darwin-install_only.tar.gz" \
    "https://github.com/indygreg/python-build-standalone/releases/download/20240814/cpython-3.12.5+20240814-${PBS_ARCH}-apple-darwin-install_only.tar.gz"; do
    [ -z "$u" ] && continue
    echo "python : $u" >> "$LOG"
    if curl -fL --retry 3 -o "$TMP/python.tar.gz" "$u" >> "$LOG" 2>&1 && tar -xzf "$TMP/python.tar.gz" -C "$TMP" >> "$LOG" 2>&1; then break; fi
  done
  [ -x "$TMP/python/bin/python3" ] || fail "Impossible de télécharger le moteur Python. Vérifie ta connexion internet puis rouvre OMAGAD."
  rm -rf "$RUNTIME/python"; mv "$TMP/python" "$RUNTIME/python"; rm -rf "$TMP"
fi

# 2. Composants (transcription, fenêtre, dessin des textes, ffmpeg) : réinstallés quand la liste change
REQ_HASH=$(md5 -q "$APPDIR/requirements.txt" 2>/dev/null)
STAMP="$RUNTIME/.deps-$REQ_HASH"
if [ ! -f "$STAMP" ]; then
  note "Installation des composants d'OMAGAD..."
  { "$PY" -m pip install --upgrade --disable-pip-version-check --no-warn-script-location pip \
    && "$PY" -m pip install --disable-pip-version-check --no-warn-script-location -r "$APPDIR/requirements.txt"; } >> "$LOG" 2>&1 \
    || fail "L'installation des composants a échoué. Vérifie ta connexion internet puis rouvre OMAGAD."
  rm -f "$RUNTIME"/.deps-*; touch "$STAMP"
fi

# 3. ffmpeg : celui du paquet imageio-ffmpeg ; sinon une version autonome téléchargée dans le moteur
mkdir -p "$RUNTIME/bin"
if [ ! -x "$RUNTIME/bin/ffmpeg" ]; then
  FF=$("$PY" -c "import imageio_ffmpeg as i; print(i.get_ffmpeg_exe())" 2>>"$LOG")
  if [ -n "$FF" ] && [ -x "$FF" ] && "$FF" -hide_banner -version >/dev/null 2>&1; then
    cp "$FF" "$RUNTIME/bin/ffmpeg" && chmod +x "$RUNTIME/bin/ffmpeg"
  else
    note "Téléchargement de ffmpeg..."
    [ "$ARCH" = "arm64" ] && FFA="arm64" || FFA="amd64"
    curl -fL --retry 3 -o "$RUNTIME/bin/ffmpeg.zip" "https://ffmpeg.martin-riedl.de/redirect/latest/macos/$FFA/release/ffmpeg.zip" >> "$LOG" 2>&1 \
      && (cd "$RUNTIME/bin" && unzip -o -q ffmpeg.zip && rm -f ffmpeg.zip && chmod +x ffmpeg) \
      || fail "Impossible d'installer ffmpeg. Vérifie ta connexion internet puis rouvre OMAGAD."
  fi
fi

export OMAGAD_RUNTIME="$RUNTIME"
export OMAGAD_FFMPEG="$RUNTIME/bin/ffmpeg"
if mkdir -p "$RUNTIME/models" 2>/dev/null && [ -w "$RUNTIME/models" ]; then
  export HF_HOME="$RUNTIME/models"         # le modèle de transcription reste dans l'app
else
  export HF_HOME="$SUPPORT/models"
fi
export VLOGCLIPS_ICON="$CONTENTS/Resources/icon.png"
export OMAGAD_BUNDLE="$BUNDLE"
export PYTHONDONTWRITEBYTECODE=1
exec "$PY" "$APPDIR/app.py" >> "$LOG" 2>&1
