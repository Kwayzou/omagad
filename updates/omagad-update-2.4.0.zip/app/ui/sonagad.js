/* SONAGAD : répare le son saturé d'un long enregistrement (DJ set, concert…). */
(function () {
  const { $, $$, esc, fmt, clamp } = VC;
  const S = { file: null, a: null, start: 0, drop: 0, fade: 20, video: true, job: null, busy: false, listen: null };

  const parseT = s => { const p = String(s).trim().split(':').map(Number); if (p.some(isNaN)) return null; return p.reduce((t, x) => t * 60 + x, 0); };
  const hms = s => { s = Math.max(0, Math.round(s)); return Math.floor(s / 3600) + ':' + String(Math.floor(s % 3600 / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };

  VC.screens.sonagad = function () {
    if (S.a) return renderEditor();
    $('#view').innerHTML = '<div class="import sona"><div class="drop" id="sDrop">' +
      '<div class="big-icon sona-ico">' + ICON + '</div>' +
      '<h1>Répare un son saturé</h1>' +
      '<p>Dépose la vidéo ou l\'audio de ton set. SONAGAD repère où le son se met à saturer, reconstruit les crêtes écrêtées sur cette partie seulement et remet le volume au niveau du reste. Tu récupères un WAV de la même durée, à glisser dans DaVinci à la place du son d\'origine.</p>' +
      '<button class="btn primary big" type="button" id="sPick">Choisir un fichier</button>' +
      '<span class="hint">MP4, MOV, MXF, WAV… Rien n\'est envoyé sur internet.</span></div>' +
      '<div id="sBusy"></div></div>';
    const dz = $('#sDrop');
    $('#sPick').onclick = pick;
    dz.ondragover = e => { e.preventDefault(); dz.classList.add('over'); };
    dz.ondragleave = () => dz.classList.remove('over');
    dz.ondrop = e => {
      e.preventDefault(); dz.classList.remove('over');
      const f = e.dataTransfer.files[0];
      if (f && f.pywebviewFullPath) VC.sonagadOpen(f.pywebviewFullPath);  // sinon l'app native passe par VC.dropPath
    };
  };

  async function pick() {
    if (!VC.native()) return VC.toast('Le choix de fichier se fait dans l\'application OMAGAD sur Mac.');
    const p = await window.pywebview.api.pick_video();
    if (p) VC.sonagadOpen(p);
  }

  /* ---------- Analyse ---------- */
  VC.sonagadOpen = async function (path) {
    if (S.busy) return VC.toast('Une opération est déjà en cours.');
    S.file = path; S.a = null; S.listen = null;
    if (VC.S.view !== 'sonagad') VC.go('sonagad');
    const name = path.split(/[\\/]/).pop();
    $('#view').innerHTML = '<div class="import sona"><div class="analysis"><div><div class="label">Analyse du son</div><h2>' + esc(name) + '</h2></div>' +
      '<div class="bar-prog"><i id="sBar"></i></div><div class="hint" id="sMsg">Démarrage…</div>' +
      '<p class="hint" style="margin:0">Compte environ une minute pour un set d\'1h30.</p>' +
      '<div><button class="btn small" type="button" id="sCancel">Annuler</button></div></div></div>';
    S.busy = true;
    try {
      const r = await VC.api('/api/sonagad/analyse', { path });
      S.job = r.job; $('#sCancel').onclick = () => VC.api('/api/cancel/' + r.job, {});
      const j = await VC.poll(r.job, x => { const b = $('#sBar'); if (b) { b.style.width = Math.round(x.progress * 100) + '%'; $('#sMsg').textContent = x.message || ''; } });
      if (j.error) throw new Error(j.error);
      S.a = j.result;
      S.start = S.a.start == null ? Math.max(0, S.a.duration * .75) : S.a.start;
      S.drop = S.a.drop_db; S.video = !!S.a.has_video;
      VC.sound('ready');
    } catch (e) { VC.sound('error'); VC.toast(e.message, 7000); S.busy = false; S.file = null; return VC.screens.sonagad(); }
    S.busy = false;
    renderEditor();
  };

  /* ---------- Réglages + courbe ---------- */
  function renderEditor() {
    const a = S.a;
    const found = a.start != null;
    const warn = [];
    if (!a.declip) warn.push('Le ffmpeg de l\'app n\'a pas le module de reconstruction des crêtes : seul le volume sera corrigé.');
    else if (a.lossy) warn.push('Le son de ce fichier est compressé (' + esc(a.codec.toUpperCase()) + ') : la reconstruction des crêtes marche moins bien que sur un son non compressé (PCM). Le volume, lui, sera bien corrigé.');
    $('#view').innerHTML = '<div class="import sona">' +
      '<section class="analysis sona-card">' +
      '<div class="sona-head"><div><div class="label">Enregistrement</div><h2>' + esc(a.name) + '</h2>' +
      '<span class="hint mono">' + hms(a.duration) + ' · son ' + esc(a.codec || '?') + ' · crête ' + a.ceiling_db.toFixed(1).replace('.', ',') + ' dBFS</span></div>' +
      '<button class="btn small" type="button" id="sOther">Autre fichier</button></div>' +
      '<div class="sona-verdict ' + (found ? 'bad' : 'ok') + '">' + (found
        ? '<b>Saturation détectée à partir de ' + hms(a.start) + '</b><span>' + fmt(a.bad_seconds) + ' de son saturé au total. La partie en rouge sera réparée.</span>'
        : '<b>Pas de saturation franche détectée</b><span>Si tu l\'entends quand même, clique sur la courbe à l\'endroit où ça commence.</span>') + '</div>' +
      (warn.length ? '<div class="sona-warn">' + warn.join('<br>') + '</div>' : '') +
      '<div class="sona-graph"><canvas id="sCv"></canvas><div class="sona-axis"><span>0:00:00</span><span>' + hms(a.duration / 2) + '</span><span>' + hms(a.duration) + '</span></div></div>' +
      '<p class="hint" style="margin:0">Niveau du son sur toute la durée. En rouge : son saturé. Clique sur la courbe pour choisir où la réparation commence.</p>' +
      '<div class="cols3 sona-ctrl">' +
      '<div class="field"><label for="sStart">Début de la réparation</label><input type="text" id="sStart" class="mono" value="' + hms(S.start) + '" spellcheck="false"></div>' +
      '<div class="field"><label for="sDropR">Baisse de volume de la fin<output id="oDrop"></output></label><input type="range" id="sDropR" min="0" max="18" step="0.1" value="' + S.drop + '">' +
      '<span class="hint">Calculée pour retrouver le niveau du début du set' + (found ? ' (−' + a.drop_db.toFixed(1).replace('.', ',') + ' dB)' : '') + '.</span></div>' +
      '<div class="field"><label for="sFade">Transition<output id="oFade"></output></label><input type="range" id="sFade" min="2" max="60" step="1" value="' + S.fade + '"><span class="hint">Durée de la baisse de volume progressive.</span></div>' +
      '</div>' +
      (a.has_video ? '<label class="check"><input type="checkbox" id="sVideo"' + (S.video ? ' checked' : '') + '> Créer aussi la vidéo avec le son réparé (.mov, image copiée sans perte)</label>' : '') +
      '</section>' +
      '<section class="analysis sona-card"><div class="sona-head"><div><div class="label">Écoute</div><h2>Compare avant / après</h2></div>' +
      '<button class="btn" type="button" id="sListen">Préparer un extrait de 20 s</button></div>' +
      '<div id="sAB"><p class="hint" style="margin:0">L\'extrait est pris 30 secondes après le début de la réparation. « Avant » est remis au même volume, pour que tu compares la distorsion et pas le niveau.</p></div></section>' +
      '<section class="analysis sona-card"><div class="sona-head"><div><div class="label">Réparation</div><h2>Fichier final</h2></div>' +
      '<button class="btn primary big" type="button" id="sGo">Réparer le son</button></div>' +
      '<div id="sOut"><p class="hint" style="margin:0">Le WAV (48 kHz, 24 bits) est créé à côté du fichier d\'origine, qui n\'est pas modifié. Compte quelques minutes : la reconstruction des crêtes est un calcul lourd.</p></div></section>' +
      '</div>';
    $('#sOther').onclick = () => { if (S.busy) return; S.a = null; S.file = null; VC.screens.sonagad(); };
    const sr = $('#sDropR'), sf = $('#sFade');
    const showVals = () => { $('#oDrop').textContent = '−' + (+sr.value).toFixed(1).replace('.', ',') + ' dB'; $('#oFade').textContent = sf.value + ' s'; };
    sr.oninput = () => { S.drop = +sr.value; showVals(); draw(); };
    sf.oninput = () => { S.fade = +sf.value; showVals(); };
    showVals();
    $('#sStart').onchange = e => { const t = parseT(e.target.value); if (t == null) { e.target.value = hms(S.start); return VC.toast('Format attendu : H:MM:SS'); } setStart(t); };
    $('#sStart').addEventListener('keydown', e => e.stopPropagation());
    if ($('#sVideo')) $('#sVideo').onchange = e => { S.video = e.target.checked; };
    $('#sListen').onclick = listen;
    $('#sGo').onclick = repair;
    const cv = $('#sCv');
    cv.onclick = e => { const r = cv.getBoundingClientRect(); setStart((e.clientX - r.left) / r.width * a.duration); };
    draw();
    window.addEventListener('resize', draw);
  }

  function setStart(t) {
    S.start = clamp(Math.round(t), 0, Math.max(0, S.a.duration - 1));
    const i = $('#sStart'); if (i) i.value = hms(S.start);
    S.listen = null; const ab = $('#sAB'); if (ab && ab.querySelector('audio')) ab.innerHTML = '<p class="hint" style="margin:0">Réglage modifié : prépare un nouvel extrait pour réécouter.</p>';
    draw();
  }

  function draw() {
    const cv = $('#sCv'); if (!cv || !S.a) return;
    const a = S.a, dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    const c = cv.getContext('2d'); c.scale(dpr, dpr); c.clearRect(0, 0, W, H);
    const lv = a.levels, n = lv.length; if (!n) return;
    const lo = -48, hi = 0, y = v => H - clamp((v - lo) / (hi - lo), 0, 1) * H;
    const x = i => i / n * W, bw = Math.max(1, W / n);
    const sx = S.start / a.duration * W, g = Math.pow(10, -S.drop / 20);
    // grille
    c.strokeStyle = 'rgba(255,255,255,.06)'; c.lineWidth = 1;
    [-6, -12, -24, -36].forEach(v => { c.beginPath(); c.moveTo(0, y(v) + .5); c.lineTo(W, y(v) + .5); c.stroke(); });
    // niveau d'origine
    for (let i = 0; i < n; i++) {
      c.fillStyle = a.bad[i] > .3 ? 'rgba(255,92,108,.85)' : 'rgba(46,138,216,.55)';
      c.fillRect(x(i), y(lv[i]), bw, H - y(lv[i]));
    }
    // niveau après réparation (contour)
    c.strokeStyle = 'rgba(61,220,151,.95)'; c.lineWidth = 1.5; c.beginPath();
    for (let i = 0; i < n; i++) {
      const t = i / n * a.duration, t0 = S.start - S.fade / 2;
      const k = t < t0 ? 1 : t > t0 + S.fade ? g : 1 + (g - 1) * (t - t0) / S.fade;
      const v = Math.min(-1, lv[i] + 20 * Math.log10(k));
      i ? c.lineTo(x(i) + bw / 2, y(v)) : c.moveTo(x(i) + bw / 2, y(v));
    }
    c.stroke();
    // zone réparée + marqueur
    c.fillStyle = 'rgba(255,255,255,.04)'; c.fillRect(sx, 0, W - sx, H);
    c.fillStyle = '#ffc54d'; c.fillRect(sx - 1, 0, 2, H);
    c.font = '600 11px -apple-system, sans-serif'; c.fillText(hms(S.start), Math.min(sx + 6, W - 56), 14);
  }

  /* ---------- Écoute avant / après ---------- */
  async function listen() {
    if (S.busy) return;
    const b = $('#sListen'), at = Math.min(S.start + 30, Math.max(0, S.a.duration - 20));
    b.disabled = true; b.textContent = 'Préparation…'; S.busy = true;
    try {
      const r = await VC.api('/api/sonagad/preview', { path: S.file, start: S.start, drop_db: S.drop, fade: S.fade, at });
      const j = await VC.poll(r.job);
      if (j.error) throw new Error(j.error);
      S.listen = j.result;
      const ts = '?t=' + Date.now();
      $('#sAB').innerHTML = '<div class="sona-ab"><div class="seg" id="sSeg"><button type="button" data-ab="before" aria-pressed="false">Avant</button><button type="button" data-ab="after" aria-pressed="true">Après</button></div>' +
        '<button class="icon-btn play" type="button" id="sPlay" aria-label="Lecture"><svg viewBox="0 0 20 20"><path d="M6 4l10 6-10 6z" fill="currentColor"/></svg></button>' +
        '<span class="hint mono" id="sPos">' + hms(at) + '</span><span class="hint">Bascule entre Avant et Après pendant la lecture : la position est conservée.</span></div>' +
        '<audio id="aBefore" preload="auto" src="/sonagad/' + encodeURIComponent(S.listen.before) + ts + '"></audio>' +
        '<audio id="aAfter" preload="auto" src="/sonagad/' + encodeURIComponent(S.listen.after) + ts + '"></audio>';
      let cur = 'after';
      const el = k => $(k === 'before' ? '#aBefore' : '#aAfter');
      const ico = p => { $('#sPlay').innerHTML = p ? '<svg viewBox="0 0 20 20"><path d="M5 4h4v12H5zM11 4h4v12h-4z" fill="currentColor"/></svg>' : '<svg viewBox="0 0 20 20"><path d="M6 4l10 6-10 6z" fill="currentColor"/></svg>'; };
      $('#sPlay').onclick = () => { const e = el(cur); if (e.paused) { e.play(); ico(true); } else { e.pause(); ico(false); } };
      ['#aBefore', '#aAfter'].forEach(s => { const e = $(s); e.ontimeupdate = () => { $('#sPos').textContent = hms(at + e.currentTime); }; e.onended = () => ico(false); });
      $('#sSeg').onclick = e => {
        const k = e.target.dataset.ab; if (!k || k === cur) return;
        const from = el(cur), to = el(k), playing = !from.paused;
        to.currentTime = from.currentTime; from.pause(); if (playing) to.play();
        cur = k; $$('#sSeg button').forEach(x => x.setAttribute('aria-pressed', String(x.dataset.ab === k)));
      };
    } catch (e) { VC.toast(e.message, 7000); }
    S.busy = false; b.disabled = false; b.textContent = 'Préparer un nouvel extrait';
  }

  /* ---------- Réparation ---------- */
  async function repair() {
    if (S.busy) return;
    S.busy = true;
    const go = $('#sGo'); go.disabled = true;
    $$('audio').forEach(a => a.pause());
    $('#sOut').innerHTML = '<div class="bar-prog"><i id="sBar"></i></div><div class="row-gap"><span class="hint" id="sMsg">Démarrage…</span><button class="btn small" type="button" id="sCancel">Annuler</button></div>';
    try {
      const r = await VC.api('/api/sonagad/repair', { path: S.file, start: S.start, drop_db: S.drop, fade: S.fade, video: S.video && S.a.has_video });
      $('#sCancel').onclick = () => VC.api('/api/cancel/' + r.job, {});
      const t0 = Date.now();
      const j = await VC.poll(r.job, x => {
        const b = $('#sBar'); if (!b) return;
        b.style.width = Math.round(x.progress * 100) + '%';
        const el = (Date.now() - t0) / 1000, left = x.progress > .03 ? el / x.progress - el : 0;
        $('#sMsg').textContent = (x.message || '') + ' ' + Math.round(x.progress * 100) + ' %' + (left > 5 ? ' · encore ≈ ' + fmt(left) : '');
      });
      if (j.error) throw new Error(j.error);
      VC.sound('done');
      const res = j.result, files = [res.wav, res.video].filter(Boolean);
      $('#sOut').innerHTML = '<div class="sona-verdict ok"><b>Son réparé</b><span>' + (res.declip ? 'Crêtes reconstruites et volume rééquilibré.' : 'Volume rééquilibré (reconstruction des crêtes indisponible).') + '</span></div>' +
        files.map(f => '<div class="sona-file"><span class="mono">' + esc(f.split(/[\\/]/).pop()) + '</span><button class="btn small" type="button" data-rev="' + esc(f) + '">Afficher dans le Finder</button></div>').join('') +
        '<p class="hint" style="margin:0">Dans DaVinci Resolve : importe le WAV, pose-le sur une piste audio calé au tout début du clip (même durée), puis coupe le son d\'origine.</p>';
      $$('[data-rev]').forEach(b => { b.onclick = () => VC.api('/api/reveal', { path: b.dataset.rev }); });
    } catch (e) {
      VC.sound('error');
      $('#sOut').innerHTML = '<div class="sona-warn">' + esc(e.message) + '</div>';
    }
    S.busy = false; go.disabled = false;
  }

  const ICON = '<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><path d="M3 12h2M7 8v8M11 4v16M15 7v10M19 10v4M21 12h0"/></svg>';
  VC.sonagadIcon = ICON;
})();
