"""SONAGAD : répare le son saturé (écrêté) d'un long enregistrement, par exemple un DJ set filmé.

1. analyse() lit l'audio en flux (sans tout charger en mémoire) et trouve à partir de quand ça sature.
2. preview() fabrique un extrait avant / après pour comparer à l'oreille.
3. repair() reconstruit les crêtes écrêtées (filtre adeclip de ffmpeg) uniquement à partir de ce moment,
   ramène progressivement le volume au niveau du reste du set, puis passe un limiteur à -1 dB.
   Résultat : un WAV 48 kHz / 24 bits de la même durée que la vidéo (synchro parfaite dans DaVinci),
   et en option la vidéo avec le son réparé (image copiée telle quelle, sans réencodage).
"""
import subprocess
from pathlib import Path

import numpy as np

from engine import config, media

SR = 48000
EDGES = -6.0 + 0.02 * np.arange(301)  # bins de -6 à 0 dBFS (pas de 0,02 dB)
WORK = config.DATA / "sonagad"
_HAS = {}


def _ff():
    media.have_ffmpeg()
    return media.FFMPEG


def has_declip():
    ff = _ff()
    if ff not in _HAS:
        try:
            out = subprocess.run([ff, "-hide_banner", "-filters"], capture_output=True, text=True, timeout=20, **media.NOWIN).stdout
            _HAS[ff] = " adeclip " in out
        except (OSError, subprocess.SubprocessError):
            _HAS[ff] = False
    return _HAS[ff]


def hms(sec):
    sec = int(round(sec))
    return "%d:%02d:%02d" % (sec // 3600, (sec % 3600) // 60, sec % 60)


# ---------- 1. Analyse ----------
def analyse(path, progress=None, cancelled=lambda: False, on_proc=None):
    path = Path(path)
    meta = info(path)
    dur = meta["duration"]
    cmd = [_ff(), "-v", "error", "-i", str(path), "-vn", "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, **media.NOWIN)
    on_proc and on_proc(proc)
    n = SR * 2
    hists, rms = [], []
    ceiling = 0.0
    try:
        while True:
            if cancelled():
                proc.kill()
                raise RuntimeError("Analyse annulée.")
            buf = proc.stdout.read(n * 4)
            if not buf:
                break
            x = np.frombuffer(buf[: len(buf) // 4 * 4], dtype=np.float32)
            if x.size < 2:
                break
            a = np.abs(x)
            ceiling = max(ceiling, float(a.max()))
            db = 20 * np.log10(a[a > 0.5] + 1e-12)
            hists.append(np.histogram(np.clip(db, -6, 5.99), bins=np.append(EDGES, 6.0))[0])
            rms.append(float(np.sqrt(np.mean(x.astype(np.float64) ** 2)) + 1e-12))
            if progress and dur and len(rms) % 20 == 0:
                progress(min(0.99, len(rms) / dur))
    finally:
        proc.wait()
    if not rms:
        raise RuntimeError("Aucun son trouvé dans ce fichier.")
    hists, rms = np.array(hists), np.array(rms)

    # Niveau de référence = 99,9e centile des crêtes de tout l'enregistrement. Un son écrêté (même après
    # compression AAC/MP4, qui fait déborder les crêtes) passe beaucoup plus de temps près de ce niveau.
    spb = SR * 2
    tot = hists.sum(axis=0)[::-1].cumsum()[::-1]
    ref = int(np.searchsorted(-tot, -spb * len(hists) * 0.001))
    ref = min(max(ref, 0), len(EDGES) - 1)
    lo = max(0, ref - 75)  # 1,5 dB sous la référence
    rate = hists[:, lo:].sum(axis=1) / spb
    crest = 20 * np.log10((10 ** (EDGES[lo] / 20)) / rms)
    bad = (rate > 0.01) & (crest < 9)
    k = 10
    dens = np.convolve(bad.astype(float), np.ones(k) / k, mode="same")
    idx = np.where(dens >= 0.5)[0]
    start = max(0, int(idx[0]) - k // 2) if idx.size else None

    level = 20 * np.log10(rms)
    drop = suggest_drop(level, start)
    # Courbe allégée pour l'affichage (au plus 1500 points)
    step = max(1, int(np.ceil(len(level) / 1500)))
    m = len(level) // step * step
    lv = level[:m].reshape(-1, step).max(axis=1) if m else level
    bd = bad[:m].reshape(-1, step).mean(axis=1) if m else bad.astype(float)
    codec = next((s["codec_name"] for s in meta["streams"] if s["codec_type"] == "audio"), "")
    return {"path": str(path), "name": path.name, "duration": float(len(level)), "start": start,
            "drop_db": drop, "bad_seconds": int(bad.sum()), "ceiling_db": round(20 * np.log10(ceiling + 1e-12), 2),
            "step": step, "levels": [round(float(v), 1) for v in lv], "bad": [round(float(v), 2) for v in bd],
            "codec": codec, "lossy": codec not in ("", "pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm_f32le", "pcm_s16be",
                                                   "pcm_s24be", "pcm_s32be", "pcm_f32be", "flac", "alac"),
            "has_video": any(s["codec_type"] == "video" for s in meta["streams"]), "declip": has_declip()}


def suggest_drop(level, start):
    """Baisse (dB) pour ramener la partie saturée au niveau des 5 minutes qui la précèdent."""
    if start is None:
        return 0.0
    before, after = level[max(0, start - 300):start], level[start:]
    if before.size < 30 or not after.size:
        return 6.0
    return round(float(np.clip(np.median(after) - np.median(before), 0.0, 18.0)), 1)


def info(path):
    """Durée et pistes lues dans la sortie de « ffmpeg -i » (marche aussi pour un simple fichier audio)."""
    import re
    try:
        err = subprocess.run([_ff(), "-hide_banner", "-i", str(path)], capture_output=True, text=True, timeout=60, **media.NOWIN).stderr
    except (OSError, subprocess.SubprocessError) as e:
        raise RuntimeError("Impossible de lire ce fichier : %s" % e)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", err)
    streams = []
    for line in err.splitlines():
        sm = re.search(r"Stream #.*?(Audio|Video):\s*([\w-]+)", line)
        if sm and "attached pic" not in line:
            streams.append({"codec_type": sm.group(1).lower(), "codec_name": sm.group(2)})
    if not any(s["codec_type"] == "audio" for s in streams):
        raise RuntimeError("Ce fichier ne contient pas de son.")
    dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.0
    return {"duration": dur, "streams": streams}


# ---------- 2. Filtre ----------
def build_filter(start, drop_db, fade=20.0, offset=0.0, declip=True):
    """Chaîne de filtres ; offset = début de l'extrait traité (pour les écoutes avant/après)."""
    g = 10 ** (-abs(drop_db) / 20)
    t0 = max(0.0, start - fade / 2) - offset
    vol = "if(lt(t,%.3f),1,if(lt(t,%.3f),1+(%.6f-1)*(t-(%.3f))/%.3f,%.6f))" % (t0, t0 + fade, g, t0, fade, g)
    parts = ["aformat=sample_fmts=dblp"]
    if declip:
        dc = max(0.0, start - 10) - offset  # on commence 10 s avant par sécurité
        parts.append("adeclip=window=55:overlap=75:arorder=8:threshold=10:hsize=1000:enable='gte(t,%.3f)'" % dc)
    parts.append("volume='%s':eval=frame:precision=double" % vol)
    parts.append("alimiter=limit=0.89:attack=5:release=50:level=disabled")
    return ",".join(parts)


# ---------- 3. Écoute avant / après ----------
def preview(path, start, drop_db, at, secs=20.0, fade=20.0):
    WORK.mkdir(parents=True, exist_ok=True)
    for f in WORK.glob("ecoute-*.wav"):
        f.unlink(missing_ok=True)
    tag = "%d" % int(at * 10)
    before, after = WORK / ("ecoute-avant-%s.wav" % tag), WORK / ("ecoute-apres-%s.wav" % tag)
    g = 10 ** (-abs(drop_db) / 20)
    base = [_ff(), "-y", "-v", "error", "-ss", "%.3f" % at, "-t", "%.3f" % secs, "-i", str(path), "-vn", "-ac", "2", "-ar", str(SR)]
    # « Avant » : le son d'origine au même volume, pour comparer la distorsion et pas le niveau
    _run(base + ["-af", "volume=%.6f" % (g if at >= start else 1.0), "-c:a", "pcm_s16le", str(before)])
    _run(base + ["-af", build_filter(start, drop_db, fade, offset=at, declip=has_declip()), "-c:a", "pcm_s16le", str(after)])
    return {"before": before.name, "after": after.name, "at": at}


def _run(cmd):
    p = subprocess.run(cmd, capture_output=True, **media.NOWIN)
    if p.returncode != 0:
        raise RuntimeError("ffmpeg : " + p.stderr.decode("utf-8", "replace")[-400:])


# ---------- 4. Réparation complète ----------
def repair(path, start, drop_db, fade=20.0, video=False, progress=None, cancelled=lambda: False, on_proc=None):
    path = Path(path)
    dur = info(path)["duration"]
    out_wav = _free(path.with_name(path.stem + "_desature.wav"))
    tmp = out_wav.with_name(out_wav.stem + ".part.wav")
    declip = has_declip()
    cmd = [_ff(), "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-i", str(path), "-vn", "-ac", "2", "-ar", str(SR),
           "-af", build_filter(start, drop_db, fade, declip=declip), "-c:a", "pcm_s24le", str(tmp)]
    _follow(cmd, dur, lambda f: progress and progress(f * (0.9 if video else 1.0)), cancelled, on_proc, tmp)
    tmp.replace(out_wav)
    result = {"wav": str(out_wav), "video": None, "declip": declip}
    if video:
        out_mov = _free(path.with_name(path.stem + "_desature.mov"))
        tmpv = out_mov.with_name(out_mov.stem + ".part.mov")
        cmd = [_ff(), "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-i", str(path), "-i", str(out_wav),
               "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "pcm_s24le", "-shortest", str(tmpv)]
        _follow(cmd, dur, lambda f: progress and progress(0.9 + 0.1 * f), cancelled, on_proc, tmpv)
        tmpv.replace(out_mov)
        result["video"] = str(out_mov)
    return result


def _free(p):
    i = 2
    out = p
    while out.exists():
        out = p.with_name("%s %d%s" % (p.stem, i, p.suffix))
        i += 1
    return out


def _follow(cmd, dur, progress, cancelled, on_proc, tmp):
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **media.NOWIN)
    on_proc and on_proc(proc)
    for raw in proc.stdout:
        if cancelled():
            proc.kill()
            break
        line = raw.decode("utf-8", "replace")
        if line.startswith("out_time_us=") and dur:
            try:
                progress(min(0.99, int(line.split("=")[1]) / 1e6 / dur))
            except ValueError:
                pass
    proc.wait()
    if cancelled():
        Path(tmp).unlink(missing_ok=True)
        raise RuntimeError("Réparation annulée.")
    if proc.returncode != 0:
        Path(tmp).unlink(missing_ok=True)
        raise RuntimeError("ffmpeg : " + (proc.stderr.read() or b"").decode("utf-8", "replace")[-400:])
