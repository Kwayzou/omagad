/* Accueil : choix du module (Clipagad, et un second module à venir). */
(function () {
  const { $ } = VC;
  VC.screens.home = function () {
    $('#view').innerHTML = '<div class="home">' +
      '<button type="button" class="mod mod-clip" id="modClip">' +
      '<span class="mod-glow"></span>' +
      '<img src="/ui/logo.png" alt="" class="mod-logo" width="132" height="132">' +
      '<span class="mod-name">CLIPAGAD</span>' +
      '<span class="mod-sub">Tes vlogs transformés en clips verticaux pour TikTok, Reels et Shorts</span>' +
      '<span class="btn primary big mod-go">Ouvrir</span></button>' +
      '<button type="button" class="mod mod-live" id="modLive">' +
      '<span class="mod-glow live"></span>' +
      '<span class="mod-eq" aria-hidden="true">' + Array.from({ length: 9 }, (_, i) => '<i style="--i:' + i + '"></i>').join('') + '</span>' +
      '<span class="mod-name">LIVEAGAD</span>' +
      '<span class="mod-sub">Glisse la timeline DaVinci de ta date : des dizaines de clips de ton set, montés et exportés tout seuls</span>' +
      '<span class="btn primary big mod-go">Ouvrir</span></button>' +
      '</div>';
    $('#modClip').onclick = () => { VC.sound('tick'); VC.go('import'); };
    $('#modLive').onclick = () => { VC.sound('tick'); VC.go('live'); };
    VC._homeReady && VC._homeReady();
  };
})();
