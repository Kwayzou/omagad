/* Opérations de montage : couper (lame), décaler finement. */
(function () {
  const r3 = v => Math.round(v * 1000) / 1000;

  /* Coupe un moment en deux clips à l'instant t (secondes du vlog) */
  VC.splitMoment = function (m, t) {
    if (!(t > m.t0 + .5 && t < m.t1 - .5)) return VC.toast('Coupe trop près du bord du moment.');
    const p = VC.S.project, cut = t - m.t0;
    const n = Math.max(0, ...p.moments.map(x => parseInt(String(x.id).slice(1), 10) || 0)) + 1;
    const b = VC.clone(m);
    b.id = 'm' + n; b.t0 = r3(t); b.status = 'todo'; b.hook_at = 0;
    m.t1 = r3(t);
    if (m.subs) { b.subs = m.subs.filter(c => c.s >= t); m.subs = m.subs.filter(c => c.s < t); }
    if (Array.isArray(m.sfx)) { b.sfx = m.sfx.filter(s => s.at >= cut).map(s => Object.assign(s, { at: r3(s.at - cut), link: null })); m.sfx = m.sfx.filter(s => s.at < cut); }
    if (m.media) {
      b.media = []; const keep = [];
      for (const it of m.media) {
        if (it.at >= cut) b.media.push(Object.assign(VC.clone(it), { at: r3(it.at - cut) }));
        else if (it.at + it.dur > cut) {
          const rest = VC.clone(it); rest.id = VC.uid('md'); rest.at = 0; rest.dur = r3(it.at + it.dur - cut);
          if (rest.kind === 'video') rest.from = r3((it.from || 0) + cut - it.at);
          b.media.push(rest);
          keep.push(Object.assign(it, { dur: r3(cut - it.at) }));
        } else keep.push(it);
      }
      m.media = keep;
    }
    const shiftKeys = k => k ? k.filter(x => x[0] >= cut).map(x => [r3(x[0] - cut), x[1]]) : k;
    if (b.frame) { b.frame.keys = shiftKeys(b.frame.keys); b.frame.zooms = shiftKeys(b.frame.zooms); if (b.frame.zooms && !b.frame.zooms.length) b.frame.zooms = [[0, 1]]; }
    p.moments.splice(p.moments.indexOf(m) + 1, 0, b);
    VC.commit(true); VC.renderList(); VC.drawTimeline();
    VC.toast('Moment coupé en deux clips', 1800);
  };

  /* Coupe un sous-titre ou un média à l'instant t */
  VC.splitItem = function (track, key, t) {
    const m = VC.cur(); if (!m || key == null) return;
    const rel = t - m.t0;
    if (track === 'subs') {
      const subs = VC.ownSubs(m), c = subs[key]; if (!c || !(t > c.s + .05 && t < c.e - .05)) return;
      let a = c.words.filter(w => (w.s + w.e) / 2 < t), b = c.words.filter(w => (w.s + w.e) / 2 >= t);
      if (!a.length || !b.length) {  // un seul mot : on coupe le texte par moitié de durée
        const w = c.words[0], parts = (w ? w.w : 'TEXTE').split(/\s+/);
        a = [{ w: parts.slice(0, Math.ceil(parts.length / 2)).join(' ') || '…', s: c.s, e: t }];
        b = [{ w: parts.slice(Math.ceil(parts.length / 2)).join(' ') || '…', s: t, e: c.e }];
      }
      subs.splice(key, 1, { s: c.s, e: r3(t), words: a }, { s: r3(t), e: c.e, words: b });
    } else if (track === 'media') {
      const it = (m.media || [])[key]; if (!it || !(rel > it.at + .1 && rel < it.at + it.dur - .1)) return;
      const b = VC.clone(it); b.id = VC.uid('md'); b.at = r3(rel); b.dur = r3(it.at + it.dur - rel);
      if (b.kind === 'video') b.from = r3((it.from || 0) + rel - it.at);
      it.dur = r3(rel - it.at); m.media.splice(key + 1, 0, b);
    } else return VC.toast('La lame coupe les moments, les sous-titres et les médias.');
    VC.invalidate(); VC.commit(true); VC.renderInspector(); VC.drawTimeline();
  };

  VC.splitAtPlayhead = function () {
    const v = VC.vid(), m = VC.cur(); if (!v || !m) return;
    const t = v.currentTime, it = VC.S.item;
    if (it && (it.track === 'subs' || it.track === 'media')) return VC.splitItem(it.track, it.key, t);
    VC.splitMoment(m, t);
  };

  /* Décale finement l'élément sélectionné (son, sous-titre, média, accroche) */
  VC.nudgeItem = function (d) {
    const m = VC.cur(), it = VC.S.item; if (!m) return;
    if (!it) { const v = VC.vid(); if (v) v.currentTime += d; return; }
    if (it.track === 'sfx') { const s = VC.ownSfx(m)[it.key]; if (!s) return; s.at = r3(Math.max(-3, s.at + d)); s.link = null; VC.toast('Son à ' + s.at.toFixed(3).replace('.', ',') + ' s', 900); }
    else if (it.track === 'subs') { const c = VC.ownSubs(m)[it.key]; if (!c) return; c.s = r3(c.s + d); c.e = r3(c.e + d); c.words.forEach(w => { w.s = r3(w.s + d); w.e = r3(w.e + d); }); }
    else if (it.track === 'media') { const md = m.media[it.key]; if (!md) return; md.at = r3(Math.max(0, md.at + d)); }
    else if (it.track === 'hook') VC.moveHook(m, VC.hookAt(m) + d);
    VC.invalidate(); VC.commit(); VC.drawTimeline();
  };
})();
