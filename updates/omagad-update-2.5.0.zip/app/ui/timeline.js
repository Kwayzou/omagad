/* Timeline multipiste : Vidéo (moments + forme d'onde), Accroche, Sous-titres, Sons, Médias.
   Tout se déplace et se recoupe à la souris ; un clic ouvre le bon réglage à droite. */
(function () {
  const { $, fmt, clamp, esc } = VC;
  const TL = { a: 0, b: 60, follow: true, collapsed: false, drag: null, hover: null, lastT: -1, dirty: true };
  let Y = { mini: [4, 16], ruler: [20, 38], video: [42, 90], hook: [94, 118], subs: [122, 146], sfx: [150, 180], media: [184, 214] };
  /* Les pistes se partagent la hauteur disponible (timeline redimensionnable) */
  function relayout(h) {
    const top = 42, gap = 4, avail = Math.max(70, h - top - 6 - gap * 4);
    const w = { video: .28, hook: .15, subs: .17, sfx: .2, media: .2 }, min = { video: 18, hook: 12, subs: 12, sfx: 14, media: 14 };
    let y = top; const out = { mini: [4, 16], ruler: [20, 38] };
    for (const k of ['video', 'hook', 'subs', 'sfx', 'media']) { const hh = Math.max(min[k], Math.round(avail * w[k])); out[k] = [y, y + hh]; y += hh + gap; }
    Y = out;
    document.querySelectorAll('.tl-label[data-k]').forEach(el => { const r = Y[el.dataset.k]; el.style.top = r[0] + 'px'; el.style.height = (r[1] - r[0]) + 'px'; el.classList.toggle('tiny', r[1] - r[0] < 20); });
  }
  const TRACKS = [['video', 'Vidéo', null], ['hook', 'Accroche', null], ['subs', 'Sous-titres', 'sub'], ['sfx', 'Sons', 'sfx'], ['media', 'Médias', 'media']];
  const TOOLS = [
    ['select', 'Sélection (A)', '<svg viewBox="0 0 20 20" width="16" height="16"><path d="M5 3l10 6-4.5 1.2L13 16l-2 1-2.6-5.6L5 14z" fill="currentColor"/></svg>'],
    ['blade', 'Lame : cliquer pour couper (B)', '<svg viewBox="0 0 20 20" width="16" height="16"><path d="M4 16L14 4l2 2L6 18z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M3 17l2 1" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>'],
    ['hand', 'Main : déplacer la vue (H)', '<svg viewBox="0 0 20 20" width="16" height="16"><path d="M7 10V4.5a1.2 1.2 0 012.4 0V9m0-4.8a1.2 1.2 0 012.4 0V9m0-3.6a1.2 1.2 0 012.4 0V10m0-2.4a1.2 1.2 0 012.4 0V12c0 3-2 5-5 5h-1c-2 0-3-1-4-2.5L4 11.5a1.2 1.2 0 012-1.4L7 11.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>']];
  VC.S.tool = VC.S.tool || 'select';
  VC.setTool = function (t) {
    VC.S.tool = t;
    document.querySelectorAll('#tlTools .tool').forEach(b => b.classList.toggle('on', b.dataset.tool === t));
    if (cv) cv.style.cursor = t === 'hand' ? 'grab' : t === 'blade' ? 'crosshair' : '';
    TL.dirty = true; VC.drawTimeline && VC.drawTimeline();
  };
  const COL = { hook: '#d4a81c', subs: '#4f6488', sfx: '#7b55e0', media: '#16a06c' };
  let cv, g, W = 0, Hh = 0, dpr = 1;
  const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
  const dur = () => (VC.S.project && VC.S.project.info.duration) || 60;
  const X = t => (t - TL.a) / (TL.b - TL.a) * W;
  const T = x => TL.a + x / W * (TL.b - TL.a);
  const MX = t => t / dur() * W;
  const r2 = v => Math.round(v * 100) / 100;

  try { TL.collapsed = localStorage.getItem('vc-tl-collapsed') === '1'; } catch (e) {}

  VC.buildTimeline = function (dock) {
    dock.classList.toggle('collapsed', TL.collapsed);
    dock.innerHTML = '<div class="dock-head"><span class="label">Timeline</span><span class="hint mono" id="tlSpan"></span><span style="flex:1"></span>' +
      '<button class="icon-btn" type="button" id="tlOut" title="Dézoomer (-)"><svg viewBox="0 0 20 20"><path d="M4 10h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>' +
      '<input type="range" class="zoom" id="tlZoom" min="0" max="1000" aria-label="Zoom de la timeline">' +
      '<button class="icon-btn" type="button" id="tlIn" title="Zoomer (+)"><svg viewBox="0 0 20 20"><path d="M4 10h12M10 4v12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>' +
      '<div class="tools" id="tlTools">' + TOOLS.map(t => '<button type="button" class="tool" data-tool="' + t[0] + '" title="' + t[1] + '">' + t[2] + '</button>').join('') + '</div><span class="sep"></span>' +
      '<button class="btn small ghost" type="button" id="tlAll">Tout le vlog</button><button class="btn small ghost" type="button" id="tlFit">Ce moment</button><span class="sep"></span>' +
      '<label class="check hint"><input type="checkbox" id="tlFollow"> Suivre la lecture</label><span class="sep"></span>' +
      '<button class="icon-btn" type="button" id="tlCollapse" title="Réduire ou agrandir la timeline"><svg viewBox="0 0 20 20"><path d="M5 8l5 5 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>' +
      '<div class="dock-body"><div class="tl-labels">' + TRACKS.map(t => '<div class="tl-label" data-k="' + t[0] + '" style="top:' + Y[t[0]][0] + 'px;height:' + (Y[t[0]][1] - Y[t[0]][0]) + 'px">' +
        '<i style="background:' + (COL[t[0]] || 'var(--blue)') + '"></i><span>' + t[1] + '</span>' + (t[2] ? '<button type="button" data-add="' + t[2] + '" title="Ajouter à la tête de lecture">+</button>' : '') + '</div>').join('') +
      '</div><div class="tl-canvas"><canvas id="tl"></canvas></div></div>';
    cv = $('#tl'); g = cv.getContext('2d');
    new ResizeObserver(() => { TL.dirty = true; VC.drawTimeline(); }).observe(dock.querySelector('.tl-canvas'));
    $('#tlOut').onclick = () => zoom(1.6);
    $('#tlIn').onclick = () => zoom(1 / 1.6);
    $('#tlAll').onclick = () => setView(0, dur());
    $('#tlFit').onclick = () => { const m = VC.cur(); if (m) fit(m); };
    $('#tlZoom').oninput = e => { const span = spanFromSlider(+e.target.value), c = (TL.a + TL.b) / 2; setView(c - span / 2, c + span / 2, true); };
    $('#tlFollow').checked = TL.follow; $('#tlFollow').onchange = e => { TL.follow = e.target.checked; };
    $('#tlCollapse').onclick = () => {
      TL.collapsed = !TL.collapsed; dock.classList.toggle('collapsed', TL.collapsed);
      $('#tlCollapse').style.transform = TL.collapsed ? 'rotate(180deg)' : ''; try { localStorage.setItem('vc-tl-collapsed', TL.collapsed ? '1' : '0'); } catch (e) {}
      VC.layoutVideo();
    };
    $('#tlCollapse').style.transform = TL.collapsed ? 'rotate(180deg)' : '';
    dock.querySelector('#tlTools').onclick = e => { const b = e.target.closest('[data-tool]'); if (b) VC.setTool(b.dataset.tool); };
    VC.setTool(VC.S.tool);
    dock.querySelector('.tl-labels').onclick = e => { const b = e.target.closest('[data-add]'); if (b) VC.addAtPlayhead(b.dataset.add); };
    cv.addEventListener('wheel', onWheel, { passive: false });
    cv.addEventListener('pointerdown', onDown);
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerup', onUp);
    cv.addEventListener('pointercancel', onUp);
    cv.addEventListener('pointerleave', () => { TL.hover = null; TL.mouseX = null; TL.dirty = true; });
    cv.addEventListener('dblclick', e => { const h = hit(e); if (h.track === 'video' && h.m) fit(h.m); });
    const m = VC.cur(); if (m) fit(m); else setView(0, dur());
  };

  /* ---------- Vue et zoom ---------- */
  const MIN = 3;
  function spanFromSlider(v) { return MIN * Math.pow(dur() / MIN, 1 - v / 1000); }
  function sliderFromSpan(s) { return Math.round((1 - Math.log(s / MIN) / Math.log(Math.max(1.0001, dur() / MIN))) * 1000); }
  function setView(a, b, fromSlider) {
    const span = clamp(b - a, Math.min(MIN, dur()), dur());
    a = clamp(a, 0, dur() - span); TL.a = a; TL.b = a + span;
    if (!fromSlider && $('#tlZoom')) $('#tlZoom').value = sliderFromSpan(span);
    if ($('#tlSpan')) $('#tlSpan').textContent = 'Vue : ' + fmt(span) + ' sur ' + fmt(dur());
    TL.dirty = true; VC.drawTimeline();
  }
  function zoom(f, at) {
    const v = VC.vid(), c = at == null ? (v && v.currentTime >= TL.a && v.currentTime <= TL.b ? v.currentTime : (TL.a + TL.b) / 2) : at;
    const r = (c - TL.a) / (TL.b - TL.a), span = clamp((TL.b - TL.a) * f, Math.min(MIN, dur()), dur());
    setView(c - span * r, c - span * r + span);
  }
  VC.zoomTimeline = zoom;
  function fit(m) { const pad = Math.max(1.5, (m.t1 - m.t0) * .08); setView(m.t0 - pad, m.t1 + pad); }
  VC.revealInTimeline = function (m) { if (m.t0 < TL.a || m.t1 > TL.b || (TL.b - TL.a) > (m.t1 - m.t0) * 4) fit(m); };

  /* ---------- Éléments des pistes (moment sélectionné) ---------- */
  function items(track, m) {
    if (!m) return [];
    if (track === 'hook') {
      if (!(m.hook || '').trim()) return [];
      const a = m.t0 + VC.hookAt(m); return [{ key: 'hook', a, b: Math.min(m.t1, a + +VC.style(m).hook_secs), label: m.hook.replace(/\n/g, ' ') }];
    }
    if (track === 'subs') return VC.chunksOf(m).map((c, i) => ({ key: i, a: c.s, b: Math.max(c.e, c.s + .15), label: c.words.map(w => w.w).join(' ') }));
    if (track === 'sfx') return VC.sfxOf(m).map((s, i) => ({ key: i, a: m.t0 + s.at, b: m.t0 + s.at + VC.sfxDur(s.sound), label: VC.sfxLabel(s.sound), vol: s.vol }));
    if (track === 'media') return (m.media || []).map((it, i) => ({ key: i, a: m.t0 + it.at, b: m.t0 + it.at + it.dur, label: VC.t(it.kind === 'image' ? 'Photo' : 'Vidéo') + ' · ' + (it.name || '') }));
    return [];
  }
  const isSel = (track, key) => VC.S.item && VC.S.item.track === track && VC.S.item.key === key;

  /* ---------- Dessin ---------- */
  VC.drawTimeline = function () {
    if (!cv || !VC.S.project) return;
    const box = cv.parentElement; if (!box.clientWidth) return;
    dpr = Math.min(2, window.devicePixelRatio || 1);
    // on compare aussi la taille réelle du canvas : un canvas recréé repart en 300×150 (timeline floue et géante)
    const bw = box.clientWidth, bh = box.clientHeight;
    if (W !== bw || Hh !== bh || cv.width !== Math.round(bw * dpr) || cv.height !== Math.round(bh * dpr)) {
      W = bw; Hh = bh; cv.width = Math.round(W * dpr); cv.height = Math.round(Hh * dpr); relayout(Hh);
    }
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const C = { bg: css('--bg-2'), panel: css('--panel'), line: css('--line'), line2: css('--line-2'), fg: css('--fg'), muted: css('--muted'), blue: css('--blue'), cyan: css('--cyan'), ok: css('--ok'), danger: css('--danger') };
    const p = VC.S.project, sel = VC.cur(), t = VC.vid() ? VC.vid().currentTime : 0;
    g.clearRect(0, 0, W, Hh); g.fillStyle = C.bg; g.fillRect(0, 0, W, Hh);
    // mini-carte
    g.fillStyle = C.panel; g.fillRect(0, Y.mini[0], W, Y.mini[1] - Y.mini[0]);
    for (const m of p.moments) { g.fillStyle = colorOf(m, C, m === sel); g.fillRect(MX(m.t0), Y.mini[0] + 3, Math.max(2, MX(m.t1) - MX(m.t0)), 6); }
    g.strokeStyle = C.cyan; g.lineWidth = 1.5; g.strokeRect(MX(TL.a) + .5, Y.mini[0] + .5, Math.max(4, MX(TL.b) - MX(TL.a)) - 1, Y.mini[1] - Y.mini[0] - 1);
    g.fillStyle = C.fg; g.fillRect(MX(t), Y.mini[0], 1.5, Y.mini[1] - Y.mini[0]);
    // règle
    const span = TL.b - TL.a, steps = [.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800];
    const st = steps.find(s => s / span * W >= 80) || 1800, minor = st / 5;
    g.font = '10px ' + css('--mono'); g.textBaseline = 'top';
    for (let i = Math.ceil(TL.a / minor); i * minor <= TL.b; i++) {
      const x = Math.round(i * minor * 100) / 100, px = Math.round(X(x)) + .5, major = i % 5 === 0;
      g.fillStyle = major ? C.line2 : C.line; g.fillRect(px, major ? Y.ruler[0] + 8 : Y.ruler[0] + 13, 1, major ? 10 : 5);
      if (major) { g.fillStyle = C.muted; g.fillText(st < 1 ? fmt(x, true) : fmt(x), px + 3, Y.ruler[0]); }
    }
    // fonds des pistes
    for (const k of ['video', 'hook', 'subs', 'sfx', 'media']) { g.fillStyle = C.panel; g.fillRect(0, Y[k][0], W, Y[k][1] - Y[k][0]); }
    // piste vidéo : forme d'onde + moments
    const wv = VC.S.wave, peaks = wv && wv.peaks, ps = wv ? wv.per_sec : 10, mid = (Y.video[0] + Y.video[1]) / 2, amp = (Y.video[1] - Y.video[0]) / 2 - 2;
    if (peaks && peaks.length) drawWave(peaks, wv.rmsA, ps, mid, amp);
    g.font = '600 11px ' + css('--font'); g.textBaseline = 'middle';
    for (const m of p.moments) {
      const x0 = X(m.t0), x1 = X(m.t1); if (x1 < 0 || x0 > W) continue;
      const on = m === sel;
      g.globalAlpha = on ? .55 : .35; g.fillStyle = colorOf(m, C, on); rr(x0, Y.video[0] + 2, Math.max(3, x1 - x0), Y.video[1] - Y.video[0] - 4, 6); g.fill(); g.globalAlpha = 1;
      if (on) { g.strokeStyle = '#fff'; g.lineWidth = 1.5; rr(x0, Y.video[0] + 2, Math.max(3, x1 - x0), Y.video[1] - Y.video[0] - 4, 6); g.stroke();
        const hm = (Y.video[0] + Y.video[1]) / 2, hh = Math.min(20, (Y.video[1] - Y.video[0]) * .45); g.fillStyle = '#fff'; g.fillRect(x0 + 2, hm - hh / 2, 3, hh); g.fillRect(x1 - 5, hm - hh / 2, 3, hh); }
      label(m.hook ? m.hook.replace(/\n/g, ' ') + '  ·  ' + Math.round(m.t1 - m.t0) + ' s' : VC.t('Moment') + ' · ' + Math.round(m.t1 - m.t0) + ' s', x0, x1, Y.video[0] + Math.min(12, (Y.video[1] - Y.video[0]) / 2), '#fff');
    }
    // zooms sur les cuts du moment sélectionné
    if (sel && sel.frame && sel.frame.zcfg && sel.frame.zcfg.on && sel.frame.zooms) {
      g.font = '600 9.5px ' + css('--mono');
      for (const [r, z] of sel.frame.zooms.slice(1)) {
        const x = X(sel.t0 + r); if (x < 0 || x > W) continue;
        g.fillStyle = '#ffd34d'; g.beginPath(); g.moveTo(x, Y.video[1] - 12); g.lineTo(x + 4, Y.video[1] - 7); g.lineTo(x, Y.video[1] - 2); g.lineTo(x - 4, Y.video[1] - 7); g.fill();
        if (TL.b - TL.a < 40) { g.fillStyle = '#ffd34d'; g.fillText('x' + z.toFixed(2), x + 6, Y.video[1] - 7); }
      }
    }
    // pistes du moment sélectionné
    if (sel) {
      g.globalAlpha = .07; g.fillStyle = '#fff'; g.fillRect(X(sel.t0), Y.hook[0], X(sel.t1) - X(sel.t0), Y.media[1] - Y.hook[0]); g.globalAlpha = 1;
      for (const k of ['hook', 'subs', 'sfx', 'media']) {
        g.font = (k === 'subs' ? '' : '600 ') + '10.5px ' + css('--font');
        for (const it of items(k, sel)) {
          const x0 = X(it.a), x1 = X(it.b); if (x1 < 0 || x0 > W) continue;
          const y0 = Y[k][0] + 2, h = Y[k][1] - Y[k][0] - 4, on = isSel(k, it.key), hov = TL.hover && TL.hover.track === k && TL.hover.key === it.key;
          g.fillStyle = COL[k]; g.globalAlpha = on ? 1 : hov ? .9 : .72; rr(x0, y0, Math.max(3, x1 - x0 - 1), h, 4); g.fill(); g.globalAlpha = 1;
          if (k === 'sfx') {  // niveau sonore : barre claire, poignée en haut
            const vh = clamp(it.vol / 1.5, 0, 1) * (h - 4);
            g.fillStyle = 'rgba(255,255,255,.22)'; g.fillRect(x0 + 1, y0 + h - 2 - vh, Math.max(2, x1 - x0 - 3), vh);
            g.fillStyle = '#fff'; g.fillRect(x0 + 1, y0 + h - 3 - vh, Math.max(2, x1 - x0 - 3), 1.5);
          }
          if (on) { g.strokeStyle = '#fff'; g.lineWidth = 1.5; rr(x0, y0, Math.max(3, x1 - x0 - 1), h, 4); g.stroke(); }
          label(it.label + (k === 'sfx' ? '  ' + Math.round(it.vol * 100) + ' %' : ''), x0, x1, y0 + h / 2, '#fff', 5);
        }
      }
    }
    // lame : ligne de coupe sous la souris
    if (VC.S.tool === 'blade' && TL.mouseX != null && !TL.drag) { g.fillStyle = '#ff5c6c'; g.fillRect(Math.round(TL.mouseX), Y.video[0], 1.5, Y.media[1] - Y.video[0]); }
    // tête de lecture
    const ph = X(t);
    if (ph >= 0 && ph <= W) { g.fillStyle = C.fg; g.fillRect(Math.round(ph) - .5, Y.ruler[0], 1.5, Hh - Y.ruler[0]); g.beginPath(); g.moveTo(ph - 5, Y.ruler[0]); g.lineTo(ph + 5, Y.ruler[0]); g.lineTo(ph, Y.ruler[0] + 7); g.fill(); }
    TL.dirty = false; TL.lastT = t;
  };
  /* Vraie forme d'onde : crête (contour) + niveau moyen (cœur), lissée, symétrique */
  function drawWave(peaks, rms, ps, mid, amp) {
    const n = peaks.length, step = .5, cols = Math.ceil(W / step) + 1;
    const top = new Float32Array(cols), core = new Float32Array(cols);
    for (let c = 0; c < cols; c++) {
      const xa = c * step, ta = T(xa) * ps, tb = T(xa + step) * ps;
      let pk = 0, rm = 0;
      if (tb - ta >= 1) {            // plusieurs points par colonne : on garde la crête
        const i0 = Math.max(0, Math.floor(ta)), i1 = Math.min(n, Math.ceil(tb));
        let sum = 0, k = 0;
        for (let i = i0; i < i1; i++) { if (peaks[i] > pk) pk = peaks[i]; if (rms) { sum += rms[i]; k++; } }
        rm = k ? sum / k : 0;
      } else {                       // zoom fort : interpolation entre deux points
        const i = Math.floor(ta), f = ta - i;
        if (i >= 0 && i < n) {
          const j = Math.min(n - 1, i + 1);
          pk = peaks[i] * (1 - f) + peaks[j] * f;
          rm = rms ? rms[i] * (1 - f) + rms[j] * f : 0;
        }
      }
      top[c] = Math.min(1, pk / 255) * amp; core[c] = Math.min(1, rm / 255, pk / 255) * amp;
    }
    const shape = (arr, color) => {
      g.beginPath(); g.moveTo(0, mid - arr[0]);
      for (let c = 1; c < cols; c++) g.lineTo(c * step, mid - arr[c]);
      for (let c = cols - 1; c >= 0; c--) g.lineTo(c * step, mid + arr[c]);
      g.closePath(); g.fillStyle = color; g.fill();
    };
    shape(top, '#24467a');
    if (rms) shape(core, '#4f87dc');
    g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(0, Math.round(mid), W, 1);
  }
  function label(text, x0, x1, y, color, padL) {
    if (x1 - x0 < 26) return;
    const l = Math.max(0, x0) + (padL || 9), r = Math.min(W, x1) - 4; if (r - l < 12) return;
    g.save(); g.beginPath(); g.rect(l, y - 9, r - l, 18); g.clip(); g.fillStyle = color; g.fillText(text, l, y); g.restore();
  }
  function colorOf(m, C, on) { return m.status === 'ok' ? C.ok : m.status === 'skip' ? C.danger : on ? C.blue : '#1c4aa8'; }
  function rr(x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  VC.timelineTick = function (t) {
    if (!cv) return;
    const v = VC.vid();
    if (TL.follow && v && !v.paused && !TL.drag && (t > TL.b - (TL.b - TL.a) * .02 || t < TL.a)) { const s = TL.b - TL.a; setView(t - s * .1, t + s * .9); }
    if (TL.dirty || Math.abs(t - TL.lastT) > 1e-3) VC.drawTimeline();
  };

  /* ---------- Interactions ---------- */
  function pos(e) { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function trackAt(y) { for (const k of ['video', 'hook', 'subs', 'sfx', 'media']) if (y >= Y[k][0] && y <= Y[k][1]) return k; return null; }
  function hit(e) {
    const { x, y } = pos(e), sel = VC.cur();
    if (y <= Y.mini[1] + 1) return { zone: 'mini' };
    const track = trackAt(y);
    if (track === 'video') {
      if (sel) { if (Math.abs(x - X(sel.t0)) <= 7) return { track, m: sel, edge: 'l' }; if (Math.abs(x - X(sel.t1)) <= 7) return { track, m: sel, edge: 'r' }; }
      const t = T(x), m = VC.S.project.moments.filter(m => t >= m.t0 && t <= m.t1).sort((a, b) => (a.t1 - a.t0) - (b.t1 - b.t0))[0];
      return m ? { track, m } : { zone: 'seek' };
    }
    if (track && sel) {
      const list = items(track, sel);
      // éléments sélectionnés d'abord, puis du plus court au plus long (pour attraper les petits)
      const order = list.slice().sort((a, b) => (isSel(track, b.key) - isSel(track, a.key)) || ((a.b - a.a) - (b.b - b.a)));
      for (const it of order) {
        const x0 = X(it.a), x1 = X(it.b);
        if (x < x0 - 4 || x > x1 + 4) continue;
        let edge = null;
        if (track !== 'sfx') { if (Math.abs(x - x0) <= 6) edge = 'l'; else if (Math.abs(x - x1) <= 6) edge = 'r'; }
        const vh = track === 'sfx' ? clamp(it.vol / 1.5, 0, 1) * (Y.sfx[1] - Y.sfx[0] - 8) : 0;
        const volZone = track === 'sfx' && Math.abs(y - (Y.sfx[1] - 5 - vh)) <= 3;
        return { track, key: it.key, it, edge, vol: volZone };
      }
      return { zone: 'seek', track };
    }
    return { zone: 'seek' };
  }
  function onWheel(e) {
    e.preventDefault();
    const { x } = pos(e);
    if (e.ctrlKey || e.metaKey) zoom(Math.exp(e.deltaY * .01), T(x));
    else { const d = (Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY) / W * (TL.b - TL.a); setView(TL.a + d, TL.b + d); }
  }
  function snapshot(m, h) {
    if (h.track === 'subs') return VC.clone(VC.chunksOf(m)[h.key]);
    if (h.track === 'sfx') return VC.clone(VC.sfxOf(m)[h.key]);
    if (h.track === 'media') return VC.clone(m.media[h.key]);
    if (h.track === 'hook') return { at: VC.hookAt(m), secs: +VC.style(m).hook_secs };
    return { t0: m.t0, t1: m.t1 };
  }
  function onDown(e) { VC.cancelSeek && VC.cancelSeek();
    const h = hit(e), { x, y } = pos(e), v = VC.vid();
    cv.setPointerCapture(e.pointerId);
    if (VC.S.tool === 'hand' || e.button === 1) { TL.drag = { kind: 'pan', x0: x, a: TL.a, b: TL.b }; cv.style.cursor = 'grabbing'; return; }
    if (VC.S.tool === 'blade' && h.zone !== 'mini' && y > Y.ruler[1]) {
      const t = T(x), track = trackAt(y);
      if (track === 'video') { const m = VC.S.project.moments.find(mm => t > mm.t0 && t < mm.t1); if (m) VC.splitMoment(m, t); }
      else if (track && VC.cur()) VC.splitItem(track, h.key, t);
      return;
    }
    if (h.zone === 'mini') { TL.drag = { kind: 'mini' }; const c = x / W * dur(), s = TL.b - TL.a; setView(c - s / 2, c + s / 2); seekTo(clamp(c, 0, dur())); return; }
    if (h.zone === 'seek') { TL.drag = { kind: 'seek' }; if (h.track && VC.S.item) { VC.S.item = null; TL.dirty = true; } seekTo(clamp(T(x), 0, dur())); return; }
    if (h.track === 'video' && h.m !== VC.cur()) VC.select(h.m.id, false, clamp(T(x), h.m.t0, h.m.t1 - .05));
    const m = VC.cur();
    TL.drag = { kind: 'item', track: h.track, key: h.key, edge: h.edge, vol: h.vol, x0: x, y0: y, m, orig: snapshot(m, h), moved: false };
  }
  /* Clic sur la règle (ou dans le vide) : la lecture va exactement là.
     Si l'endroit est dans un moment, ce moment devient le moment actif ; sinon lecture libre dans le vlog. */
  function seekTo(t) {
    const v = VC.vid(); if (!v) return;
    const cur = VC.cur(), m = VC.S.project.moments.find(mm => t >= mm.t0 && t < mm.t1);
    if (m && m !== cur) { VC.select(m.id, false, t); return; }
    VC.S.free = !m;
    v.currentTime = t; VC.resetSfx && VC.resetSfx(); TL.dirty = true; VC.drawTimeline();
  }
  function fmtMs(t) { const sg = t < 0 ? '−' : ''; t = Math.abs(t); return sg + Math.floor(t) + ',' + String(Math.round((t % 1) * 1000)).padStart(3, '0') + ' s'; }
  function showTip(e, text) {
    let tip = document.getElementById('tlTip');
    if (!tip) { tip = document.createElement('div'); tip.id = 'tlTip'; tip.className = 'tl-tip'; document.body.appendChild(tip); }
    tip.textContent = text; tip.style.left = (e.clientX + 12) + 'px'; tip.style.top = (e.clientY - 30) + 'px'; tip.hidden = false;
  }
  function hideTip() { const tip = document.getElementById('tlTip'); if (tip) tip.hidden = true; }
  function onMove(e) {
    const { x, y } = pos(e), d = TL.drag, v = VC.vid();
    TL.mouseX = x;
    if (!d && VC.S.tool !== 'select') { cv.style.cursor = VC.S.tool === 'hand' ? 'grab' : 'crosshair'; TL.dirty = true; return; }
    if (!d) {
      const h = hit(e), prev = TL.hover; TL.hover = h;
      if (!prev || prev.track !== h.track || prev.key !== h.key) TL.dirty = true;
      cv.style.cursor = h.zone === 'mini' ? 'grab' : h.vol ? 'ns-resize' : h.edge ? 'ew-resize' : (h.track && h.zone !== 'seek') ? 'grab' : 'text';
      return;
    }
    if (d.kind === 'mini') { const c = clamp(x, 0, W) / W * dur(), s = TL.b - TL.a; setView(c - s / 2, c + s / 2); return; }
    if (d.kind === 'pan') { const dt = (x - d.x0) / W * (d.b - d.a); setView(d.a - dt, d.b - dt); return; }
    if (d.kind === 'seek') { seekTo(clamp(T(x), 0, dur())); return; }
    if (Math.abs(x - d.x0) > 3 || Math.abs(y - d.y0) > 3) d.moved = true;
    if (!d.moved) return;
    const dt = (x - d.x0) / W * (TL.b - TL.a), m = d.m, o = d.orig, len = m.t1 - m.t0;
    if (d.track === 'video') {
      if (d.edge === 'l') m.t0 = r2(clamp(o.t0 + dt, 0, m.t1 - 3));
      else if (d.edge === 'r') m.t1 = r2(clamp(o.t1 + dt, m.t0 + 3, dur()));
      else { const L = o.t1 - o.t0, a = r2(clamp(o.t0 + dt, 0, dur() - L)); m.t0 = a; m.t1 = r2(a + L); }
      if (v) v.currentTime = d.edge === 'r' ? Math.max(m.t0, m.t1 - .05) : m.t0;
    } else if (d.track === 'hook') {
      const end = o.at + o.secs;
      if (d.edge === 'l') { const at = clamp(o.at + dt, 0, end - .8); VC.moveHook(m, at, end - at); }
      else if (d.edge === 'r') VC.moveHook(m, o.at, clamp(o.secs + dt, .8, len - o.at));
      else VC.moveHook(m, clamp(o.at + dt, 0, Math.max(0, len - o.secs)));
      if (v) v.currentTime = m.t0 + VC.hookAt(m) + (d.edge === 'r' ? +VC.style(m).hook_secs - .3 : 0);
    } else if (d.track === 'subs') {
      const c = VC.ownSubs(m)[d.key]; if (!c) return;
      const os = o.s, oe = Math.max(o.e, os + .15);
      let ns = os, ne = oe;
      if (d.edge === 'l') ns = clamp(os + dt, m.t0, oe - .1);
      else if (d.edge === 'r') ne = clamp(oe + dt, os + .1, m.t1);
      else { ns = clamp(os + dt, m.t0, m.t1 - (oe - os)); ne = ns + (oe - os); }
      const k = (ne - ns) / Math.max(1e-6, oe - os);
      c.s = r2(ns); c.e = r2(ne); c.words = o.words.map(w => ({ w: w.w, s: r2(ns + (w.s - os) * k), e: r2(ns + (w.e - os) * k) }));
      if (v) v.currentTime = c.s + .02;
    } else if (d.track === 'sfx') {
      const s = VC.ownSfx(m)[d.key]; if (!s) return;
      if (d.vol) { const h = Y.sfx[1] - Y.sfx[0] - 8; s.vol = r2(clamp((Y.sfx[1] - 5 - y) / h * 1.5, 0, 1.5)); }
      else { s.at = Math.round(clamp(o.at + dt * (e.altKey ? .1 : 1), -3, len - .02) * 1000) / 1000; s.link = null; showTip(e, fmtMs(s.at)); }
    } else if (d.track === 'media') {
      const it = m.media[d.key]; if (!it) return;
      const maxDur = it.kind === 'video' ? Math.max(.2, (it.vdur || 1e9) - (o.from || 0)) : 1e9;
      if (d.edge === 'l') {
        const shift = clamp(dt, -Math.min(o.at, it.kind === 'video' ? (o.from || 0) : 1e9), o.dur - .2);
        it.at = r2(o.at + shift); it.dur = r2(o.dur - shift); if (it.kind === 'video') it.from = r2((o.from || 0) + shift);
      } else if (d.edge === 'r') it.dur = r2(clamp(o.dur + dt, .2, Math.min(maxDur, len - o.at)));
      else it.at = r2(clamp(o.at + dt, 0, Math.max(0, len - o.dur)));
      if (v) v.currentTime = m.t0 + it.at + (d.edge === 'r' ? it.dur - .1 : 0);
    }
    VC.invalidate(); TL.dirty = true; VC.drawTimeline();
  }
  function onUp() {
    hideTip();
    const d = TL.drag; TL.drag = null;
    if (d && d.kind === 'pan') { cv.style.cursor = VC.S.tool === 'hand' ? 'grab' : ''; return; }
    if (!d || d.kind !== 'item') return;
    const m = d.m;
    if (d.moved) {
      if (d.track === 'video') { VC.S.project.moments.sort((a, b) => a.t0 - b.t0); VC.renderList(); }
      VC.commit(true);
      if (d.track !== 'video') { VC.S.item = { track: d.track, key: d.key }; VC.openItem(d.track, d.key); }
      else if (VC.syncFrameTimes && $('#vT0')) VC.syncFrameTimes();
      if (d.track === 'sfx' && d.vol) VC.toast('Volume : ' + Math.round(VC.sfxOf(m)[d.key].vol * 100) + ' %', 1200);
      return;
    }
    // simple clic : sélection + ouverture du réglage correspondant
    const v = VC.vid();
    if (d.track === 'video') {
      const z = m.frame && m.frame.zcfg && m.frame.zcfg.on && m.frame.zooms;
      if (z && z.slice(1).some(([r]) => Math.abs(X(m.t0 + r) - d.x0) <= 6) && d.y0 > Y.video[1] - 14) { VC.openItem('frame'); return; }
      VC.S.item = null; if (v) v.currentTime = Math.max(m.t0, T(d.x0)); TL.dirty = true; return;
    }
    VC.S.item = { track: d.track, key: d.key }; TL.dirty = true;
    const it = items(d.track, m).find(i => i.key === d.key); if (it && v) v.currentTime = it.a + .02;
    VC.openItem(d.track, d.key);
  }
})();
