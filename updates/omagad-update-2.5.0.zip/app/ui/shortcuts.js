/* Raccourcis clavier personnalisables. Combinaisons : « Mod » = ⌘ (Ctrl hors Mac), « Alt » = ⌥, « Shift » = ⇧. */
(function () {
  const { $, esc } = VC;
  const M = 'montage';
  const A = [
    // id, groupe, libellé, combinaisons par défaut, contexte, action
    ['import', 'Général', 'Importer une vidéo', ['Mod+O'], null, () => { VC.go('import'); setTimeout(() => { const b = $('#btnPick'); if (b) b.click(); }, 50); }],
    ['export', 'Général', 'Exporter', ['Mod+E'], null, () => { if (VC.S.view !== 'export') VC.go('export'); else { const b = $('#btnExport'); if (b && !b.disabled) b.click(); } }],
    ['goImport', 'Général', 'Aller à Import', ['Mod+1'], null, () => VC.go('import')],
    ['goMontage', 'Général', 'Aller au Montage', ['Mod+2'], null, () => VC.go('montage')],
    ['goExport', 'Général', 'Aller à Export', ['Mod+3'], null, () => VC.go('export')],
    ['undo', 'Général', 'Annuler la dernière action', ['Mod+Z'], 'edit', () => VC.undo()],
    ['redo', 'Général', 'Rétablir', ['Mod+Shift+Z'], 'edit', () => VC.redo()],
    ['settings', 'Général', 'Réglages', ['Mod+,'], null, () => $('#btnSettings').click()],
    ['shortcuts', 'Général', 'Raccourcis clavier', ['Mod+/'], null, () => VC.openShortcuts()],
    ['play', 'Lecture', 'Lecture / pause', ['Space'], M, () => VC.togglePlay()],
    ['back1', 'Lecture', 'Reculer d\'1 s', ['ArrowLeft'], M, () => seek(-1)],
    ['fwd1', 'Lecture', 'Avancer d\'1 s', ['ArrowRight'], M, () => seek(1)],
    ['back5', 'Lecture', 'Reculer de 5 s', ['Shift+ArrowLeft'], M, () => seek(-5)],
    ['fwd5', 'Lecture', 'Avancer de 5 s', ['Shift+ArrowRight'], M, () => seek(5)],
    ['frameBack', 'Lecture', 'Image précédente', [','], M, () => seek(-1 / 30)],
    ['frameFwd', 'Lecture', 'Image suivante', ['.'], M, () => seek(1 / 30)],
    ['replay', 'Lecture', 'Revoir le moment depuis le début', ['R'], M, () => { const m = VC.cur(), v = VC.vid(); if (m && v) VC.seek(m.t0, true); }],
    ['prevMoment', 'Moments', 'Moment précédent', ['ArrowUp'], M, () => VC.stepMoment(-1)],
    ['nextMoment', 'Moments', 'Moment suivant', ['ArrowDown'], M, () => VC.stepMoment(1)],
    ['validate', 'Moments', 'Valider le moment', ['V'], M, () => VC.verdict('ok')],
    ['skip', 'Moments', 'Écarter le moment', ['X'], M, () => VC.verdict('skip')],
    ['newMoment', 'Moments', 'Nouveau moment à la tête de lecture', ['N'], M, () => VC.addHere()],
    ['setIn', 'Moments', 'Début du moment ici', ['I'], M, () => VC.setInOut('in')],
    ['setOut', 'Moments', 'Fin du moment ici', ['O'], M, () => VC.setInOut('out')],
    ['toolSelect', 'Timeline', 'Outil Sélection', ['A'], M, () => VC.setTool('select')],
    ['toolBlade', 'Timeline', 'Outil Lame (couper)', ['B'], M, () => VC.setTool('blade')],
    ['toolHand', 'Timeline', 'Outil Main (déplacer la vue)', ['H'], M, () => VC.setTool('hand')],
    ['split', 'Timeline', 'Couper à la tête de lecture', ['Mod+B'], M, () => VC.splitAtPlayhead()],
    ['delete', 'Timeline', 'Supprimer l\'élément sélectionné', ['Backspace', 'Delete'], M, () => VC.deleteItem()],
    ['nudgeL', 'Timeline', 'Décaler l\'élément de −10 ms', ['Alt+ArrowLeft'], M, () => VC.nudgeItem(-.01)],
    ['nudgeR', 'Timeline', 'Décaler l\'élément de +10 ms', ['Alt+ArrowRight'], M, () => VC.nudgeItem(.01)],
    ['nudgeL100', 'Timeline', 'Décaler l\'élément de −100 ms', ['Alt+Shift+ArrowLeft'], M, () => VC.nudgeItem(-.1)],
    ['nudgeR100', 'Timeline', 'Décaler l\'élément de +100 ms', ['Alt+Shift+ArrowRight'], M, () => VC.nudgeItem(.1)],
    ['zoomIn', 'Timeline', 'Zoomer', ['Plus', '='], M, () => VC.zoomTimeline(1 / 1.5)],
    ['zoomOut', 'Timeline', 'Dézoomer', ['-'], M, () => VC.zoomTimeline(1.5)],
    ['fitMoment', 'Timeline', 'Voir tout le moment', ['F'], M, () => { const b = $('#tlFit'); if (b) b.click(); }],
    ['fitAll', 'Timeline', 'Voir tout le vlog', ['Shift+F'], M, () => { const b = $('#tlAll'); if (b) b.click(); }],
    ['toggleTimeline', 'Affichage', 'Réduire / agrandir la timeline', ['Mod+J'], M, () => { const b = $('#tlCollapse'); if (b) b.click(); }],
    ['toggleLeft', 'Affichage', 'Réduire / agrandir la liste des moments', ['Mod+Alt+ArrowLeft'], M, () => VC.toggleSide('left')],
    ['toggleRight', 'Affichage', 'Réduire / agrandir les réglages', ['Mod+Alt+ArrowRight'], M, () => VC.toggleSide('right')],
    ['safeZones', 'Affichage', 'Zones cachées par TikTok', ['Z'], M, () => { const b = $('#btnSafe'); if (b) b.click(); }]
  ].map(a => ({ id: a[0], group: a[1], label: a[2], def: a[3], ctx: a[4], run: a[5] }));
  VC.ACTIONS = A;
  function seek(d) { const v = VC.vid(); VC.cancelSeek && VC.cancelSeek(); if (v) v.currentTime = Math.max(0, v.currentTime + d); }

  const custom = () => (VC.S.state && VC.S.state.settings.shortcuts) || {};
  VC.combosOf = a => custom()[a.id] || a.def;

  /* KeyboardEvent -> « Mod+Shift+Z » */
  function comboOf(e) {
    let k = e.key;
    if (k === ' ' || e.code === 'Space') k = 'Space';
    if (k === '+') k = 'Plus';
    if (['Meta', 'Control', 'Alt', 'Shift'].includes(k)) return null;
    const printable = k.length === 1;
    if (printable && /[a-z]/i.test(k)) k = (e.code && e.code.startsWith('Key') ? e.code.slice(3) : k).toUpperCase();
    else if (printable && e.altKey && e.code && e.code.startsWith('Digit')) k = e.code.slice(5);
    const parts = [];
    if (e.metaKey || e.ctrlKey) parts.push('Mod');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey && !(printable && !/[A-Z]/.test(k))) parts.push('Shift');  // Maj sert à taper « + » : ignorée
    parts.push(k);
    return parts.join('+');
  }
  VC.comboOf = comboOf;
  const SYM = { Plus: '+', Mod: '⌘', Alt: '⌥', Shift: '⇧', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Space: 'Espace', Backspace: '⌫', Delete: '⌦', Enter: '↩', Escape: 'Échap', Tab: '⇥' };
  VC.prettyCombo = c => c.split('+').map(p => SYM[p] || p).join('');

  VC.handleShortcut = function (e) {
    if (recording) return;
    if (e.key === 'Escape' && $('.popover:not([hidden])')) return;
    const tag = (e.target.tagName || '').toLowerCase(), typing = ['input', 'textarea', 'select'].includes(tag) && e.target.type !== 'checkbox' && e.target.type !== 'range';
    if ($('dialog[open]')) return;
    const c = comboOf(e); if (!c) return;
    if (typing && !c.startsWith('Mod+')) return;
    for (const a of A) {
      if (!VC.combosOf(a).includes(c)) continue;
      if (a.ctx === M && VC.S.view !== 'montage') continue;
      if (a.ctx === 'edit' && (VC.S.view === 'import' || typing)) continue;
      e.preventDefault(); e.stopPropagation();
      try { a.run(e); } catch (err) { console.error(err); }
      return;
    }
  };

  /* ---------- Fenêtre des raccourcis ---------- */
  let recording = null, filter = '';
  function dlg() {
    let d = $('#dlgKeys');
    if (!d) {
      d = document.createElement('dialog'); d.id = 'dlgKeys'; d.className = 'dlg keys-dlg';
      d.innerHTML = '<form method="dialog"><div class="keys-head"><h2>Raccourcis clavier</h2><input type="text" id="keysSearch" placeholder="Rechercher une action"></div>' +
        '<p class="hint" style="margin:0">Clique sur un raccourci puis appuie sur les touches voulues. Échap pour annuler, ⌫ pour l\'effacer.</p>' +
        '<div class="keys-list" id="keysList"></div><div class="dlg-actions"><button class="btn ghost" type="button" id="keysReset">Tout réinitialiser</button><span style="flex:1"></span><button class="btn primary" value="close">Fermer</button></div></form>';
      document.body.appendChild(d);
      d.querySelector('#keysSearch').oninput = e => { filter = e.target.value.toLowerCase(); render(); };
      d.querySelector('#keysReset').onclick = async () => { await save({}); render(); VC.toast('Raccourcis réinitialisés'); };
      d.querySelector('#keysList').onclick = e => {
        const r = e.target.closest('[data-rec]'); if (r) { recording = r.dataset.rec; render(); return; }
        const z = e.target.closest('[data-reset]'); if (z) { const c = Object.assign({}, custom()); delete c[z.dataset.reset]; save(c).then(render); }
      };
      d.addEventListener('keydown', onRecord, true);
      d.addEventListener('close', () => { recording = null; });
    }
    return d;
  }
  async function save(map) { await VC.saveSettings({ shortcuts: map }); }
  async function onRecord(e) {
    if (!recording) return;
    e.preventDefault(); e.stopPropagation();
    if (e.key === 'Escape') { recording = null; render(); return; }
    const c = (e.key === 'Backspace' && !e.metaKey && !e.altKey && !e.shiftKey) ? '' : comboOf(e);
    if (c === null) return;
    const map = Object.assign({}, custom()), id = recording;
    recording = null;
    let msg = '';
    if (c) {
      for (const a of A) if (a.id !== id && VC.combosOf(a).includes(c)) { map[a.id] = VC.combosOf(a).filter(x => x !== c); msg = ' (retiré de « ' + a.label + ' »)'; }
      map[id] = [c];
    } else map[id] = [];
    await save(map); render();
    VC.toast(c ? 'Raccourci ' + VC.prettyCombo(c) + ' enregistré' + msg : 'Raccourci effacé', 2500);
  }
  function render() {
    const box = $('#keysList'); if (!box) return;
    const groups = [...new Set(A.map(a => a.group))];
    box.innerHTML = groups.map(g => {
      const rows = A.filter(a => a.group === g && (!filter || (a.label + ' ' + VC.t(a.label)).toLowerCase().includes(filter)));
      if (!rows.length) return '';
      return '<div class="keys-group"><h4>' + esc(g) + '</h4>' + rows.map(a => {
        const cs = VC.combosOf(a), changed = !!custom()[a.id];
        return '<div class="keys-row"><span>' + esc(a.label) + '</span><button type="button" class="kbd-btn' + (recording === a.id ? ' rec' : '') + '" data-rec="' + a.id + '">' +
          (recording === a.id ? 'Appuie sur une touche…' : cs.length ? cs.map(c => '<kbd>' + esc(VC.t(VC.prettyCombo(c))) + '</kbd>').join('<i>ou</i>') : '<span class="hint">aucun</span>') + '</button>' +
          '<button type="button" class="icon-btn small" data-reset="' + a.id + '" title="Revenir au raccourci d\'origine"' + (changed ? '' : ' hidden') + '>↺</button></div>';
      }).join('') + '</div>';
    }).join('');
  }
  VC.openShortcuts = function () { const d = dlg(); filter = ''; d.querySelector('#keysSearch').value = ''; render(); d.showModal(); };
})();
