/* Mise en page : panneaux redimensionnables (glisser les séparateurs), panneaux et sections réductibles. */
(function () {
  const { $, $$, clamp } = VC;
  const KEY = 'omagad-layout-v1';
  const L = Object.assign({ lw: 280, rw: 420, tlh: 230, lc: false, rc: false }, (() => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } })());
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(L)); } catch (e) {} };
  const RAIL = 44;

  function apply() {
    const r = document.documentElement.style;
    r.setProperty('--lw', (L.lc ? RAIL : L.lw) + 'px');
    r.setProperty('--rw', (L.rc ? RAIL : L.rw) + 'px');
    r.setProperty('--tlh', L.tlh + 'px');
    const side = $('.side'), insp = $('#inspector');
    if (side) side.classList.toggle('collapsed', L.lc);
    if (insp) insp.classList.toggle('collapsed', L.rc);
    VC.layoutVideo && VC.layoutVideo();
    VC.drawTimeline && VC.drawTimeline();
  }
  VC.applyLayout = apply;
  VC.toggleSide = which => { if (which === 'left') L.lc = !L.lc; else L.rc = !L.rc; save(); apply(); };

  /* Séparateurs : glisser pour redimensionner, double-clic pour réduire/agrandir */
  VC.initSplitters = function (root) {
    $$('.split', root).forEach(sp => {
      const kind = sp.dataset.split;
      sp.ondblclick = () => { if (kind === 'left') VC.toggleSide('left'); else if (kind === 'right') VC.toggleSide('right'); else { L.tlh = L.tlh > 120 ? 90 : 230; save(); apply(); } };
      sp.onpointerdown = e => {
        e.preventDefault(); sp.setPointerCapture(e.pointerId); sp.classList.add('drag'); document.body.classList.add('resizing');
        const x0 = e.clientX, y0 = e.clientY, s = { lw: L.lc ? RAIL : L.lw, rw: L.rc ? RAIL : L.rw, tlh: L.tlh };
        const move = ev => {
          if (kind === 'left') { const w = s.lw + ev.clientX - x0; L.lc = w < 120; if (!L.lc) L.lw = clamp(w, 200, 520); }
          else if (kind === 'right') { const w = s.rw - (ev.clientX - x0); L.rc = w < 150; if (!L.rc) L.rw = clamp(w, 300, 640); }
          else L.tlh = clamp(s.tlh - (ev.clientY - y0), 90, Math.max(140, window.innerHeight - 330));
          apply();
        };
        const up = () => { sp.classList.remove('drag'); document.body.classList.remove('resizing'); sp.removeEventListener('pointermove', move); sp.removeEventListener('pointerup', up); save(); };
        sp.addEventListener('pointermove', move); sp.addEventListener('pointerup', up);
      };
    });
    apply();
  };

  /* Sections repliables dans le panneau de réglages (mémorisées) */
  const SKEY = 'omagad-sections-v1';
  const closed = (() => { try { return JSON.parse(localStorage.getItem(SKEY)) || {}; } catch (e) { return {}; } })();
  const DEFAULT_CLOSED = /^(Lueur|Ombre portée|Encadré|Appliquer|Sons par défaut|Bibliothèque|Découpe|Zooms aléatoires)/;
  const CHEV = '<svg class="chev" viewBox="0 0 20 20" width="14" height="14"><path d="M6 8l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  VC.enhanceSections = function (pane, tab) {
    $$('.group', pane).forEach(g => {
      const lab = g.querySelector(':scope > .label') || g.querySelector(':scope > div:first-child > .label');
      if (!lab || g.classList.contains('sec')) return;
      const title = lab.textContent.trim(), id = tab + ':' + title;
      const head = document.createElement('div');
      head.className = 'sec-head'; head.setAttribute('role', 'button'); head.tabIndex = 0;
      const extra = lab.parentElement !== g ? lab.parentElement : null;  // en-tête avec bouton à droite
      head.innerHTML = CHEV + '<span>' + VC.esc(title) + '</span>';
      const body = document.createElement('div'); body.className = 'sec-body';
      [...g.childNodes].forEach(n => { if (n !== lab && n !== extra) body.appendChild(n); });
      if (extra) { lab.remove(); extra.classList.add('sec-tools'); [...extra.childNodes].forEach(n => { if (n.nodeType === 1) head.appendChild(n); }); extra.remove(); }
      else lab.remove();
      g.classList.add('sec'); g.prepend(head); g.appendChild(body);
      const isClosed = id in closed ? closed[id] : DEFAULT_CLOSED.test(title);
      g.classList.toggle('closed', isClosed);
      head.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); head.click(); } });
      head.addEventListener('click', e => {
        if (e.target.closest('button, select, input')) return;  // un bouton de l'en-tête garde son action
        const c = !g.classList.contains('closed'); g.classList.toggle('closed', c); closed[id] = c;
        try { localStorage.setItem(SKEY, JSON.stringify(closed)); } catch (err) {}
      });
    });
  };
})();
