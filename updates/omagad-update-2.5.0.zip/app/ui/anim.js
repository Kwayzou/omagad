/* Animations de l'accroche (même calcul que engine/anim.py) + zooms aléatoires sur les cuts. */
(function () {
  const IN = {
    none: {}, fade: { alpha: 0 }, pop: { scale: 0, alpha: 0 }, zoom_in: { scale: 1.9, alpha: 0 }, zoom_out: { scale: .4, alpha: 0 },
    slide_left: { dx: -1100, alpha: .6 }, slide_right: { dx: 1100, alpha: .6 }, slide_up: { dy: 160, alpha: 0 }, slide_down: { dy: -160, alpha: 0 },
    rotate: { rot: -25, scale: .5, alpha: 0 }, bounce: { dy: -260 }
  };
  const OUT = {
    none: {}, fade: { alpha: 0 }, swipe_right: { dx: 1300 }, swipe_left: { dx: -1300 }, slide_down: { dy: 220, alpha: 0 }, slide_up: { dy: -220, alpha: 0 },
    zoom_out: { scale: 0, alpha: 0 }, zoom_in: { scale: 1.18, alpha: 0 }, pop_out: { scale: 0 }, rotate: { rot: 25, scale: .4, alpha: 0 }
  };
  /* Libellés et réglages conseillés (durée, courbe) quand on choisit un préréglage */
  VC.ANIM_IN = [['slide_left', 'Glisse de la gauche', 230, 'out'], ['slide_right', 'Glisse de la droite', 230, 'out'], ['slide_up', 'Monte', 280, 'out'],
    ['slide_down', 'Descend', 280, 'out'], ['pop', 'Pop', 280, 'back'], ['zoom_in', 'Impact (zoom arrière)', 260, 'out'], ['zoom_out', 'Zoom avant', 300, 'out'],
    ['bounce', 'Rebond', 600, 'bounce'], ['rotate', 'Rotation', 320, 'back'], ['fade', 'Fondu', 250, 'out'], ['none', 'Aucune', 0, 'out'], ['custom', 'Personnalisée', 350, 'out']];
  VC.ANIM_OUT = [['swipe_right', 'Part à droite', 320, 'in'], ['swipe_left', 'Part à gauche', 320, 'in'], ['slide_down', 'Descend', 300, 'in'],
    ['slide_up', 'Monte', 300, 'in'], ['zoom_out', 'Rétrécit', 280, 'in'], ['zoom_in', 'Grossit en fondu', 400, 'lin'], ['pop_out', 'Pop inversé', 260, 'back_in'],
    ['rotate', 'Rotation', 350, 'in'], ['fade', 'Fondu', 300, 'lin'], ['none', 'Aucune', 0, 'lin'], ['custom', 'Personnalisée', 350, 'in']];
  VC.EASES = [['out', 'Rapide puis douce'], ['in', 'Douce puis rapide'], ['inout', 'Douce aux deux bouts'], ['lin', 'Constante'], ['back', 'Dépasse et revient'], ['back_in', 'Recule puis part'], ['bounce', 'Rebond'], ['elastic', 'Élastique']];
  const LEGACY = {
    swipe: { hook_in: 'slide_left', hook_in_ms: 230, hook_in_ease: 'out', hook_out: 'swipe_right', hook_out_ms: 320, hook_out_ease: 'in', hook_drift: 22, hook_shake: false, hook_words: false },
    slam: { hook_in: 'zoom_in', hook_in_ms: 260, hook_in_ease: 'out', hook_out: 'zoom_in', hook_out_ms: 400, hook_out_ease: 'lin', hook_drift: 0, hook_shake: true, hook_words: false },
    pop: { hook_in: 'pop', hook_in_ms: 280, hook_in_ease: 'back', hook_out: 'fade', hook_out_ms: 300, hook_out_ease: 'lin', hook_drift: 0, hook_shake: false, hook_words: false },
    slide: { hook_in: 'slide_up', hook_in_ms: 280, hook_in_ease: 'out', hook_out: 'fade', hook_out_ms: 300, hook_out_ease: 'lin', hook_drift: 0, hook_shake: false, hook_words: false },
    words: { hook_in: 'none', hook_in_ms: 0, hook_in_ease: 'out', hook_out: 'fade', hook_out_ms: 300, hook_out_ease: 'lin', hook_drift: 0, hook_shake: false, hook_words: true }
  };
  VC.migrateStyle = function (s) { if (s && s.hook_anim && !('hook_in' in s)) { Object.assign(s, LEGACY[s.hook_anim] || {}); } delete (s || {}).hook_anim; return s; };

  function ease(name, u) {
    u = Math.min(1, Math.max(0, u));
    if (name === 'lin') return u;
    if (name === 'in') return Math.pow(u, 2.4);
    if (name === 'inout') return u < .5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2;
    if (name === 'back') { const c = 1.70158; return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2); }
    if (name === 'back_in') { const c = 1.70158; return (c + 1) * u * u * u - c * u * u; }
    if (name === 'bounce') {
      const n = 7.5625, d = 2.75;
      if (u < 1 / d) return n * u * u;
      if (u < 2 / d) { u -= 1.5 / d; return n * u * u + .75; }
      if (u < 2.5 / d) { u -= 2.25 / d; return n * u * u + .9375; }
      u -= 2.625 / d; return n * u * u + .984375;
    }
    if (name === 'elastic') return u === 0 || u === 1 ? u : Math.pow(2, -10 * u) * Math.sin((u * 10 - .75) * (2 * Math.PI / 3)) + 1;
    return 1 - Math.pow(1 - u, 3);
  }
  VC.ease = ease;
  function params(st, side) {
    const kind = st['hook_' + side] || 'none', p = { dx: 0, dy: 0, scale: 1, rot: 0, alpha: 1 };
    if (kind === 'custom') for (const k in p) p[k] = +(st['hook_' + side + '_' + k] ?? p[k]);
    else Object.assign(p, (side === 'in' ? IN : OUT)[kind] || {});
    p.ms = kind === 'none' ? 0 : +(st['hook_' + side + '_ms'] || 300); p.ease = st['hook_' + side + '_ease'] || 'out';
    return p;
  }
  /* Mouvement aléatoire haut/bas/gauche/droite (même calcul que engine/anim.py : wander) */
  VC.wander = function (st, ms) {
    if (!st.hook_wander) return [0, 0, 0];
    let sd = (Math.floor(+st.hook_wander_seed || 7) >>> 0) || 1;
    const r = () => { sd ^= sd << 13; sd >>>= 0; sd ^= sd >>> 17; sd ^= sd << 5; sd >>>= 0; return (sd % 100000) / 100000; };
    const tau = 2 * Math.PI, ph = [], k = [];
    for (let i = 0; i < 5; i++) ph.push(r() * tau);
    for (let i = 0; i < 5; i++) k.push(.75 + .5 * r());
    const sp = Math.max(.01, +st.hook_wander_speed || .6), t = ms / 1000, env = Math.min(1, Math.max(0, ms / 400));
    const ax = +st.hook_wander_x || 0, ay = +st.hook_wander_y || 0, ar = +st.hook_wander_rot || 0;
    return [ax * env * (.65 * Math.sin(tau * sp * k[0] * t + ph[0]) + .35 * Math.sin(tau * sp * 2.3 * k[1] * t + ph[1])),
      ay * env * (.65 * Math.sin(tau * sp * k[2] * t + ph[2]) + .35 * Math.sin(tau * sp * 2.1 * k[3] * t + ph[3])),
      ar * env * Math.sin(tau * sp * .8 * k[4] * t + ph[4])];
  };
  VC.hookTransform = function (st, ms, total) {
    const pin = params(st, 'in'), pout = params(st, 'out');
    let dx = 0, dy = 0, rot = 0, sc = 1, al = 1;
    if (pin.ms > 0 && ms < pin.ms) {
      const u = ms / pin.ms, e = ease(pin.ease, u);
      dx = pin.dx * (1 - e); dy = pin.dy * (1 - e); rot = pin.rot * (1 - e); sc = pin.scale + (1 - pin.scale) * e;
      al = pin.alpha + (1 - pin.alpha) * Math.min(1, Math.max(0, pin.ease === 'bounce' ? u * 3 : e));
    }
    const ost = Math.max(pin.ms, total - pout.ms), drift = +st.hook_drift || 0;
    if (drift && ost > pin.ms) dx += drift * Math.min(1, Math.max(0, (ms - pin.ms) / (ost - pin.ms)));
    if (st.hook_shake) { const t = ms - pin.ms; if (t >= 0 && t < 80) rot += 2 * t / 80; else if (t >= 80 && t < 160) rot += 2 - 4 * (t - 80) / 80; else if (t >= 160 && t < 240) rot += -2 + 2 * (t - 160) / 80; }
    if (pout.ms > 0 && ms >= ost) {
      const e = ease(pout.ease, (ms - ost) / pout.ms);
      dx += pout.dx * e; dy += pout.dy * e; rot += pout.rot * e; sc *= 1 + (pout.scale - 1) * e; al *= 1 + (pout.alpha - 1) * Math.min(1, Math.max(0, e));
    }
    const w = VC.wander(st, ms);
    return { dx: dx + w[0], dy: dy + w[1], sc: Math.max(0, sc), rot: rot + w[2], al: Math.min(1, Math.max(0, al)) };
  };
  VC.sfxOutOffset = st => { const p = params(st, 'out'); return (+st.hook_secs * 1000 - (p.ms || 360)) / 1000 - .04; };
  VC.subAnim = function (kind, ms) {
    if (kind === 'none' || ms >= 200) return { dy: 0, sc: 1, al: 1 };
    if (kind === 'pop') return { dy: 0, sc: .75 + .25 * ease('back', ms / 140), al: Math.min(1, ms / 60) };
    if (kind === 'fade') return { dy: 0, sc: 1, al: Math.min(1, ms / 150) };
    if (kind === 'slide') return { dy: 40 * (1 - ease('out', ms / 160)), sc: 1, al: Math.min(1, ms / 100) };
    if (kind === 'zoom') return { dy: 0, sc: 1.35 - .35 * ease('out', ms / 160), al: Math.min(1, ms / 80) };
    return { dy: 0, sc: 1, al: 1 };
  };

  /* ---------- Zooms aléatoires sur les cuts ---------- */
  function rng(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 100000) / 100000; }; }
  VC.makeZooms = function (m, cfg) {
    const len = m.t1 - m.t0, rnd = rng(cfg.seed || 1), maxZ = +cfg.max || 1.25, every = +cfg.every || 3;
    // coupes : débuts de phrases du moment, espacées d'au moins « every » secondes ; sinon à intervalle régulier
    const cuts = [];
    let last = 0;
    for (const l of VC.S.project.lines || []) {
      const t = l.s - m.t0;
      if (t > .6 && t < len - .6 && t - last >= every * .8) { cuts.push(t); last = t; }
    }
    for (let i = 0; i < cuts.length + 1; i++) {
      const a = i ? cuts[i - 1] : 0, b = i < cuts.length ? cuts[i] : len;
      for (let t = a + every * 1.4; t < b - every * .5; t += every * (1 + rnd() * .4)) cuts.push(t);
    }
    cuts.sort((a, b) => a - b);
    const keys = [[0, cfg.startWide === false ? 1 + (maxZ - 1) * rnd() : 1]];
    let prev = keys[0][1];
    for (const t of cuts) {
      let z, tries = 0;
      do { z = 1 + (maxZ - 1) * rnd(); tries++; } while (Math.abs(z - prev) < (maxZ - 1) * .35 && tries < 12);
      if (cfg.alternate && Math.abs(prev - 1) > .02) z = 1;  // alterne zoom / plan large
      keys.push([Math.round(t * 100) / 100, Math.round(z * 1000) / 1000]); prev = z;
    }
    return keys;
  };
  VC.zoomAt = function (m, rel) {
    const f = m.frame || {}, k = f.zcfg && f.zcfg.on && f.zooms;
    if (!k || !k.length) return 1;
    const ramp = f.zcfg.mode === 'smooth' ? .18 : .001;
    let z = k[0][1];
    for (let i = 1; i < k.length; i++) { const u = Math.min(1, Math.max(0, (rel - k[i][0]) / ramp)); z += (k[i][1] - k[i - 1][1]) * u; }
    return z;
  };
})();
