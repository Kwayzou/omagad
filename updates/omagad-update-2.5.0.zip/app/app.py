"""OMAGAD : application de bureau (fenêtre native, sans navigateur)."""
import json
import re
import os
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

_T0 = time.time()
HERE = Path(__file__).resolve().parent
os.chdir(HERE)
sys.path.insert(0, str(HERE))
os.environ["VLOGCLIPS_NATIVE"] = "1"


_SOUNDS = []  # garde les sons en mémoire pendant leur lecture
SPLASH = '<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;height:100%;background:#000}</style></head><body></body></html>'
VIDEO_TYPES = ("Vidéos (*.mp4;*.mov;*.m4v;*.mkv;*.webm;*.avi;*.mts)", "Tous les fichiers (*.*)")
ZIP_TYPES = ("Mise à jour OMAGAD (*.zip)",)
AUDIO_TYPES = ("Sons (*.wav;*.mp3;*.m4a;*.aif;*.aiff;*.caf;*.ogg;*.flac)",)
MEDIA_TYPES = ("Photos et vidéos (*.jpg;*.jpeg;*.png;*.heic;*.webp;*.gif;*.mp4;*.mov;*.m4v;*.mkv;*.webm)",)


class Bridge:
    """Fonctions natives appelées depuis l'interface (window.pywebview.api)."""

    def __init__(self):
        self._win = None

    def pick_video(self):
        import webview
        r = self._win.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=VIDEO_TYPES)
        return r[0] if r else None

    def pick_videos(self):
        import webview
        r = self._win.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=True, file_types=VIDEO_TYPES)
        return list(r) if r else []

    def pick_zip(self):
        import webview
        r = self._win.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=ZIP_TYPES)
        return r[0] if r else None

    def pick_audio(self):
        import webview
        r = self._win.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=AUDIO_TYPES)
        return r[0] if r else None

    def pick_media(self):
        import webview
        r = self._win.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=MEDIA_TYPES)
        return r[0] if r else None

    def pick_font(self):
        import webview
        r = self._win.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=("Polices (*.ttf;*.otf;*.ttc)",))
        return r[0] if r else None

    def restart(self):
        """Redémarre OMAGAD (après une mise à jour) : la même app se ferme puis se rouvre, jamais deux à la fois."""
        pid = os.getpid()
        bundle = os.environ.get("OMAGAD_BUNDLE")
        if sys.platform == "darwin" and bundle:
            # attend que cette app soit vraiment fermée, puis la rouvre (sans -n : une seule OMAGAD)
            script = 'while kill -0 %d 2>/dev/null; do sleep 0.2; done; sleep 0.4; open "$0"' % pid
            subprocess.Popen(["/bin/sh", "-c", script, bundle], start_new_session=True)
        else:
            script = 'while kill -0 %d 2>/dev/null; do sleep 0.2; done; "$0" "$1"' % pid
            subprocess.Popen(["/bin/sh", "-c", script, sys.executable, str(HERE / "app.py")], start_new_session=True)
        threading.Timer(0.15, self._quit).start()
        return True

    def _quit(self):
        try:
            self._win.destroy()
        finally:
            threading.Timer(1.5, lambda: os._exit(0)).start()  # au cas où la fenêtre traîne

    def pick_image(self):
        import webview
        r = self._win.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False,
                                         file_types=("Images (*.jpg;*.jpeg;*.png;*.heic;*.webp)",))
        return r[0] if r else None

    def set_menu_lang(self, lang):
        """L'interface a changé de langue : on met à jour le menu OMAGAD."""
        install_menu(self._win, lang)
        return True

    def play_sound(self, name, volume=0.55):
        """Joue un son de l'interface avec macOS (fonctionne même sans clic préalable dans la fenêtre)."""
        name = re.sub(r"[^a-z0-9_-]", "", str(name))
        path = HERE / "ui" / "sounds" / (name + ".wav")
        if sys.platform != "darwin" or not path.exists():
            return False
        try:
            from AppKit import NSSound
            from PyObjCTools import AppHelper

            def go():
                snd = NSSound.alloc().initWithContentsOfFile_byReference_(str(path), True)
                if snd is not None:
                    snd.setVolume_(max(0.0, min(1.0, float(volume))))
                    _SOUNDS.append(snd)
                    del _SOUNDS[:-6]
                    snd.play()
            AppHelper.callAfter(go)
            return True
        except Exception:
            return False

    def pick_folder(self, start=""):
        import webview
        r = self._win.create_file_dialog(webview.FOLDER_DIALOG, directory=start or "")
        return r[0] if r else None


def mac_branding():
    """Nom et icône dans le Dock et la barre de menus (sinon macOS affiche « Python »)."""
    if sys.platform != "darwin":
        return
    try:
        from Foundation import NSBundle
        from AppKit import NSApplication, NSImage
        info = NSBundle.mainBundle().infoDictionary()
        info["CFBundleName"] = "OMAGAD"
        info["CFBundleDisplayName"] = "OMAGAD"
        icon = str(HERE / "icon.png") if (HERE / "icon.png").exists() else os.environ.get("VLOGCLIPS_ICON", "")
        if os.path.exists(icon):
            NSApplication.sharedApplication().setApplicationIconImage_(NSImage.alloc().initWithContentsOfFile_(icon))
    except Exception:
        pass


LSREGISTER = "/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"


def refresh_bundle_icon():
    """Remplace l'icône de l'app (Finder, Dock, Launchpad) par le logo de la version installée."""
    bundle = os.environ.get("OMAGAD_BUNDLE")
    src = HERE / "AppIcon.icns"
    if sys.platform != "darwin" or not bundle or not src.exists():
        return
    # lanceur à jour (il est remplacé seulement quand Python tourne déjà : sans risque)
    try:
        new_l, cur_l = HERE / "macos" / "launcher.sh", Path(bundle) / "Contents" / "MacOS" / "OMAGAD"
        if new_l.exists() and cur_l.exists() and new_l.read_bytes() != cur_l.read_bytes():
            cur_l.write_bytes(new_l.read_bytes())
            os.chmod(cur_l, 0o755)
    except OSError:
        pass
    dest = Path(bundle) / "Contents" / "Resources" / "AppIcon.icns"
    try:
        if not dest.exists() or dest.read_bytes() != src.read_bytes():
            dest.write_bytes(src.read_bytes())
    except OSError:
        pass
    stamp = Path(os.path.expanduser("~/Library/Application Support/OMAGAD/.icone"))
    try:
        sig = "%s:%d" % (bundle, src.stat().st_size + int(src.stat().st_mtime))
        if stamp.exists() and stamp.read_text() == sig:
            return  # icône déjà à jour : rien à refaire (démarrage plus rapide)
        stamp.write_text(sig)
    except OSError:
        pass
    try:  # icône personnalisée : prise en compte tout de suite par le Finder et le Dock
        from AppKit import NSImage, NSWorkspace
        img = NSImage.alloc().initWithContentsOfFile_(str(HERE / "icon.png"))
        if img is not None:
            NSWorkspace.sharedWorkspace().setIcon_forFile_options_(img, bundle, 0)
    except Exception:
        pass
    try:
        os.utime(bundle, None)
        if os.path.exists(LSREGISTER):
            subprocess.Popen([LSREGISTER, "-f", bundle], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def dock_icon_later():
    """L'icône du Dock doit être posée une fois l'app lancée (sinon macOS remet l'ancienne)."""
    if sys.platform != "darwin":
        return
    try:
        from AppKit import NSApplication, NSImage
        from PyObjCTools import AppHelper
        path = str(HERE / "icon.png")

        def apply():
            img = NSImage.alloc().initWithContentsOfFile_(path)
            if img is not None:
                NSApplication.sharedApplication().setApplicationIconImage_(img)
        for delay in (0.3, 1.5, 4.0):
            threading.Timer(delay, lambda: AppHelper.callAfter(apply)).start()
    except Exception:
        pass


MENU_TAG = 7700
MENU_TEXT = {
    "fr": {"settings": "Réglages…", "shortcuts": "Raccourcis clavier…", "lang": "Langue", "account": "Mon compte…",
           "update": "Vérifier les mises à jour…", "dmg": "Créer l'installateur (.dmg)…", "guide": "Revoir le guide"},
    "en": {"settings": "Settings…", "shortcuts": "Keyboard Shortcuts…", "lang": "Language", "account": "My Account…",
           "update": "Check for Updates…", "dmg": "Create Installer (.dmg)…", "guide": "Show Welcome Guide"},
}
_menu_target = None
_menu_win = None


def _menu_target_class():
    """Cible Objective-C des éléments de menu (créée une seule fois)."""
    global _menu_target
    if _menu_target is None:
        import objc
        from Foundation import NSObject

        class OMAGADMenuTarget(NSObject):
            @objc.IBAction
            def menuAction_(self, sender):
                what = str(sender.representedObject())
                win = _menu_win
                if win is None:
                    return
                # evaluate_js attend le résultat : jamais depuis le fil principal
                threading.Thread(target=lambda: win.evaluate_js("VC.menu(%s)" % json.dumps(what)), daemon=True).start()
        _menu_target = OMAGADMenuTarget.alloc().init()
    return _menu_target


def install_menu(win, lang="fr"):
    """Ajoute Réglages, Raccourcis clavier, Langue… dans le menu OMAGAD de la barre des menus (Mac)."""
    if sys.platform != "darwin":
        return
    try:
        from AppKit import NSApplication, NSMenu, NSMenuItem
        from PyObjCTools import AppHelper
    except Exception:
        return
    t = MENU_TEXT.get(lang, MENU_TEXT["fr"])

    def build():
        try:
            global _menu_win
            _menu_win = win
            target = _menu_target_class()
            main = NSApplication.sharedApplication().mainMenu()
            if main is None or main.numberOfItems() == 0:
                return
            app_menu = main.itemAtIndex_(0).submenu()
            for i in reversed(range(app_menu.numberOfItems())):  # on retire nos anciens éléments
                if app_menu.itemAtIndex_(i).tag() >= MENU_TAG:
                    app_menu.removeItemAtIndex_(i)
            # supprime aussi un éventuel « Settings/Préférences » vide ajouté par défaut
            pos = 1  # juste après « À propos d'OMAGAD »

            def add(item):
                nonlocal pos
                item.setTag_(MENU_TAG + pos)
                app_menu.insertItem_atIndex_(item, pos)
                pos += 1

            def action(title, what, key=""):
                it = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, "menuAction:", key)
                it.setTarget_(target)
                it.setRepresentedObject_(what)
                return it
            add(NSMenuItem.separatorItem())
            add(action(t["settings"], "settings", ","))
            add(action(t["shortcuts"], "shortcuts"))
            sub = NSMenu.alloc().initWithTitle_(t["lang"])
            for code, name in (("fr", "Français"), ("en", "English")):
                it = action(name, "lang:" + code)
                it.setState_(1 if code == lang else 0)
                sub.addItem_(it)
            lang_item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(t["lang"], None, "")
            lang_item.setSubmenu_(sub)
            add(lang_item)
            add(NSMenuItem.separatorItem())
            add(action(t["account"], "account"))
            add(action(t["update"], "update"))
            add(action(t["dmg"], "dmg"))
            add(action(t["guide"], "guide"))
        except Exception as e:  # le menu est un bonus : ne jamais bloquer l'app
            print("menu:", e)
    try:
        AppHelper.callAfter(build)
    except Exception:
        pass


def setup_drop(win):
    """Glisser-déposer : récupère le vrai chemin du fichier (pas de copie de la vidéo)."""
    dock_icon_later()
    try:
        from engine import config
        lang = config.load_settings().get("lang", "fr")
    except Exception:
        lang = "fr"
    for delay in (0.2, 1.2):  # après que pywebview a posé son propre menu
        threading.Timer(delay, lambda: install_menu(win, lang)).start()
    try:
        from webview.dom import DOMEventHandler

        def on_drop(e):
            files = (e.get("dataTransfer") or {}).get("files") or []
            paths = [f.get("pywebviewFullPath") for f in files if f.get("pywebviewFullPath")]
            if len(paths) > 1:
                win.evaluate_js("VC.dropPaths(%s)" % json.dumps(paths))
            elif paths:
                win.evaluate_js("VC.dropPath(%s)" % json.dumps(paths[0]))
        win.dom.document.events.drop += DOMEventHandler(on_drop, True, True)
    except Exception:
        pass


def main():
    try:
        import webview
    except ImportError:
        import server
        srv, url = server.start(0)
        os.environ["VLOGCLIPS_NATIVE"] = "0"
        print("pywebview absent : ouverture dans le navigateur (%s)" % url)
        webbrowser.open(url)
        while True:
            time.sleep(3600)
    mac_branding()
    threading.Timer(6.0, refresh_bundle_icon).start()  # après l'ouverture, hors du chemin critique
    bridge = Bridge()
    import server  # léger : le moteur se charge en arrière-plan
    srv, url = server.start(0)
    print("démarrage : serveur prêt en %.2f s" % (time.time() - _T0), flush=True)
    win = webview.create_window("OMAGAD", url, js_api=bridge, width=1480, height=940, min_size=(1100, 720),
                                background_color="#000000", text_select=True)
    bridge._win = win

    def boot(win):
        print("démarrage : fenêtre ouverte en %.2f s" % (time.time() - _T0), flush=True)
        setup_drop(win)
    webview.start(boot, win, debug=os.environ.get("VLOGCLIPS_DEBUG") == "1")
    os._exit(0)  # quitte tout de suite (pas de processus qui traîne derrière)


if __name__ == "__main__":
    main()
