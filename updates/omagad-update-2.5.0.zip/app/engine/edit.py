"""Règles partagées du montage d'un moment (mêmes règles que l'interface, ui/core.js)."""


def hook_at(clip):
    try:
        return max(0.0, float(clip.get("hook_at") or 0))
    except (TypeError, ValueError):
        return 0.0


def out_offset(st):
    from .anim import sfx_out_offset
    return sfx_out_offset(st)


def effective_sfx(clip, st):
    """Liste des sons du moment : [{sound, at (s depuis le début du clip), vol}].
    Sans liste explicite : le son d'entrée et de sortie de l'accroche définis dans le style."""
    if isinstance(clip.get("sfx"), list):
        return [s for s in clip["sfx"] if s.get("sound") and s.get("sound") != "none"]
    if not (clip.get("hook") or "").strip():
        return []
    h = hook_at(clip)
    out = []
    for key, at in (("sfx_in", h), ("sfx_out", h + out_offset(st))):
        if st.get(key) and st.get(key) != "none":
            out.append({"sound": st[key], "at": at, "vol": float(st.get(key + "_vol", 0.7))})
    return out


def crop_fx_expr(frame):
    """Position horizontale du cadre : constante, ou animée (recadrage automatique) en expression ffmpeg de t."""
    keys = frame.get("keys") if frame.get("auto") else None
    if not keys or len(keys) < 2:
        return "%.4f" % min(1.0, max(0.0, float(frame.get("fx", 0.5))))
    keys = sorted((float(t), min(1.0, max(0.0, float(v)))) for t, v in keys)
    expr = "%.4f" % keys[0][1]
    for (ta, va), (tb, vb) in zip(keys, keys[1:]):
        if tb - ta < 1e-3 or abs(vb - va) < 1e-4:
            continue
        expr += "+(%.4f)*clip((t-%.3f)/%.3f,0,1)" % (vb - va, ta, tb - ta)
    return expr


def fx_at(frame, rel):
    keys = frame.get("keys") if frame.get("auto") else None
    if not keys:
        return float(frame.get("fx", 0.5))
    keys = sorted(keys)
    if rel <= keys[0][0]:
        return keys[0][1]
    for (ta, va), (tb, vb) in zip(keys, keys[1:]):
        if rel <= tb:
            return va + (vb - va) * (rel - ta) / max(1e-6, tb - ta)
    return keys[-1][1]


def zoom_expr(frame):
    """Zooms aléatoires sur les cuts : facteur de zoom en expression ffmpeg de t (1 si désactivé)."""
    keys = frame.get("zooms") if (frame.get("zcfg") or {}).get("on") else None
    if not keys:
        return "1"
    ramp = 0.18 if (frame.get("zcfg") or {}).get("mode") == "smooth" else 0.001
    keys = sorted((float(t), float(z)) for t, z in keys)
    expr = "%.4f" % keys[0][1]
    for (ta, za), (tb, zb) in zip(keys, keys[1:]):
        if abs(zb - za) > 1e-4:
            expr += "+(%.4f)*clip((t-%.3f)/%.3f,0,1)" % (zb - za, tb, ramp)
    return expr


def _rng(seed):
    """Même générateur que l'interface (xorshift 32 bits) : mêmes zooms pour une même graine."""
    s = [(int(seed) & 0xFFFFFFFF) or 1]

    def nxt():
        x = s[0]
        x ^= (x << 13) & 0xFFFFFFFF
        x ^= x >> 17
        x ^= (x << 5) & 0xFFFFFFFF
        s[0] = x & 0xFFFFFFFF
        return (s[0] % 100000) / 100000
    return nxt


def make_zooms(m, cfg, lines):
    """Zooms aléatoires sur les changements de phrase (copie de VC.makeZooms)."""
    length = m["t1"] - m["t0"]
    rnd, max_z, every = _rng(cfg.get("seed") or 1), float(cfg.get("max") or 1.25), float(cfg.get("every") or 3)
    cuts, last = [], 0.0
    for ln in lines or []:
        t = ln["s"] - m["t0"]
        if 0.6 < t < length - 0.6 and t - last >= every * 0.8:
            cuts.append(t)
            last = t
    base = list(cuts)
    for i in range(len(base) + 1):
        a = base[i - 1] if i else 0
        b = base[i] if i < len(base) else length
        t = a + every * 1.4
        while t < b - every * 0.5:
            cuts.append(t)
            t += every * (1 + rnd() * 0.4)
    cuts.sort()
    keys = [[0, 1 + (max_z - 1) * rnd() if cfg.get("startWide") is False else 1]]
    prev = keys[0][1]
    for t in cuts:
        tries = 0
        while True:
            z = 1 + (max_z - 1) * rnd()
            tries += 1
            if not (abs(z - prev) < (max_z - 1) * 0.35 and tries < 12):
                break
        if cfg.get("alternate") and abs(prev - 1) > 0.02:
            z = 1
        keys.append([round(t, 2), round(z, 3)])
        prev = z
    return keys
