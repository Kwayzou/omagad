"""Restauration poussée du son saturé (utilisée par SONAGAD).

Deux traitements, appliqués seulement à partir du moment où le son sature :
1. Reconstruction des crêtes : chaque passage « collé » au plafond (même étalé par la compression AAC d'un MP4)
   est remplacé par une courbe lisse (spline cubique d'Hermite) qui prolonge le signal autour.
2. Égaliseur d'appariement : la saturation ajoute du grésillement dans les aigus et écrase le bas.
   On compare le timbre de la partie saturée à celui du début propre du set et on corrige l'écart
   (lissé par tiers d'octave et borné, pour ne pas dénaturer la musique).
Tout est traité en flux, morceau par morceau : un set de plusieurs heures ne remplit pas la mémoire.
"""
import numpy as np

SR = 48000
NFIR = 4096                      # longueur du filtre (phase linéaire, retard NFIR/2)
LOOK = 8192                      # contexte de chaque côté pour la reconstruction des crêtes (2 trames)
FORCE = {"rapide": (1.5, 30, 0.6), "maximale": (1.5, 60, 0.8)}  # (dB sous le plafond, itérations, force de l'égaliseur)


# ---------- 1. Reconstruction des crêtes ----------
FRAME, HOP, STEP = 4096, 1024, 8


def declip(x, thr, iters=60, maxgain=4.0, batch=512):
    """Reconstruction parcimonieuse cohérente (famille SPADE / IHT), trames traitées en lot.
    Dans chaque trame qui contient des crêtes écrêtées, on cherche le signal le plus « simple » en fréquence
    qui garde à l'identique les échantillons sains et dépasse le plafond là où le son était collé.
    x : (n, canaux) float ; thr : plafond par canal."""
    out = np.empty_like(x)
    for c in range(x.shape[1]):
        out[:, c] = _declip1(x[:, c], float(thr[c]), iters, maxgain, batch)
    return out


def _declip1(x, thr, iters, maxgain, batch):
    N, hop = FRAME, HOP
    n = len(x)
    if not (np.abs(x) >= thr).any():
        return x.copy()
    xp = np.concatenate([np.zeros(N), x, np.zeros(2 * N)])
    m = np.abs(xp) >= thr
    starts = np.arange(0, len(xp) - N + 1, hop)
    w = np.hanning(N + 1)[:N]
    out = np.zeros_like(xp)
    norm = np.zeros_like(xp)
    cm = np.concatenate(([0], np.cumsum(m)))
    has = (cm[starts + N] - cm[starts]) > 0
    for st in starts[~has]:
        out[st:st + N] += xp[st:st + N] * w
        norm[st:st + N] += w
    sel = starts[has]
    ar = np.arange(N)
    for b0 in range(0, len(sel), batch):
        st = sel[b0:b0 + batch]
        ii = st[:, None] + ar[None, :]
        y = xp[ii]
        mm = m[ii]
        pos, neg, rel = mm & (y > 0), mm & (y < 0), ~mm
        xx = y.copy()
        hi, lo = np.maximum(y, thr * maxgain), np.minimum(y, -thr * maxgain)
        for it in range(iters):
            k = min(STEP * (it + 1), N)
            Z = np.fft.rfft(xx, 2 * N, axis=1)
            mag = np.abs(Z)
            kth = -np.partition(-mag, k - 1, axis=1)[:, k - 1:k]
            Z[mag < kth] = 0
            xh = np.fft.irfft(Z, 2 * N, axis=1)[:, :N]
            xx = np.where(rel, y, np.where(pos, np.clip(xh, y, hi), np.clip(xh, lo, y)))
        for j, s0 in enumerate(st):
            out[s0:s0 + N] += xx[j] * w
            norm[s0:s0 + N] += w
    res = np.where(norm > 1e-6, out / np.maximum(norm, 1e-9), xp)
    return res[N:N + n]


def clip_threshold(seg, below_db):
    """Plafond de la partie saturée (par canal), moins une marge pour attraper les crêtes étalées."""
    p = np.percentile(np.abs(seg), 99.5, axis=0)
    return p * 10 ** (-below_db / 20)


# ---------- 2. Égaliseur d'appariement ----------
def spectrum(x, n=8192):
    x = x.mean(axis=1)
    hop = n // 2
    w = np.hanning(n)
    frames = (len(x) - n) // hop
    if frames < 4:
        return None
    acc = np.zeros(n // 2 + 1)
    for i in range(0, frames, max(1, frames // 400)):               # au plus ~400 trames
        acc += np.abs(np.fft.rfft(x[i * hop:i * hop + n] * w)) ** 2
    return acc


def match_fir(clean, dirty, strength):
    """Filtre (phase linéaire) qui donne au son « dirty » le timbre moyen du son « clean »."""
    a, b = spectrum(clean), spectrum(dirty)
    if a is None or b is None:
        return None
    f = np.fft.rfftfreq(8192, 1 / SR)
    diff = 10 * np.log10((a + 1e-12) / (b + 1e-12))
    # lissage par tiers d'octave
    lf = np.log2(np.maximum(f, 1.0))
    sm = np.empty_like(diff)
    for i in range(len(f)):
        sel = np.abs(lf - lf[i]) <= 1 / 6
        sm[i] = diff[sel].mean()
    band = (f >= 200) & (f <= 4000)
    sm -= np.median(sm[band])                                      # forme seulement : le niveau est géré à part
    sm = np.clip(sm * strength, -10.0, 4.0)
    sm[(f < 30) | (f > 18000)] = 0.0
    sm = np.convolve(sm, np.ones(9) / 9, mode="same")
    fg = np.fft.rfftfreq(NFIR, 1 / SR)
    H = 10 ** (np.interp(fg, f, sm) / 20)
    h = np.roll(np.fft.irfft(H, n=NFIR), NFIR // 2) * np.hanning(NFIR)
    return h.astype(np.float64), {"freq": [float(x) for x in fg[::16]], "db": [round(float(x), 2) for x in np.interp(fg, f, sm)[::16]]}


# ---------- 3. Traitement en flux ----------
def treat(x, thr, iters, ul, dh):
    """Chaîne complète sur un bloc : crêtes coupées → dé-limiteur → anti-grésillement."""
    if thr is not None:
        x = declip(x, thr, iters)
    x = unlimit(x, ul)
    return deharsh(x, dh)


class Restorer:
    """Reçoit l'audio d'origine par morceaux (n, 2), rend l'audio restauré, même longueur au total."""

    def __init__(self, start, drop_db, fade, thr, fir, t_offset=0.0, iters=60, do_declip=True, ul=None, dh=None, headroom_db=0.0):
        self.t0 = max(0.0, start - fade / 2)
        self.fade = max(0.5, fade)
        self.g = 10 ** (-(abs(drop_db) + headroom_db) / 20)
        self.do_declip, self.ul, self.dh = do_declip, ul, dh
        self.thr = thr
        self.iters = iters
        self.fir = fir
        self.dc_from = max(0.0, start - 10)                       # reconstruction 10 s avant, par sécurité
        self.off = t_offset
        self.left = np.zeros((0, 2))                                # contexte déjà rendu (pour la spline)
        self.carry = np.zeros((0, 2))                               # anticipation pas encore rendue
        self.in_pos = 0                                             # échantillons d'origine sortis de l'étage 1
        self.d = NFIR // 2 if fir is not None else 0
        self.hw = np.zeros((NFIR - 1, 2)) if fir is not None else None   # historique de l'étage filtre (mouillé)
        self.hd = np.zeros((NFIR - 1, 2)) if fir is not None else None   # historique (sec)
        self.out_pos = -self.d                                      # temps (en échantillons) du prochain son rendu
        if fir is not None:
            self.Hk = {}

    def _stage1(self, chunk, final=False):
        buf = np.concatenate([self.left, self.carry, chunk])
        nl = len(self.left)
        end = len(buf) if final else max(nl, len(buf) - LOOK)
        raw = buf[nl:end]
        # temps absolu du premier échantillon de raw
        t_raw = self.in_pos / SR + self.off
        if len(raw) and t_raw + len(raw) / SR > self.dc_from:
            fixed = treat(buf, self.thr if self.do_declip else None, self.iters, self.ul, self.dh)[nl:end]
            k = int(max(0, (self.dc_from - t_raw) * SR))
            if k:
                fixed[:k] = raw[:k]
        else:
            fixed = raw.copy()
        self.left = buf[max(0, end - LOOK):end]
        self.carry = buf[end:]
        self.in_pos += len(raw)
        return raw, fixed

    def _conv(self, hist, x):
        seg = np.concatenate([hist, x])
        n = len(seg)
        nf = 1 << int(np.ceil(np.log2(n + NFIR)))
        if nf not in self.Hk:
            self.Hk[nf] = np.fft.rfft(self.fir, nf)
        y = np.fft.irfft(np.fft.rfft(seg, nf, axis=0) * self.Hk[nf][:, None], nf, axis=0)[NFIR - 1:n]
        return y, seg[-(NFIR - 1):]

    def _weights(self, n):
        t = (self.out_pos + np.arange(n)) / SR + self.off
        return np.clip((t - self.t0) / self.fade, 0.0, 1.0)[:, None]

    def process(self, chunk, final=False):
        raw, fixed = self._stage1(chunk, final)
        if self.fir is not None:
            if final:  # vide le filtre
                raw = np.concatenate([raw, np.zeros((self.d, 2))])
                fixed = np.concatenate([fixed, np.zeros((self.d, 2))])
            wet, self.hw = self._conv(self.hw, fixed)
            seg = np.concatenate([self.hd, raw])
            dry = seg[NFIR - 1 - self.d:len(seg) - self.d]
            self.hd = seg[-(NFIR - 1):]
        else:
            wet, dry = fixed, raw
        w = self._weights(len(wet))
        out = (dry * (1 - w) + wet * w) * (1 + (self.g - 1) * w)
        skip = max(0, -self.out_pos)
        self.out_pos += len(out)
        return out[skip:]


# ---------- 4. Diagnostic : écrêtage (crêtes à plat) ou écrasement (limiteur) ? ----------
def clip_kind(seg):
    """Longueur médiane des passages collés au plafond : >= 4 échantillons → crêtes coupées à plat
    (à reconstruire) ; sinon → son écrasé par un limiteur (à dé-limiter)."""
    a = np.abs(seg).max(axis=1)
    top = np.percentile(a, 99.9) * 10 ** (-0.5 / 20)
    m = a >= top
    d = np.diff(np.concatenate(([0], m.view(np.int8), [0])))
    runs = np.where(d == -1)[0] - np.where(d == 1)[0]
    return float(np.median(runs)) if len(runs) else 0.0


# ---------- 5. Dé-limiteur (B) ----------
def unlimit_params(seg, amount):
    """Plafond du limiteur et seuil à partir duquel il agissait (4 dB dessous)."""
    a = np.abs(seg).max(axis=1)
    ceil = float(np.percentile(a, 99.9))
    return {"ceil": ceil, "thr": ceil * 10 ** (-4.0 / 20), "amount": float(amount)}


def _movmax(v, w):
    """Maximum glissant centré (fenêtre w impaire), en numpy pur."""
    h = w // 2
    p = np.concatenate([np.full(h, v[0]), v, np.full(h, v[-1])])
    from numpy.lib.stride_tricks import sliding_window_view
    return sliding_window_view(p, w).max(axis=1)


def unlimit(x, p):
    """Expansion des crêtes : là où le limiteur a tassé le signal près du plafond, on redonne du gain,
    de façon lisse (enveloppe centrée de ~10 ms, sans distorsion). amount 1 → +1 dB par dB au-dessus du seuil."""
    if p is None or p["amount"] <= 0:
        return x
    env = np.abs(x).max(axis=1)
    env = _movmax(env, int(0.004 * SR) | 1)                        # tient la crête 4 ms
    k = np.hanning(int(0.012 * SR) | 1)
    env = np.convolve(env, k / k.sum(), mode="same")              # lissage centré 12 ms (phase nulle)
    over = 20 * np.log10(np.maximum(env, 1e-9) / p["thr"])
    g_db = np.clip(over, 0, None) * p["amount"]
    g_db = np.minimum(g_db, 8.0)                                   # au plus +8 dB
    return x * (10 ** (g_db / 20))[:, None]


# ---------- 6. Anti-grésillement dynamique (C) ----------
DH_N, DH_HOP = 2048, 512
DH_EDGES = np.geomspace(1500, 16000, 13)                           # 12 bandes de 1,5 à 16 kHz


def _frames_bands(x):
    """Énergie (dB) par trame : bande de référence 150-1500 Hz et 12 bandes aiguës."""
    v = x.mean(axis=1)
    n = (len(v) - DH_N) // DH_HOP + 1
    if n < 1:
        return None, None
    from numpy.lib.stride_tricks import sliding_window_view
    fr = sliding_window_view(v, DH_N)[::DH_HOP][:n] * np.hanning(DH_N)
    P = np.abs(np.fft.rfft(fr, axis=1)) ** 2
    f = np.fft.rfftfreq(DH_N, 1 / SR)
    ref = 10 * np.log10(P[:, (f >= 150) & (f < 1500)].sum(1) + 1e-12)
    bands = np.stack([10 * np.log10(P[:, (f >= a) & (f < b)].sum(1) + 1e-12) for a, b in zip(DH_EDGES[:-1], DH_EDGES[1:])], 1)
    return ref, bands


def deharsh_params(seg, clean=None, amount=0.6):
    """Calibre le traitement : timbre « normal » = début propre du set s'il existe, sinon les 25 % de moments
    les moins agressifs de la partie saturée (la distorsion grimpe avec le volume)."""
    src = clean if clean is not None and len(clean) > SR * 20 else seg
    ref, bands = _frames_bands(src)
    if ref is None:
        return None
    loud = ref > np.percentile(ref, 30)                            # ignore les silences et breaks
    r = bands[loud] - ref[loud, None]
    target = np.median(r, 0) if src is clean else np.percentile(r, 25, axis=0)
    return {"target": target, "amount": float(amount)}


def deharsh(x, p, maxcut=12.0):
    if p is None or p["amount"] <= 0 or len(x) < DH_N:
        return x
    N, hop = DH_N, DH_HOP
    n = len(x)
    pad = np.concatenate([np.zeros((N, 2)), x, np.zeros((2 * N, 2))])
    nf = (len(pad) - N) // hop + 1
    from numpy.lib.stride_tricks import sliding_window_view
    w = np.hanning(N)
    f = np.fft.rfftfreq(N, 1 / SR)
    fr = sliding_window_view(pad, N, axis=0)[::hop][:nf]           # (nf, 2, N)
    S = np.fft.rfft(fr * w, axis=2)
    P = (np.abs(S) ** 2).sum(1)                                    # (nf, bins)
    ref = 10 * np.log10(P[:, (f >= 150) & (f < 1500)].sum(1) + 1e-12)
    bands = np.stack([10 * np.log10(P[:, (f >= a) & (f < b)].sum(1) + 1e-12) for a, b in zip(DH_EDGES[:-1], DH_EDGES[1:])], 1)
    excess = bands - ref[:, None] - p["target"][None, :]
    cut = -np.clip(excess, 0, maxcut) * p["amount"]               # (nf, 12) dB
    k = np.hanning(9)[1:-1]
    cut = np.apply_along_axis(lambda c: np.convolve(c, k / k.sum(), mode="same"), 0, cut)   # lissage temps (±3 trames)
    cut = np.apply_along_axis(lambda c: np.convolve(c, [.25, .5, .25], mode="same"), 1, cut)  # lissage bandes
    centers = np.sqrt(DH_EDGES[:-1] * DH_EDGES[1:])
    lf = np.log2(np.maximum(f, 1))
    G = np.empty((nf, len(f)))
    for i in range(nf):
        G[i] = np.interp(lf, np.log2(centers), cut[i], left=0.0, right=cut[i, -1])
    G[:, f < 1200] = 0.0
    G = 10 ** (G / 20)
    y = np.fft.irfft(S * G[:, None, :], N, axis=2) * w            # synthèse
    out = np.zeros_like(pad)
    norm = np.zeros(len(pad))
    for i in range(nf):
        s = i * hop
        out[s:s + N] += y[i].T
        norm[s:s + N] += w * w
    out = out / np.maximum(norm, 1e-9)[:, None]
    return out[N:N + n]
