"""Choix des moments forts et des accroches avec l'API Anthropic (appel HTTPS direct, sans SDK)."""
import json
import os
import re
import ssl
import urllib.error
import urllib.request

API = os.environ.get("ANTHROPIC_API_URL", "https://api.anthropic.com/v1/messages")

CLIPS_TOOL = {
    "name": "propose_clips",
    "description": "Propose les meilleurs moments du vlog à publier en clips verticaux.",
    "input_schema": {"type": "object", "required": ["clips"], "properties": {"clips": {"type": "array", "items": {
        "type": "object",
        "required": ["start_line", "end_line", "score", "hook", "reason", "caption"],
        "properties": {
            "start_line": {"type": "integer", "description": "Numéro de la première phrase du clip."},
            "end_line": {"type": "integer", "description": "Numéro de la dernière phrase du clip (incluse)."},
            "score": {"type": "integer", "minimum": 1, "maximum": 10, "description": "Potentiel du moment, 10 = très fort."},
            "hook": {"type": "string", "description": "Texte d'accroche affiché en gros au début du clip."},
            "emphasis": {"type": "string", "description": "Un mot du hook à mettre en couleur."},
            "reason": {"type": "string", "description": "Pourquoi ce moment fonctionne, en une phrase."},
            "caption": {"type": "string", "description": "Description à publier, 1 à 2 phrases, avec 3 à 5 hashtags."}}}}}},
}
HOOKS_TOOL = {
    "name": "propose_hooks",
    "description": "Propose des accroches alternatives pour un clip.",
    "input_schema": {"type": "object", "required": ["hooks"], "properties": {"hooks": {
        "type": "array", "items": {"type": "string"}, "minItems": 3, "maxItems": 3}}},
}

HOOK_RULES = (
    "Règles du hook : 3 à 8 mots, 55 caractères maximum, français parlé et naturel, qui crée de la curiosité ou une "
    "tension sans mentir sur le contenu. Il doit être directement lié à ce qui se dit dans le clip. Pas d'emoji, pas de "
    "hashtag, pas de guillemets, pas de point final. Les majuscules sont gérées par l'application."
)


def _ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _post(key, payload):
    req = urllib.request.Request(API, data=json.dumps(payload).encode("utf-8"), method="POST", headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=300, context=_ctx()) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        try:
            detail = json.loads(detail)["error"]["message"]
        except Exception:
            pass
        raise RuntimeError("Erreur de l'API Anthropic (%s) : %s" % (e.code, detail)) from e
    except urllib.error.URLError as e:
        raise RuntimeError("Impossible de joindre l'API Anthropic : %s" % e.reason) from e


def _json_from_text(text):
    """Extrait le premier objet JSON d'une réponse texte (```json ... ``` ou { ... })."""
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    cands = [m.group(1)] if m else []
    i = text.find("{")
    if i >= 0:
        cands.append(text[i:text.rfind("}") + 1])
    for c in cands:
        try:
            return json.loads(c)
        except ValueError:
            continue
    return None


def _call(settings, system, user, tool):
    """Demande une réponse structurée. L'outil est proposé sans être imposé (certains modèles refusent
    l'outil obligatoire) ; si le modèle répond en texte, on lit le JSON dans le texte."""
    key = settings.get("api_key", "")
    if not key:
        raise RuntimeError("Clé API Anthropic manquante. Ajoute-la dans les réglages.")
    schema = json.dumps(tool["input_schema"], ensure_ascii=False)
    sys2 = (system + "\n\nRéponds en appelant l'outil « %s ». Si tu ne peux pas utiliser d'outil, réponds uniquement "
            "avec un objet JSON conforme à ce schéma, sans aucun autre texte : %s" % (tool["name"], schema))
    payload = {"model": settings.get("claude_model") or "claude-sonnet-5-5", "max_tokens": 16000, "system": sys2,
               "messages": [{"role": "user", "content": user}], "tools": [tool], "tool_choice": {"type": "auto"}}
    try:
        data = _post(key, payload)
    except RuntimeError as e:
        if "(400)" not in str(e) or "tool" not in str(e).lower():
            raise
        payload.pop("tools")  # modèle sans outils : réponse JSON en texte
        payload.pop("tool_choice")
        data = _post(key, payload)
    text = ""
    for block in data.get("content", []):
        if block.get("type") == "tool_use" and isinstance(block.get("input"), dict):
            return block["input"]
        if block.get("type") == "text":
            text += block.get("text", "")
    out = _json_from_text(text)
    if isinstance(out, dict):
        return out
    raise RuntimeError("Réponse de Claude illisible. Réessaie, ou choisis un autre modèle dans les Réglages.")


def _mmss(t):
    return "%d:%02d" % (int(t // 60), int(t % 60))


LENGTHS = {"short": (15, 30), "medium": (20, 60), "long": (30, 90)}


def target_count(settings, duration):
    t = int(settings.get("clips_target") or 0)
    if t > 0:
        return t
    return max(4, min(40, round(duration / 60 * 0.62)))  # ~ 18 clips pour 30 minutes


def pick_moments(settings, lines, duration):
    n = target_count(settings, duration)
    lo, hi = LENGTHS.get(settings.get("clips_length") or "medium", (20, 60))
    transcript = "\n".join("[%d] %s  %s" % (l["id"], _mmss(l["s"]), l["text"]) for l in lines)
    system = (
        "Tu es monteur vidéo spécialisé dans les clips verticaux pour TikTok, Reels et Shorts. Tu reçois la "
        "transcription d'un vlog, découpée en phrases numérotées avec leur horodatage. Ton travail : trouver un maximum "
        "de moments publiables, qui fonctionnent seuls sans le reste de la vidéo.")
    user = (
        "Durée du vlog : %s. Trouve AU MOINS %d moments (vise %d à %d), chacun de %d à %d secondes. Parcours toute la "
        "transcription, du début à la fin, et répartis les moments sur l'ensemble du vlog : ne te limite pas aux meilleurs.\n\n"
        "Ce qui fait un moment publiable (sois large) : une anecdote ou une histoire, une révélation, un rebondissement, une "
        "punchline, un moment drôle ou gênant, une réaction forte, une émotion, un conseil concret, une opinion tranchée, une "
        "question intrigante, un avant/après, une coulisse (préparation, backstage, trajet, matériel), une interaction avec "
        "quelqu'un, un moment de tension ou de suspense, une phrase qui marche en citation. Le clip doit se comprendre sans "
        "contexte, commencer sur une phrase qui accroche (jamais un 'salut' ou une transition) et finir sur une idée complète. "
        "Évite seulement les vrais temps morts. Les moments peuvent se suivre mais ne se chevauchent pas.\n\n%s\n\nTranscription :\n%s"
        % (_mmss(duration), n, n, n + 6, lo, hi, HOOK_RULES, transcript))
    prof = settings.get("profile") or {}
    if prof.get("artist") or prof.get("hashtags"):
        user += ("\n\nInfos sur le créateur : %s. Dans chaque description, glisse aussi ces hashtags : %s"
                 % (prof.get("artist") or "vlogueur", prof.get("hashtags") or "aucun"))
    out = _call(settings, system, user, CLIPS_TOOL)
    return _build(out.get("clips", []), lines, duration, min_len=max(8.0, lo * 0.6), max_len=hi * 1.5)


def _clean_hook(text):
    text = re.sub(r"[\"“”«»]", "", text or "").strip().rstrip(".")
    return re.sub(r"\s+", " ", text)[:60]


def _build(raw, lines, duration, min_len=12.0, max_len=90.0):
    picked = []
    for c in sorted(raw, key=lambda c: -int(c.get("score", 0))):
        try:
            a, b = int(c["start_line"]), int(c["end_line"])
        except (KeyError, TypeError, ValueError):
            continue
        if not (0 <= a <= b < len(lines)):
            continue
        t0 = max(0.0, lines[a]["s"] - 0.2)
        if t0 >= duration - 3:
            continue
        while b > a and lines[b]["e"] - t0 > max_len:
            b -= 1
        t1 = min(duration, lines[b]["e"] + 0.35)
        while t1 - t0 < min_len and b + 1 < len(lines):
            b += 1
            t1 = min(duration, lines[b]["e"] + 0.35)
        if any(min(t1, p["t1"]) - max(t0, p["t0"]) > 0.3 * (t1 - t0) for p in picked):
            continue
        hook = _clean_hook(c.get("hook"))
        emph = (c.get("emphasis") or "").strip()
        if emph and emph.lower() not in hook.lower():
            emph = ""
        picked.append({"t0": round(t0, 2), "t1": round(t1, 2), "score": int(c.get("score", 5)), "hook": hook,
                       "emphasis": emph, "reason": (c.get("reason") or "").strip(),
                       "caption": (c.get("caption") or "").strip()})
    return finalize(picked)


def finalize(picked, source="claude"):
    picked.sort(key=lambda p: p["t0"])
    for i, p in enumerate(picked):
        p.update(id="m%d" % (i + 1), status="todo", export=True, source=source, subs=None, style=None,
                 frame={"mode": "fill", "fx": 0.5, "fy": 0.5, "zoom": 1.0, "punch": True})
    return picked


# ---------- Détection sans clé API : densité de parole + marqueurs d'émotion ----------
STRONG = set("""incroyable jamais fou folle dingue ouf pire meilleur meilleure secret vrai vraiment choqué choquée
honnêtement franchement énorme grave impossible premier première dernière dernier histoire problème peur
erreur bizarre trop jamais personne toujours enfin surprise oh wow mdr attends regardez regarde""".split())


def heuristic_moments(lines, duration, target_len=35.0, n=None):
    if not lines:
        return []
    n = n or max(4, min(40, round(duration / 60 * 0.62)))
    scored = []
    for a in range(len(lines)):
        b = a
        while b + 1 < len(lines) and lines[b + 1]["e"] - lines[a]["s"] <= target_len:
            b += 1
        span = max(1.0, lines[b]["e"] - lines[a]["s"])
        if span < 12:
            continue
        text = " ".join(l["text"] for l in lines[a:b + 1]).lower()
        words = re.findall(r"[\w']+", text)
        density = len(words) / span
        marks = text.count("!") * 1.5 + text.count("?") + sum(1 for w in words if w in STRONG) * 1.2
        first = lines[a]["text"].lower()
        opener_penalty = 2.0 if re.match(r"^(salut|bonjour|hello|bon|donc|euh|alors voilà)", first) else 0
        scored.append((density + marks - opener_penalty, a, b))
    scored.sort(reverse=True)
    picked = []
    for sc, a, b in scored:
        t0, t1 = max(0.0, lines[a]["s"] - 0.2), min(duration, lines[b]["e"] + 0.35)
        if any(min(t1, p["t1"]) - max(t0, p["t0"]) > 0 for p in picked):
            continue
        hook = _clean_hook(" ".join(lines[a]["text"].split()[:7]))
        picked.append({"t0": round(t0, 2), "t1": round(t1, 2), "score": max(1, min(10, round(sc))), "hook": hook,
                       "emphasis": "", "reason": "Choisi automatiquement (sans clé API) : passage dense et expressif.",
                       "caption": ""})
        if len(picked) >= n:
            break
    return finalize(picked, source="auto")


def suggest_hooks(settings, text):
    user = "Voici ce qui se dit dans un clip de vlog :\n\n%s\n\nPropose 3 accroches différentes.\n%s" % (text, HOOK_RULES)
    out = _call(settings, "Tu écris des accroches pour des clips verticaux.", user, HOOKS_TOOL)
    return [_clean_hook(h) for h in out.get("hooks", []) if h][:3]
