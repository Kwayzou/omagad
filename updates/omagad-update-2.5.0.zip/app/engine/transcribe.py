"""Transcription locale (faster-whisper) avec horodatage mot par mot."""
import os
import re


MLX_MODELS = {"base": "mlx-community/whisper-base-mlx", "small": "mlx-community/whisper-small-mlx",
              "medium": "mlx-community/whisper-medium-mlx", "large-v3": "mlx-community/whisper-large-v3-turbo"}


def mlx_available():
    """Transcription sur la puce Apple (M1, M2, M3…) : 4 à 8 fois plus rapide que sur le processeur."""
    if os.environ.get("OMAGAD_NO_MLX") == "1":
        return False
    try:
        import importlib
        import importlib.util
        importlib.invalidate_caches()
        return importlib.util.find_spec("mlx_whisper") is not None
    except Exception:
        return False


_mlx_state = {"busy": False}


def ensure_mlx():
    """Installe le moteur « puce Apple » en arrière-plan (une seule fois, sans bloquer l'app)."""
    import platform
    import subprocess
    import sys
    import threading
    if sys.platform != "darwin" or platform.machine() != "arm64" or mlx_available() or _mlx_state["busy"]:
        return
    import time
    from .config import DATA
    stamp = DATA / ".mlx-essai"
    try:  # un essai par jour au plus (pas d'installation relancée à chaque ouverture)
        if stamp.exists() and time.time() - stamp.stat().st_mtime < 86400:
            return
        stamp.write_text(str(time.time()))
    except OSError:
        pass
    _mlx_state["busy"] = True

    def go():
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--quiet",
                            "--no-warn-script-location", "mlx-whisper>=0.4"], capture_output=True, timeout=3600)
        except Exception as e:
            print("installation mlx-whisper :", e)
        finally:
            _mlx_state["busy"] = False
    threading.Thread(target=go, daemon=True).start()


def engine_name():
    return "apple" if mlx_available() else ("installing" if _mlx_state["busy"] else "cpu")


def _load_wav(path):
    import wave
    import numpy as np
    with wave.open(str(path), "rb") as w:
        raw, ch = w.readframes(w.getnframes()), w.getnchannels()
    a = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    return a.reshape(-1, ch).mean(axis=1) if ch > 1 else a


def transcribe_mlx(wav_path, model_size, language, on_progress):
    import sys
    import mlx_whisper
    mt = sys.modules["mlx_whisper.transcribe"]  # le module (mlx_whisper.transcribe est aussi le nom de la fonction)
    audio = _load_wav(wav_path)
    total_frames = max(1, len(audio) // 160)  # 100 images de spectrogramme par seconde

    class _Bar:  # remplace la barre de progression de mlx-whisper par la nôtre
        def __init__(self, total=None, **kw):
            self.total, self.n = total or total_frames, 0

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def update(self, k):
            self.n += k
            on_progress(min(1.0, self.n / max(1, self.total)), "Transcription de la parole (puce Apple)...")

    class _Shim:
        tqdm = _Bar
    old = getattr(mt, "tqdm", None)
    mt.tqdm = _Shim
    on_progress(0.0, "Chargement du modèle Whisper (téléchargement la première fois)...")
    kw = dict(path_or_hf_repo=MLX_MODELS.get(model_size, MLX_MODELS["small"]), language=language or None,
              word_timestamps=True, condition_on_previous_text=False, verbose=False)
    try:
        try:
            r = mlx_whisper.transcribe(audio, hallucination_silence_threshold=2.0, **kw)
        except TypeError:
            r = mlx_whisper.transcribe(audio, **kw)
    finally:
        if old is not None:
            mt.tqdm = old
    words = []
    for seg in r.get("segments", []):
        for w in seg.get("words") or []:
            txt = (w.get("word") or "").strip()
            if txt:
                words.append({"w": txt, "s": round(float(w["start"]), 2), "e": round(float(w["end"]), 2)})
    return words, r.get("language")


def transcribe(wav_path, model_size, language, on_progress):
    if mlx_available():
        try:
            return transcribe_mlx(wav_path, model_size, language, on_progress)
        except Exception as e:  # puce Apple indisponible : on repasse sur le processeur
            print("mlx-whisper :", e)
    try:
        from faster_whisper import WhisperModel
    except ImportError as e:
        raise RuntimeError("faster-whisper n'est pas installé. Lance start.command (ou start.bat) pour l'installer.") from e
    on_progress(0.0, "Chargement du modèle Whisper (téléchargement la première fois)...")
    model = WhisperModel(model_size, device="cpu", compute_type="int8", cpu_threads=min(8, os.cpu_count() or 4))
    # on donne directement le son (et pas le fichier) : faster-whisper n'a pas besoin de PyAV pour le lire.
    # (les versions récentes de PyAV ont retiré l'option « metadata_errors » qu'il utilisait → erreur.)
    audio = _load_wav(wav_path)
    segments, info = model.transcribe(
        audio, language=language or None, word_timestamps=True, vad_filter=True,
        beam_size=3, condition_on_previous_text=False)
    total = max(info.duration, 1.0)
    words = []
    for seg in segments:
        for w in (seg.words or []):
            txt = w.word.strip()
            if txt:
                words.append({"w": txt, "s": round(w.start, 2), "e": round(w.end, 2)})
        on_progress(min(seg.end / total, 1.0), "Transcription de la parole...")
    return words, info.language


_END = re.compile(r"[.!?…]$")


def make_lines(words, max_len=10.0, gap=0.7):
    """Regroupe les mots en phrases courtes : c'est l'unité que Claude utilise pour couper proprement."""
    lines, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        if (nxt is None or _END.search(w["w"]) or nxt["s"] - w["e"] > gap or w["e"] - cur[0]["s"] > max_len):
            lines.append({"id": len(lines), "s": cur[0]["s"], "e": cur[-1]["e"], "text": " ".join(x["w"] for x in cur)})
            cur = []
    return lines
