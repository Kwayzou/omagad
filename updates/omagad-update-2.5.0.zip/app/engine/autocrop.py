"""Recadrage automatique : suit le visage principal pour le garder au centre du cadre 9:16.

Détecteur : YuNet (réseau de neurones d'OpenCV, fourni avec l'app) ; sinon visages Haar ; sinon mouvement.
La trajectoire est lissée sans retard (moyenne centrée) pour que le sujet reste vraiment au milieu."""
import subprocess
from pathlib import Path

from . import media
from .media import NOWIN

SAMPLE_FPS = 6
SW = 480  # largeur d'analyse
YUNET = Path(__file__).resolve().parent / "models" / "face_detection_yunet_2023mar.onnx"


def _frames(src, t0, t1, w, h, color=False):
    sh = int(round(SW * h / w / 2)) * 2
    cmd = [media.FFMPEG, "-hide_banner", "-loglevel", "error", "-ss", "%.3f" % t0, "-i", str(src), "-t", "%.3f" % (t1 - t0),
           "-vf", "fps=%d,scale=%d:%d,format=%s" % (SAMPLE_FPS, SW, sh, "bgr24" if color else "gray"), "-f", "rawvideo", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, **NOWIN)
    size = SW * sh * (3 if color else 1)
    i = 0
    while True:
        buf = p.stdout.read(size)
        if len(buf) < size:
            break
        yield i / SAMPLE_FPS, buf, sh
        i += 1
    p.wait()


def _smooth(vals, k=3):
    out = []
    for i in range(len(vals)):
        win = sorted(vals[max(0, i - k): i + k + 1])
        out.append(win[len(win) // 2])
    return out


def _simplify(pts, eps):
    """Ramer-Douglas-Peucker : garde peu de points clés."""
    if len(pts) < 3:
        return pts
    (x0, y0), (x1, y1) = pts[0], pts[-1]
    best, idx = -1, 0
    for i in range(1, len(pts) - 1):
        x, y = pts[i]
        yl = y0 + (y1 - y0) * (x - x0) / max(1e-9, x1 - x0)
        d = abs(y - yl)
        if d > best:
            best, idx = d, i
    if best <= eps:
        return [pts[0], pts[-1]]
    return _simplify(pts[:idx + 1], eps)[:-1] + _simplify(pts[idx:], eps)


def _yunet(cv2, sh):
    try:
        if YUNET.exists() and hasattr(cv2, "FaceDetectorYN"):
            return cv2.FaceDetectorYN.create(str(YUNET), "", (SW, sh), 0.55, 0.3, 50)
    except Exception as e:
        print("YuNet indisponible :", e)
    return None


def _interp(xs):
    """Remplit les trous (images sans visage) par interpolation entre les détections voisines."""
    idx = [i for i, x in enumerate(xs) if x is not None]
    if not idx:
        return xs
    out = list(xs)
    for i in range(idx[0]):
        out[i] = xs[idx[0]]
    for i in range(idx[-1] + 1, len(xs)):
        out[i] = xs[idx[-1]]
    for a, b in zip(idx, idx[1:]):
        for i in range(a + 1, b):
            u = (i - a) / (b - a)
            out[i] = xs[a] * (1 - u) + xs[b] * u
    return out


def _center_avg(vals, k):
    out = []
    for i in range(len(vals)):
        win = vals[max(0, i - k): i + k + 1]
        out.append(sum(win) / len(win))
    return out


def track(src, info, t0, t1, zoom=1.0, on_progress=None):
    """Renvoie {"keys": [[t, fx], ...], "found": proportion d'images avec un visage}."""
    import numpy as np
    try:
        import cv2
    except ImportError:
        cv2 = None
    w, h = info["width"], info["height"]
    sh = int(round(SW * h / w / 2)) * 2
    # largeur du cadre 9:16 rapportée à la largeur de la vidéo
    r = min(1.0, (h * 9 / 16) / w / max(1.0, zoom))
    if r >= 0.999:
        return {"keys": [], "found": 0.0, "message": "La vidéo est déjà verticale : rien à recadrer."}
    yn = _yunet(cv2, sh) if cv2 is not None else None
    front = prof = upper = None
    if cv2 is not None:
        base = getattr(getattr(cv2, "data", None), "haarcascades", "") or ""
        cs = [cv2.CascadeClassifier(base + n) for n in ("haarcascade_frontalface_default.xml",
                                                          "haarcascade_profileface.xml", "haarcascade_upperbody.xml")]
        if not cs[0].empty():
            front, prof, upper = cs
    last_gray = None
    total = max(1, int((t1 - t0) * SAMPLE_FPS))
    xs, ts, hits, prev = [], [], 0, None
    for t, buf, _ in _frames(src, t0, t1, w, h, color=yn is not None):
        cands = []
        if yn is not None:
            img3 = np.frombuffer(buf, dtype=np.uint8).reshape(sh, SW, 3)
            try:
                _, faces = yn.detect(img3)
            except Exception:
                faces = None
            for f in (faces if faces is not None else []):
                x, y, fw, fh, score = float(f[0]), float(f[1]), float(f[2]), float(f[3]), float(f[-1])
                cands.append((fw * fh * score * 2, (x + fw / 2) / SW))
            img = cv2.cvtColor(img3, cv2.COLOR_BGR2GRAY)
        else:
            img = np.frombuffer(buf, dtype=np.uint8).reshape(sh, SW)
        if not cands and front is not None:  # visages Haar (de face puis de profil)
            eq = cv2.equalizeHist(img)
            for casc, flip in ((front, False), (prof, False), (prof, True)):
                im = cv2.flip(eq, 1) if flip else eq
                for (x, y, fw, fh) in casc.detectMultiScale(im, 1.12, 5, minSize=(24, 24)):
                    cx = (SW - (x + fw / 2)) if flip else (x + fw / 2)
                    cands.append((fw * fh, cx / SW))
                if cands:
                    break
            if not cands and upper is not None:
                for (x, y, fw, fh) in upper.detectMultiScale(eq, 1.1, 4, minSize=(50, 50)):
                    cands.append((fw * fh * 0.5, (x + fw / 2) / SW))
        g = img.astype(np.int16)
        if not cands and last_gray is not None:  # rien de reconnu : on suit ce qui bouge
            col = np.abs(g - last_gray).sum(axis=0).astype(np.float64)
            if col.sum() > SW * sh * 2.5:
                cands.append((1.0, float((col * np.arange(SW)).sum() / col.sum()) / SW))
        last_gray = g
        cx = None
        if cands:
            hits += 1
            if prev is None:
                cx = max(cands)[1]
            else:  # le plus gros visage, en favorisant celui qui était déjà suivi
                cx = max(cands, key=lambda c: c[0] / (1 + 10 * abs(c[1] - prev)))[1]
            prev = cx
        xs.append(cx)
        ts.append(t)
        if on_progress and len(ts) % 8 == 0:
            on_progress(min(0.95, len(ts) / total))
    if not hits:
        return {"keys": [], "found": 0.0, "message": "Aucun sujet trouvé dans ce moment."}
    xs = _interp(xs)
    xs = _smooth(xs, 2)                          # enlève les fausses détections isolées
    xs = _center_avg(xs, max(1, SAMPLE_FPS // 3))  # lisse sans retard : le sujet reste au milieu
    # micro-mouvements ignorés (pas de tremblement), mais pas de zone morte : on recentre toujours
    cam, out = xs[0], []
    for x in xs:
        if abs(x - cam) > r * 0.02:
            cam = x
        out.append(cam)
    out = _center_avg(out, 1)
    fx = [min(1.0, max(0.0, (c - r / 2) / (1 - r))) for c in out]
    pts = _simplify(list(zip(ts, fx)), 0.004)
    keys = [[round(t, 2), round(v, 4)] for t, v in pts]
    if len(keys) == 1:
        keys.append([round(t1 - t0, 2), keys[0][1]])
    return {"keys": keys, "found": hits / max(1, len(ts)), "message": None}
