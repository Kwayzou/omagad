"""Polices : installées avec l'app, téléchargées au premier lancement, ou ajoutées par l'utilisateur."""
import ssl
import struct
import threading
import urllib.request

from .config import BUNDLED_FONTS, USER_FONTS

EXT = {".ttf", ".otf"}

# Polices libres (licence OFL) installées automatiquement. League Spartan = équivalent libre de Futura Bold,
# la police des titres façon TikTok / Shorts ; Montserrat = variante plus large et ronde.
AUTO = [
    ("LeagueSpartan-Black.ttf", ["https://cdn.jsdelivr.net/fontsource/fonts/league-spartan@latest/latin-900-normal.ttf",
                                 "https://cdn.jsdelivr.net/fontsource/fonts/league-spartan@5.0.0/latin-900-normal.ttf"]),
    ("Montserrat-Black.ttf", ["https://cdn.jsdelivr.net/fontsource/fonts/montserrat@latest/latin-900-normal.ttf"]),
]
STATUS = {"state": "idle", "error": None}


def family_name(path):
    """Nom de famille lu dans la table 'name' (16 = famille typographique, sinon 1)."""
    try:
        data = path.read_bytes()
        num = struct.unpack(">H", data[4:6])[0]
        for i in range(num):
            tag, _, off, _ = struct.unpack(">4sIII", data[12 + 16 * i: 28 + 16 * i])
            if tag != b"name":
                continue
            _, count, sto = struct.unpack(">HHH", data[off:off + 6])
            best = {}
            for j in range(count):
                pid, eid, lid, nid, ln, so = struct.unpack(">HHHHHH", data[off + 6 + 12 * j: off + 18 + 12 * j])
                if nid not in (1, 16):
                    continue
                raw = data[off + sto + so: off + sto + so + ln]
                txt = raw.decode("utf-16-be", "ignore") if pid in (0, 3) else raw.decode("latin-1", "ignore")
                if txt:
                    best.setdefault(nid, txt)
            return best.get(16) or best.get(1)
    except (OSError, struct.error):
        pass
    return None


def _ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def ensure_fonts():
    """Télécharge les polices manquantes (une seule fois, en arrière-plan)."""
    def run():
        STATUS["state"] = "downloading"
        errors = []
        for name, urls in AUTO:
            dest = USER_FONTS / name
            if dest.exists() and dest.stat().st_size > 10000:
                continue
            for u in urls:
                try:
                    req = urllib.request.Request(u, headers={"User-Agent": "OMAGAD"})
                    with urllib.request.urlopen(req, timeout=30, context=_ctx()) as r:
                        data = r.read()
                    if data[:4] in (b"\x00\x01\x00\x00", b"OTTO", b"true") and len(data) > 10000:
                        dest.write_bytes(data)
                        break
                except Exception as e:  # pas de réseau : on réessaiera au prochain lancement
                    errors.append("%s : %s" % (name, e))
        missing = [n for n, _ in AUTO if not (USER_FONTS / n).exists()]
        try:
            from . import overlay
            overlay._INDEX = None  # les nouvelles polices seront prises en compte au prochain export
            overlay._FONTS.clear()
        except Exception:
            pass
        STATUS.update(state="ready" if not missing else "missing", error="; ".join(errors[-2:]) if missing else None)
    threading.Thread(target=run, daemon=True).start()


def installed_families():
    return {f["family"] for f in list_fonts()}


def list_fonts():
    out = []
    for folder, prefix in ((BUNDLED_FONTS, "app"), (USER_FONTS, "user")):
        if not folder.is_dir():
            continue
        for f in sorted(folder.iterdir()):
            if f.suffix.lower() in EXT:
                fam = family_name(f) or f.stem
                weight = 900 if "black" in f.stem.lower() else 700 if "bold" in f.stem.lower() else 400
                out.append({"family": fam, "url": "/fonts/%s/%s" % (prefix, f.name), "weight": weight})
    return out


# Si une police choisie n'est pas (encore) installée : remplaçant présent sur tous les Mac.
FALLBACK = {"League Spartan": "Futura", "Montserrat": "Avenir Next"}


def resolve(family):
    if family in FALLBACK and family not in installed_families():
        return FALLBACK[family]
    return family


def import_font(src):
    """Ajoute une police (.ttf / .otf / .ttc) choisie par l'utilisateur ; renvoie son nom de famille."""
    import shutil
    from pathlib import Path
    src = Path(src)
    if src.suffix.lower() not in EXT | {".ttc"}:
        raise ValueError("Choisis un fichier de police .ttf ou .otf.")
    dest = USER_FONTS / src.name
    shutil.copyfile(src, dest)
    fam = family_name(dest) or src.stem
    try:
        from . import overlay
        overlay._INDEX = None
        overlay._FONTS.clear()
    except Exception:
        pass
    return fam
