"""Rendu d'un clip : recadrage 9:16, textes dessinés par OMAGAD (overlay.py), sons, volume normalisé.

N'utilise que des filtres présents dans toutes les versions de ffmpeg (pas de libass).
"""
import subprocess
import threading

from . import anim, edit, media, overlay, sfx
from .config import DEFAULT_STYLE, MUSIC
from .media import NOWIN

W, H = 1080, 1920
make_chunks = overlay.make_chunks


def sfx_cues(clip, st, dur):
    cues = []
    for it in edit.effective_sfx(clip, st):
        p = sfx.path_of(it.get("sound"))
        vol, at = float(it.get("vol", 0.7)), float(it.get("at", 0))
        if p and vol > 0 and -10 < at < dur:  # un son peut démarrer avant le début du clip (on garde sa fin)
            cues.append((p, at, vol))
    return cues


def video_graph(info, frame):
    w, h = info["width"], info["height"]
    fx = min(1.0, max(0.0, float(frame.get("fx", 0.5))))
    fy = min(1.0, max(0.0, float(frame.get("fy", 0.5))))
    zoom = min(3.0, max(1.0, float(frame.get("zoom", 1.0))))
    if frame.get("mode") == "blur":
        return ("[0:v]split=2[a][b];[a]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=10:3,"
                "scale=%d:%d,eq=brightness=-0.12[bg];[b]scale=%d:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1[v0];"
                % (W, H, int(W * zoom) // 2 * 2))
    s0 = max(W / w, H / h) * zoom
    punch = "*(1+0.07*max(0,1-t/0.7))" if frame.get("punch", True) else ""
    z = edit.zoom_expr(frame)
    if z != "1":
        punch += "*(" + z + ")"
    return ("[0:v]scale=w='trunc(iw*%.5f%s/2)*2':h=-2:eval=frame,crop=%d:%d:x='(iw-%d)*(%s)':y='(ih-%d)*%.3f',setsar=1[v0];"
            % (s0, punch, W, H, W, edit.crop_fx_expr(frame), H, fy))


def video_encoder(opts):
    q = {"high": (19, "14M"), "medium": (22, "9M"), "light": (25, "6M")}.get(opts.get("quality", "high"), (19, "14M"))
    want = opts.get("encoder") or "h264_videotoolbox"
    avail = media.encoders()
    order = [want] + [e for e in ("h264_videotoolbox", "libx264", "libopenh264", "mpeg4") if e != want]
    enc = next((e for e in order if e in avail), "libx264")
    if enc == "h264_videotoolbox":
        return ["-c:v", "h264_videotoolbox", "-b:v", q[1], "-allow_sw", "1", "-pix_fmt", "yuv420p"]
    if enc == "libx264":
        return ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(q[0]), "-profile:v", "high", "-pix_fmt", "yuv420p"]
    if enc == "libopenh264":
        return ["-c:v", "libopenh264", "-b:v", q[1], "-pix_fmt", "yuv420p"]
    return ["-c:v", "mpeg4", "-q:v", "3", "-pix_fmt", "yuv420p"]


def media_items(clip, media_dir, dur):
    out = []
    for it in clip.get("media") or []:
        if not media_dir or not it.get("file"):
            continue
        p = media_dir / it["file"]
        at, d = max(0.0, float(it.get("at", 0))), float(it.get("dur", 3))
        if p.exists() and d > 0.05 and at < dur:
            out.append(dict(it, path=p, at=at, dur=min(d, dur - at)))
    return out


def render_clip(src, info, words, clip, opts, out_path, work_dir, on_progress, register=None, media_dir=None):
    st = dict(DEFAULT_STYLE)
    st.update(anim.migrate(clip.get("style")) or {})
    work_dir.mkdir(parents=True, exist_ok=True)
    dur = clip["t1"] - clip["t0"]
    ov = overlay.Overlay(clip, words, st)
    tail = "scale=720:1280," if int(opts.get("resolution", 1080)) == 720 else ""
    inputs = ["-ss", "%.3f" % clip["t0"], "-i", str(src),
              "-f", "rawvideo", "-pix_fmt", "rgba", "-s", "%dx%d" % (W, ov.height), "-framerate", "30", "-i", "pipe:0"]
    graph = video_graph(info, clip.get("frame") or {})
    last, n_in = "v0", 2
    for j, it in enumerate(media_items(clip, media_dir, dur)):
        f, at, d = it["path"], it["at"], it["dur"]
        if it["kind"] == "image":
            inputs += ["-loop", "1", "-framerate", "30", "-t", "%.3f" % d, "-i", str(f)]
        else:
            inputs += ["-ss", "%.3f" % float(it.get("from", 0)), "-t", "%.3f" % d, "-i", str(f)]
        if it.get("mode") == "pip":
            pw = int(W * float(it.get("scale", 0.45))) // 2 * 2
            fit = "scale=%d:-2" % pw
            x = "%d-w/2" % int(W * float(it.get("x", 0.5)))
            y = "%d-h/2" % int(H * float(it.get("y", 0.3)))
        else:
            fit = "scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d" % (W, H, W, H)
            x, y = "0", "0"
        graph += "[%d:v]%s,format=rgba,setpts=PTS-STARTPTS+%.3f/TB[m%d];" % (n_in, fit, at, j)
        graph += "[%s][m%d]overlay=%s:%s:eof_action=pass:enable='between(t,%.3f,%.3f)'[vm%d];" % (last, j, x, y, at, at + d, j)
        last, n_in = "vm%d" % j, n_in + 1
    graph += "[1:v]format=rgba[ov];[%s][ov]overlay=0:%d:format=auto:eof_action=pass,%sformat=yuv420p[v]" % (last, ov.top, tail)
    cues = sfx_cues(clip, st, dur)
    fmt_a = "aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo"
    if info.get("has_audio", True):
        agraph = "[0:a:0]%s[a0];" % fmt_a
    else:
        agraph = "anullsrc=r=48000:cl=stereo,atrim=0:%.3f[a0];" % dur
    first_sfx = n_in
    for i, (p, at, vol) in enumerate(cues, start=n_in):
        inputs += ["-i", str(p)]
        if at >= 0:
            ms = int(round(at * 1000))
            agraph += "[%d:a:0]%s,adelay=%d|%d,volume=%.3f[s%d];" % (i, fmt_a, ms, ms, vol, i)
        else:
            agraph += "[%d:a:0]%s,atrim=start=%.3f,asetpts=PTS-STARTPTS,volume=%.3f[s%d];" % (i, fmt_a, -at, vol, i)
    labels = ["[s%d]" % i for i in range(first_sfx, first_sfx + len(cues))]
    # musique de fond : fondu, et baisse automatique quand tu parles (compresseur piloté par la voix)
    mu = clip.get("music") or {}
    mpath = (MUSIC / mu["file"]) if mu.get("file") else None
    voice = "[a0]"
    if mpath and mpath.exists() and float(mu.get("vol", 0.5)) > 0:
        k = first_sfx + len(cues)
        inputs += ["-ss", "%.3f" % float(mu.get("from", 0)), "-t", "%.3f" % (dur + 0.5), "-i", str(mpath)]
        fades = "afade=t=in:d=0.5,afade=t=out:st=%.3f:d=0.8" % max(0.0, dur - 0.8)
        agraph += "[%d:a:0]%s,volume=%.3f,%s[mus];" % (k, fmt_a, float(mu.get("vol", 0.5)), fades)
        if mu.get("duck", True):
            lvl = min(0.9, max(0.03, float(mu.get("duck_level", 0.25))))
            ratio = min(20.0, max(2.0, 1.0 / lvl * 1.6))
            agraph += "[a0]asplit=2[av][sc];[mus][sc]sidechaincompress=threshold=0.015:ratio=%.2f:attack=25:release=450:knee=4[musd];" % ratio
            voice, labels = "[av]", labels + ["[musd]"]
        else:
            labels.append("[mus]")
    mix = voice + "".join(labels)
    agraph += (mix + "amix=inputs=%d:duration=first:normalize=0" % (len(labels) + 1)) if labels else voice + "anull"
    if opts.get("loudnorm", True):
        agraph += ",loudnorm=I=-14:TP=-1.5:LRA=11"
    agraph += "[a]"
    cmd = [media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-progress", "pipe:1", "-nostats"] + inputs + [
        "-t", "%.3f" % dur, "-filter_complex", graph + ";" + agraph, "-map", "[v]", "-map", "[a]"] + \
        video_encoder(opts) + ["-r", "30", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", str(out_path)]
    log = work_dir / ("%s.log" % clip["id"])
    errors = []

    def feed(stdin):
        try:
            for n in range(ov.frames):
                stdin.write(ov.frame(n))
        except (BrokenPipeError, OSError, ValueError):
            pass
        except Exception as e:  # erreur de dessin : on la remonte
            errors.append(e)
        finally:
            try:
                stdin.close()
            except OSError:
                pass

    with open(log, "w", encoding="utf-8") as errf:
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errf, **NOWIN)
        if register:
            register(p)
        writer = threading.Thread(target=feed, args=(p.stdin,), daemon=True)
        writer.start()
        for raw in p.stdout:
            line = raw.decode("utf-8", "replace")
            if line.startswith("out_time_us="):
                try:
                    on_progress(min(1.0, int(line.split("=")[1]) / 1e6 / dur))
                except ValueError:
                    pass
        p.wait()
        writer.join(timeout=5)
    if errors:
        raise RuntimeError("Dessin des textes impossible : %s" % errors[0])
    if p.returncode != 0:
        if p.returncode < 0 or p.returncode == 255:
            raise InterruptedError("Export annulé.")
        tail = log.read_text(encoding="utf-8", errors="replace").strip().splitlines()[-6:]
        raise RuntimeError("ffmpeg a échoué : " + " | ".join(tail))
    on_progress(1.0)
