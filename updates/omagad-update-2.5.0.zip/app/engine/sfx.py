"""Effets sonores : bibliothèque intégrée + sons ajoutés par l'utilisateur."""
import re
import shutil
from pathlib import Path

from .config import BUNDLED_SFX, USER_SFX

AUDIO = {".wav", ".mp3", ".m4a", ".aif", ".aiff", ".caf", ".ogg", ".flac"}
LABELS = {"whoosh": "Whoosh", "swipe": "Swipe (sortie)", "pop": "Pop", "impact": "Impact", "boom": "Boom ciné",
          "riser": "Montée", "click": "Clic", "ding": "Ding", "glitch": "Glitch"}


_DUR = {}


def duration(p):
    key = (str(p), p.stat().st_mtime)
    if key not in _DUR:
        d = 0.5
        try:
            if p.suffix.lower() == ".wav":
                import wave
                with wave.open(str(p)) as w:
                    d = w.getnframes() / float(w.getframerate())
            else:
                from . import media
                d = media.probe_audio_duration(p)
        except Exception:
            pass
        _DUR[key] = round(d, 3)
    return _DUR[key]


def list_sfx():
    out = []
    for folder, scope in ((BUNDLED_SFX, "app"), (USER_SFX, "user")):
        if not folder.is_dir():
            continue
        for f in sorted(folder.iterdir()):
            if f.suffix.lower() in AUDIO:
                sid = f.stem if scope == "app" else "user:" + f.name
                out.append({"id": sid, "label": LABELS.get(f.stem, f.stem.replace("_", " ")) if scope == "app" else f.stem, "scope": scope,
                            "url": "/sfx/%s/%s" % (scope, f.name), "dur": duration(f)})
    return out


def path_of(sid):
    if not sid or sid == "none":
        return None
    if sid.startswith("user:"):
        p = USER_SFX / Path(sid[5:]).name
    else:
        p = next((f for f in BUNDLED_SFX.glob(Path(sid).name + ".*") if f.suffix.lower() in AUDIO), None)
    return p if p and p.exists() else None


def import_sound(src):
    src = Path(src)
    if src.suffix.lower() not in AUDIO:
        raise ValueError("Format audio non pris en charge (wav, mp3, m4a, aiff...).")
    name = re.sub(r"[^\w\- .]", "", src.stem)[:40].strip() or "son"
    dest = USER_SFX / (name + src.suffix.lower())
    shutil.copyfile(src, dest)
    return "user:" + dest.name
