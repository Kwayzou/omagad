/* Sons de l'interface + animation de lancement :
   fond noir, le nom apparaît, le logo arrive en grand puis se « morphe » dans la carte Clipagad à gauche. */
(function () {
  const $ = s => document.querySelector(s);

  /* ---------- Sons (comme DaVinci : un carillon quand un rendu se termine) ---------- */
  const cache = {};
  VC.sound = function (name) {
    const st = VC.S.state && VC.S.state.settings;
    if (st && st.ui_sounds === false) return;
    const api = window.pywebview && window.pywebview.api;
    if (api && api.play_sound) { api.play_sound(name).then(ok => { if (!ok) web(name); }).catch(() => web(name)); return; }
    web(name);
  };
  function web(name) {
    try { const a = cache[name] || (cache[name] = new Audio('/ui/sounds/' + name + '.wav')); a.currentTime = 0; a.volume = .9; a.play().catch(() => {}); } catch (e) { /* pas de son */ }
  }

  /* ---------- Animation de lancement ---------- */
  let wantIntro = true;
  try { wantIntro = localStorage.getItem('omagad-intro') !== '0'; } catch (e) { /* stockage indisponible */ }
  const ov = $('#intro');
  let resolveDone; VC.introDone = new Promise(r => { resolveDone = r; });
  if (!ov) { resolveDone(); return; }
  if (!wantIntro) { ov.remove(); resolveDone(); return; }

  const wait = ms => new Promise(r => setTimeout(r, ms));
  let skipped = false, finished = false;
  const skip = () => { if (!finished) { skipped = true; ov.classList.add('fast'); } };
  ov.addEventListener('click', skip);
  document.addEventListener('keydown', skip, { once: true });

  async function apiReady(ms) {
    if (window.pywebview && window.pywebview.api && window.pywebview.api.play_sound) return;
    await Promise.race([new Promise(r => window.addEventListener('pywebviewready', r, { once: true })), wait(ms)]);
  }

  async function run() {
    await apiReady(350);
    let soundOn = true;
    try { soundOn = localStorage.getItem('omagad-sounds') !== '0'; } catch (e) { /* idem */ }
    if (soundOn) { const api = window.pywebview && window.pywebview.api; if (api && api.play_sound) api.play_sound('intro').catch(() => web('intro')); else web('intro'); }
    ov.classList.add('go');                       // 0,0 s : les lettres apparaissent
    await wait(skipped ? 0 : 900);
    ov.classList.add('logo');                     // 0,9 s : le logo arrive en grand (impact)
    await wait(skipped ? 0 : 950);
    await Promise.race([VC.homeReady, wait(5000)]);  // l'accueil est prêt derrière
    morph();
  }

  function morph() {
    const logo = $('#introLogo'), target = document.querySelector('.mod-logo');
    ov.classList.add('out');
    if (target && logo) {
      const a = logo.getBoundingClientRect(), b = target.getBoundingClientRect();
      const dx = b.left + b.width / 2 - (a.left + a.width / 2), dy = b.top + b.height / 2 - (a.top + a.height / 2), sc = b.width / a.width;
      target.style.opacity = '0';
      logo.style.transition = 'transform .85s cubic-bezier(.7,0,.2,1), border-radius .85s, box-shadow .85s';
      logo.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(' + sc + ')';
      logo.style.borderRadius = (30 / sc) + 'px';
    }
    document.body.classList.add('intro-reveal');
    setTimeout(() => {
      if (target) target.style.opacity = '';
      ov.remove(); finished = true; document.body.classList.remove('intro-reveal');
      resolveDone();
    }, skipped ? 450 : 900);
  }
  run();
})();
