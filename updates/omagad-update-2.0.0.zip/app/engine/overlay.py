"""Dessin de l'accroche et des sous-titres en images (Pillow), sans dépendre de libass.

Les images sont composées image par image et envoyées à ffmpeg, qui les superpose à la vidéo
avec le filtre « overlay » présent dans toutes les versions de ffmpeg.
"""
import math
import mmap
import os
import re
import struct
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

from . import anim
from .config import BUNDLED_FONTS, USER_FONTS

W, H, FPS = 1080, 1920, 30
MAX_W = 920  # largeur utile (marges 80 px), identique à l'aperçu
_STOP = re.compile(r"[.!?…,;]$")
_STRIP = re.compile(r"[.,;:«»\"“”…()]")


def norm(tok):
    return re.sub(r"[^\w]", "", tok.upper())


def hex_rgb(h, default=(255, 255, 255)):
    try:
        h = (h or "").lstrip("#")
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return default


# ---------- Polices : index des familles disponibles ----------
def _font_dirs():
    home = Path.home()
    dirs = [USER_FONTS, BUNDLED_FONTS, home / "Library/Fonts", Path("/Library/Fonts"), Path("/System/Library/Fonts"),
            Path("/System/Library/Fonts/Supplemental"), Path("/usr/share/fonts"), Path("C:/Windows/Fonts")]
    return [d for d in dirs if d.is_dir()]


def _read_face(data, off):
    """(famille, sous-famille, graisse, italique) d'une police à l'offset donné."""
    num = struct.unpack(">H", data[off + 4:off + 6])[0]
    tables = {}
    for i in range(num):
        tag, _, toff, _ = struct.unpack(">4sIII", data[off + 12 + 16 * i: off + 28 + 16 * i])
        tables[tag] = toff
    names = {}
    if b"name" in tables:
        t = tables[b"name"]
        _, count, sto = struct.unpack(">HHH", data[t:t + 6])
        for j in range(count):
            pid, eid, lid, nid, ln, so = struct.unpack(">HHHHHH", data[t + 6 + 12 * j: t + 18 + 12 * j])
            if nid not in (1, 2, 16, 17) or (pid == 3 and lid not in (0x409, 0x40C, 0)):
                continue
            raw = data[t + sto + so: t + sto + so + ln]
            txt = raw.decode("utf-16-be", "ignore") if pid in (0, 3) else raw.decode("latin-1", "ignore")
            if txt:
                names.setdefault(nid, txt)
    weight, italic = 400, False
    if b"OS/2" in tables:
        t = tables[b"OS/2"]
        weight = struct.unpack(">H", data[t + 4:t + 6])[0]
        italic = bool(struct.unpack(">H", data[t + 62:t + 64])[0] & 1)
    fam, sub = names.get(16) or names.get(1), names.get(17) or names.get(2) or ""
    italic = italic or bool(re.search(r"italic|oblique", sub, re.I))
    return fam, sub, weight, italic


_INDEX = None


def font_index(refresh=False):
    global _INDEX
    if _INDEX is not None and not refresh:
        return _INDEX
    idx = []
    for d in _font_dirs():
        for root, _, files in os.walk(d):
            for f in files:
                if not f.lower().endswith((".ttf", ".otf", ".ttc")):
                    continue
                p = os.path.join(root, f)
                try:
                    fh = open(p, "rb")
                    data = mmap.mmap(fh.fileno(), 0, access=mmap.ACCESS_READ)  # lecture paresseuse : rapide même pour les grosses polices
                    offs = [0]
                    if data[:4] == b"ttcf":
                        n = struct.unpack(">I", data[8:12])[0]
                        offs = list(struct.unpack(">%dI" % n, data[12:12 + 4 * n]))
                    for i, off in enumerate(offs):
                        fam, sub, wgt, ita = _read_face(data, off)
                        if fam:
                            idx.append((fam.lower(), sub, wgt, ita, p, i))
                    data.close()
                    fh.close()
                except (OSError, struct.error, IndexError, ValueError):
                    continue
    _INDEX = idx
    return idx


FALLBACKS = {"league spartan": ["futura", "avenir next"], "montserrat": ["avenir next", "futura"]}
LAST_RESORT = ["futura", "arial black", "impact", "helvetica neue", "helvetica", "arial", "inter", "dejavu sans", "liberation sans"]


def find_font(family, bold, italic=False):
    """(chemin, indice) de la police la plus proche ; synth_italic=True si l'italique doit être simulé."""
    idx, fam = font_index(), (family or "").lower()
    target = 800 if bold else 400
    for name in [fam] + FALLBACKS.get(fam, []) + LAST_RESORT:
        faces = [f for f in idx if f[0] == name]
        if not faces:
            continue

        def cost(f):
            narrow = 0 if re.search(r"condensed|narrow|compressed", name) else (300 if re.search(r"condensed|narrow|compressed", f[1], re.I) else 0)
            return abs(f[2] - target) + (0 if f[3] == bool(italic) else 1000) + narrow + (5 if f[2] < target else 0)
        best = min(faces, key=cost)
        return best[4], best[5], bool(italic) and not best[3]
    return None, 0, bool(italic)


_FONTS = {}


def load_font(family, bold, size, italic=False):
    """Renvoie (police, italique_à_simuler)."""
    key = (family, bool(bold), int(size), bool(italic))
    if key not in _FONTS:
        path, i, synth = find_font(family, bold, italic)
        try:
            f = ImageFont.truetype(path, int(size), index=i) if path else ImageFont.load_default(int(size))
        except OSError:
            f = ImageFont.load_default(int(size))
        _FONTS[key] = (f, synth)
    return _FONTS[key]


def _glow_layers(mask, st, k, size):
    """Lueur extérieure et/ou intérieure à partir du masque du texte."""
    out = []
    if not st.get(k + "glow"):
        return out
    g = max(1, int(st.get(k + "glow_size", 16)))
    mode = st.get(k + "glow_mode", "out")
    op = float(st.get(k + "glow_opacity", 1.0))
    col = hex_rgb(st.get(k + "glow_color", "#000000"))
    if mode in ("out", "both"):
        grown = mask.filter(ImageFilter.MaxFilter(3)) if g > 2 else mask
        blur = grown.filter(ImageFilter.GaussianBlur(g * 0.75))
        layer = Image.new("RGBA", mask.size, col + (0,))
        layer.putalpha(blur.point(lambda v: min(255, int(v * 1.6 * op))))
        out.append(("under", layer))
    if mode in ("in", "both"):
        inv = mask.point(lambda v: 255 - v).filter(ImageFilter.GaussianBlur(max(1.0, g * 0.45)))
        inner = ImageChops.multiply(inv, mask)
        layer = Image.new("RGBA", mask.size, col + (0,))
        layer.putalpha(inner.point(lambda v: min(255, int(v * 2.2 * op))))
        out.append(("over", layer))
    return out


def _draw_text(d, xy, text, font, spacing, **kw):
    """Texte avec espacement des lettres (Pillow n'en a pas : lettre par lettre)."""
    if not spacing:
        d.text(xy, text, font=font, anchor="ls", **kw)
        return
    x, y = xy
    for ch in text:
        d.text((x, y), ch, font=font, anchor="ls", **kw)
        x += font.getlength(ch) + spacing


def _width(font, text, spacing):
    return font.getlength(text) + (spacing * max(0, len(text) - 1) if spacing else 0)


# ---------- Dessin d'un bloc de texte ----------
def draw_block(lines, st, kind, colors=None, scales=None, visible=None):
    """lines : liste de lignes, chaque ligne = liste de mots. Renvoie une image RGBA centrée sur le texte.
    colors / scales / visible : dictionnaires {indice global du mot: valeur} pour les mots particuliers."""
    k = kind + "_"
    size = int(st[k + "size"])
    bold, italic = st.get(k + "bold"), st.get(k + "italic")
    base, synth = load_font(st[k + "font"], bold, size, italic)
    spacing = float(st.get(k + "spacing", 0) or 0)
    asc, desc = base.getmetrics()
    lh = int((asc + desc) * 1.02 * float(st.get(k + "line", 1.0) or 1.0))
    outline = int(st[k + "outline"])
    box = bool(st[k + "box"])
    glow = int(st.get(k + "glow_size", 0)) if st.get(k + "glow") and not box else 0
    shadow = (not box) and st.get(k + "shadow", True)
    sh_d = int(st.get(k + "shadow_dist", max(1, outline // 2))) if shadow else 0
    color = hex_rgb(st[k + "color"])
    space = base.getlength(" ") + spacing
    colors, scales = colors or {}, scales or {}
    laid, gi = [], 0
    for words in lines:
        cur, cur_w = [], 0.0
        for w in words:
            sc = scales.get(gi, 1.0)
            f = base if sc == 1.0 else load_font(st[k + "font"], bold, size * sc, italic)[0]
            ww = _width(f, w, spacing)
            if cur and cur_w + space + ww > MAX_W:
                laid.append((cur, cur_w))
                cur, cur_w = [], 0.0
            cur_w += (space if cur else 0) + ww
            cur.append((w, gi, f, ww))
            gi += 1
        if cur:
            laid.append((cur, cur_w))
    if not laid:
        return None
    pad = outline + glow * 2 + abs(sh_d) + (int(size * 0.3) if box else 0) + 6 + (int(size * 0.25) if synth else 0)
    tw = int(max(w for _, w in laid)) + 2 * pad
    th = lh * len(laid) + 2 * pad
    pos = []
    for li, (words, lw) in enumerate(laid):
        x, base_y = (tw - lw) / 2, pad + li * lh + asc
        for (w, g, f, ww) in words:
            pos.append((x, base_y, w, g, f))
            x += ww + space
    show = (lambda g: True) if visible is None else (lambda g: g in visible)
    oc = hex_rgb(st[k + "outline_color"])
    # texte (contour + remplissage) sur son propre calque
    text = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    dt = ImageDraw.Draw(text)
    mask = Image.new("L", (tw, th), 0)
    dm = ImageDraw.Draw(mask)
    for x, y, w, g, f in pos:
        if show(g):
            fill = colors.get(g, color)
            _draw_text(dt, (x, y), w, f, spacing, fill=fill + (255,), stroke_width=0 if box else outline, stroke_fill=oc + (255,))
            _draw_text(dm, (x, y), w, f, spacing, fill=255, stroke_width=0 if box else outline, stroke_fill=255)
    img = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    if box:
        bc = hex_rgb(st[k + "box_color"]) + (222,)
        d = ImageDraw.Draw(img)
        r = int(size * 0.18)
        for li, (words, lw) in enumerate(laid):
            x0 = (tw - lw) / 2 - size * 0.3
            y0 = pad + li * lh - size * 0.04
            d.rounded_rectangle((x0, y0, x0 + lw + size * 0.6, y0 + lh + size * 0.02), radius=r, fill=bc)
    layers = _glow_layers(mask, st, k, size) if not box else []
    for where, layer in layers:
        if where == "under":
            img = Image.alpha_composite(img, layer)
    if sh_d:
        sc_ = hex_rgb(st.get(k + "shadow_color", "#000000"))
        sop = float(st.get(k + "shadow_opacity", 0.5))
        sl = Image.new("RGBA", (tw, th), sc_ + (0,))
        sm = Image.new("L", (tw, th), 0)
        sm.paste(mask, (sh_d, sh_d))
        sl.putalpha(sm.filter(ImageFilter.GaussianBlur(max(0.5, sh_d * 0.35))).point(lambda v: int(v * sop)))
        img = Image.alpha_composite(img, sl)
    img = Image.alpha_composite(img, text)
    for where, layer in layers:
        if where == "over":
            img = Image.alpha_composite(img, layer)
    if synth:  # italique simulé : légère inclinaison
        sh = 0.2
        img = img.transform((img.width, img.height), Image.AFFINE, (1, sh, -sh * img.height / 2, 0, 1, 0), resample=Image.BICUBIC)
    return img


def scale_alpha(img, a):
    if a >= 0.999:
        return img
    out = img.copy()
    out.putalpha(img.getchannel("A").point(lambda v: int(v * max(0.0, a))))
    return out


def transformed(img, sc, rot, a):
    if sc <= 0.02 or a <= 0.01:
        return None
    if abs(sc - 1) > 1e-3:
        img = img.resize((max(1, int(img.width * sc)), max(1, int(img.height * sc))), Image.BICUBIC)
    if abs(rot) > 0.05:
        img = img.rotate(rot, resample=Image.BICUBIC, expand=True)
    return scale_alpha(img, a)


# ---------- Accroche ----------
def hook_lines(clip, st):
    text = (clip.get("hook") or "").strip()
    if st["hook_upper"]:
        text = text.upper()
    return [l.split() for l in text.replace("\r", "").split("\n") if l.split()]


class Hook:
    def __init__(self, clip, st):
        from .edit import hook_at
        self.at = hook_at(clip)
        self.st = st
        self.lines = hook_lines(clip, st)
        self.secs = max(0.5, float(st["hook_secs"]))
        self.y = float(st["hook_y"]) * H
        emph = {norm(t) for t in (clip.get("emphasis") or "").split() if norm(t)}
        ec = hex_rgb(st["hook_emph_color"])
        words = [w for l in self.lines for w in l]
        self.colors = {i: ec for i, w in enumerate(words) if norm(w) in emph}
        self.n = len(words)
        self.full = draw_block(self.lines, st, "hook", self.colors) if self.lines else None
        self._partial = {}
        self.reach = 1.0  # agrandissement maximal (pour réserver la place)
        self.span_y = 0.0
        for ms in range(0, int(self.secs * 1000), 20):
            dx, dy, sc, rot, a = anim.transform(st, ms, self.secs * 1000)
            self.reach = max(self.reach, sc * (1 + abs(rot) / 40))
            self.span_y = max(self.span_y, abs(dy))

    def state(self, rel):
        """(image, x_centre, y_centre, clé) à l'instant rel (secondes depuis le début du clip), ou None."""
        rel -= self.at
        if self.full is None or rel < 0 or rel >= self.secs:
            return None
        ms = rel * 1000
        img = self.full
        k = anim.words_visible(self.st, ms, self.n)
        if k == 0:
            return None
        if k < self.n:
            if k not in self._partial:
                self._partial[k] = draw_block(self.lines, self.st, "hook", self.colors, visible=set(range(k)))
            img = self._partial[k]
        dx, dy, sc, rot, a = anim.transform(self.st, ms, self.secs * 1000)
        out = transformed(img, sc, rot, a)
        if out is None:
            return None
        plain = abs(sc - 1) < 1e-3 and abs(rot) < 0.05 and a >= 0.999
        key = (id(img), round(dx), round(dy)) if plain else ("f", round(ms))
        return out, 540.0 + dx, self.y + dy, key


# ---------- Sous-titres ----------
def make_chunks(words, t0, t1, per=3):
    ws = []
    for w in words:
        txt = _STRIP.sub("", w["w"]).strip()
        if txt and re.search(r"\w", txt) and w["e"] > t0 and w["s"] < t1:
            ws.append({"w": txt, "s": w["s"], "e": w["e"], "stop": bool(_STOP.search(w["w"]))})
    chunks, cur = [], []
    for i, w in enumerate(ws):
        cur.append(w)
        nxt = ws[i + 1] if i + 1 < len(ws) else None
        if nxt is None or len(cur) >= per or sum(len(x["w"]) for x in cur) >= 18 or w["stop"] or nxt["s"] - w["e"] > 0.5:
            chunks.append({"s": cur[0]["s"], "e": cur[-1]["e"], "words": [{"w": x["w"], "s": x["s"], "e": x["e"]} for x in cur]})
            cur = []
    return chunks


class Subs:
    def __init__(self, clip, words, st):
        self.st, self.t0, self.t1 = st, clip["t0"], clip["t1"]
        self.y = float(st["sub_y"]) * H
        self.events = []  # (début, fin, indice du bloc, mot actif)
        self.chunks, self.starts = [], []
        self._cache = {}
        if not st["sub_on"]:
            return
        for ch in clip.get("subs") or make_chunks(words, self.t0, self.t1, int(st["sub_words"])):
            ws = [w for w in ch.get("words", []) if (w.get("w") or "").strip()]
            if not ws:
                continue
            ci = len(self.chunks)
            self.chunks.append([w["w"].upper() if st["sub_upper"] else w["w"] for w in ws])
            self.starts.append(ws[0]["s"])
            spans = [(w["s"], ws[i + 1]["s"] if i + 1 < len(ws) else max(w["e"], ch["e"]) + 0.12) for i, w in enumerate(ws)]
            if st["sub_hl"] == "none":
                self.events.append((ws[0]["s"], spans[-1][1], ci, -1))
            else:
                for i, (s, e) in enumerate(spans):
                    self.events.append((s, max(e, s + 0.08), ci, i))

    def _img(self, ci, wi):
        key = (ci, wi)
        if key not in self._cache:
            st = self.st
            colors = {wi: hex_rgb(st["sub_hl_color"])} if wi >= 0 else {}
            scales = {wi: 1.12} if wi >= 0 and st["sub_hl"] == "pop" else {}
            self._cache[key] = draw_block([self.chunks[ci]], st, "sub", colors, scales)
        return self._cache[key]

    def state(self, t):
        """(clé, image, dy) ; l'image est déjà animée (apparition de la ligne)."""
        for s, e, ci, wi in self.events:
            if s <= t < e and t < self.t1:
                img = self._img(ci, wi)
                if img is None:
                    return None, None, 0
                ms = (t - self.starts[ci]) * 1000
                dy, sc, a = anim.sub_anim(self.st.get("sub_anim", "none"), ms)
                if sc == 1.0 and a >= 0.999 and dy == 0:
                    return (ci, wi), img, 0
                out = transformed(img, sc, 0, a)
                return (ci, wi, round(ms / 15)), out, dy
        return None, None, 0

    def max_height(self):
        hs = [self._img(ci, -1 if self.st["sub_hl"] == "none" else 0).height for ci in range(len(self.chunks))
              if self._img(ci, -1 if self.st["sub_hl"] == "none" else 0) is not None]
        return int(max(hs) * 1.4) if hs else 0


# ---------- Images envoyées à ffmpeg ----------
class Overlay:
    """Produit les images RGBA d'une bande horizontale (pour limiter le volume de données)."""

    def __init__(self, clip, words, st):
        self.hook, self.subs = Hook(clip, st), Subs(clip, words, st)
        self.t0, self.dur = clip["t0"], clip["t1"] - clip["t0"]
        tops, bots = [], []
        if self.hook.full is not None:
            hh = self.hook.full.height * self.hook.reach + 2 * self.hook.span_y
            hw = self.hook.full.width * self.hook.reach
            hh = max(hh, hw * 0.5 if self.hook.reach > 1.05 else 0)
            tops.append(self.hook.y - hh / 2 - 20)
            bots.append(self.hook.y + hh / 2 + 20)
        sh = self.subs.max_height()
        if sh:
            tops.append(self.subs.y - sh / 2 - 50)
            bots.append(self.subs.y + sh / 2 + 50)
        if not tops:
            tops, bots = [0], [16]
        top = max(0, int(min(tops)) // 2 * 2)
        bot = min(H, int(math.ceil(max(bots))) // 2 * 2 + 2)
        self.top, self.height = top, max(16, bot - top)
        self.frames = int(math.ceil(self.dur * FPS)) + 2
        self._last_key, self._last = None, None

    def _paste(self, canvas, img, cx, cy):
        px, py = int(round(cx - img.width / 2)), int(round(cy - img.height / 2 - self.top))
        if px >= W or px + img.width <= 0:
            return
        sx, sy = max(0, -px), max(0, -py)
        crop = img.crop((sx, sy, min(img.width, W - px), min(img.height, self.height - py)))
        if crop.width > 0 and crop.height > 0:
            canvas.alpha_composite(crop, (px + sx, py + sy))

    def frame(self, n):
        rel = n / FPS
        hs = self.hook.state(rel)
        sk, simg, sdy = self.subs.state(self.t0 + rel)
        key = (sk, None if hs is None else hs[3])
        if key == self._last_key and self._last is not None:
            return self._last
        canvas = Image.new("RGBA", (W, self.height), (0, 0, 0, 0))
        if simg is not None:
            self._paste(canvas, simg, 540, self.subs.y + sdy)
        if hs is not None:
            self._paste(canvas, hs[0], hs[1], hs[2])
        self._last_key, self._last = key, canvas.tobytes()
        return self._last


if __name__ == "__main__" and len(sys.argv) > 1:  # aide au débogage : python -m engine.overlay "Texte"
    from .config import DEFAULT_STYLE
    img = draw_block([sys.argv[1].upper().split()], dict(DEFAULT_STYLE), "hook")
    img.save("hook_test.png")
