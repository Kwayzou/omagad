"""Crée l'installateur OMAGAD.dmg (fenêtre blanche : OMAGAD → dossier Applications) avec les outils du Mac.

L'app copiée est exactement celle qui tourne (même version, mêmes mises à jour), sans le moteur Python
ni les modèles téléchargés : chez tes amis, ils se préparent au premier lancement.
"""
import os
import plistlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from .config import ROOT, VERSION

ICON_APP, ICON_APPS, WIN = (165, 205), (495, 205), (660, 420)

FINDER_SCRIPT = '''
on run argv
  set volName to item 1 of argv
  tell application "Finder"
    tell disk volName
      open
      set current view of container window to icon view
      set toolbar visible of container window to false
      set statusbar visible of container window to false
      set the bounds of container window to {200, 120, %(r)d, %(b)d}
      set opts to the icon view options of container window
      set arrangement of opts to not arranged
      set icon size of opts to 112
      set text size of opts to 13
      set background picture of opts to file ".background:%(bg)s"
      set position of item "OMAGAD.app" of container window to {%(ax)d, %(ay)d}
      set position of item "Applications" of container window to {%(bx)d, %(by)d}
      update without registering applications
      delay 1
      close
      open
      delay 1
      close
    end tell
  end tell
end run
'''


def _run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def build_dmg(out_dir, on_step=lambda m, f: None, with_engine=True):
    if sys.platform != "darwin":
        raise RuntimeError("L'installateur .dmg se crée sur Mac.")
    bundle = os.environ.get("OMAGAD_BUNDLE")
    if not bundle or not Path(bundle).exists():
        raise RuntimeError("Lance OMAGAD depuis l'application pour créer l'installateur.")
    out_dir = Path(out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="omagad-dmg-"))
    vol = "OMAGAD"
    try:
        on_step("Copie de l'application…", 0.05)
        stage = tmp / "stage"
        stage.mkdir()
        app = stage / "OMAGAD.app"
        skip = re.compile(r"^(runtime-.*|__pycache__|\.deps-.*|.*\.pyc|\.DS_Store)$")
        shutil.copytree(bundle, app, symlinks=True, ignore=lambda d, names: [n for n in names if skip.match(n)])
        # code de l'app = version qui tourne en ce moment (mises à jour comprises)
        res_app = app / "Contents/Resources/app"
        if Path(ROOT).resolve() != res_app.resolve():
            shutil.rmtree(res_app, ignore_errors=True)
            shutil.copytree(ROOT, res_app, ignore=lambda d, names: [n for n in names if skip.match(n)])
        # moteur (Python + bibliothèques) déjà prêt : l'app s'ouvre tout de suite chez tes amis
        if with_engine:
            runtime = os.environ.get("OMAGAD_RUNTIME")
            if runtime and Path(runtime).is_dir():
                on_step("Copie du moteur (quelques centaines de Mo)…", 0.12)
                dest = app / "Contents/Resources" / Path(runtime).name
                shutil.rmtree(dest, ignore_errors=True)
                shutil.copytree(runtime, dest, symlinks=True,
                                ignore=lambda d, names: [n for n in names if n == "__pycache__" or (Path(d) == Path(runtime) and n == "models")])
        try:  # tes amis reçoivent les mises à jour depuis le même dépôt GitHub que toi
            from .config import load_settings
            repo = (load_settings().get("update_repo") or "").strip()
            if repo:
                (res_app / "update-repo.txt").write_text(repo, encoding="utf-8")
        except Exception:
            pass
        icns = Path(ROOT) / "AppIcon.icns"
        if icns.exists():
            shutil.copy2(icns, app / "Contents/Resources/AppIcon.icns")
        plist = app / "Contents/Info.plist"
        try:
            info = plistlib.loads(plist.read_bytes())
            info["CFBundleVersion"] = VERSION
            info["CFBundleShortVersionString"] = ".".join(VERSION.split(".")[:2])
            plist.write_bytes(plistlib.dumps(info))
        except Exception:
            pass
        launcher = Path(ROOT) / "macos/launcher.sh"
        if launcher.exists():
            shutil.copy2(launcher, app / "Contents/MacOS/OMAGAD")
        os.chmod(app / "Contents/MacOS/OMAGAD", 0o755)
        _run(["xattr", "-cr", str(app)])
        os.symlink("/Applications", stage / "Applications")
        (stage / ".background").mkdir()
        bg1, bg2 = Path(ROOT) / "installer/dmg-background.png", Path(ROOT) / "installer/dmg-background@2x.png"
        bg_name = "background.png"
        if bg1.exists() and bg2.exists() and _run(["tiffutil", "-cathidpicheck", str(bg1), str(bg2), "-out",
                                                   str(stage / ".background/background.tiff")]).returncode == 0:
            bg_name = "background.tiff"
        elif bg1.exists():
            shutil.copy2(bg1, stage / ".background/background.png")
        if icns.exists():
            shutil.copy2(icns, stage / ".VolumeIcon.icns")

        on_step("Création de l'image disque…", 0.3)
        rw = tmp / "rw.dmg"
        size = int(sum(f.stat().st_size for f in stage.rglob("*") if f.is_file() and not f.is_symlink()) * 1.15) // (1 << 20) + 60
        _run(["hdiutil", "detach", "/Volumes/" + vol, "-force"])  # un ancien volume OMAGAD resté monté
        r = _run(["hdiutil", "create", "-srcfolder", str(stage), "-volname", vol, "-fs", "HFS+",
                  "-fsargs", "-c c=64,a=16,e=16", "-format", "UDRW", "-size", "%dm" % size, str(rw)])
        if r.returncode != 0:
            raise RuntimeError("hdiutil create : " + (r.stderr or r.stdout).strip()[-300:])
        r = _run(["hdiutil", "attach", "-readwrite", "-noverify", "-noautoopen", str(rw)])
        if r.returncode != 0:
            raise RuntimeError("hdiutil attach : " + (r.stderr or r.stdout).strip()[-300:])
        mount = next((l.split("\t")[-1].strip() for l in r.stdout.splitlines() if "/Volumes/" in l), "/Volumes/" + vol)
        vol_name = Path(mount).name
        layout_ok = True
        try:
            on_step("Mise en page de la fenêtre…", 0.5)
            # icône du volume
            if (Path(mount) / ".VolumeIcon.icns").exists():
                _run(["SetFile", "-a", "C", mount])  # présent si les outils Xcode sont installés
            script = FINDER_SCRIPT % {"r": 200 + WIN[0], "b": 120 + WIN[1] + 28, "bg": bg_name,
                                      "ax": ICON_APP[0], "ay": ICON_APP[1], "bx": ICON_APPS[0], "by": ICON_APPS[1]}
            r = _run(["osascript", "-", vol_name], input=script, timeout=90)
            layout_ok = r.returncode == 0
            time.sleep(1.5)
            _run(["chmod", "-Rf", "go-w", mount])
            _run(["sync"])
        finally:
            for _ in range(5):
                if _run(["hdiutil", "detach", mount]).returncode == 0:
                    break
                time.sleep(1.5)
            else:
                _run(["hdiutil", "detach", mount, "-force"])
        on_step("Compression…", 0.75)
        final = out_dir / ("OMAGAD-%s.dmg" % VERSION)
        if final.exists():
            final.unlink()
        r = _run(["hdiutil", "convert", str(rw), "-format", "UDZO", "-imagekey", "zlib-level=9", "-o", str(final)])
        if r.returncode != 0:
            raise RuntimeError("hdiutil convert : " + (r.stderr or r.stdout).strip()[-300:])
        _run(["open", "-R", str(final)])
        return {"file": str(final), "layout": layout_ok, "size": final.stat().st_size}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
