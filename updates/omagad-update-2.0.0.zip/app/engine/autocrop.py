"""Recadrage automatique : suit le visage principal pour le garder au centre du cadre 9:16."""
import subprocess

from . import media
from .media import NOWIN

SAMPLE_FPS = 4
SW = 320  # largeur d'analyse


def _frames(src, t0, t1, w, h):
    sh = int(round(SW * h / w / 2)) * 2
    cmd = [media.FFMPEG, "-hide_banner", "-loglevel", "error", "-ss", "%.3f" % t0, "-i", str(src), "-t", "%.3f" % (t1 - t0),
           "-vf", "fps=%d,scale=%d:%d,format=gray" % (SAMPLE_FPS, SW, sh), "-f", "rawvideo", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, **NOWIN)
    size = SW * sh
    i = 0
    while True:
        buf = p.stdout.read(size)
        if len(buf) < size:
            break
        yield i / SAMPLE_FPS, buf, sh
        i += 1
    p.wait()


def _smooth(vals, k=3):
    out = []
    for i in range(len(vals)):
        win = sorted(vals[max(0, i - k): i + k + 1])
        out.append(win[len(win) // 2])
    return out


def _simplify(pts, eps):
    """Ramer-Douglas-Peucker : garde peu de points clés."""
    if len(pts) < 3:
        return pts
    (x0, y0), (x1, y1) = pts[0], pts[-1]
    best, idx = -1, 0
    for i in range(1, len(pts) - 1):
        x, y = pts[i]
        yl = y0 + (y1 - y0) * (x - x0) / max(1e-9, x1 - x0)
        d = abs(y - yl)
        if d > best:
            best, idx = d, i
    if best <= eps:
        return [pts[0], pts[-1]]
    return _simplify(pts[:idx + 1], eps)[:-1] + _simplify(pts[idx:], eps)


def track(src, info, t0, t1, zoom=1.0, on_progress=None):
    """Renvoie {"keys": [[t, fx], ...], "found": proportion d'images avec un visage}."""
    import numpy as np
    try:
        import cv2
    except ImportError:
        cv2 = None
    front = prof = upper = None
    if cv2 is not None:
        base = getattr(getattr(cv2, "data", None), "haarcascades", "") or ""
        cs = [cv2.CascadeClassifier(base + n) for n in ("haarcascade_frontalface_default.xml",
                                                          "haarcascade_profileface.xml", "haarcascade_upperbody.xml")]
        if not cs[0].empty():
            front, prof, upper = cs
    last_gray = None
    w, h = info["width"], info["height"]
    # largeur du cadre 9:16 rapportée à la largeur de la vidéo
    r = min(1.0, (h * 9 / 16) / w / max(1.0, zoom))
    if r >= 0.999:
        return {"keys": [], "found": 0.0, "message": "La vidéo est déjà verticale : rien à recadrer."}
    total = max(1, int((t1 - t0) * SAMPLE_FPS))
    xs, ts, hits, prev = [], [], 0, None
    for t, buf, sh in _frames(src, t0, t1, w, h):
        img = np.frombuffer(buf, dtype=np.uint8).reshape(sh, SW)
        cands = []
        if front is None:  # pas de détecteur de visage : on suit ce qui bouge
            g = img.astype(np.int16)
            if last_gray is not None:
                diff = np.abs(g - last_gray)
                col = diff.sum(axis=0).astype(np.float64)
                if col.sum() > SW * sh * 2.5:
                    xs_ = np.arange(SW)
                    cands.append((col.sum(), float((col * xs_).sum() / col.sum()) / SW))
            last_gray = g
        else:
            img = cv2.equalizeHist(img)
        for casc, flip in (((front, False), (prof, False), (prof, True)) if front is not None else ()):
            im = cv2.flip(img, 1) if flip else img
            for (x, y, fw, fh) in casc.detectMultiScale(im, 1.15, 5, minSize=(18, 18)):  # noqa
                cx = (SW - (x + fw / 2)) if flip else (x + fw / 2)
                cands.append((fw * fh, cx / SW))
            if cands:
                break
        if not cands and upper is not None:
            for (x, y, fw, fh) in upper.detectMultiScale(img, 1.1, 4, minSize=(40, 40)):
                cands.append((fw * fh * 0.5, (x + fw / 2) / SW))
        if cands:
            hits += 1
            if prev is None:
                cx = max(cands)[1]
            else:  # le plus gros visage, en favorisant celui qui était déjà suivi
                cx = max(cands, key=lambda c: c[0] / (1 + 8 * abs(c[1] - prev)))[1]
            prev = cx
        xs.append(prev)
        ts.append(t)
        if on_progress and len(ts) % 8 == 0:
            on_progress(min(0.95, len(ts) / total))
    if not hits:
        return {"keys": [], "found": 0.0, "message": "Aucun sujet trouvé dans ce moment."}
    first = next(x for x in xs if x is not None)
    xs = [first if x is None else x for x in xs]
    xs = _smooth(xs, 3)
    # caméra stable : ne bouge que si le sujet sort d'une zone centrale
    cam, out = xs[0], []
    dead = r * 0.12
    for x in xs:
        if abs(x - cam) > dead:
            cam += (x - cam) * 0.35
        out.append(cam)
    fx = [min(1.0, max(0.0, (c - r / 2) / (1 - r))) for c in out]
    pts = _simplify(list(zip(ts, fx)), 0.012)
    keys = [[round(t, 2), round(v, 4)] for t, v in pts]
    if len(keys) == 1:
        keys.append([round(t1 - t0, 2), keys[0][1]])
    return {"keys": keys, "found": hits / max(1, len(ts)), "message": None}
