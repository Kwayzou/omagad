/* Inspecteur : accroche, sous-titres (texte), style des sous-titres, cadrage, publication. */
(function () {
  const { $, $$, esc, fmt, clamp } = VC;
  let tab = 'hook';
  const TABS = [['hook', 'Accroche'], ['subs', 'Sous-titres'], ['sound', 'Sons'], ['media', 'Médias'], ['frame', 'Cadrage'], ['pub', 'Post']];
  const norm = t => t.toUpperCase().replace(/[^\p{L}\p{N}]/gu, '');

  /* Petits constructeurs de contrôles liés au style du moment */
  const range = (k, lab, min, max, stp, unit, fmtv) => '<div class="field"><label for="i_' + k + '">' + lab + '<output id="o_' + k + '"></output></label><input type="range" id="i_' + k + '" data-s="' + k + '" min="' + min + '" max="' + max + '" step="' + stp + '" data-unit="' + (unit || '') + '"' + (fmtv ? ' data-fmt="' + fmtv + '"' : '') + '></div>';
  const color = (k, lab) => '<div class="field"><span class="flabel">' + lab + '</span><div class="color"><input type="color" id="i_' + k + '" data-s="' + k + '"><span id="o_' + k + '"></span></div></div>';
  const check = (k, lab) => '<label class="check"><input type="checkbox" id="i_' + k + '" data-s="' + k + '"> ' + lab + '</label>';
  const seg = (k, lab, opts) => '<div class="field"><span class="flabel">' + lab + '</span><div class="seg" data-seg="' + k + '">' + opts.map(o => '<button type="button" data-v="' + o[0] + '">' + o[1] + '</button>').join('') + '</div></div>';
  const fontSel = (k, lab) => '<div class="field"><label for="i_' + k + '">' + lab + '</label><div class="sfx-row"><select id="i_' + k + '" data-s="' + k + '">' + VC.fontList().map(f => '<option>' + esc(f) + '</option>').join('') + '</select>' +
    '<button class="icon-btn" type="button" data-addfont="' + k + '" title="Ajouter une police (.ttf, .otf)"><svg viewBox="0 0 20 20" width="16" height="16"><path d="M10 4v12M4 10h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button></div></div>';
  const selectF = (k, lab, opts) => '<div class="field"><label for="i_' + k + '">' + lab + '</label><select id="i_' + k + '" data-s="' + k + '">' + opts.map(o => '<option value="' + o[0] + '">' + esc(o[1]) + '</option>').join('') + '</select></div>';
  const applyAll = kind => '<div class="group"><span class="label">Appliquer</span><div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small" type="button" data-all="' + kind + '">À tous les moments</button><button class="btn small ghost" type="button" data-def="' + kind + '">Par défaut pour les prochains vlogs</button></div></div>';

  VC.renderInspector = function () {
    const box = $('#inspector'); if (!box) return;
    const m = VC.cur();
    if (tab === 'look') tab = 'subs';
    box.innerHTML = '<button class="rail" type="button" data-rail="right" title="Afficher les réglages"><span>Réglages</span></button>' +
      '<div class="tabs" role="tablist">' + TABS.map(t => '<button type="button" role="tab" data-tab="' + t[0] + '" aria-selected="' + (t[0] === tab) + '">' + t[1] + '</button>').join('') +
      '<button class="icon-btn small collapse-r" type="button" data-collapse="right" title="Réduire"><svg viewBox="0 0 20 20" width="15" height="15"><path d="M8 5l5 5-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div><div class="pane" id="pane"></div>';
    box.querySelector('.tabs').onclick = e => { const b = e.target.closest('[data-tab]'); if (b) { tab = b.dataset.tab; VC.renderInspector(); } };
    box.onclick = e => { if (e.target.closest('[data-collapse="right"], [data-rail="right"]')) VC.toggleSide('right'); };
    const pane = $('#pane');
    if (!m) { pane.innerHTML = '<div class="empty">Sélectionne un moment dans la liste ou sur la timeline.</div>'; return; }
    ({ hook: paneHook, sound: paneSound, subs: paneSubs, media: paneMedia, frame: paneFrame, pub: panePub })[tab](pane, m);
    if (tab !== 'pub' && tab !== 'media') pane.insertAdjacentHTML('afterbegin', styleBar());
    if (tab === 'subs') pane.insertAdjacentHTML('beforeend', lookHTML());
    bindStyle(pane, m);
    bindStyleBar(pane, m);
    VC.enhanceSections(pane, tab);
    if (VC.applyLayout) $('#inspector').classList.toggle('collapsed', getComputedStyle(document.documentElement).getPropertyValue('--rw').trim() === '44px');
  };

  /* ---------- Styles enregistrés (police, couleurs, animation, sons, zooms, cadrage) ---------- */
  const styles = () => VC.S.state.settings.styles || [];
  function styleBar() {
    const list = styles();
    return '<div class="style-bar"><span class="sb-l">Style</span><select id="sbSel"><option value="">' + (list.length ? 'Choisir un style…' : 'Aucun style enregistré') + '</option>' +
      list.map((x, i) => '<option value="' + i + '">' + esc(x.name) + '</option>').join('') + '</select>' +
      '<button class="btn small" type="button" id="sbApply" disabled>Appliquer</button><button class="btn small ghost" type="button" id="sbAll" disabled>À tous</button>' +
      '<button class="icon-btn" type="button" id="sbSave" title="Enregistrer le style de ce moment"><svg viewBox="0 0 20 20" width="15" height="15"><path d="M10 4v12M4 10h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>' +
      '<button class="icon-btn" type="button" id="sbDel" title="Supprimer ce style" disabled><svg viewBox="0 0 20 20" width="15" height="15"><path d="M5 6h10M8 6V4h4v2M6.5 6l.7 10h5.6l.7-10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg></button>' +
      '<div class="sb-save" id="sbForm" hidden><input type="text" id="sbName" maxlength="40" placeholder="Nom du style (ex. Piazza Festival)"><button class="btn small primary" type="button" id="sbOk">Enregistrer</button></div></div>';
  }
  VC.applyStyleTo = function (m, x) {
    m.style = VC.clone(x.style);
    m.frame = m.frame || { mode: 'fill', fx: .5, fy: .5, zoom: 1, punch: true };
    if (x.zcfg) { m.frame.zcfg = Object.assign({}, x.zcfg, { seed: Math.floor(Math.random() * 1e6) + 1 }); m.frame.zooms = m.frame.zcfg.on ? VC.makeZooms(m, m.frame.zcfg) : null; }
    if (x.punch != null) m.frame.punch = x.punch;
    if (x.mode) m.frame.mode = x.mode;
    if (x.zoom) m.frame.zoom = x.zoom;
    if (x.sfx !== undefined) m.sfx = x.sfx ? VC.clone(x.sfx) : null;
    if (x.music !== undefined) m.music = x.music ? VC.clone(x.music) : null;
  };
  function bindStyleBar(pane, m) {
    const sel = $('#sbSel', pane); if (!sel) return;
    const cur = () => styles()[+sel.value];
    sel.onchange = () => { const on = sel.value !== ''; ['sbApply', 'sbAll', 'sbDel'].forEach(id => $('#' + id).disabled = !on); };
    $('#sbApply').onclick = () => { const x = cur(); if (!x) return; VC.applyStyleTo(m, x); VC.invalidate(); VC.commit(true); VC.renderInspector(); VC.drawTimeline(); VC.layoutVideo(); VC.toast('Style « ' + x.name + ' » appliqué', 1800); };
    $('#sbAll').onclick = async () => {
      const x = cur(); if (!x) return;
      if (!await VC.confirm('Appliquer « ' + x.name + ' » à tous les moments ?', 'Police, couleurs, animation, sons et zooms de tous les moments seront remplacés. Tu pourras annuler avec Cmd+Z.', 'Appliquer')) return;
      VC.S.project.moments.forEach(mm => VC.applyStyleTo(mm, x)); VC.invalidate(); VC.commit(true); VC.renderInspector(); VC.drawTimeline(); VC.layoutVideo();
      VC.toast('Style appliqué à tous les moments', 1800);
    };
    $('#sbSave').onclick = () => { const f = $('#sbForm'); f.hidden = !f.hidden; if (!f.hidden) $('#sbName').focus(); };
    const save = async () => {
      const name = $('#sbName').value.trim(); if (!name) return $('#sbName').focus();
      const f = m.frame || {}, list = styles().filter(x => x.name !== name);
      list.push({ name, style: VC.style(m), zcfg: f.zcfg ? VC.clone(f.zcfg) : null, punch: f.punch !== false, mode: f.mode || 'fill', zoom: f.zoom || 1,
        sfx: Array.isArray(m.sfx) ? VC.clone(m.sfx) : null, music: m.music ? VC.clone(m.music) : null });
      await VC.saveSettings({ styles: list }); VC.renderInspector(); VC.toast('Style « ' + name + ' » enregistré', 1800);
    };
    $('#sbOk').onclick = save;
    $('#sbName').onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); save(); } e.stopPropagation(); };
    $('#sbDel').onclick = async () => {
      const x = cur(); if (!x || !await VC.confirm('Supprimer le style « ' + x.name + ' » ?', 'Les moments qui l\'utilisent gardent leur apparence.', 'Supprimer')) return;
      await VC.saveSettings({ styles: styles().filter(y => y !== x) }); VC.renderInspector();
    };
  }

  function bindStyle(pane, m) {
    const st = VC.style(m);
    $$('[data-s]', pane).forEach(el => {
      const k = el.dataset.s, out = $('#o_' + k);
      const show = () => { if (out) out.textContent = el.dataset.fmt === 'pct' ? Math.round(el.value * 100) + ' %' : el.type === 'color' ? el.value.toUpperCase() : el.value + (el.dataset.unit || ''); };
      if (el.tagName === 'SELECT' && st[k] != null && ![...el.options].some(o => o.value === String(st[k]))) el.add(new Option(String(st[k]), String(st[k])), 0);
      if (el.type === 'checkbox') el.checked = !!st[k]; else el.value = st[k];
      show();
      el.addEventListener(el.tagName === 'SELECT' || el.type === 'checkbox' ? 'change' : 'input', () => {
        m.style = m.style || {};
        m.style[k] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? parseFloat(el.value) : el.value;
        show(); VC.invalidate();
        if (k === 'sub_words' && !m.subs) VC.drawTimeline();
        if (k === 'hook_in' || k === 'hook_out') {  // préréglage : durée et courbe conseillées
          const p = (k === 'hook_in' ? VC.ANIM_IN : VC.ANIM_OUT).find(x => x[0] === el.value);
          if (p) { m.style[k + '_ms'] = p[2]; m.style[k + '_ease'] = p[3]; }
          VC.commit(true); VC.renderInspector(); replayHook(m); return;
        }
        if (/^hook_(secs|in_|out_|drift|shake|words|wander)/.test(k)) replayHook(m);
        if (k === 'hook_secs') VC.drawTimeline();
        VC.commit();
      });
    });
    $$('[data-seg]', pane).forEach(sg => {
      const k = sg.dataset.seg, isFrame = k.startsWith('f_'), key = isFrame ? k.slice(2) : k;
      const get = () => isFrame ? m.frame[key] : st[key];
      const mark = () => $$('button', sg).forEach(b => b.setAttribute('aria-pressed', String(String(get()) === b.dataset.v)));
      mark();
      sg.onclick = e => {
        const b = e.target.closest('button'); if (!b) return;
        if (isFrame) { m.frame[key] = b.dataset.v; VC.layoutVideo(); } else { m.style = m.style || {}; m.style[key] = b.dataset.v; st[key] = b.dataset.v; if (key === 'sub_anim') { const v = VC.vid(); if (v) v.play().catch(() => {}); } }
        mark(); VC.invalidate(); VC.commit();
      };
    });
    $$('[data-addfont]', pane).forEach(b => b.onclick = async () => {
      if (!VC.native()) return VC.toast('L\'ajout de police fonctionne dans l\'application OMAGAD.');
      const p = await window.pywebview.api.pick_font(); if (!p) return;
      try {
        const r = await VC.api('/api/font-import', { path: p });
        VC.S.state.fonts = r.fonts; VC.loadFonts();
        m.style = m.style || {}; m.style[b.dataset.addfont] = r.family; VC.invalidate(); VC.commit(true); VC.renderInspector();
        VC.toast('Police « ' + r.family + ' » ajoutée');
      } catch (e) { VC.toast(e.message); }
    });
    $$('[data-all]', pane).forEach(b => b.onclick = async () => {
      const keys = Object.keys(VC.S.state.settings.default_style).filter(k => k.startsWith(b.dataset.all));
      if (!await VC.confirm('Appliquer ce style à tous les moments ?', 'Les réglages ' + ({ hook_: 'de l\'accroche', sub_: 'des sous-titres', sfx_: 'des sons' }[b.dataset.all]) + ' de ce moment seront copiés sur les ' + (VC.S.project.moments.length - 1) + ' autres.', 'Appliquer')) return;
      for (const x of VC.S.project.moments) { x.style = x.style || {}; keys.forEach(k => { x.style[k] = st[k]; }); }
      VC.commit(true); VC.toast('Style appliqué à tous les moments');
    });
    $$('[data-def]', pane).forEach(b => b.onclick = async () => {
      const keys = Object.keys(VC.S.state.settings.default_style).filter(k => k.startsWith(b.dataset.def));
      const s = Object.assign({}, VC.S.state.settings.style); keys.forEach(k => { s[k] = st[k]; });
      await VC.saveSettings({ style: s }); VC.toast('Enregistré comme style par défaut');
    });
  }
  function replayHook(m) { const v = VC.vid(); if (v) VC.seek(m.t0, true); }

  /* Bloc d'apparence commun à l'accroche (hook_) et aux sous-titres (sub_) */
  function looks(k) {
    const hook = k === 'hook_';
    return '<div class="group"><span class="label">Texte</span>' + fontSel(k + 'font', 'Police') +
      '<div style="display:flex;gap:16px;flex-wrap:wrap">' + check(k + 'bold', 'Gras') + check(k + 'italic', 'Italique') + check(k + 'upper', 'Majuscules') + '</div>' +
      '<div class="cols2">' + range(k + 'size', 'Taille', hook ? 50 : 36, hook ? 220 : 150, 2, '') + range(k + 'y', 'Position verticale', .08, .92, .01, '', 'pct') + '</div>' +
      '<div class="cols2">' + range(k + 'spacing', 'Espacement des lettres', -6, 30, 1, '') + (hook ? range('hook_line', 'Interligne', .7, 1.8, .05, '') : '<span></span>') + '</div>' +
      '<div class="cols3">' + color(k + 'color', 'Texte') + color(hook ? 'hook_emph_color' : 'sub_hl_color', hook ? 'Mot fort' : 'Mot prononcé') + color(k + 'outline_color', 'Contour') + '</div>' +
      range(k + 'outline', 'Épaisseur du contour', 0, 18, 1, '') + '</div>' +
      '<div class="group"><span class="label">Lueur</span>' + check(k + 'glow', 'Activer la lueur') +
      seg(k + 'glow_mode', 'Type', [['out', 'Extérieure'], ['in', 'Intérieure'], ['both', 'Les deux']]) +
      '<div class="cols2">' + color(k + 'glow_color', 'Couleur') + range(k + 'glow_size', 'Taille', 2, 60, 1, '') + '</div>' +
      range(k + 'glow_opacity', 'Opacité', .1, 1, .05, '', 'pct') + '</div>' +
      '<div class="group"><span class="label">Ombre portée</span>' + check(k + 'shadow', 'Activer l\'ombre') +
      '<div class="cols3">' + color(k + 'shadow_color', 'Couleur') + range(k + 'shadow_dist', 'Distance', 0, 30, 1, '') + range(k + 'shadow_opacity', 'Opacité', 0, 1, .05, '', 'pct') + '</div></div>' +
      '<div class="group"><span class="label">Encadré</span>' + check(k + 'box', 'Texte dans un encadré') + color(k + 'box_color', 'Couleur de l\'encadré') + '</div>';
  }
  function customAnim(side) {
    return '<div class="custom-anim"><span class="hint">Point de ' + (side === 'in' ? 'départ' : 'arrivée') + ' de l\'animation (par rapport à la position normale)</span>' +
      '<div class="cols2">' + range('hook_' + side + '_dx', 'Décalage horizontal', -1400, 1400, 10, ' px') + range('hook_' + side + '_dy', 'Décalage vertical', -1000, 1000, 10, ' px') + '</div>' +
      '<div class="cols3">' + range('hook_' + side + '_scale', 'Taille', 0, 3, .05, '', 'pct') + range('hook_' + side + '_rot', 'Rotation', -180, 180, 1, '°') + range('hook_' + side + '_alpha', 'Opacité', 0, 1, .05, '', 'pct') + '</div></div>';
  }
  function animBlock(st) {
    return '<div class="group"><div style="display:flex;justify-content:space-between;align-items:center"><span class="label">Animation</span><button class="btn small" type="button" id="btnReplay">Rejouer</button></div>' +
      '<div class="cols2">' + selectF('hook_in', 'Entrée', VC.ANIM_IN) + selectF('hook_in_ease', 'Courbe d\'entrée', VC.EASES) + '</div>' +
      range('hook_in_ms', 'Durée de l\'entrée', 0, 1500, 10, ' ms') + (st.hook_in === 'custom' ? customAnim('in') : '') +
      '<div class="cols2">' + selectF('hook_out', 'Sortie', VC.ANIM_OUT) + selectF('hook_out_ease', 'Courbe de sortie', VC.EASES) + '</div>' +
      range('hook_out_ms', 'Durée de la sortie', 0, 1500, 10, ' ms') + (st.hook_out === 'custom' ? customAnim('out') : '') +
      range('hook_secs', 'Durée totale à l\'écran', .8, 8, .1, ' s') +
      range('hook_drift', 'Dérive pendant l\'affichage', -80, 80, 1, ' px') +
      '<div style="display:flex;gap:16px;flex-wrap:wrap">' + check('hook_shake', 'Secousse à l\'arrivée') + check('hook_words', 'Apparition mot à mot') + '</div></div>' +
      '<div class="group"><div style="display:flex;justify-content:space-between;align-items:center"><span class="label">Mouvement aléatoire</span>' +
      '<button class="btn small" type="button" id="btnWander">Nouveau mouvement</button></div>' +
      '<p class="hint" style="margin:0">Le titre flotte doucement vers le haut, le bas, la gauche et la droite pendant qu\'il est affiché.</p>' + check('hook_wander', 'Activer') +
      '<div class="cols2">' + range('hook_wander_x', 'Gauche ↔ droite', 0, 120, 1, ' px') + range('hook_wander_y', 'Haut ↕ bas', 0, 120, 1, ' px') + '</div>' +
      '<div class="cols2">' + range('hook_wander_rot', 'Rotation', 0, 15, .5, '°') + range('hook_wander_speed', 'Vitesse', .1, 3, .05, ' Hz') + '</div></div>';
  }

  /* ---------- Accroche ---------- */
  function paneHook(pane, m) {
    pane.innerHTML = '<div class="group"><div class="field"><label for="hookText">Texte accrocheur <span class="hint">Entrée = retour à la ligne</span></label><textarea class="hook-input" id="hookText" maxlength="80" rows="2" placeholder="Ex. Koh Lanta x GTA 6&#10;ça va être fort">' + esc(m.hook) + '</textarea></div>' +
      '<div class="field"><span class="flabel">Mot mis en couleur <span class="hint">clique pour choisir</span></span><div class="chips" id="emph"></div></div>' +
      '<div style="display:flex;gap:6px;align-items:center"><button class="btn small" type="button" id="btnIdeas">Autres idées avec Claude</button><span class="hint" id="ideasMsg"></span></div><div class="chips" id="ideas"></div></div>' +
      animBlock(VC.style(m)) + looks('hook_') + applyAll('hook_');
    setTimeout(() => { const b = $('#btnWander'); if (b) b.onclick = () => { m.style = m.style || {}; m.style.hook_wander = true; m.style.hook_wander_seed = Math.floor(Math.random() * 1e6) + 1; VC.invalidate(); VC.commit(true); VC.renderInspector(); replayHook(m); }; });
    $('#btnReplay').onclick = () => replayHook(m);
    const chips = () => {
      const set = new Set((m.emphasis || '').split(/\s+/).map(norm).filter(Boolean));
      $('#emph').innerHTML = (m.hook || '').split(/\s+/).filter(Boolean).map(w => '<button type="button" class="chip' + (set.has(norm(w)) ? ' on' : '') + '" data-w="' + esc(w) + '">' + esc(w) + '</button>').join('') || '<span class="hint">Écris d\'abord l\'accroche.</span>';
    };
    chips();
    $('#hookText').oninput = e => {
      m.hook = e.target.value;
      const keep = (m.emphasis || '').split(/\s+/).filter(x => m.hook.split(/\s+/).map(norm).includes(norm(x)));
      m.emphasis = keep.join(' '); chips(); VC.invalidate(); VC.renderList(); VC.drawTimeline(); VC.commit();
    };
    $('#emph').onclick = e => {
      const c = e.target.closest('[data-w]'); if (!c) return;
      const cur = (m.emphasis || '').split(/\s+/).filter(Boolean), n = norm(c.dataset.w);
      m.emphasis = cur.some(x => norm(x) === n) ? cur.filter(x => norm(x) !== n).join(' ') : cur.concat(c.dataset.w).join(' ');
      chips(); VC.invalidate(); VC.commit();
    };
    $('#btnIdeas').onclick = async () => {
      if (!VC.S.state.settings.has_key) return VC.toast('Ajoute une clé API Anthropic dans les Réglages pour avoir des idées d\'accroche.');
      $('#btnIdeas').disabled = true; $('#ideasMsg').textContent = 'Claude réfléchit...';
      try {
        const r = await VC.api('/api/hooks', { pid: VC.S.project.id, t0: m.t0, t1: m.t1 });
        $('#ideas').innerHTML = r.hooks.map(h => '<button type="button" class="chip" data-h="' + esc(h) + '">' + esc(h) + '</button>').join('');
        $('#ideasMsg').textContent = '';
      } catch (err) { $('#ideasMsg').textContent = err.message; }
      $('#btnIdeas').disabled = false;
    };
    $('#ideas').onclick = e => {
      const c = e.target.closest('[data-h]'); if (!c) return;
      m.hook = c.dataset.h; m.emphasis = ''; $('#hookText').value = m.hook; chips(); VC.invalidate(); VC.renderList(); VC.commit(true); replayHook(m);
    };
  }

  /* ---------- Sons (liste, comme sur la timeline) ---------- */
  const PLAY = '<svg viewBox="0 0 20 20" width="14" height="14"><path d="M6 4l11 6-11 6z" fill="currentColor"/></svg>';
  const TRASH = '<svg viewBox="0 0 20 20" width="14" height="14"><path d="M4 6h12M8 6V4h4v2M6 6l1 10h6l1-10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const sel = (track, i) => VC.S.item && VC.S.item.track === track && VC.S.item.key === i;
  /* ---------- Musique de fond avec baisse automatique sous la voix ---------- */
  function musicHTML(m) {
    const mu = m.music;
    return '<div class="group"><span class="label">Musique de fond</span>' +
      (mu ? '<div class="item"><div class="row"><span class="grow" style="font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">♪ ' + esc(mu.name || 'Musique') + '</span>' +
        '<button class="icon-btn" type="button" id="muDel" title="Retirer la musique">' + TRASH + '</button></div>' +
        '<div class="field"><label for="muFrom">Départ dans le morceau<output id="oMuFrom"></output></label><input type="range" id="muFrom" min="0" max="' + Math.max(1, Math.floor((mu.dur || 60) - 1)) + '" step="0.5" value="' + (+mu.from || 0) + '"></div>' +
        '<div class="field"><label for="muVol">Volume<output id="oMuVol"></output></label><input type="range" id="muVol" min="0" max="1" step="0.02" value="' + (mu.vol == null ? .5 : mu.vol) + '"></div>' +
        '<label class="check"><input type="checkbox" id="muDuck"' + (mu.duck !== false ? ' checked' : '') + '> Baisser la musique quand je parle</label>' +
        '<div class="field"><label for="muLvl">Niveau pendant la parole<output id="oMuLvl"></output></label><input type="range" id="muLvl" min="0.05" max="0.8" step="0.05" value="' + (+mu.duck_level || .25) + '"></div></div>' +
        '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small" type="button" id="muPick">Changer de morceau</button><button class="btn small ghost" type="button" id="muAll">Même musique sur tous les moments</button></div>'
        : '<p class="hint" style="margin:0">Pose un morceau ou un extrait de set sous le clip : son volume baisse tout seul quand tu parles.</p><div><button class="btn small primary" type="button" id="muPick">Choisir une musique</button></div>') + '</div>';
  }
  function bindMusic(m) {
    const show = () => { const mu = m.music; if (!mu) return; $('#oMuFrom').textContent = fmt(+mu.from || 0); $('#oMuVol').textContent = Math.round((mu.vol == null ? .5 : mu.vol) * 100) + ' %'; $('#oMuLvl').textContent = Math.round((+mu.duck_level || .25) * 100) + ' %'; };
    $('#muPick').onclick = async () => {
      if (!VC.native()) return VC.toast('L\'import de son fonctionne dans l\'application OMAGAD.');
      const path = await window.pywebview.api.pick_audio(); if (!path) return;
      VC.toast('Import de la musique…', 1500);
      try {
        const r = await VC.api('/api/music-import', { path });
        m.music = Object.assign({ from: 0, vol: .5, duck: true, duck_level: .25 }, m.music || {}, { file: r.file, name: r.name, dur: r.dur, from: 0 });
        VC.commit(true); VC.renderInspector();
      } catch (e) { VC.toast(e.message); }
    };
    if (!m.music) return;
    show();
    $('#muDel').onclick = () => { m.music = null; VC.stopMusic(); VC.commit(true); VC.renderInspector(); };
    $('#muFrom').oninput = e => { m.music.from = +e.target.value; show(); VC.commit(); };
    $('#muVol').oninput = e => { m.music.vol = +e.target.value; show(); VC.commit(); };
    $('#muLvl').oninput = e => { m.music.duck_level = +e.target.value; show(); VC.commit(); };
    $('#muDuck').onchange = e => { m.music.duck = e.target.checked; VC.commit(true); };
    $('#muAll').onclick = async () => {
      if (!await VC.confirm('Même musique sur tous les moments ?', 'Chaque moment reçoit ce morceau, avec un départ différent pour ne pas entendre toujours le même passage.', 'Appliquer')) return;
      let off = +m.music.from || 0; const len = m.music.dur || 120;
      for (const x of VC.S.project.moments) { if (x === m) continue; off = (off + (x.t1 - x.t0) + 5) % Math.max(10, len - 20); x.music = Object.assign({}, m.music, { from: Math.round(off) }); }
      VC.commit(true); VC.toast('Musique posée sur tous les moments', 2000);
    };
  }

  function libHTML() {
    const all = VC.S.state.sfx || [], app = all.filter(x => !String(x.id).startsWith('user:')), mine = all.filter(x => String(x.id).startsWith('user:'));
    const btn = x => '<button type="button" data-lib="' + esc(x.id) + '" title="' + esc(x.label) + '">' + PLAY + '<span>' + esc(x.label) + '</span></button>';
    return '<div class="lib-sec"><span class="lib-h">Sons OMAGAD <i>' + app.length + '</i></span><div class="sfx-lib">' + app.map(btn).join('') + '</div></div>' +
      '<div class="lib-sec"><span class="lib-h">Sons importés <i>' + mine.length + '</i></span>' + (mine.length ? '<div class="sfx-lib">' + mine.map(btn).join('') + '</div>'
        : '<p class="hint" style="margin:0">Tes sons apparaîtront ici. Importe un fichier, ou glisse-le dans la fenêtre.</p>') + '</div>';
  }
  function paneSound(pane, m) {
    const list = VC.sfxOf(m), opts = id => (VC.S.state.sfx || []).map(x => '<option value="' + esc(x.id) + '"' + (x.id === id ? ' selected' : '') + '>' + esc(x.label) + '</option>').join('');
    pane.innerHTML = '<div class="group"><div style="display:flex;justify-content:space-between;align-items:center"><span class="label">Sons de ce clip</span>' +
      '<button class="btn small primary" type="button" id="btnSfxHere">+ Son à la tête de lecture</button></div>' +
      '<div class="items" id="sfxItems">' + (list.length ? list.map((it, i) => '<div class="item' + (sel('sfx', i) ? ' on' : '') + '" data-i="' + i + '">' +
        '<div class="row"><select class="grow" data-f="sound">' + opts(it.sound) + '</select><button class="icon-btn" type="button" data-play="' + i + '" title="Écouter">' + PLAY + '</button><button class="icon-btn" type="button" data-del="' + i + '" title="Supprimer">' + TRASH + '</button></div>' +
        '<div class="row"><span class="hint">À</span><input type="number" step="0.01" min="-3" data-f="at" value="' + (+it.at).toFixed(3) + '"><span class="hint">s</span><span class="hint" style="margin-left:8px">Volume</span>' +
        '<input class="grow" type="range" min="0" max="1.5" step="0.05" data-f="vol" value="' + it.vol + '"><span class="mono hint" data-out="' + i + '">' + Math.round(it.vol * 100) + ' %</span></div>' +
        (it.link ? '<span class="hint">' + (it.link === 'in' ? 'Suit l\'entrée de l\'accroche' : 'Suit la sortie de l\'accroche') + '</span>' : '') + '</div>').join('')
        : '<div class="hint">Aucun son. Ajoute-en un, ou clique sur + dans la piste Sons de la timeline.</div>') + '</div>' +
      '<p class="hint" style="margin:0">Sur la timeline : fais glisser un son pour le déplacer (Alt pour un réglage fin, ⌥← / ⌥→ pour 10 ms), tire la ligne blanche pour le volume. Un son peut commencer avant le début du clip. Suppr pour l\'effacer.</p></div>' +
      musicHTML(m) +
      '<div class="group"><span class="label">Bibliothèque</span>' + libHTML() +
      '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small" type="button" id="btnSfxAdd">Importer un son</button><button class="btn small ghost" type="button" id="btnSfxDir">Dossier des sons</button>' +
      '<button class="btn small ghost" type="button" id="btnSfxAll">Copier ces sons sur tous les moments</button></div></div>' +
      '<div class="group"><span class="label">Sons par défaut des nouveaux clips</span>' +
      '<div class="cols2"><div class="field"><label for="i_sfx_in">Entrée de l\'accroche</label><select id="i_sfx_in" data-s="sfx_in"><option value="none">Aucun</option>' + opts() + '</select></div>' +
      '<div class="field"><label for="i_sfx_out">Sortie de l\'accroche</label><select id="i_sfx_out" data-s="sfx_out"><option value="none">Aucun</option>' + opts() + '</select></div></div>' +
      '<p class="hint" style="margin:0">Utilisés quand tu n\'as pas modifié les sons d\'un clip. « Par défaut pour les prochains vlogs » les enregistre.</p>' +
      '<div><button class="btn small ghost" type="button" data-def="sfx_">Par défaut pour les prochains vlogs</button></div></div>';
    const box = $('#sfxItems');
    box.addEventListener('input', e => {
      const row = e.target.closest('.item'); if (!row) return;
      const it = VC.ownSfx(m)[+row.dataset.i], f = e.target.dataset.f; if (!it || !f) return;
      if (f === 'vol') { it.vol = +e.target.value; $('[data-out="' + row.dataset.i + '"]').textContent = Math.round(it.vol * 100) + ' %'; }
      else if (f === 'at') { it.at = Math.max(-3, Math.min(m.t1 - m.t0, +e.target.value || 0)); it.link = null; }
      else if (f === 'sound') { it.sound = e.target.value; VC.playSfx(it.sound, it.vol); }
      VC.drawTimeline(); VC.commit();
    });
    box.onclick = e => {
      const pl = e.target.closest('[data-play]'); if (pl) { const it = VC.sfxOf(m)[+pl.dataset.play]; return VC.playSfx(it.sound, it.vol); }
      const d = e.target.closest('[data-del]'); if (d) { VC.ownSfx(m).splice(+d.dataset.del, 1); VC.S.item = null; VC.commit(true); VC.renderInspector(); VC.drawTimeline(); return; }
      const row = e.target.closest('.item'); if (row && !e.target.closest('select,input,button')) { VC.S.item = { track: 'sfx', key: +row.dataset.i }; const it = VC.sfxOf(m)[+row.dataset.i]; VC.vid().currentTime = m.t0 + it.at; VC.renderInspector(); VC.drawTimeline(); }
    };
    $$('.sfx-lib', pane).forEach(el => el.onclick = e => { const l = e.target.closest('[data-lib]'); if (l) VC.playSfx(l.dataset.lib, .8); });
    bindMusic(m);
    $('#btnSfxHere').onclick = () => VC.addAtPlayhead('sfx');
    $('#btnSfxAdd').onclick = async () => {
      if (!VC.native()) return VC.toast('L\'import de son fonctionne dans l\'application OMAGAD.');
      const p = await window.pywebview.api.pick_audio(); if (p) VC.importSound(p);
    };
    $('#btnSfxDir').onclick = () => VC.api('/api/sfx-folder', {});
    $('#btnSfxAll').onclick = async () => {
      if (!await VC.confirm('Copier ces sons sur tous les moments ?', 'Chaque moment recevra les mêmes sons, placés par rapport à son accroche.', 'Copier')) return;
      const base = VC.hookAt(m), src = VC.clone(VC.sfxOf(m));
      for (const x of VC.S.project.moments) if (x !== m) x.sfx = src.map(it => Object.assign({}, it, { at: Math.max(0, VC.hookAt(x) + it.at - base) }));
      VC.commit(true); VC.toast('Sons copiés sur tous les moments');
    };
  }
  VC.importSound = async function (path) {
    try {
      const r = await VC.api('/api/sfx-import', { path });
      VC.S.state.sfx = r.sfx; VC.toast('Son ajouté à la bibliothèque');
      if (VC.S.view === 'montage') { tab = 'sound'; VC.renderInspector(); }
    } catch (e) { VC.toast(e.message); }
  };

  /* ---------- Médias : photos et vidéos par-dessus ---------- */
  function paneMedia(pane, m) {
    const list = m.media || [];
    pane.innerHTML = '<div class="group"><div style="display:flex;justify-content:space-between;align-items:center"><span class="label">Photos et vidéos</span>' +
      '<button class="btn small primary" type="button" id="btnMediaAdd">+ Importer à la tête de lecture</button></div>' +
      '<div class="items" id="mediaItems">' + (list.length ? list.map((it, i) => '<div class="item' + (sel('media', i) ? ' on' : '') + '" data-i="' + i + '">' +
        '<div class="row"><div class="thumb" style="background-image:url(/pmedia/' + VC.S.project.id + '/' + esc(it.kind === 'image' ? it.file : '') + ')"></div><div class="grow"><div class="name">' + esc(it.name || it.file) + '</div><span class="hint">' + (it.kind === 'image' ? 'Photo' : 'Vidéo (sans son)') + '</span></div>' +
        '<button class="icon-btn" type="button" data-del="' + i + '" title="Supprimer">' + TRASH + '</button></div>' +
        '<div class="row"><span class="hint">Début</span><input type="number" step="0.1" min="0" data-f="at" value="' + (+it.at).toFixed(2) + '"><span class="hint">Durée</span><input type="number" step="0.1" min="0.2" data-f="dur" value="' + (+it.dur).toFixed(2) + '"><span class="hint">s</span></div>' +
        '<div class="seg" data-mode="' + i + '"><button type="button" data-v="full" aria-pressed="' + (it.mode !== 'pip') + '">Plein écran</button><button type="button" data-v="pip" aria-pressed="' + (it.mode === 'pip') + '">Incrusté</button></div>' +
        (it.mode === 'pip' ? '<div class="cols3"><div class="field"><span class="flabel">Taille</span><input type="range" min=".2" max="1" step=".01" data-f="scale" value="' + (it.scale || .45) + '"></div>' +
          '<div class="field"><span class="flabel">Gauche-droite</span><input type="range" min="0" max="1" step=".01" data-f="x" value="' + (it.x == null ? .5 : it.x) + '"></div>' +
          '<div class="field"><span class="flabel">Haut-bas</span><input type="range" min="0" max="1" step=".01" data-f="y" value="' + (it.y == null ? .3 : it.y) + '"></div></div>' : '') + '</div>').join('')
        : '<div class="hint">Aucun média. Importe une photo ou une vidéo : elle s\'affichera par-dessus ton vlog à la tête de lecture.</div>') + '</div>' +
      '<p class="hint" style="margin:0">Sur la timeline, piste Médias : glisse pour déplacer, tire les bords pour changer quand ça arrive et quand ça part.</p></div>';
    $('#btnMediaAdd').onclick = () => VC.addAtPlayhead('media');
    const box = $('#mediaItems');
    box.addEventListener('input', e => {
      const row = e.target.closest('.item'); if (!row) return;
      const it = m.media[+row.dataset.i], f = e.target.dataset.f; if (!it || !f) return;
      const v = +e.target.value; if (isNaN(v)) return;
      if (f === 'at') it.at = Math.max(0, Math.min(m.t1 - m.t0 - .2, v));
      else if (f === 'dur') it.dur = Math.max(.2, Math.min(m.t1 - m.t0 - it.at, it.kind === 'video' ? (it.vdur || 1e9) - (it.from || 0) : 1e9, v));
      else it[f] = v;
      VC.drawTimeline(); VC.commit();
    });
    box.onclick = e => {
      const d = e.target.closest('[data-del]'); if (d) { m.media.splice(+d.dataset.del, 1); VC.S.item = null; VC.commit(true); VC.renderInspector(); VC.drawTimeline(); return; }
      const sg = e.target.closest('[data-mode]'), b = e.target.closest('button[data-v]');
      if (sg && b) { m.media[+sg.dataset.mode].mode = b.dataset.v; VC.commit(true); VC.renderInspector(); return; }
      const row = e.target.closest('.item'); if (row && !e.target.closest('input,button')) { VC.S.item = { track: 'media', key: +row.dataset.i }; VC.vid().currentTime = m.t0 + m.media[+row.dataset.i].at + .05; VC.renderInspector(); VC.drawTimeline(); }
    };
  }

  /* ---------- Actions communes à la timeline et à l'inspecteur ---------- */
  VC.openItem = function (track, key) {
    tab = { hook: 'hook', subs: 'subs', sfx: 'sound', media: 'media', frame: 'frame' }[track] || tab;
    VC.renderInspector();
    const el = track === 'subs' ? $('.subrow[data-i="' + key + '"]') : $('#inspector .item[data-i="' + key + '"]');
    if (el) { el.scrollIntoView({ block: 'center' }); const inp = el.querySelector('input[type=text]'); if (inp) { inp.focus(); inp.select(); } }
    if (track === 'hook') { const h = $('#hookText'); if (h) h.focus(); }
  };
  VC.addAtPlayhead = async function (kind) {
    const m = VC.cur(); if (!m) return VC.toast('Sélectionne d\'abord un moment.');
    const v = VC.vid(), rel = Math.max(0, Math.min(m.t1 - m.t0 - .2, (v.currentTime || m.t0) - m.t0));
    if (kind === 'sfx') {
      const list = VC.ownSfx(m); list.push({ id: VC.uid('s'), sound: 'pop', at: Math.round(rel * 100) / 100, vol: .8 });
      VC.S.item = { track: 'sfx', key: list.length - 1 }; VC.commit(true); VC.openItem('sfx', list.length - 1); VC.drawTimeline(); VC.playSfx('pop', .8);
    } else if (kind === 'sub') {
      const subs = VC.ownSubs(m), s = m.t0 + rel, e = Math.min(m.t1, s + 1.2);
      subs.push({ s, e, words: [{ w: 'TEXTE', s, e }] }); subs.sort((a, b) => a.s - b.s);
      const i = subs.findIndex(c => c.s === s); VC.S.item = { track: 'subs', key: i }; VC.invalidate(); VC.commit(true); VC.openItem('subs', i); VC.drawTimeline();
    } else if (kind === 'media') {
      if (!VC.native()) return VC.toast('L\'import de photos et vidéos fonctionne dans l\'application OMAGAD.');
      const p = await window.pywebview.api.pick_media(); if (!p) return;
      VC.toast('Import en cours...', 20000);
      try {
        const r = await VC.api('/api/media-import', { pid: VC.S.project.id, path: p });
        const len = m.t1 - m.t0, d = r.kind === 'video' ? Math.min(r.vdur, len - rel) : Math.min(3, len - rel);
        m.media = m.media || []; m.media.push(Object.assign(r, { id: VC.uid('md'), at: Math.round(rel * 100) / 100, dur: Math.round(Math.max(.2, d) * 100) / 100, mode: 'full', from: 0 }));
        VC.S.item = { track: 'media', key: m.media.length - 1 }; VC.commit(true); VC.openItem('media', m.media.length - 1); VC.drawTimeline(); VC.toast('Média ajouté');
      } catch (e) { VC.toast(e.message); }
    }
  };
  VC.deleteItem = function () {
    const m = VC.cur(), it = VC.S.item; if (!m || !it) return;
    if (it.track === 'subs') VC.ownSubs(m).splice(it.key, 1);
    else if (it.track === 'sfx') VC.ownSfx(m).splice(it.key, 1);
    else if (it.track === 'media') (m.media || []).splice(it.key, 1);
    else return;
    VC.S.item = null; VC.invalidate(); VC.commit(true); VC.renderInspector(); VC.drawTimeline(); VC.toast('Supprimé (Cmd+Z pour annuler)', 1600);
  };

  /* ---------- Sous-titres : texte ---------- */
  function paneSubs(pane, m) {
    const chunks = VC.chunksOf(m);
    pane.innerHTML = '<div class="group"><div style="display:flex;justify-content:space-between;align-items:center"><span class="label">Texte des sous-titres</span>' +
      '<span class="hint">' + (m.subs ? 'Modifiés à la main' : 'Depuis la transcription') + '</span></div>' +
      '<p class="hint" style="margin:0">Corrige un mot directement dans la ligne. Clique sur l\'heure pour y aller.</p>' +
      '<div class="subrows" id="subrows">' + (chunks.length ? chunks.map((c, i) => '<div class="subrow' + (sel('subs', i) ? ' cur' : '') + '" data-i="' + i + '"><span class="t" data-seek="' + c.s + '">' + fmt(c.s - m.t0, true) + '</span>' +
        '<input type="text" value="' + esc(c.words.map(w => w.w).join(' ')) + '" aria-label="Sous-titre ' + (i + 1) + '"><button type="button" data-del="' + i + '" title="Supprimer cette ligne">×</button></div>').join('') : '<div class="hint">Aucune parole détectée dans ce moment.</div>') + '</div>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small ghost" type="button" id="btnRegen"' + (m.subs ? '' : ' disabled') + '>Revenir à la transcription</button></div></div>' +
      '<div class="group">' + check('sub_on', 'Afficher les sous-titres') + range('sub_words', 'Mots par ligne', 1, 5, 1, '') + '<p class="hint" style="margin:0">Changer le nombre de mots refait le découpage depuis la transcription.</p></div>';
    const own = () => { if (!m.subs) m.subs = VC.clone(VC.makeChunks(m.t0, m.t1, VC.style(m).sub_words)); return m.subs; };
    $('#subrows').addEventListener('input', e => {
      const row = e.target.closest('.subrow'); if (!row) return;
      const c = own()[+row.dataset.i], toks = e.target.value.split(/\s+/).filter(Boolean);
      const old = c.words, s = c.s, end = Math.max(c.e, old.length ? old[old.length - 1].e : c.e);
      c.words = toks.length === old.length ? toks.map((w, i) => ({ w, s: old[i].s, e: old[i].e }))
        : toks.map((w, i) => ({ w, s: s + (end - s) * i / toks.length, e: s + (end - s) * (i + 1) / toks.length }));
      VC.invalidate(); VC.commit(); $('#btnRegen').disabled = false;
    });
    $('#subrows').onclick = e => {
      const sk = e.target.closest('[data-seek]'); if (sk) { VC.vid().currentTime = +sk.dataset.seek; return; }
      const d = e.target.closest('[data-del]'); if (d) { own().splice(+d.dataset.del, 1); VC.invalidate(); VC.commit(true); VC.renderInspector(); VC.drawTimeline(); }
    };
    $('#btnRegen').onclick = () => { m.subs = null; VC.invalidate(); VC.commit(true); VC.renderInspector(); VC.drawTimeline(); };
    const words = pane.querySelector('[data-s="sub_words"]');
    words.addEventListener('change', () => { m.subs = null; VC.invalidate(); VC.commit(true); VC.renderInspector(); VC.drawTimeline(); });
  }

  /* ---------- Sous-titres : style ---------- */
  function lookHTML() {
    return '<div class="group"><span class="label">Animation des sous-titres</span>' +
      seg('sub_anim', 'Apparition de chaque ligne', [['none', 'Aucune'], ['pop', 'Pop'], ['fade', 'Fondu'], ['slide', 'Monte'], ['zoom', 'Zoom']]) +
      seg('sub_hl', 'Mot prononcé', [['pop', 'Couleur + zoom'], ['word', 'Couleur'], ['none', 'Aucun']]) + '</div>' +
      looks('sub_') + applyAll('sub_');
  }

  /* ---------- Cadrage ---------- */
  function paneFrame(pane, m) {
    const f = m.frame;
    pane.innerHTML = '<div class="group">' + seg('f_mode', 'Format', [['fill', 'Plein écran 9:16'], ['blur', 'Vidéo entière + fond flou']]) +
      '<div class="field"><label for="fFx">Position horizontale<output id="oFx"></output></label><input type="range" id="fFx" min="0" max="1" step=".01"></div>' +
      '<div class="field"><label for="fFy">Position verticale<output id="oFy"></output></label><input type="range" id="fFy" min="0" max="1" step=".01"></div>' +
      '<div class="field"><label for="fZoom">Zoom<output id="oZoom"></output></label><input type="range" id="fZoom" min="1" max="2.5" step=".05"></div>' +
      '<label class="check"><input type="checkbox" id="fPunch"> Petit zoom d\'entrée (rendu final)</label>' +
      '</div><div class="group"><span class="label">Recadrage automatique</span><p class="hint" style="margin:0">OMAGAD repère ton visage et déplace le cadre pour te garder au centre, même quand tu bouges.</p>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><button class="btn small primary" type="button" id="fAuto">' + (f.auto && f.keys ? 'Relancer le suivi' : 'Suivre le sujet') + '</button>' +
      (f.auto && f.keys ? '<button class="btn small ghost" type="button" id="fAutoOff">Désactiver</button><span class="badge ok">Actif</span>' : '') + '<span class="hint" id="fAutoMsg"></span></div>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small" type="button" id="fAutoAll">Suivre le sujet sur tous les moments</button><button class="btn small ghost" type="button" id="fReset">Recentrer</button></div></div>' +
      '<div class="group"><span class="label">Zooms aléatoires sur les cuts</span><p class="hint" style="margin:0">Zoom et dézoom à chaque changement de phrase, comme des coupes de montage.</p>' +
      '<label class="check"><input type="checkbox" id="zOn"> Activer</label>' +
      '<div class="seg" id="zMode"><button type="button" data-v="cut">Coupe sèche</button><button type="button" data-v="smooth">Transition douce</button></div>' +
      '<div class="cols2"><div class="field"><label for="zMax">Zoom maximum<output id="oZMax"></output></label><input type="range" id="zMax" min="1.05" max="1.6" step=".01"></div>' +
      '<div class="field"><label for="zEvery">Un cut toutes les<output id="oZEvery"></output></label><input type="range" id="zEvery" min="1.2" max="8" step=".1"></div></div>' +
      '<label class="check"><input type="checkbox" id="zAlt"> Alterner zoom et plan large</label>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small" type="button" id="zShuffle">Mélanger</button><button class="btn small ghost" type="button" id="zAll">Appliquer à tous les moments</button><span class="hint" id="zCount"></span></div></div>' +
      '<div class="group"><span class="label">Découpe</span><div class="cols2"><div class="field"><span class="flabel">Début</span><div style="display:flex;gap:4px;align-items:center"><span class="mono" id="vT0"></span></div></div>' +
      '<div class="field"><span class="flabel">Fin</span><span class="mono" id="vT1"></span></div></div>' +
      '<p class="hint" style="margin:0">Tire les bords du moment sur la timeline, ou utilise les touches I (début) et O (fin) à la position de lecture.</p></div>';
    const sync = () => {
      $('#fFx').value = f.fx; $('#fFy').value = f.fy; $('#fZoom').value = f.zoom; $('#fPunch').checked = f.punch !== false;
      $('#oFx').textContent = Math.round(f.fx * 100) + ' %'; $('#oFy').textContent = Math.round(f.fy * 100) + ' %'; $('#oZoom').textContent = (+f.zoom).toFixed(2) + 'x';
      $('#vT0').textContent = fmt(m.t0, true); $('#vT1').textContent = fmt(m.t1, true) + '  (' + Math.round(m.t1 - m.t0) + ' s)';
    };
    sync();
    [['fFx', 'fx'], ['fFy', 'fy'], ['fZoom', 'zoom']].forEach(([id, k]) => { $('#' + id).oninput = e => { f[k] = parseFloat(e.target.value); sync(); VC.layoutVideo(); VC.commit(); }; });
    $('#fPunch').onchange = e => { f.punch = e.target.checked; VC.commit(); };
    $('#fReset').onclick = () => { Object.assign(f, { fx: .5, fy: .5, zoom: 1, auto: false }); sync(); VC.layoutVideo(); VC.commit(true); VC.renderInspector(); };
    VC.syncFrameTimes = sync;
    const off = $('#fAutoOff'); if (off) off.onclick = () => { f.auto = false; VC.commit(true); VC.layoutVideo(); VC.renderInspector(); };
    $('#fAuto').onclick = async () => {
      const b = $('#fAuto'); b.disabled = true; $('#fAutoMsg').textContent = 'Analyse du moment...';
      try {
        const r = await VC.api('/api/autocrop', { pid: VC.S.project.id, mid: m.id, t0: m.t0, t1: m.t1, zoom: f.zoom || 1 });
        const j = await VC.poll(r.job, j => { const el = $('#fAutoMsg'); if (el) el.textContent = 'Analyse... ' + Math.round(j.progress * 100) + ' %'; });
        if (j.error) throw new Error(j.error);
        f.keys = j.result.keys; f.auto = true; f.mode = 'fill'; VC.commit(true); VC.layoutVideo(); VC.renderInspector();
        VC.toast('Recadrage automatique appliqué', 2500);
      } catch (e) { const el = $('#fAutoMsg'); if (el) el.textContent = e.message; b.disabled = false; }
    };
    if (f.auto && f.keys) { $('#fFx').disabled = true; $('#oFx').textContent = 'auto'; }
    $('#fAutoAll').onclick = () => VC.autocropAll();
    const zc = f.zcfg = Object.assign({ on: false, mode: 'cut', max: 1.25, every: 3, alternate: false, seed: 7 }, f.zcfg || {});
    const zsync = () => {
      $('#zOn').checked = zc.on; $('#zMax').value = zc.max; $('#zEvery').value = zc.every; $('#zAlt').checked = !!zc.alternate;
      $('#oZMax').textContent = 'x' + (+zc.max).toFixed(2); $('#oZEvery').textContent = (+zc.every).toFixed(1) + ' s';
      $$('#zMode button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === zc.mode)));
      $('#zCount').textContent = zc.on && f.zooms ? (f.zooms.length - 1) + ' cuts' : '';
    };
    const regen = (now) => { if (zc.on) f.zooms = VC.makeZooms(m, zc); zsync(); VC.layoutVideo(); VC.drawTimeline(); VC.commit(now); };
    zsync();
    $('#zOn').onchange = e => { zc.on = e.target.checked; regen(true); if (zc.on) replayHook(m); };
    $('#zMax').oninput = e => { zc.max = +e.target.value; regen(); };
    $('#zEvery').oninput = e => { zc.every = +e.target.value; regen(); };
    $('#zAlt').onchange = e => { zc.alternate = e.target.checked; regen(true); };
    $('#zMode').onclick = e => { const b = e.target.closest('button'); if (b) { zc.mode = b.dataset.v; regen(true); } };
    $('#zShuffle').onclick = () => { zc.seed = Math.floor(Math.random() * 1e6) + 1; zc.on = true; regen(true); replayHook(m); };
    $('#zAll').onclick = () => {
      for (const x of VC.S.project.moments) { x.frame = x.frame || { mode: 'fill', fx: .5, fy: .5, zoom: 1, punch: true }; x.frame.zcfg = Object.assign({}, zc, { seed: Math.floor(Math.random() * 1e6) + 1 }); x.frame.zooms = zc.on ? VC.makeZooms(x, x.frame.zcfg) : null; }
      VC.commit(true); VC.drawTimeline(); VC.toast('Zooms appliqués à tous les moments');
    };
  }

  /* Recadrage automatique de tous les moments, l'un après l'autre */
  let cropping = false;
  VC.autocropAll = async function () {
    if (cropping) return;
    const p = VC.S.project, list = p.moments.filter(x => x.status !== 'skip');
    if (!list.length) return;
    cropping = true; let ok = 0;
    for (let i = 0; i < list.length; i++) {
      const x = list[i]; const el = $('#fAutoMsg');
      if (el) el.textContent = 'Moment ' + (i + 1) + ' / ' + list.length + '…';
      try {
        x.frame = x.frame || { mode: 'fill', fx: .5, fy: .5, zoom: 1, punch: true };
        const r = await VC.api('/api/autocrop', { pid: p.id, mid: x.id, t0: x.t0, t1: x.t1, zoom: x.frame.zoom || 1 });
        const j = await VC.poll(r.job, () => {});
        if (!j.error && j.result) { x.frame.keys = j.result.keys; x.frame.auto = true; x.frame.mode = 'fill'; ok++; }
      } catch (e) { /* moment suivant */ }
    }
    cropping = false;
    VC.commit(true); VC.layoutVideo(); VC.renderInspector();
    VC.toast('Recadrage automatique : ' + ok + ' / ' + list.length + ' moments', 3000);
  };

  /* ---------- Publication ---------- */
  function panePub(pane, m) {
    const text = VC.S.project.lines.filter(l => l.e > m.t0 && l.s < m.t1).map(l => l.text).join(' ');
    pane.innerHTML = '<div class="group"><div class="field"><label for="cap">Description à publier</label><textarea id="cap" placeholder="Texte + hashtags pour TikTok, Reels et Shorts">' + esc(m.caption) + '</textarea></div>' +
      '<div style="display:flex;gap:6px"><button class="btn small" type="button" id="btnCopy">Copier</button><span class="hint" style="align-self:center">Elle est aussi enregistrée en .txt à côté du clip à l\'export.</span></div></div>' +
      (m.reason ? '<div class="group"><span class="label">Pourquoi ce moment</span><div class="hint">' + esc(m.reason) + '</div></div>' : '') +
      '<div class="group"><span class="label">Ce qui est dit</span><div class="excerpt">' + esc(text || '(pas de parole)') + '</div></div>' +
      '<div class="group"><button class="btn small danger" type="button" id="btnDel">Supprimer ce moment</button></div>';
    $('#cap').oninput = e => { m.caption = e.target.value; VC.commit(); };
    $('#btnCopy').onclick = () => navigator.clipboard.writeText($('#cap').value).then(() => VC.toast('Description copiée'), () => { $('#cap').select(); VC.toast('Sélectionnée : Cmd+C pour copier'); });
    $('#btnDel').onclick = () => {
      const ms = VC.S.project.moments, i = ms.indexOf(m); ms.splice(i, 1);
      VC.S.sel = (ms[i] || ms[i - 1] || {}).id || null; VC.commit(true); VC.toast('Moment supprimé (Cmd+Z pour annuler)'); VC.refresh();
    };
  }
})();
