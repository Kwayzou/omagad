/* Langue de l'interface : français (texte d'origine) ou anglais.
   L'interface est écrite en français ; en anglais, chaque texte affiché est traduit à la volée. */
(function () {
  const EN = {
    // Général / barre du haut
    'Import': 'Import', 'Montage': 'Edit', 'Export': 'Export',
    'Annuler': 'Cancel', 'Annuler (Cmd+Z)': 'Undo (Cmd+Z)', 'Rétablir': 'Redo', 'Rétablir (Cmd+Maj+Z)': 'Redo (Cmd+Shift+Z)',
    'Compte': 'Account', 'Mon compte': 'My account', 'Mon profil': 'My profile',
    'Réglages': 'Settings', 'Réglages enregistrés': 'Settings saved', 'Enregistrer': 'Save', 'Fermer': 'Close',
    'Confirmer': 'Confirm', 'Choisir': 'Choose', 'Copier': 'Copy', 'Supprimer': 'Delete', 'Appliquer': 'Apply',
    'Activer': 'Enable', 'Désactiver': 'Disable', 'Actif': 'On', 'Aucun': 'None', 'Aucune': 'None', 'Tous': 'All',
    'Erreur': 'Error', 'Réessayer': 'Retry', 'Relancer': 'Restart', 'Retour': 'Back', 'Revenir': 'Revert', 'Plus': 'More',
    'Terminé': 'Done', 'Prêt': 'Ready', 'En attente': 'Waiting', 'Inachevé': 'Unfinished', 'Préparation': 'Preparing',
    'Démarrage...': 'Starting...', 'Analyse...': 'Analyzing...', 'Analyse en cours': 'Analyzing', 'Rendu...': 'Rendering...',
    'Afficher dans le Finder': 'Show in Finder', 'Ouvrir le dossier': 'Open folder', 'Clip': 'Clip',
    'Glisser pour redimensionner, double-clic pour réduire': 'Drag to resize, double-click to collapse',
    'Réduire': 'Collapse', 'Afficher les moments': 'Show moments', 'Afficher les réglages': 'Show settings',
    'Bienvenue ! Crée ton compte en cliquant sur l\'icône en haut à droite.': 'Welcome! Create your account by clicking the icon at the top right.',
    'à l\'instant': 'just now',
    // Réglages
    'Clé API Anthropic': 'Anthropic API key', 'Modèle Claude': 'Claude model', 'Langue parlée': 'Spoken language',
    'Langue de l\'interface': 'Interface language',
    'Français': 'French', 'Anglais': 'English', 'Détection auto': 'Auto-detect',
    'Nombre de clips visés': 'Target number of clips', 'Automatique (≈ 18 pour 30 min)': 'Automatic (≈ 18 per 30 min)',
    'Durée des clips': 'Clip length', 'Courts (15 à 30 s)': 'Short (15 to 30 s)', 'Moyens (20 à 60 s)': 'Medium (20 to 60 s)', 'Longs (30 à 90 s)': 'Long (30 to 90 s)',
    'Précision de la transcription': 'Transcription accuracy', 'Rapide': 'Fast', 'Équilibrée (conseillé)': 'Balanced (recommended)',
    'Précise (plus lent)': 'Accurate (slower)', 'Maximale (très lent)': 'Maximum (very slow)',
    'Polices': 'Fonts', 'Ouvrir le dossier des polices': 'Open fonts folder',
    'Pour utiliser une police perso, dépose un fichier .ttf ou .otf dans le dossier des polices, puis relance l\'application.': 'To use a custom font, drop a .ttf or .otf file into the fonts folder, then restart the app.',
    'Sans clé, les moments sont choisis automatiquement mais les accroches seront moins bonnes.': 'Without a key, moments are picked automatically but hooks will be weaker.',
    'Raccourcis clavier': 'Keyboard shortcuts', 'Annuler la dernière action': 'Undo', 'Raccourcis clavier…': 'Keyboard Shortcuts…',
    // Compte
    'Crée ton compte': 'Create your account', 'Créer mon compte': 'Create my account', 'Compte créé': 'Account created', 'Profil enregistré': 'Profile saved',
    'Ton profil sert à personnaliser OMAGAD : nom d\'artiste et hashtags ajoutés automatiquement aux descriptions écrites par Claude.': 'Your profile personalizes OMAGAD: artist name and hashtags are automatically added to the descriptions Claude writes.',
    'Ton nom d\'artiste et tes hashtags seront ajoutés automatiquement aux descriptions de tes clips.': 'Your artist name and hashtags will be added automatically to your clip descriptions.',
    'Choisir une photo': 'Choose a photo', 'Prénom': 'First name', 'Nom d\'artiste': 'Artist name', 'Ex. Piazza': 'e.g. Piazza',
    'toi@exemple.com': 'you@example.com', '@compte': '@account', '@chaine': '@channel', 'Hashtags': 'Hashtags',
    'Hashtags ajoutés aux descriptions': 'Hashtags added to descriptions', 'Réseaux': 'Socials',
    'Le compte est enregistré sur ce Mac uniquement.': 'The account is stored on this Mac only.',
    'Indique au moins ton prénom ou ton nom d\'artiste.': 'Enter at least your first name or artist name.',
    'Cette adresse email ne semble pas valide.': 'This email address doesn\'t look valid.',
    // Mise à jour
    'À jour': 'Up to date', 'Mise à jour': 'Update', 'Mise à jour disponible': 'Update available', 'Mettre à jour': 'Update',
    'Plus tard': 'Later', 'Vérifier à nouveau': 'Check again', 'Vérifiée': 'Checked', 'Actuelle': 'Current', 'Dernière': 'Latest',
    'Nouveautés': 'What\'s new', 'Installer un fichier…': 'Install a file…', 'OMAGAD est à jour': 'OMAGAD is up to date',
    'Aucune note pour cette version.': 'No notes for this version.', 'Installation de la mise à jour…': 'Installing update…',
    'Redémarrage d\'OMAGAD…': 'Restarting OMAGAD…', 'Revenir à la version d\'origine': 'Revert to original version',
    'Revenir à la version d\'origine ?': 'Revert to the original version?',
    'Les mises à jour installées seront retirées. Tes projets ne sont pas touchés.': 'Installed updates will be removed. Your projects are not affected.',
    'Quand je t\'envoie une mise à jour, télécharge-la : elle apparaîtra ici.': 'When you receive an update, download it: it will show up here.',
    'Une nouvelle version d\'OMAGAD a été trouvée dans tes Téléchargements.': 'A new version of OMAGAD was found in your Downloads.',
    'Installée : ferme et rouvre OMAGAD.': 'Installed: quit and reopen OMAGAD.',
    // Import
    'Dépose ton vlog': 'Drop your vlog', 'Importer une vidéo': 'Import a video', 'Choisir une vidéo': 'Choose a video',
    'MP4, MOV, MKV... La vidéo reste sur ton Mac.': 'MP4, MOV, MKV... The video stays on your Mac.',
    'L\'application transcrit ce que tu dis, repère les meilleurs moments et prépare un clip vertical pour chacun, avec son accroche. Tu n\'as plus qu\'à vérifier.': 'The app transcribes what you say, finds the best moments and prepares a vertical clip for each one, with its hook. All you have to do is review.',
    'Projets récents': 'Recent projects', 'Import en cours...': 'Importing...', 'Copie du fichier dans l\'application...': 'Copying file into the app...',
    'Transcription': 'Transcription', 'Moments forts': 'Highlights', 'Recherche des moments...': 'Finding moments...',
    'Tu peux laisser l\'application tourner : la transcription d\'un vlog de 30 minutes prend en général 5 à 15 minutes. Au tout premier lancement, le modèle de transcription se télécharge.': 'You can leave the app running: transcribing a 30-minute vlog usually takes 5 to 15 minutes. On the very first run, the transcription model is downloaded.',
    'Supprimer ce projet ?': 'Delete this project?',
    'Les moments et la transcription seront effacés. Ta vidéo d\'origine et les clips exportés ne sont pas touchés.': 'Moments and transcript will be erased. Your original video and exported clips are not affected.',
    'Claude connecté': 'Claude connected', 'Sans clé API': 'No API key', 'Clé API à ajouter': 'API key needed',
    'ffmpeg incomplet (voir Export)': 'ffmpeg incomplete (see Export)', 'Vlog': 'Vlog',
    // Statuts du serveur
    'Claude cherche les moments forts et écrit les accroches...': 'Claude is finding highlights and writing hooks...',
    'Recherche automatique des moments...': 'Finding moments automatically...', 'Lecture du fichier vidéo...': 'Reading video file...',
    'Extraction du son...': 'Extracting audio...', 'Finalisation de l\'aperçu vidéo...': 'Finalizing video preview...',
    'Chargement du modèle Whisper (téléchargement la première fois)...': 'Loading Whisper model (downloaded the first time)...',
    'Transcription de la parole...': 'Transcribing speech...', 'Recherche du sujet...': 'Finding the subject...', 'Recadrage prêt': 'Reframing ready',
    'Démarrage de l\'installation...': 'Starting installation...', 'ffmpeg complet installé.': 'Full ffmpeg installed.', 'Export annulé.': 'Export cancelled.',
    'Aucun sujet trouvé.': 'No subject found.', 'Analyse du moment...': 'Analyzing moment...', 'Claude réfléchit...': 'Claude is thinking...',
    'Clé API Anthropic manquante. Ajoute-la dans les réglages.': 'Anthropic API key missing. Add it in Settings.',
    'Réponse de Claude illisible. Réessaie, ou choisis un autre modèle dans les Réglages.': 'Unreadable answer from Claude. Try again, or pick another model in Settings.',
    'Cette vidéo n\'a pas de son : impossible de trouver les moments forts.': 'This video has no audio: highlights can\'t be found.',
    // Montage : liste
    'Moments': 'Moments', 'Validé': 'Approved', 'Validés': 'Approved', 'Écarté': 'Skipped', 'À vérifier': 'To review',
    'Aucun moment.': 'No moments.', 'Aucun moment dans ce filtre.': 'No moments in this filter.',
    'Aucun moment. Place la lecture sur la timeline et clique sur « + Moment ici ».': 'No moments. Move the playhead on the timeline and click “+ Moment here”.',
    'Tous les moments sont vérifiés. Passe à l\'export !': 'All moments are reviewed. On to export!',
    'Rechercher à nouveau': 'Search again', 'Chercher de nouveaux moments ?': 'Find new moments?',
    'Les moments actuels seront remplacés. Tu pourras revenir en arrière avec Annuler.': 'Current moments will be replaced. You can go back with Undo.',
    'Sélectionne un moment dans la liste ou sur la timeline.': 'Select a moment in the list or on the timeline.',
    'Sélectionne d\'abord un moment.': 'Select a moment first.', '(sans accroche)': '(no hook)',
    'Valider le moment': 'Approve moment', '✓ Valider': '✓ Approve', 'Écarter': 'Skip', 'Écarter le moment': 'Skip moment',
    'Supprimer ce moment': 'Delete this moment', 'Moment supprimé (Cmd+Z pour annuler)': 'Moment deleted (Cmd+Z to undo)',
    'Supprimé (Cmd+Z pour annuler)': 'Deleted (Cmd+Z to undo)', 'Moment ajouté : écris son accroche à droite.': 'Moment added: write its hook on the right.',
    'Moment coupé en deux clips': 'Moment split into two clips', 'Coupe trop près du bord du moment.': 'Cut too close to the edge of the moment.',
    'Moment précédent': 'Previous moment', 'Moment suivant': 'Next moment', 'Moment précédent (↑)': 'Previous moment (↑)', 'Moment suivant (↓)': 'Next moment (↓)',
    'Pourquoi ce moment': 'Why this moment', 'Ce qui est dit': 'What is said', 'Aucune parole détectée dans ce moment.': 'No speech detected in this moment.',
    'Revoir depuis le début': 'Replay from start', 'Rejouer': 'Replay', 'Lecture': 'Playback', 'Lecture (Espace)': 'Play (Space)',
    'Zones cachées par TikTok': 'Areas hidden by TikTok', 'Plein écran 9:16': 'Full screen 9:16',
    // Timeline
    'Timeline': 'Timeline', 'Vidéo': 'Video', 'Accroche': 'Hook', 'Sous-titres': 'Subtitles', 'Sons': 'Sounds', 'Médias': 'Media', 'Photo': 'Photo',
    '+ Moment ici': '+ Moment here', 'Zoom de la timeline': 'Timeline zoom', 'Zoomer': 'Zoom in', 'Dézoomer': 'Zoom out',
    'Zoomer (+)': 'Zoom in (+)', 'Dézoomer (-)': 'Zoom out (-)', 'Voir tout le moment': 'Fit moment', 'Voir tout le vlog': 'Fit whole vlog',
    'Suivre la lecture': 'Follow playback', 'Réduire ou agrandir la timeline': 'Collapse or expand the timeline',
    'Glisser pour agrandir la timeline': 'Drag to enlarge the timeline', 'Sélection (A)': 'Select (A)',
    'Lame : cliquer pour couper (B)': 'Blade: click to cut (B)', 'Main : déplacer la vue (H)': 'Hand: move the view (H)',
    'La lame coupe les moments, les sous-titres et les médias.': 'The blade cuts moments, subtitles and media.',
    'Créer un moment à la position de lecture (A)': 'Create a moment at the playhead (A)',
    'Début': 'Start', 'Fin': 'End', 'Durée': 'Duration', 'Durée totale': 'Total duration',
    // Inspecteur
    'Post': 'Post', 'Cadrage': 'Framing', 'Texte accrocheur': 'Hook text', 'Entrée = retour à la ligne': 'Enter = new line',
    'Ex. Koh Lanta x GTA 6 ça va être fort': 'e.g. This set is going to be insane',
    'Autres idées avec Claude': 'More ideas with Claude', 'Choix et accroches': 'Picks and hooks',
    'Ajoute une clé API Anthropic dans les Réglages pour avoir des idées d\'accroche.': 'Add an Anthropic API key in Settings to get hook ideas.',
    'Écris d\'abord l\'accroche.': 'Write the hook first.', 'Position dans le moment': 'Position in the moment',
    'Durée totale à l\'écran': 'Total time on screen', 'Police': 'Font', 'Taille': 'Size', 'Couleur': 'Color', 'Gras': 'Bold',
    'Italique': 'Italic', 'Majuscules': 'Uppercase', 'Contour': 'Outline', 'Épaisseur du contour': 'Outline thickness',
    'Espacement des lettres': 'Letter spacing', 'Interligne': 'Line height', 'Position verticale': 'Vertical position',
    'Position horizontale': 'Horizontal position', 'Mot fort': 'Key word', 'Mot mis en couleur': 'Highlighted word', 'Mot prononcé': 'Spoken word',
    'Lueur': 'Glow', 'Activer la lueur': 'Enable glow', 'Extérieure': 'Outer', 'Intérieure': 'Inner', 'Les deux': 'Both',
    'Opacité': 'Opacity', 'Ombre portée': 'Drop shadow', 'Activer l\'ombre': 'Enable shadow', 'Distance': 'Distance',
    'Encadré': 'Box', 'Texte dans un encadré': 'Text in a box', 'Couleur de l\'encadré': 'Box color',
    'Ajouter une police (.ttf, .otf)': 'Add a font (.ttf, .otf)',
    'Animation': 'Animation', 'Entrée': 'In', 'Sortie': 'Out', 'Entrée de l\'accroche': 'Hook entrance', 'Sortie de l\'accroche': 'Hook exit',
    'Durée de l\'entrée': 'Entrance duration', 'Durée de la sortie': 'Exit duration', 'Courbe d\'entrée': 'Entrance curve', 'Courbe de sortie': 'Exit curve',
    'Dérive pendant l\'affichage': 'Drift while on screen', 'Secousse à l\'arrivée': 'Shake on arrival', 'Apparition mot à mot': 'Word-by-word reveal',
    'Personnalisée': 'Custom', 'Décalage horizontal': 'Horizontal offset', 'Décalage vertical': 'Vertical offset', 'Rotation': 'Rotation', 'Zoom': 'Zoom',
    'Constante': 'Linear', 'Rapide puis douce': 'Fast then smooth', 'Douce puis rapide': 'Smooth then fast', 'Douce aux deux bouts': 'Smooth at both ends',
    'Dépasse et revient': 'Overshoot', 'Recule puis part': 'Anticipate', 'Rebond': 'Bounce', 'Élastique': 'Elastic',
    'Glisse de la gauche': 'Slide from left', 'Glisse de la droite': 'Slide from right', 'Part à gauche': 'Exit left', 'Part à droite': 'Exit right',
    'Monte': 'Rise', 'Descend': 'Drop', 'Fondu': 'Fade', 'Pop': 'Pop', 'Pop inversé': 'Reverse pop', 'Grossit en fondu': 'Grow and fade',
    'Rétrécit': 'Shrink', 'Coupe sèche': 'Hard cut', 'Transition douce': 'Smooth transition', 'Impact (zoom arrière)': 'Impact (zoom out)',
    'Haut-bas': 'Up-down', 'Gauche-droite': 'Left-right', 'Couleur + zoom': 'Color + zoom', 'Légère': 'Light', 'Moyenne': 'Medium', 'Haute': 'High',
    'Appliquer à tous les moments': 'Apply to all moments', 'Appliquer ce style à tous les moments ?': 'Apply this style to all moments?',
    'Style appliqué à tous les moments': 'Style applied to all moments', 'Par défaut pour les prochains vlogs': 'Default for next vlogs',
    'Enregistré comme style par défaut': 'Saved as default style', 'Bibliothèque': 'Library',
    // Sous-titres
    'Texte des sous-titres': 'Subtitle text', 'Mots par ligne': 'Words per line', 'Animation des sous-titres': 'Subtitle animation',
    'Apparition de chaque ligne': 'Line entrance', 'Afficher les sous-titres': 'Show subtitles', 'Parole mot par mot': 'Speech word by word',
    'Revenir à la transcription': 'Back to transcript', 'Depuis la transcription': 'From transcript', 'Supprimer cette ligne': 'Delete this line',
    'Changer le nombre de mots refait le découpage depuis la transcription.': 'Changing the number of words re-splits from the transcript.',
    'Corrige un mot directement dans la ligne. Clique sur l\'heure pour y aller.': 'Fix a word directly in the line. Click the time to jump there.',
    // Sons
    'Sons de ce clip': 'Sounds in this clip', 'Sons par défaut des nouveaux clips': 'Default sounds for new clips', '+ Son à la tête de lecture': '+ Sound at playhead',
    'Importer un son': 'Import a sound', 'Dossier des sons': 'Sounds folder', 'Écouter': 'Listen', 'Volume': 'Volume', 'Volume :': 'Volume:',
    'Son ajouté à la bibliothèque': 'Sound added to library', 'Sons copiés sur tous les moments': 'Sounds copied to all moments',
    'Copier ces sons sur tous les moments': 'Copy these sounds to all moments', 'Copier ces sons sur tous les moments ?': 'Copy these sounds to all moments?',
    'Chaque moment recevra les mêmes sons, placés par rapport à son accroche.': 'Every moment will get the same sounds, placed relative to its hook.',
    'Suit l\'entrée de l\'accroche': 'Follows hook entrance', 'Suit la sortie de l\'accroche': 'Follows hook exit',
    'Aucun son. Ajoute-en un, ou clique sur + dans la piste Sons de la timeline.': 'No sounds. Add one, or click + in the Sounds track of the timeline.',
    'Utilisés quand tu n\'as pas modifié les sons d\'un clip. « Par défaut pour les prochains vlogs » les enregistre.': 'Used when you haven\'t changed a clip\'s sounds. “Default for next vlogs” saves them.',
    'Sur la timeline : fais glisser un son pour le déplacer (Alt pour un réglage fin, ⌥← / ⌥→ pour 10 ms), tire la ligne blanche pour le volume. Un son peut commencer avant le début du clip. Suppr pour l\'effacer.': 'On the timeline: drag a sound to move it (Alt for fine control, ⌥← / ⌥→ for 10 ms), drag the white line for volume. A sound can start before the clip begins. Delete to remove it.',
    'Type': 'Type', 'À': 'At', 'À tous les moments': 'To all moments', 'Tout le vlog': 'Whole vlog', 'Ce moment': 'This moment', 'clique pour choisir': 'click to choose', 'Alterner zoom et plan large': 'Alternate zoom and wide shot',
    'Ex. Koh Lanta x GTA 6\nça va être fort': 'e.g. This set\nis going to be insane', 'Mélanger': 'Shuffle', 'Swipe (sortie)': 'Swipe (exit)', 'Boom ciné': 'Cinematic boom', 'Montée': 'Riser', 'Clic': 'Click',
    // Médias
    'Photos et vidéos': 'Photos and videos', '+ Importer à la tête de lecture': '+ Import at playhead', 'Ajouter à la tête de lecture': 'Add at playhead',
    'Média ajouté': 'Media added', 'Vidéo (sans son)': 'Video (muted)', 'Vidéo et son': 'Video and sound',
    'Aucun média. Importe une photo ou une vidéo : elle s\'affichera par-dessus ton vlog à la tête de lecture.': 'No media. Import a photo or video: it will appear over your vlog at the playhead.',
    'Sur la timeline, piste Médias : glisse pour déplacer, tire les bords pour changer quand ça arrive et quand ça part.': 'On the timeline, Media track: drag to move, drag the edges to change when it appears and disappears.',
    // Cadrage
    'Recadrage automatique': 'Auto reframe', 'Recadrage automatique appliqué': 'Auto reframe applied', 'Suivre le sujet': 'Track subject',
    'Relancer le suivi': 'Re-run tracking', 'Recentrer': 'Recenter', 'Vidéo entière + fond flou': 'Whole video + blurred background',
    'OMAGAD repère ton visage et déplace le cadre pour te garder au centre, même quand tu bouges.': 'OMAGAD finds your face and moves the frame to keep you centered, even when you move.',
    'Petit zoom d\'entrée (rendu final)': 'Small intro zoom (final render)', 'Zooms aléatoires sur les cuts': 'Random zooms on cuts',
    'Zoom et dézoom à chaque changement de phrase, comme des coupes de montage.': 'Zoom in and out on each sentence change, like edit cuts.',
    'Zoom maximum': 'Maximum zoom', 'Zoom avant': 'Zoom in', 'Un cut toutes les': 'A cut every', 'Zooms appliqués à tous les moments': 'Zooms applied to all moments',
    'Découpe': 'Trim', 'Début du moment ici': 'Moment start here', 'Fin du moment ici': 'Moment end here',
    'Tire les bords du moment sur la timeline, ou utilise les touches I (début) et O (fin) à la position de lecture.': 'Drag the moment edges on the timeline, or use I (start) and O (end) at the playhead.',
    // Post
    'Description à publier': 'Description to post', 'Texte + hashtags pour TikTok, Reels et Shorts': 'Text + hashtags for TikTok, Reels and Shorts',
    'Description copiée': 'Description copied', 'Sélectionnée : Cmd+C pour copier': 'Selected: Cmd+C to copy',
    'Enregistrer la description en .txt': 'Save description as .txt', 'Elle est aussi enregistrée en .txt à côté du clip à l\'export.': 'It is also saved as a .txt next to the clip on export.',
    // Export
    'Clips à exporter': 'Clips to export', 'Exporter': 'Export', 'Annuler l\'export': 'Cancel export', 'Dossier de sortie': 'Output folder',
    'Qualité': 'Quality', 'Résolution': 'Resolution', 'Encodage': 'Encoding', 'Puce du Mac (rapide)': 'Mac chip (fast)',
    'Processeur (compatible partout)': 'CPU (works everywhere)', 'Volume normalisé pour les réseaux': 'Loudness normalized for socials',
    'Retour au montage': 'Back to editing', 'Un composant manque pour l\'export': 'A component is missing for export',
    'Le ffmpeg installé sur ton Mac est une version allégée qui ne sait pas incruster l\'accroche et les sous-titres.': 'The ffmpeg installed on your Mac is a slim version that can\'t burn in the hook and subtitles.',
    'OMAGAD peut installer la version complète (ffmpeg-full) : 5 à 15 minutes, une seule fois.': 'OMAGAD can install the full version (ffmpeg-full): 5 to 15 minutes, only once.',
    'Installer ffmpeg complet': 'Install full ffmpeg', 'Déjà installé ? Vérifier': 'Already installed? Check', 'Installation en cours...': 'Installing...',
    'Homebrew est introuvable. Dans le Terminal :': 'Homebrew not found. In Terminal:', 'Toujours la version allégée de ffmpeg.': 'Still the slim version of ffmpeg.',
    'ffmpeg complet installé : tu peux exporter.': 'Full ffmpeg installed: you can export.', 'ffmpeg complet trouvé : tu peux exporter.': 'Full ffmpeg found: you can export.',
    'ffmpeg est introuvable. Installe-le avec Homebrew : brew install ffmpeg': 'ffmpeg not found. Install it with Homebrew: brew install ffmpeg',
    // Messages « fonctionne dans l'application »
    'L\'ajout de police fonctionne dans l\'application OMAGAD.': 'Adding fonts works in the OMAGAD app.',
    'L\'import de photos et vidéos fonctionne dans l\'application OMAGAD.': 'Importing photos and videos works in the OMAGAD app.',
    'L\'import de son fonctionne dans l\'application OMAGAD.': 'Importing sounds works in the OMAGAD app.',
    'Le choix de fichier fonctionne dans l\'application OMAGAD.': 'File picking works in the OMAGAD app.',
    'Le choix de photo fonctionne dans l\'application OMAGAD.': 'Photo picking works in the OMAGAD app.',
    'Copie impossible.': 'Copy failed.',
    'Réglages de rendu': 'Render Settings',
    'Personnalisé': 'Custom',
    'Aperçu rapide': 'Quick draft',
    'Emplacement': 'Location',
    'Parcourir': 'Browse',
    'Format': 'Format',
    'Codec': 'Codec',
    'Encodeur': 'Encoder',
    'Images/s': 'Frame rate',
    'Audio': 'Audio',
    'Fichier': 'File',
    'AAC · 192 kb/s · 48 kHz': 'AAC · 192 kb/s · 48 kHz',
    '−14 LUFS, le niveau attendu par TikTok, Instagram et YouTube.': '−14 LUFS, the level TikTok, Instagram and YouTube expect.',
    'Nom des fichiers': 'File names',
    'Ajouter à la file de rendu': 'Add to Render Queue',
    'Clip précédent': 'Previous clip',
    'Clip suivant': 'Next clip',
    'File de rendu': 'Render Queue',
    'Vider': 'Clear',
    'DaVinci Resolve': 'DaVinci Resolve',
    'Les clips choisis en timeline verticale 1080 × 1920 : moments bout à bout, sons, médias, accroches en marqueurs et sous-titres en .srt.': 'Selected clips as a vertical 1080 × 1920 timeline: moments back to back, sounds, media, hooks as markers and subtitles as .srt.',
    'Exporter la timeline (.xml)': 'Export timeline (.xml)',
    'Ouvrir dans DaVinci': 'Open in DaVinci',
    'Tout rendre': 'Render All',
    'Arrêter le rendu': 'Stop render',
    'Clips': 'Clips',
    'Pas encore rendu': 'Not rendered yet',
    'Rendu…': 'Rendering…',
    'Échec': 'Failed',
    'Aucune tâche': 'No jobs',
    'Choisis tes clips en bas, puis « Ajouter à la file de rendu ». « Tout rendre » ajoute la sélection automatiquement.': 'Pick your clips below, then “Add to Render Queue”. “Render All” adds the selection automatically.',
    'Retirer': 'Remove',
    'Annulé': 'Cancelled',
    'Sélectionne au moins un clip en bas.': 'Select at least one clip below.',
    'Ouverture de DaVinci Resolve…': 'Opening DaVinci Resolve…',
    'Création de la timeline…': 'Creating timeline…',
    'Import de la timeline…': 'Importing timeline…',
    'Timeline prête': 'Timeline ready',
    'Timeline DaVinci prête': 'DaVinci timeline ready',
    'Afficher dans le Finder': 'Show in Finder',
    'Fichiers': 'Files',
    'La timeline est ouverte dans DaVinci Resolve.': 'The timeline is open in DaVinci Resolve.',
    'Timeline ouverte dans DaVinci': 'Timeline opened in DaVinci',
    'DaVinci est ouvert.': 'DaVinci is open.',
    'Espace de travail ▸ Scripts ▸ OMAGAD - Importer la timeline': 'Workspace ▸ Scripts ▸ OMAGAD - Importer la timeline',
    ': la timeline se monte toute seule.': ': the timeline builds itself.',
    'Ouvre (ou crée) un projet, puis menu': 'Open (or create) a project, then menu',
    'DaVinci Resolve n\'est pas installé sur ce Mac. Utilise « Exporter la timeline (.xml) ».': 'DaVinci Resolve isn\'t installed on this Mac. Use “Export timeline (.xml)”.',
    'DaVinci Resolve n\'est pas installé sur ce Mac.': 'DaVinci Resolve isn\'t installed on this Mac.',
    'Aucun moment à mettre dans la timeline.': 'No moments to put in the timeline.',
    'Export terminé.': 'Export finished.',
    'Finder': 'Finder',
    'Partager OMAGAD': 'Share OMAGAD',
    'Crée « OMAGAD.dmg » sur ton Bureau : la fenêtre d\'installation avec OMAGAD et le dossier Applications, à envoyer à tes amis.': 'Creates “OMAGAD.dmg” on your Desktop: the install window with OMAGAD and the Applications folder, ready to send to friends.',
    'Créer l\'installateur (.dmg)': 'Create installer (.dmg)',
    'Copie de l\'application…': 'Copying the app…',
    'Création de l\'image disque…': 'Creating disk image…',
    'Mise en page de la fenêtre…': 'Laying out the window…',
    'Compression…': 'Compressing…',
    'Installateur prêt': 'Installer ready',
    'Création de l\'installateur… (environ 1 minute)': 'Creating installer… (about 1 minute)',
    'L\'installateur se crée dans l\'application OMAGAD sur Mac.': 'The installer is created in the OMAGAD app on Mac.',
    'Transcription · puce Apple': 'Transcription · Apple chip',
    'Transcription · moteur rapide en installation': 'Transcription · installing fast engine',
    'Transcription de la parole (puce Apple)...': 'Transcribing speech (Apple chip)...',
    'Style': 'Style',
    'Choisir un style…': 'Choose a style…',
    'Aucun style enregistré': 'No saved styles',
    'À tous': 'To all',
    'Enregistrer le style de ce moment': 'Save this moment\'s style',
    'Supprimer ce style': 'Delete this style',
    'Nom du style (ex. Piazza Festival)': 'Style name (e.g. Piazza Festival)',
    'Style appliqué à tous les moments': 'Style applied to all moments',
    'Police, couleurs, animation, sons et zooms de tous les moments seront remplacés. Tu pourras annuler avec Cmd+Z.': 'Font, colors, animation, sounds and zooms of every moment will be replaced. You can undo with Cmd+Z.',
    'Les moments qui l\'utilisent gardent leur apparence.': 'Moments using it keep their look.',
    'Suivre le sujet sur tous les moments': 'Track subject on all moments',
    'Musique de fond': 'Background music',
    'Retirer la musique': 'Remove music',
    'Départ dans le morceau': 'Start point in track',
    'Baisser la musique quand je parle': 'Lower the music when I speak',
    'Niveau pendant la parole': 'Level while speaking',
    'Changer de morceau': 'Change track',
    'Même musique sur tous les moments': 'Same music on all moments',
    'Choisir une musique': 'Choose music',
    'Pose un morceau ou un extrait de set sous le clip : son volume baisse tout seul quand tu parles.': 'Put a track or a set excerpt under the clip: its volume drops automatically when you speak.',
    'Import de la musique…': 'Importing music…',
    'Même musique sur tous les moments ?': 'Same music on all moments?',
    'Chaque moment reçoit ce morceau, avec un départ différent pour ne pas entendre toujours le même passage.': 'Every moment gets this track, with a different start so you don\'t always hear the same part.',
    'Musique posée sur tous les moments': 'Music added to all moments',
    'Mode automatique': 'Auto mode',
    'Dépose un ou plusieurs vlogs : OMAGAD trouve les moments, garde les meilleurs, applique ton style et exporte tout seul. Tu retrouves les clips dans ton dossier d\'export.': 'Drop one or more vlogs: OMAGAD finds the moments, keeps the best, applies your style and exports on its own. Your clips land in your export folder.',
    'Clips exportés par vlog': 'Clips exported per vlog',
    '5 meilleurs': 'Best 5',
    '10 meilleurs': 'Best 10',
    '15 meilleurs': 'Best 15',
    '20 meilleurs': 'Best 20',
    'Tous les moments trouvés': 'All moments found',
    'Style par défaut': 'Default style',
    'Recadrage automatique sur le visage': 'Auto reframe on face',
    'File de vlogs': 'Vlog queue',
    'Tu peux continuer à travailler : tout se fait en arrière-plan.': 'You can keep working: everything runs in the background.',
    'Vider la liste': 'Clear list',
    'Auto': 'Auto',
    'Voir les clips': 'Show clips',
    'Ouvrir': 'Open',
    'Aucune vidéo trouvée.': 'No video found.',
    'Vidéo introuvable': 'Video not found',
    'Retrouver la vidéo': 'Locate video',
    'Vidéo retrouvée': 'Video located',
    'Vidéo d\'origine introuvable': 'Original video not found',
    'Elle a été déplacée ou renommée. Retrouve-la pour pouvoir exporter.': 'It was moved or renamed. Locate it to be able to export.',
    'Mises à jour automatiques (GitHub)': 'Automatic updates (GitHub)',
    'ton-compte/omagad': 'your-account/omagad',
    'Dépôt GitHub où sont publiées les versions. OMAGAD les trouve et les installe tout seul, chez toi comme chez tes amis.': 'GitHub repository where versions are published (Releases tab). OMAGAD finds and installs them by itself, for you and your friends.',
    'Téléchargement de la mise à jour…': 'Downloading update…',
    'Inclure le moteur : l\'app s\'ouvre tout de suite chez eux (fichier d\'environ 250 Mo)': 'Include the engine: the app opens right away for them (file of about 250 MB)',
    'Copie du moteur (quelques centaines de Mo)…': 'Copying the engine (a few hundred MB)…',
    'Création de l\'installateur… (1 à 3 minutes)': 'Creating installer… (1 to 3 minutes)',
    'Dépose ton vlog ici': 'Drop your vlog here',
    'Glisse une vidéo (ou plusieurs à la fois) dans cette zone. OMAGAD transcrit ce que tu dis et trouve les meilleurs moments tout seul.': 'Drag a video (or several at once) into this area. OMAGAD transcribes what you say and finds the best moments on its own.',
    'Active-le pour que les clips soient exportés directement, sans passer par le montage. Pratique pour lancer plusieurs vlogs le soir.': 'Turn it on to export clips directly, without editing. Handy for launching several vlogs in the evening.',
    'Vérifie chaque moment : accroche, sous-titres mot par mot, sons, musique, photos, cadrage. Tout se règle à droite et sur la timeline.': 'Review each moment: hook, word-by-word subtitles, sounds, music, photos, framing. Everything is set on the right and on the timeline.',
    'Rends tes clips en 1080 × 1920 pour TikTok, Reels et Shorts, ou envoie la timeline dans DaVinci Resolve.': 'Render your clips in 1080 × 1920 for TikTok, Reels and Shorts, or send the timeline to DaVinci Resolve.',
    'Mises à jour et compte': 'Updates and account',
    'Les nouvelles versions d\'OMAGAD apparaissent ici. Ton compte ajoute ton nom d\'artiste et tes hashtags aux descriptions.': 'New OMAGAD versions show up here. Your account adds your artist name and hashtags to descriptions.',
    'Astuces': 'Tips',
    '⌘/ ouvre les raccourcis clavier (tous modifiables), ⌘, les réglages. Le menu OMAGAD en haut de l\'écran permet de changer de langue et de revoir ce guide.': '⌘/ opens keyboard shortcuts (all customizable), ⌘, opens settings. The OMAGAD menu at the top of the screen lets you switch language and replay this guide.',
    'Passer': 'Skip',
    'Suivant': 'Next',
    'C\'est parti': 'Let\'s go',
    'Sons OMAGAD': 'OMAGAD sounds',
    'Sons importés': 'Imported sounds',
    'Tes sons apparaîtront ici. Importe un fichier, ou glisse-le dans la fenêtre.': 'Your sounds will appear here. Import a file, or drag it into the window.',
    'Aperçu incomplet : reconstruction en cours': 'Incomplete preview: rebuilding',
    'La vidéo d\'aperçu s\'arrêtait avant la fin du vlog. Tu peux continuer, la lecture complète revient dans un instant.': 'The preview video stopped before the end of the vlog. You can keep working, full playback will be back shortly.',
    'Aperçu réparé : tout le vlog est lisible': 'Preview repaired: the whole vlog plays',
    'Reconstruction de l\'aperçu…': 'Rebuilding preview…',
    'Aperçu prêt': 'Preview ready',
    'CLIPAGAD': 'CLIPAGAD',
    'Tes vlogs transformés en clips verticaux pour TikTok, Reels et Shorts': 'Your vlogs turned into vertical clips for TikTok, Reels and Shorts',
    'Coming soon…': 'Coming soon…',
    'Un nouveau module arrive bientôt dans OMAGAD': 'A new module is coming soon to OMAGAD',
    'Mouvement aléatoire': 'Random motion',
    'Nouveau mouvement': 'New motion',
    'Le titre flotte doucement vers le haut, le bas, la gauche et la droite pendant qu\'il est affiché.': 'The title floats gently up, down, left and right while it is on screen.',
    'Gauche ↔ droite': 'Left ↔ right',
    'Haut ↕ bas': 'Up ↕ down',
    'Vitesse': 'Speed',
    'Projet': 'Project',
    'Dossier': 'Folder',
    'Créer un dossier au nom du projet': 'Create a folder named after the project',
    'Noms': 'Names',
    '1, 2, 3…': '1, 2, 3…',
    'Projet 1, Projet 2…': 'Project 1, Project 2…',
    '1 - accroche…': '1 - hook…',
    'Nom du fichier de ce clip': 'File name of this clip',
    'Nom du projet': 'Project name',
    'Il sert aussi de nom au dossier créé à l\'export (les clips s\'appelleront 1, 2, 3…).': 'It is also used as the name of the folder created on export (clips will be named 1, 2, 3…).',
    'Analyser': 'Analyze',
    'Continuer': 'Continue',
    'Ajouter': 'Add',
    // Raccourcis
    'Général': 'General', 'Affichage': 'View', 'Rechercher une action': 'Search an action', 'Raccourci': 'Shortcut',
    'Raccourci effacé': 'Shortcut cleared', 'Raccourcis réinitialisés': 'Shortcuts reset', 'Tout réinitialiser': 'Reset all',
    'Revenir au raccourci d\'origine': 'Restore default shortcut', 'Appuie sur une touche…': 'Press a key…',
    'Clique sur un raccourci puis appuie sur les touches voulues. Échap pour annuler, ⌫ pour l\'effacer.': 'Click a shortcut then press the keys you want. Esc to cancel, ⌫ to clear it.',
    'Aller à Import': 'Go to Import', 'Aller au Montage': 'Go to Edit', 'Aller à Export': 'Go to Export',
    'Lecture / pause': 'Play / pause', 'Reculer d\'1 s': 'Back 1 s', 'Avancer d\'1 s': 'Forward 1 s', 'Reculer de 5 s': 'Back 5 s', 'Avancer de 5 s': 'Forward 5 s',
    'Image précédente': 'Previous frame', 'Image suivante': 'Next frame', 'Revoir le moment depuis le début': 'Replay moment from start',
    'Nouveau moment à la tête de lecture': 'New moment at playhead', 'Outil Sélection': 'Select tool', 'Outil Lame (couper)': 'Blade tool (cut)',
    'Outil Main (déplacer la vue)': 'Hand tool (move view)', 'Couper à la tête de lecture': 'Cut at playhead', 'Supprimer l\'élément sélectionné': 'Delete selected item',
    'Décaler l\'élément de −10 ms': 'Nudge item −10 ms', 'Décaler l\'élément de +10 ms': 'Nudge item +10 ms',
    'Décaler l\'élément de −100 ms': 'Nudge item −100 ms', 'Décaler l\'élément de +100 ms': 'Nudge item +100 ms',
    'Réduire / agrandir la timeline': 'Collapse / expand timeline', 'Réduire / agrandir la liste des moments': 'Collapse / expand moment list',
    'Réduire / agrandir les réglages': 'Collapse / expand settings panel', 'Espace': 'Space', 'Échap': 'Esc', 'ou': 'or', 'aucun': 'none',
    'Langue': 'Language', 'Interface en anglais': 'Interface in English', 'Interface en français': 'Interface in French'
  };

  const RX = [
    [/^Vue : (.+) sur (.+)$/, 'View: $1 of $2'],
    [/^(\d+) validés \/ (\d+)$/, '$1 approved / $2'],
    [/^(\d+)\/(\d+) validés$/, '$1/$2 approved'],
    [/^Exporter (\d+) clips?$/, (m, n) => 'Export ' + n + ' clip' + (n > 1 ? 's' : '')],
    [/^(\d+) clip\(s\) exporté\(s\)$/, '$1 clip(s) exported'],
    [/^(\d+) moments trouvés$/, '$1 moments found'],
    [/^(\d+) projet\(s\)$/, '$1 project(s)'],
    [/^(.+) · (\d+) moments$/, '$1 · $2 moments'],
    [/^il y a (\d+) min$/, '$1 min ago'], [/^il y a (\d+) h$/, '$1 h ago'], [/^il y a (\d+) j$/, '$1 d ago'],
    [/^Copie : (\d+) \/ (\d+) Mo$/, 'Copying: $1 / $2 MB'],
    [/^Police « (.+) » ajoutée$/, 'Font “$1” added'],
    [/^Son à (.+) s$/, 'Sound at $1 s'],
    [/^Clip (\d+) sur (\d+)$/, 'Clip $1 of $2'],
    [/^Clé enregistrée \((.+)\)\. Laisse vide pour la garder\.$/, 'Key saved ($1). Leave empty to keep it.'],
    [/^Les réglages (de l'accroche|des sous-titres|des sons) de ce moment seront copiés sur les (\d+) autres\.$/,
      (m, w, n) => 'This moment\'s ' + ({ 'de l\'accroche': 'hook', 'des sous-titres': 'subtitle', 'des sons': 'sound' }[w]) + ' settings will be copied to the ' + n + ' others.'],
    [/^(.+) (\d+) clip\(s\) dans (.*)$/, (m, a, n, rest) => tr(a) + ' ' + n + ' clip(s) in ' + rest.replace(/\. (\d+) échec\(s\) : /, '. $1 failed: ')],
    [/^ \(retiré de « (.+) »\)$/, (m, a) => ' (removed from “' + tr(a) + '”)'],
    [/^(.+) \(retiré de « (.+) »\)$/, (m, a, b) => tr(a) + ' (removed from “' + tr(b) + '”)'],
    [/^Point de départ de l'animation \(par rapport à la position normale\)$/, 'Animation start point (relative to normal position)'],
    [/^Point de arrivée de l'animation \(par rapport à la position normale\)$/, 'Animation end point (relative to normal position)'],
    [/^Sous-titre (\d+)$/, 'Subtitle $1'],
    [/^Moment · (\d+) s$/, 'Moment · $1 s'],
    [/^(.+) est disponible : clique sur « Mise à jour disponible » en haut à droite\.$/, '$1 is available: click “Update available” at the top right.'],
    [/^Erreur de l'API Anthropic \((\d+)\) : (.*)$/, 'Anthropic API error ($1): $2'],
    [/^Impossible de joindre l'API Anthropic : (.*)$/, 'Can\'t reach the Anthropic API: $1'],
    [/^Claude indisponible \((.*)\)(.*)$/, 'Claude unavailable ($1)$2'],
    [/^ffmpeg a échoué : (.*)$/, 'ffmpeg failed: $1'],
    [/^L'installation a échoué : (.*)$/, 'Installation failed: $1'],
    [/^Fichier vidéo introuvable : (.*)\. A-t-il été déplacé ou renommé \?$/, 'Video file not found: $1. Was it moved or renamed?'],
    [/^Transcription de la parole\.\.\. (.*)$/, 'Transcribing speech... $1'],
    [/^Version (.+)$/, 'Version $1'],
    [/^Tâche (\d+)$/, 'Job $1'],
    [/^Style « (.+) » (appliqué|enregistré)$/, (m, n, w) => 'Style “' + n + '” ' + (w === 'appliqué' ? 'applied' : 'saved')],
    [/^Appliquer « (.+) » à tous les moments \?$/, 'Apply “$1” to all moments?'],
    [/^Supprimer le style « (.+) » \?$/, 'Delete style “$1”?'],
    [/^Recadrage automatique : (\d+) \/ (\d+) moments$/, 'Auto reframe: $1 / $2 moments'],
    [/^Moment (\d+) \/ (\d+)…$/, 'Moment $1 / $2…'],
    [/^Recadrage (\d+) \/ (\d+)$/, 'Reframing $1 / $2'],
    [/^(\d+) vlogs? ajoutés? à la file$/, (m, n) => n + ' vlog' + (n > 1 ? 's' : '') + ' added to the queue'],
    [/^Ce n'est pas la même vidéo \(durée (.+) au lieu de (.+)\)\.$/, 'Not the same video (length $1 instead of $2).'],
    [/^Installateur prêt sur ton Bureau : (.+)$/, 'Installer ready on your Desktop: $1'],
    [/^(\d+) clips? · (.+)$/, (m, n, r) => n + ' clip' + (n > 1 ? 's' : '') + ' · ' + r],
    [/^(\d+) tâches?$/, (m, n) => n + ' job' + (n > 1 ? 's' : '')],
    [/^Tout rendre \((\d+)\)$/, 'Render All ($1)'],
    [/^Rendu… (\d+) \/ (\d+)$/, 'Rendering… $1 / $2'],
    [/^Terminé · (\d+) \/ (\d+)$/, 'Done · $1 / $2'],
    [/^Timeline créée : (\d+) clips\.$/, 'Timeline created: $1 clips.'],
    [/^(\d+) clip\(s\) ajouté\(s\) à la file de rendu$/, '$1 clip(s) added to the render queue']
  ];

  let lang = 'fr';
  function tr(s) {
    if (lang !== 'en' || !s) return s;
    const k = s.trim(); if (!k || !/[A-Za-zÀ-ÿ]/.test(k)) return s;
    let out = EN[k];
    if (out == null && /[.…]$/.test(k)) { const b = k.replace(/(\.\.\.|…|\.)$/, ''); if (EN[b] != null) out = EN[b] + k.slice(b.length); }
    if (out == null) for (const [re, rep] of RX) if (re.test(k)) { out = k.replace(re, rep); break; }
    if (out == null) return s;
    return s.replace(k, () => out);
  }
  VC.t = tr;
  VC.lang = () => lang;

  /* Traduction du DOM : on garde le texte français d'origine pour pouvoir revenir en arrière */
  const ORIG = new WeakMap(), DONE = new WeakMap(), ATTRS = ['title', 'placeholder', 'aria-label'];
  const SKIP = 'script,style,textarea,[contenteditable],.no-i18n,.hk,#ovHook,#ovSub,.proj-name,.keys-combo,kbd';
  const SKIP_ATTR = '.no-i18n,#ovHook,#ovSub';
  const skip = el => !el || (el.closest && el.closest(SKIP));
  const skipAttr = el => !el || (el.closest && el.closest(SKIP_ATTR));
  function doText(n) {
    if (skip(n.parentElement)) return;
    const cur = n.data;
    if (DONE.get(n) === cur) return;               // c'est notre propre traduction
    const fr = cur;
    ORIG.set(n, fr);
    const out = lang === 'en' ? tr(fr) : fr;
    if (out !== cur) n.data = out;
    DONE.set(n, out);
  }
  function doAttrs(el) {
    if (skipAttr(el)) return;
    let o = ORIG.get(el); if (!o) { o = {}; ORIG.set(el, o); }
    let d = DONE.get(el); if (!d) { d = {}; DONE.set(el, d); }
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      const v = el.getAttribute(a);
      if (d[a] === v) continue;
      o[a] = v;
      const out = lang === 'en' ? tr(v) : v;
      d[a] = out;
      if (out !== v) el.setAttribute(a, out);
    }
  }
  function walk(root) {
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1) return;
    doAttrs(root);
    const it = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let n; while ((n = it.nextNode())) n.nodeType === 3 ? doText(n) : doAttrs(n);
  }
  /* Revenir au français ou repasser en anglais : on repart des textes d'origine */
  function reapply() {
    const it = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let n;
    while ((n = it.nextNode())) {
      const o = ORIG.get(n);
      if (n.nodeType === 3) {
        if (o != null && DONE.get(n) === n.data) { DONE.delete(n); n.data = o; }
        doText(n);
      } else {
        if (o) for (const a in o) if (DONE.get(n) && DONE.get(n)[a] === n.getAttribute(a)) n.setAttribute(a, o[a]);
        DONE.delete(n); doAttrs(n);
      }
    }
    document.documentElement.lang = lang;
    document.title = 'OMAGAD';
  }
  let obs = null;
  function observe() {
    if (obs) return;
    obs = new MutationObserver(list => {
      for (const m of list) {
        if (m.type === 'characterData') doText(m.target);
        else if (m.type === 'attributes') doAttrs(m.target);
        else m.addedNodes.forEach(walk);
      }
    });
    obs.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  VC.setLang = function (l, save) {
    l = l === 'en' ? 'en' : 'fr';
    const changed = l !== lang;
    lang = l;
    if (changed) reapply();
    if (save) {
      VC.saveSettings && VC.saveSettings({ lang: l });
      try { window.pywebview && window.pywebview.api.set_menu_lang && window.pywebview.api.set_menu_lang(l); } catch (e) { /* hors app */ }
      VC.drawTimeline && VC.drawTimeline();
      VC.toast(l === 'en' ? 'Interface in English' : 'Interface en français', 1500);
    }
  };
  VC.initLang = function (l) {
    lang = l === 'en' ? 'en' : 'fr';
    walk(document.body); observe();
    document.documentElement.lang = lang;
  };
})();
