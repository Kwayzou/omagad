/* Compte : profil enregistré sur ce Mac (photo, nom d'artiste, email, réseaux, hashtags) + accès aux réglages. */
(function () {
  const { $, esc } = VC;
  const pop = $('#popAccount'), dlg = $('#dlgAccount');
  const PERSON = '<svg viewBox="0 0 24 24" width="20" height="20"><circle cx="12" cy="8.5" r="4" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4.5 20c1.4-3.6 4.2-5.2 7.5-5.2s6.1 1.6 7.5 5.2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
  let avatarV = Date.now(), hasAvatar = false;
  const prof = () => (VC.S.state && VC.S.state.settings.profile) || {};
  const has = () => !!(prof().created);

  function initials(p) { return ((p.artist || p.first || '?').trim()[0] || '?').toUpperCase(); }
  function paintAvatar(el, big) {
    const p = prof();
    if (hasAvatar) el.innerHTML = '<img src="/api/avatar?v=' + avatarV + '" alt="">';
    else if (has()) el.innerHTML = '<b>' + esc(initials(p)) + '</b>';
    else el.innerHTML = PERSON;
    el.classList.toggle('big', !!big);
  }
  async function probeAvatar() {
    try { const r = await fetch('/api/avatar?v=' + avatarV, { method: 'GET' }); hasAvatar = r.ok; } catch (e) { hasAvatar = false; }
  }
  function paint() { paintAvatar($('#avatarSmall')); $('#accDot').hidden = has(); }

  function render() {
    const p = prof(), s = VC.S.state.settings;
    const key = s.has_key ? '<span class="badge ok">Claude connecté</span>' : '<span class="badge todo">Clé API à ajouter</span>';
    if (!has()) {
      pop.innerHTML = '<div class="pop-arrow"></div><div class="pop-head"><span class="pop-ico blue">' + PERSON + '</span><div><h3>Crée ton compte</h3><p>Ton nom d\'artiste et tes hashtags seront ajoutés automatiquement aux descriptions de tes clips.</p></div></div>' +
        '<div class="pop-actions"><button class="btn" type="button" data-a="settings">Réglages</button><span class="sp"></span><button class="btn primary" type="button" data-a="create">Créer mon compte</button></div>';
    } else {
      const nets = [['TikTok', p.tiktok], ['Instagram', p.instagram], ['YouTube', p.youtube]].filter(x => x[1]);
      pop.innerHTML = '<div class="pop-arrow"></div><div class="acc-card"><span class="avatar big" id="accPopAvatar"></span><div><h3>' + esc(p.artist || p.first || 'Mon compte') + '</h3><p>' + esc(p.email || (p.first && p.artist ? p.first : '')) + '</p></div></div>' +
        '<div class="pop-card">' + (nets.length ? nets.map(n => '<div><span>' + n[0] + '</span><b>' + esc(n[1]) + '</b></div>').join('') : '<div><span>Réseaux</span><b>—</b></div>') +
        '<div><span>Hashtags</span><b class="ellipsis">' + esc(p.hashtags || '—') + '</b></div><div><span>Claude</span><b>' + key + '</b></div></div>' +
        '<div class="pop-actions"><button class="btn" type="button" data-a="settings">Réglages</button><span class="sp"></span><button class="btn primary" type="button" data-a="edit">Modifier le profil</button></div>';
      paintAvatar($('#accPopAvatar'), true);
    }
  }
  $('#btnAccount').onclick = e => {
    e.stopPropagation();
    if (!pop.hidden) { pop.hidden = true; return; }
    VC.closePopovers('popAccount'); render(); pop.hidden = false;
  };
  pop.onclick = e => {
    const a = (e.target.closest('[data-a]') || {}).dataset; if (!a) return;
    pop.hidden = true;
    if (a.a === 'settings') $('#btnSettings').click();
    else openForm();
  };

  function openForm() {
    const p = prof();
    $('#accTitle').textContent = has() ? 'Mon profil' : 'Crée ton compte';
    $('#btnAccSave').textContent = has() ? 'Enregistrer' : 'Créer mon compte';
    $('#aFirst').value = p.first || ''; $('#aArtist').value = p.artist || ''; $('#aEmail').value = p.email || '';
    $('#aTiktok').value = p.tiktok || ''; $('#aInsta').value = p.instagram || ''; $('#aYt').value = p.youtube || ''; $('#aTags').value = p.hashtags || '';
    paintAvatar($('#avatarBig'), true);
    dlg.showModal();
    setTimeout(() => $(has() ? '#aArtist' : '#aFirst').focus(), 50);
  }
  VC.openAccount = openForm;
  $('#btnAccCancel').onclick = () => dlg.close();
  $('#btnAvatar').onclick = async () => {
    if (!VC.native()) return VC.toast('Le choix de photo fonctionne dans l\'application OMAGAD.');
    const path = await window.pywebview.api.pick_image(); if (!path) return;
    try { await VC.api('/api/avatar-set', { path }); avatarV = Date.now(); hasAvatar = true; paintAvatar($('#avatarBig'), true); paint(); }
    catch (e) { VC.toast(e.message); }
  };
  $('#formAccount').onsubmit = async e => {
    e.preventDefault();
    const email = $('#aEmail').value.trim();
    if (!$('#aFirst').value.trim() && !$('#aArtist').value.trim()) { VC.toast('Indique au moins ton prénom ou ton nom d\'artiste.'); return; }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { VC.toast('Cette adresse email ne semble pas valide.'); $('#aEmail').focus(); return; }
    const at = v => { v = v.trim(); return v && !v.startsWith('@') && !/^https?:/.test(v) ? '@' + v : v; };
    const tags = $('#aTags').value.trim().split(/[\s,]+/).filter(Boolean).map(t => t.startsWith('#') ? t : '#' + t).join(' ');
    const profile = { first: $('#aFirst').value.trim(), artist: $('#aArtist').value.trim(), email, tiktok: at($('#aTiktok').value), instagram: at($('#aInsta').value),
      youtube: at($('#aYt').value), hashtags: tags, created: prof().created || new Date().toISOString() };
    try {
      await VC.api('/api/profile', { profile });
      VC.S.state = await VC.api('/api/state');
      dlg.close(); paint();
      VC.toast(has() ? 'Profil enregistré' : 'Compte créé');
    } catch (err) { VC.toast(err.message); }
  };

  const boot = VC.boot;
  VC.boot = async function () { await boot(); await probeAvatar(); paint(); if (!has()) setTimeout(() => { if (!has()) VC.toast('Bienvenue ! Crée ton compte en cliquant sur l\'icône en haut à droite.', 5000); }, 2500); };
})();
