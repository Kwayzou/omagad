"""Dossiers de données, réglages et style par défaut."""
import copy
import json
import os
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
BUNDLED_FONTS = ROOT / "fonts"
BUNDLED_SFX = ROOT / "sfx"
APP_NAME = "OMAGAD"
try:
    VERSION = (ROOT / "VERSION").read_text().strip()
except OSError:
    VERSION = "1.0.0"


def _data_dir():
    env = os.environ.get("VLOGCLIPS_DATA")
    if env:
        return Path(env)
    home = Path.home()
    if sys.platform == "darwin":
        base = home / "Library" / "Application Support"
    elif os.name == "nt":
        base = Path(os.environ.get("APPDATA", home))
    else:
        return ROOT / "data"
    new, old = base / APP_NAME, base / "Vlog Clips"
    if not new.exists() and old.exists():  # ancienne version : on garde projets et réglages
        try:
            old.rename(new)
        except OSError:
            return old
    return new
    return ROOT / "data"


def _default_out():
    home = Path.home()
    base = home / ("Movies" if sys.platform == "darwin" else "Videos")
    return str((base if base.exists() else home) / APP_NAME)


DATA = _data_dir()
PROJECTS = DATA / "projects"
USER_FONTS = DATA / "fonts"
USER_SFX = DATA / "sfx"
MUSIC = DATA / "musique"
SETTINGS_FILE = DATA / "settings.json"
for d in (PROJECTS, USER_FONTS, USER_SFX):
    d.mkdir(parents=True, exist_ok=True)

DEFAULT_STYLE = {
    # Accroche
    "hook_font": "League Spartan", "hook_bold": True, "hook_size": 104, "hook_color": "#FFE81A",
    "hook_emph_color": "#FFFFFF", "hook_outline": 3, "hook_outline_color": "#000000", "hook_y": 0.55,
    "hook_secs": 3.5, "hook_box": False, "hook_box_color": "#0A1A33", "hook_upper": True,
    "hook_italic": False, "hook_spacing": 0, "hook_line": 1.0,
    "hook_glow": True, "hook_glow_mode": "out", "hook_glow_color": "#000000", "hook_glow_size": 22, "hook_glow_opacity": 1.0,
    "hook_shadow": True, "hook_shadow_color": "#000000", "hook_shadow_dist": 4, "hook_shadow_opacity": 0.5,
    # Animation de l'accroche : entrée, maintien, sortie (préréglage ou « custom »)
    "hook_in": "slide_left", "hook_in_ms": 230, "hook_in_ease": "out",
    "hook_out": "swipe_right", "hook_out_ms": 320, "hook_out_ease": "in",
    "hook_drift": 22, "hook_shake": False, "hook_words": False,
    "hook_in_dx": -600, "hook_in_dy": 0, "hook_in_scale": 1.0, "hook_in_rot": 0, "hook_in_alpha": 0.0,
    "hook_out_dx": 600, "hook_out_dy": 0, "hook_out_scale": 1.0, "hook_out_rot": 0, "hook_out_alpha": 0.0,
    # Effets sonores de l'accroche
    "sfx_in": "whoosh", "sfx_in_vol": 0.7, "sfx_out": "swipe", "sfx_out_vol": 0.6,
    # Sous-titres
    "sub_on": True, "sub_font": "Arial Black", "sub_bold": False, "sub_size": 74, "sub_color": "#FFFFFF", "sub_hl_color": "#3D9BFF",
    "sub_hl": "pop", "sub_outline": 7, "sub_outline_color": "#000000", "sub_y": 0.76, "sub_words": 3,
    "sub_upper": True, "sub_box": False, "sub_box_color": "#000000",
    "sub_italic": False, "sub_spacing": 0, "sub_anim": "pop",
    "sub_glow": False, "sub_glow_mode": "out", "sub_glow_color": "#000000", "sub_glow_size": 14, "sub_glow_opacity": 0.9,
    "sub_shadow": True, "sub_shadow_color": "#000000", "sub_shadow_dist": 3, "sub_shadow_opacity": 0.5,
}

def _default_repo():
    """Dépôt de mises à jour livré avec l'app (écrit par « Créer l'installateur »)."""
    try:
        return (ROOT / "update-repo.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


DEFAULTS = {
    "api_key": "",
    "claude_model": "claude-sonnet-5-5",
    "whisper_model": "small",
    "language": "fr",
    "encoder": "h264_videotoolbox" if sys.platform == "darwin" else "libx264",
    "quality": "high",
    "resolution": 1080,
    "loudnorm": True,
    "captions_txt": True,
    "out_dir": _default_out(),
    "style": DEFAULT_STYLE,
    "profile": {},
    "clips_target": 0,
    "clips_length": "medium",
    "lang": "fr",
    "shortcuts": {},
    "update_checked": 0,
    "styles": [],             # styles enregistrés : [{name, style, zcfg, punch, autocrop}]
    "auto_mode": False,       # mode automatique : exporte directement les meilleurs clips
    "auto_count": 10,         # nombre de clips exportés en mode automatique (0 = tous)
    "auto_style": "",         # style enregistré appliqué en mode automatique
    "auto_autocrop": True,
    "update_repo": _default_repo(),  # dépôt GitHub des mises à jour (ex. piazza/omagad)
    "guide_done": False,
}

_lock = threading.Lock()


def load_settings():
    data = copy.deepcopy(DEFAULTS)
    try:
        saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        for k, v in saved.items():
            if k == "style" and isinstance(v, dict):
                data["style"].update({sk: sv for sk, sv in v.items() if sk in DEFAULT_STYLE})
            elif k in DEFAULTS:
                data[k] = v
    except (OSError, ValueError):
        pass
    env_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if env_key:
        data["api_key"] = env_key
    return data


def save_settings(patch):
    with _lock:
        current = {}
        try:
            current = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        for k, v in patch.items():
            if k in DEFAULTS:
                current[k] = v
        SETTINGS_FILE.write_text(json.dumps(current, indent=2, ensure_ascii=False), encoding="utf-8")
    return load_settings()


def public_settings():
    s = load_settings()
    key = s.pop("api_key", "")
    s["has_key"] = bool(key)
    s["key_hint"] = ("..." + key[-4:]) if len(key) > 8 else ""
    s["default_style"] = DEFAULT_STYLE
    s["version"] = VERSION
    return s
