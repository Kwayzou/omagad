"""Animations de l'accroche : entrée, maintien, sortie. Mêmes formules que ui/anim.js (aperçu)."""
import math

IN_PRESETS = {
    "none": {}, "fade": {"alpha": 0}, "pop": {"scale": 0, "alpha": 0},
    "zoom_in": {"scale": 1.9, "alpha": 0}, "zoom_out": {"scale": 0.4, "alpha": 0},
    "slide_left": {"dx": -1100, "alpha": 0.6}, "slide_right": {"dx": 1100, "alpha": 0.6},
    "slide_up": {"dy": 160, "alpha": 0}, "slide_down": {"dy": -160, "alpha": 0},
    "rotate": {"rot": -25, "scale": 0.5, "alpha": 0}, "bounce": {"dy": -260},
}
OUT_PRESETS = {
    "none": {}, "fade": {"alpha": 0}, "swipe_right": {"dx": 1300}, "swipe_left": {"dx": -1300},
    "slide_down": {"dy": 220, "alpha": 0}, "slide_up": {"dy": -220, "alpha": 0},
    "zoom_out": {"scale": 0, "alpha": 0}, "zoom_in": {"scale": 1.18, "alpha": 0}, "pop_out": {"scale": 0},
    "rotate": {"rot": 25, "scale": 0.4, "alpha": 0},
}
# anciennes animations (versions 1.1 à 1.3) -> nouveaux réglages
LEGACY = {
    "swipe": {"hook_in": "slide_left", "hook_in_ms": 230, "hook_in_ease": "out", "hook_out": "swipe_right", "hook_out_ms": 320,
              "hook_out_ease": "in", "hook_drift": 22, "hook_shake": False, "hook_words": False},
    "slam": {"hook_in": "zoom_in", "hook_in_ms": 260, "hook_in_ease": "out", "hook_out": "zoom_in", "hook_out_ms": 400,
             "hook_out_ease": "lin", "hook_drift": 0, "hook_shake": True, "hook_words": False},
    "pop": {"hook_in": "pop", "hook_in_ms": 280, "hook_in_ease": "back", "hook_out": "fade", "hook_out_ms": 300,
            "hook_out_ease": "lin", "hook_drift": 0, "hook_shake": False, "hook_words": False},
    "slide": {"hook_in": "slide_up", "hook_in_ms": 280, "hook_in_ease": "out", "hook_out": "fade", "hook_out_ms": 300,
              "hook_out_ease": "lin", "hook_drift": 0, "hook_shake": False, "hook_words": False},
    "words": {"hook_in": "none", "hook_in_ms": 0, "hook_in_ease": "out", "hook_out": "fade", "hook_out_ms": 300,
              "hook_out_ease": "lin", "hook_drift": 0, "hook_shake": False, "hook_words": True},
}


def migrate(raw_style):
    """Style d'un moment enregistré avec l'ancienne option « hook_anim »."""
    if raw_style and "hook_anim" in raw_style and "hook_in" not in raw_style:
        out = dict(raw_style)
        out.update(LEGACY.get(raw_style["hook_anim"], {}))
        return out
    return raw_style


def ease(name, u):
    u = min(1.0, max(0.0, u))
    if name == "lin":
        return u
    if name == "in":
        return u ** 2.4
    if name == "inout":
        return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
    if name == "back":
        c1 = 1.70158
        return 1 + (c1 + 1) * (u - 1) ** 3 + c1 * (u - 1) ** 2
    if name == "back_in":
        c1 = 1.70158
        return (c1 + 1) * u ** 3 - c1 * u ** 2
    if name == "bounce":
        n, d = 7.5625, 2.75
        if u < 1 / d:
            return n * u * u
        if u < 2 / d:
            u -= 1.5 / d
            return n * u * u + 0.75
        if u < 2.5 / d:
            u -= 2.25 / d
            return n * u * u + 0.9375
        u -= 2.625 / d
        return n * u * u + 0.984375
    if name == "elastic":
        if u in (0.0, 1.0):
            return u
        return 2 ** (-10 * u) * math.sin((u * 10 - 0.75) * (2 * math.pi / 3)) + 1
    return 1 - (1 - u) ** 3  # "out"


def _params(st, side):
    kind = st.get("hook_" + side, "none")
    base = {"dx": 0.0, "dy": 0.0, "scale": 1.0, "rot": 0.0, "alpha": 1.0}
    if kind == "custom":
        for k in base:
            base[k] = float(st.get("hook_%s_%s" % (side, k), base[k]))
    else:
        base.update((IN_PRESETS if side == "in" else OUT_PRESETS).get(kind, {}))
    base["ms"] = 0.0 if kind == "none" else float(st.get("hook_%s_ms" % side, 300))
    base["ease"] = st.get("hook_%s_ease" % side, "out")
    return base


def out_start(st, total_ms):
    pin, pout = _params(st, "in"), _params(st, "out")
    return max(pin["ms"], total_ms - pout["ms"])


def sfx_out_offset(st):
    """Moment où démarre la sortie (en s), un peu avant pour le son."""
    total = float(st["hook_secs"]) * 1000
    pout = _params(st, "out")
    return (total - (pout["ms"] or 360)) / 1000.0 - 0.04


def transform(st, ms, total_ms):
    """(dx, dy, échelle, rotation en degrés, opacité) à l'instant ms depuis le début de l'accroche."""
    pin, pout = _params(st, "in"), _params(st, "out")
    dx = dy = rot = 0.0
    sc = al = 1.0
    if pin["ms"] > 0 and ms < pin["ms"]:
        u = ms / pin["ms"]
        e = ease(pin["ease"], u)
        dx, dy, rot = pin["dx"] * (1 - e), pin["dy"] * (1 - e), pin["rot"] * (1 - e)
        sc = pin["scale"] + (1 - pin["scale"]) * e
        al = pin["alpha"] + (1 - pin["alpha"]) * min(1.0, max(0.0, e if pin["ease"] not in ("bounce",) else u * 3))
    ost = max(pin["ms"], total_ms - pout["ms"])
    drift = float(st.get("hook_drift", 0) or 0)
    if drift and ost > pin["ms"]:
        dx += drift * min(1.0, max(0.0, (ms - pin["ms"]) / (ost - pin["ms"])))
    if st.get("hook_shake"):
        t = ms - pin["ms"]
        if 0 <= t < 80:
            rot += 2 * t / 80
        elif 80 <= t < 160:
            rot += 2 - 4 * (t - 80) / 80
        elif 160 <= t < 240:
            rot += -2 + 2 * (t - 160) / 80
    if pout["ms"] > 0 and ms >= ost:
        e = ease(pout["ease"], (ms - ost) / pout["ms"])
        dx += pout["dx"] * e
        dy += pout["dy"] * e
        rot += pout["rot"] * e
        sc *= 1 + (pout["scale"] - 1) * e
        al *= 1 + (pout["alpha"] - 1) * min(1.0, max(0.0, e))
    return dx, dy, max(0.0, sc), rot, min(1.0, max(0.0, al))


def words_visible(st, ms, n):
    if not st.get("hook_words"):
        return n
    return sum(1 for i in range(n) if ms >= 120 + i * 140)


def sub_anim(kind, ms):
    """Apparition de chaque ligne de sous-titres : (dy, échelle, opacité)."""
    if kind == "none" or ms >= 200:
        return 0.0, 1.0, 1.0
    if kind == "pop":
        e = ease("back", ms / 140)
        return 0.0, 0.75 + 0.25 * e, min(1.0, ms / 60)
    if kind == "fade":
        return 0.0, 1.0, min(1.0, ms / 150)
    if kind == "slide":
        e = ease("out", ms / 160)
        return 40 * (1 - e), 1.0, min(1.0, ms / 100)
    if kind == "zoom":
        e = ease("out", ms / 160)
        return 0.0, 1.35 - 0.35 * e, min(1.0, ms / 80)
    return 0.0, 1.0, 1.0
