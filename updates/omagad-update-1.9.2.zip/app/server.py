"""Serveur interne de l'application (affiché dans une fenêtre native par app.py)."""
import importlib.util
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import zipfile

from engine import autocrop, config, davinci, edit, fonts, installer, media, moments, render, sfx, transcribe

JOBS, JLOCK, PLOCK = {}, threading.Lock(), threading.Lock()
PID_RE = re.compile(r"^[a-f0-9]{8}$")
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mts"}
mimetypes.add_type("font/ttf", ".ttf")
mimetypes.add_type("font/otf", ".otf")
mimetypes.add_type("audio/wav", ".wav")
UPDATES = config.DATA / "app"


# ---------- Projets ----------
def pdir(pid):
    if not PID_RE.match(pid or ""):
        raise ValueError("Projet inconnu.")
    return config.PROJECTS / pid


def load(pid):
    return json.loads((pdir(pid) / "project.json").read_text(encoding="utf-8"))


def save(pid, data):
    with PLOCK:
        tmp = pdir(pid) / "project.json.tmp"
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(pdir(pid) / "project.json")


def source_of(pid, p):
    src = Path(p["source"])
    src = src if src.is_absolute() else pdir(pid) / src
    if not src.exists():
        raise RuntimeError("Fichier vidéo introuvable : %s. A-t-il été déplacé ou renommé ?" % src)
    return src


def summaries():
    out = []
    for d in sorted(config.PROJECTS.iterdir(), key=lambda x: -x.stat().st_mtime):
        try:
            p = json.loads((d / "project.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        ms = p.get("moments", [])
        out.append({"id": p["id"], "name": p["name"], "status": p.get("status"), "created": p.get("created"),
                    "duration": (p.get("info") or {}).get("duration"), "moments": len(ms),
                    "validated": sum(1 for m in ms if m.get("status") == "ok"),
                    "thumb": (d / "thumb.jpg").exists(), "missing": not _source_ok(d, p)})
    return out


def _source_ok(d, p):
    try:
        src = Path(p.get("source") or "")
        return (src if src.is_absolute() else d / src).is_file()
    except OSError:
        return False


def preview_ok(d, info):
    """L'aperçu existe et couvre bien toute la vidéo (sinon : impossible d'aller au-delà de sa fin)."""
    f = Path(d) / "preview.mp4"
    if not f.exists() or f.stat().st_size < 10000:
        return False
    want = float((info or {}).get("duration") or 0)
    try:
        got = media.probe(f)["duration"]
    except Exception:
        return False
    return not want or got >= want - 2.0


def run_preview_fix(job, pid):
    """Refait l'aperçu complet du vlog (avec progression), sans toucher aux moments."""
    try:
        p, d = load(pid), pdir(pid)
        src = source_of(pid, p)
        want = float((p.get("info") or {}).get("duration") or media.probe(src)["duration"])
        tmp = d / "preview.part.mp4"
        proc = media.start_preview(src, tmp, progress=True)
        upd(job, proc=proc, message="Reconstruction de l'aperçu…")
        for raw in proc.stdout:
            line = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else raw
            if line.startswith("out_time_us="):
                try:
                    upd(job, progress=min(0.99, int(line.split("=")[1]) / 1e6 / max(1.0, want)))
                except ValueError:
                    pass
        proc.wait()
        if proc.returncode != 0 or not tmp.exists():
            raise RuntimeError("Aperçu impossible : " + (proc.stderr.read() or b"").decode("utf-8", "replace")[-300:])
        tmp.replace(d / "preview.mp4")
        shutil.rmtree(d / "thumbs", ignore_errors=True)
        upd(job, done=True, progress=1.0, proc=None, message="Aperçu prêt")
    except Exception as e:
        upd(job, done=True, proc=None, error=str(e))


def relink(pid, path):
    """La vidéo a été déplacée ou renommée : on la retrouve (même durée, à une seconde près)."""
    p, src = load(pid), Path(path).expanduser()
    if not src.is_file():
        raise ValueError("Fichier introuvable.")
    want = float((p.get("info") or {}).get("duration") or 0)
    got = media.probe(src)["duration"]
    if want and abs(got - want) > 1.5:
        raise ValueError("Ce n'est pas la même vidéo (durée %s au lieu de %s)." % (fmt_dur(got), fmt_dur(want)))
    p["source"] = str(src.resolve())
    save(pid, p)
    return {"ok": True}


def fmt_dur(t):
    t = int(round(t))
    return "%d:%02d:%02d" % (t // 3600, t // 60 % 60, t % 60) if t >= 3600 else "%d:%02d" % (t // 60, t % 60)


def slug(s):
    s = unicodedata.normalize("NFKD", (s or "").lower()).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "clip"


def new_project(name, source):
    pid = uuid.uuid4().hex[:8]
    pdir(pid).mkdir(parents=True)
    p = {"id": pid, "name": Path(name).stem[:60] or "vlog", "source": source, "status": "imported",
         "created": time.time(), "moments": []}
    save(pid, p)
    return pid


# ---------- Tâches de fond ----------
def new_job(kind, pid):
    job = {"id": uuid.uuid4().hex[:8], "kind": kind, "pid": pid, "stage": "", "progress": 0.0, "message": "",
           "error": None, "warning": None, "done": False, "items": [], "cancel": False}
    with JLOCK:
        JOBS[job["id"]] = job
    return job


def upd(job, **kw):
    with JLOCK:
        job.update(kw)


STAGES = {"prepare": (0.0, 0.06), "transcribe": (0.06, 0.9), "moments": (0.9, 1.0)}


def stage(job, name, frac, msg):
    a, b = STAGES[name]
    upd(job, stage=name, progress=a + (b - a) * min(1.0, max(0.0, frac)), message=msg)


def detect(p, st, job):
    if st.get("api_key"):
        stage(job, "moments", 0.2, "Claude cherche les moments forts et écrit les accroches...")
        try:
            return moments.pick_moments(st, p["lines"], p["info"]["duration"]), None
        except Exception as e:
            warn = "Claude indisponible (%s). Moments choisis automatiquement à la place." % e
    else:
        warn = "Pas de clé API : moments choisis automatiquement. Ajoute une clé dans les Réglages pour de meilleures accroches."
    stage(job, "moments", 0.5, "Recherche automatique des moments...")
    return moments.heuristic_moments(p["lines"], p["info"]["duration"], n=moments.target_count(st, p["info"]["duration"])), warn


def run_analyze(job, pid, only_moments=False):
    try:
        p, st, d = load(pid), config.load_settings(), pdir(pid)
        if not only_moments:
            src = source_of(pid, p)
            stage(job, "prepare", 0.1, "Lecture du fichier vidéo...")
            p["info"] = media.probe(src)
            if not p["info"]["has_audio"]:
                raise RuntimeError("Cette vidéo n'a pas de son : impossible de trouver les moments forts.")
            prev, proc = d / "preview.mp4", None
            prev_tmp = d / "preview.part.mp4"
            if not preview_ok(d, p["info"]):  # absent, ou coupé (app fermée pendant sa création)
                proc = media.start_preview(src, prev_tmp)
            try:
                media.thumbnail(src, min(30, p["info"]["duration"] / 3), d / "thumb.jpg")
            except Exception:
                pass
            wav = d / "audio.wav"
            if not wav.exists():
                stage(job, "prepare", 0.5, "Extraction du son...")
                media.extract_audio(src, wav)
            (d / "wave.json").write_text(json.dumps(media.waveform(wav)), encoding="utf-8")
            save(pid, p)
            wf = d / "words.json"
            if wf.exists():
                words = json.loads(wf.read_text(encoding="utf-8"))
            else:
                words, _ = transcribe.transcribe(wav, st["whisper_model"], st["language"],
                                                 lambda f, m: stage(job, "transcribe", f, m))
                wf.write_text(json.dumps(words, ensure_ascii=False), encoding="utf-8")
            p["words"], p["lines"] = words, transcribe.make_lines(words)
            if proc is not None:
                stage(job, "transcribe", 1.0, "Finalisation de l'aperçu vidéo...")
                _, err = proc.communicate()
                if proc.returncode != 0:
                    raise RuntimeError("Aperçu impossible : " + (err or b"").decode("utf-8", "replace")[-300:])
                prev_tmp.replace(prev)
        p["moments"], warn = detect(p, st, job)
        p["status"], p["warning"] = "ready", warn
        save(pid, p)
        upd(job, done=True, progress=1.0, stage="done", message="Terminé", warning=warn)
    except Exception as e:
        upd(job, error=str(e), done=True)


# ---------- Mode automatique et file de vlogs ----------
QUEUE, QLOCK = [], threading.Lock()
_qworker = {"t": None}


def apply_preset(m, preset):
    m["style"] = dict(preset.get("style") or {})
    fr = m.setdefault("frame", {"mode": "fill", "fx": 0.5, "fy": 0.5, "zoom": 1, "punch": True})
    if preset.get("zcfg"):
        fr["zcfg"] = dict(preset["zcfg"], seed=int(uuid.uuid4().int % 999999) + 1)
    for k in ("punch", "mode", "zoom"):
        if preset.get(k) is not None:
            fr[k] = preset[k]
    if "sfx" in preset:
        m["sfx"] = [dict(x) for x in preset["sfx"]] if preset.get("sfx") else None
    if "music" in preset:
        m["music"] = dict(preset["music"]) if preset.get("music") else None


def run_auto(entry, pid):
    """Mode automatique : garde les meilleurs moments, applique le style, recadre et exporte sans passer par le montage."""
    st = config.load_settings()
    p = load(pid)
    ms = sorted(p["moments"], key=lambda m: -float(m.get("score") or 0))
    n = int(st.get("auto_count") or 0) or len(ms)
    keep = {m["id"] for m in ms[:n]}
    preset = next((x for x in st.get("styles") or [] if x.get("name") == st.get("auto_style")), None)
    lines = p.get("lines") or []
    chosen = [m for m in p["moments"] if m["id"] in keep]
    prev = pdir(pid) / "preview.mp4"
    for i, m in enumerate(chosen):
        if preset:
            apply_preset(m, preset)
        fr = m.setdefault("frame", {"mode": "fill", "fx": 0.5, "fy": 0.5, "zoom": 1, "punch": True})
        if (fr.get("zcfg") or {}).get("on"):
            fr["zooms"] = edit.make_zooms(m, fr["zcfg"], lines)
        if st.get("auto_autocrop", True) and fr.get("mode", "fill") == "fill":
            entry.update(message="Recadrage %d / %d" % (i + 1, len(chosen)), progress=0.5 + 0.15 * i / max(1, len(chosen)))
            try:
                r = autocrop.track(prev if prev.exists() else source_of(pid, p), p["info"], m["t0"], m["t1"], float(fr.get("zoom", 1)), lambda f: None)
                if r.get("keys"):
                    fr.update(keys=r["keys"], auto=True)
            except Exception as e:
                print("autocrop :", e)
        m["status"] = "ok"
    for m in p["moments"]:
        if m["id"] not in keep:
            m["status"] = "skip"
    save(pid, p)
    out = Path(st["out_dir"]).expanduser() / re.sub(r'[\\/:*?"<>|]+', "-", p["name"])
    job = new_job("export", pid)
    entry["job"] = job["id"]
    t = threading.Thread(target=run_export, args=(job, pid, keep, {"out_dir": str(out)}), daemon=True)
    t.start()
    while t.is_alive():
        entry.update(message=job.get("message") or "Export…", progress=0.65 + 0.35 * float(job.get("progress") or 0))
        time.sleep(0.5)
    done = sum(1 for it in job["items"] if it["state"] == "done")
    if job.get("error") and not done:
        raise RuntimeError(job["error"])
    entry.update(out_dir=str(out), clips=done)


def _queue_worker():
    while True:
        with QLOCK:
            entry = next((e for e in QUEUE if e["state"] == "wait"), None)
            if entry:
                entry["state"] = "run"
        if not entry:
            _qworker["t"] = None
            return
        try:
            job = new_job("analyze", entry["pid"])
            entry["job"] = job["id"]
            t = threading.Thread(target=run_analyze, args=(job, entry["pid"]), daemon=True)
            t.start()
            while t.is_alive():
                f = float(job.get("progress") or 0)
                entry.update(message=job.get("message") or "", progress=f * (0.5 if entry["auto"] else 1.0))
                time.sleep(0.5)
            if job.get("error"):
                raise RuntimeError(job["error"])
            entry["moments"] = len(load(entry["pid"]).get("moments") or [])
            if entry["auto"]:
                run_auto(entry, entry["pid"])
            entry.update(state="done", progress=1.0, message="Terminé")
        except Exception as e:
            entry.update(state="error", error=str(e), message=str(e))


def queue_add(paths, auto):
    added = []
    for raw in paths:
        src = Path(raw).expanduser()
        if not src.is_file():
            continue
        pid = new_project(src.name, str(src.resolve()))
        e = {"id": uuid.uuid4().hex[:8], "pid": pid, "name": src.stem, "auto": bool(auto), "state": "wait",
             "progress": 0.0, "message": "En attente", "error": None, "out_dir": None, "clips": 0, "moments": 0}
        with QLOCK:
            QUEUE.append(e)
        added.append(e)
    with QLOCK:
        if added and _qworker["t"] is None:
            _qworker["t"] = threading.Thread(target=_queue_worker, daemon=True)
            _qworker["t"].start()
    return added


def run_davinci(job, pid, ids, open_app, out_dir=None):
    """Timeline XML + SRT + sons pour DaVinci Resolve, et ouverture automatique si demandé."""
    try:
        p, st = load(pid), config.load_settings()
        src, d = source_of(pid, p), pdir(pid)
        items = [m for m in p["moments"] if m["id"] in ids] or [m for m in p["moments"] if m.get("status") != "skip"]
        upd(job, message="Création de la timeline…", progress=0.1)
        r = davinci.build(p, src, items, out_dir or st["out_dir"], media_dir=d / "media")
        upd(job, result=r, progress=0.4 if open_app else 1.0)
        if open_app:
            ok = davinci.open_in_resolve(r["script"], lambda msg, f: upd(job, message=msg, progress=0.4 + 0.6 * f))
            r["auto"] = ok
        upd(job, done=True, progress=1.0, result=r, message="Timeline prête")
    except Exception as e:
        upd(job, error=str(e), done=True)


def run_export(job, pid, ids, opts):
    try:
        p, st = load(pid), config.load_settings()
        src, d = source_of(pid, p), pdir(pid)
        out_dir = Path(opts.get("out_dir") or st["out_dir"]).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)
        items = [m for m in p["moments"] if m["id"] in ids]
        merged = {k: opts.get(k, st[k]) for k in ("encoder", "quality", "resolution", "loudnorm", "captions_txt")}
        upd(job, items=[{"id": m["id"], "hook": m.get("hook"), "state": "wait", "progress": 0, "file": None} for m in items])
        for i, m in enumerate(items):
            if job["cancel"]:
                break
            name = "%s-%02d-%s.mp4" % (slug(p["name"])[:24], i + 1, slug(m.get("hook"))[:32])
            out = out_dir / name
            item = job["items"][i]
            upd(job, message="Clip %d sur %d" % (i + 1, len(items)))
            item["state"] = "run"

            def prog(f, i=i, item=item):
                item["progress"] = f
                upd(job, progress=(i + f) / len(items))
            try:
                render.render_clip(src, p["info"], p["words"], m, merged, out, d / "work", prog,
                                   register=lambda proc: upd(job, proc=proc), media_dir=d / "media")
            except InterruptedError:
                item["state"] = "cancel"
                break
            except Exception as e:
                item.update(state="error", error=str(e))
                continue
            if merged["captions_txt"] and m.get("caption"):
                out.with_suffix(".txt").write_text(m["caption"] + "\n", encoding="utf-8")
            item.update(state="done", file=str(out), progress=1.0)
        errs = [it for it in job["items"] if it["state"] == "error"]
        upd(job, done=True, progress=1.0, proc=None, out_dir=str(out_dir),
            error=(errs[0]["error"] if errs and len(errs) == len(job["items"]) else None),
            message="Export annulé." if job["cancel"] else "Export terminé.")
    except Exception as e:
        upd(job, error=str(e), done=True, proc=None)


IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".gif", ".bmp", ".tif", ".tiff"}


def import_music(src):
    """Copie un morceau dans la bibliothèque musique d'OMAGAD (AAC, lisible partout)."""
    if not src.is_file():
        raise ValueError("Fichier introuvable.")
    config.MUSIC.mkdir(parents=True, exist_ok=True)
    dest = config.MUSIC / (uuid.uuid4().hex[:10] + ".m4a")
    media.run([media.FFMPEG, "-y", "-loglevel", "error", "-i", str(src), "-vn", "-ac", "2", "-ar", "48000",
               "-c:a", "aac", "-b:a", "192k", str(dest)])
    return {"file": dest.name, "name": src.stem[:80], "dur": round(media.probe_audio_duration(dest) or 0, 2)}


def import_media(pid, src):
    """Copie une photo ou une vidéo dans le projet (convertie si besoin) et renvoie ses infos."""
    if not src.is_file():
        raise ValueError("Fichier introuvable.")
    d = pdir(pid) / "media"
    d.mkdir(exist_ok=True)
    ext = src.suffix.lower()
    name = uuid.uuid4().hex[:8]
    if ext in IMAGE_EXT:
        dest = d / (name + ".png")
        media.run([media.FFMPEG, "-y", "-loglevel", "error", "-i", str(src), "-frames:v", "1",
                   "-vf", "scale='min(2160,iw)':-2", str(dest)])
        from PIL import Image
        with Image.open(dest) as im:
            w, h = im.size
        return {"file": dest.name, "kind": "image", "name": src.name, "w": w, "h": h}
    if ext in VIDEO_EXT or ext in {".mxf"}:
        info = media.probe(src)
        dest = d / (name + ".mp4")
        media.run([media.FFMPEG, "-y", "-loglevel", "error", "-i", str(src), "-an", "-vf", "scale=-2:'min(1920,ih)'",
                   "-c:v", "libx264" if "libx264" in media.encoders() else "mpeg4", "-preset", "veryfast", "-crf", "20",
                   "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(dest)])
        return {"file": dest.name, "kind": "video", "name": src.name, "vdur": info["duration"],
                "w": info["width"], "h": info["height"]}
    raise ValueError("Format non pris en charge : choisis une photo (jpg, png, heic...) ou une vidéo (mp4, mov...).")


def run_autocrop(job, pid, mid, t0, t1, zoom):
    try:
        p = load(pid)
        src = pdir(pid) / "preview.mp4"
        if not src.exists():
            src = source_of(pid, p)
        upd(job, message="Recherche du sujet...")
        r = autocrop.track(src, p["info"], t0, t1, zoom, lambda f: upd(job, progress=f))
        if not r["keys"]:
            return upd(job, done=True, error=r.get("message") or "Aucun sujet trouvé.")
        upd(job, done=True, progress=1.0, result=r, message="Recadrage prêt")
    except Exception as e:
        upd(job, done=True, error=str(e))


UPDATE_DIRS = [config.DATA / "mises-a-jour", Path.home() / "Downloads", Path.home() / "Téléchargements", Path.home() / "Desktop"]


def find_updates():
    """Mises à jour plus récentes que la version actuelle (déposées dans Téléchargements ou le dossier OMAGAD)."""
    (config.DATA / "mises-a-jour").mkdir(exist_ok=True)
    found = {}
    for d in UPDATE_DIRS:
        try:
            files = list(d.glob("omagad-update-*.zip"))
        except OSError:
            continue
        for f in files:
            try:
                with zipfile.ZipFile(f) as z:
                    meta = json.loads(z.read("omagad-update.json").decode("utf-8"))
            except Exception:
                continue
            v = meta.get("version", "0")
            if _vtuple(v) > _vtuple(config.VERSION) and (v not in found or f.stat().st_mtime > found[v]["mtime"]):
                found[v] = {"version": v, "notes": meta.get("notes", ""), "path": str(f), "mtime": f.stat().st_mtime}
    r = remote_update()
    if r and _vtuple(r["version"]) > _vtuple(config.VERSION) and r["version"] not in found:
        found[r["version"]] = r
    return sorted(found.values(), key=lambda x: _vtuple(x["version"]), reverse=True)


_REMOTE = {"t": 0, "v": None, "repo": None}


def remote_update():
    """Dernière version publiée sur GitHub (Releases du dépôt choisi dans les réglages), vérifiée toutes les 10 min."""
    repo = (config.load_settings().get("update_repo") or config._default_repo() or "").strip().strip("/")
    repo = re.sub(r"^https?://github\.com/", "", repo)
    if not re.match(r"^[\w.-]+/[\w.-]+$", repo):
        return None
    if _REMOTE["repo"] == repo and time.time() - _REMOTE["t"] < 600:
        return _REMOTE["v"]
    _REMOTE.update(t=time.time(), repo=repo, v=None)
    import urllib.request

    def get(url):
        req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json", "User-Agent": "OMAGAD", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=10, context=moments._ctx()) as r:
            return json.loads(r.read().decode("utf-8"))
    found = []
    # 1. fichier latest.json à la racine du dépôt (mises à jour publiées directement dans le dépôt)
    try:
        meta = get("https://raw.githubusercontent.com/%s/HEAD/latest.json?t=%d" % (repo, int(time.time())))
        if meta.get("version") and meta.get("file"):
            found.append({"version": str(meta["version"]), "notes": meta.get("notes") or "", "path": "", "mtime": time.time(), "remote": True,
                          "url": "https://raw.githubusercontent.com/%s/HEAD/%s" % (repo, meta["file"].lstrip("/"))})
    except Exception as e:
        print("mises à jour GitHub (latest.json) :", e)
    # 2. onglet Releases
    try:
        rel = get("https://api.github.com/repos/%s/releases/latest" % repo)
        asset = next((a for a in rel.get("assets") or [] if re.match(r"omagad-update-.*\.zip$", a.get("name", ""))), None)
        if asset:
            v = re.sub(r"^[vV]", "", rel.get("tag_name") or "") or re.search(r"omagad-update-(.+)\.zip", asset["name"]).group(1)
            found.append({"version": v, "notes": rel.get("body") or rel.get("name") or "", "path": "", "url": asset["browser_download_url"],
                          "mtime": time.time(), "remote": True})
    except Exception as e:
        print("mises à jour GitHub (releases) :", e)
    if found:
        _REMOTE["v"] = max(found, key=lambda x: _vtuple(x["version"]))
    return _REMOTE["v"]


def download_update(url):
    import urllib.request
    if not url.startswith(("https://github.com/", "https://objects.githubusercontent.com/", "https://raw.githubusercontent.com/")):
        raise ValueError("Adresse de mise à jour refusée.")
    d = config.DATA / "mises-a-jour"
    d.mkdir(parents=True, exist_ok=True)
    dest = d / url.split("?")[0].rsplit("/", 1)[-1]
    tmp = dest.with_suffix(".part")
    req = urllib.request.Request(url, headers={"User-Agent": "OMAGAD"})
    with urllib.request.urlopen(req, timeout=60, context=moments._ctx()) as r, open(tmp, "wb") as f:
        shutil.copyfileobj(r, f)
    tmp.replace(dest)
    return dest


def run_install_ffmpeg(job):
    """Installe ffmpeg-full (avec libass) via Homebrew, en affichant la progression."""
    brew = media.brew_path()
    if not brew:
        return upd(job, done=True, error="Homebrew est introuvable. Installe-le depuis brew.sh, puis : brew install ffmpeg-full")
    env = dict(os.environ, HOMEBREW_NO_AUTO_UPDATE="1", HOMEBREW_NO_INSTALL_CLEANUP="1", NONINTERACTIVE="1",
               HOMEBREW_NO_ENV_HINTS="1", HOMEBREW_COLOR="0")
    upd(job, message="Démarrage de l'installation...", progress=0.02)
    try:
        p = subprocess.Popen([brew, "install", "ffmpeg-full"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, env=env, bufsize=1)
        upd(job, proc=p)
        lines, n = [], 0
        for line in p.stdout:
            line = line.strip()
            if not line:
                continue
            lines.append(line)
            n += 1
            msg = line[4:] if line.startswith("==> ") else line
            upd(job, message=msg[:160], progress=min(0.95, 0.03 + n * 0.006))
        p.wait()
        if p.returncode != 0:
            return upd(job, done=True, proc=None, error="L'installation a échoué : " + " | ".join(lines[-3:])[:400])
    except OSError as e:
        return upd(job, done=True, proc=None, error=str(e))
    info = media.detect_ffmpeg()
    upd(job, done=True, proc=None, progress=1.0, result=info,
        error=None if info["libass"] else "ffmpeg-full est installé mais OMAGAD ne le trouve pas. Redémarre l'application.",
        message="ffmpeg complet installé.")


def _vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0")[:3])


def install_update(zpath):
    """Installe un fichier de mise à jour OMAGAD (.zip) dans le dossier de données ; actif au redémarrage."""
    if not zpath.is_file() or zpath.suffix.lower() != ".zip":
        raise ValueError("Choisis un fichier de mise à jour .zip.")
    with zipfile.ZipFile(zpath) as z:
        names = z.namelist()
        try:
            meta = json.loads(z.read("omagad-update.json").decode("utf-8"))
        except KeyError:
            raise ValueError("Ce fichier n'est pas une mise à jour OMAGAD.")
        if "app/app.py" not in names:
            raise ValueError("Mise à jour incomplète (app.py manquant).")
        tmp = config.DATA / "app.new"
        shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir()
        for n in names:
            if not n.startswith("app/") or n.endswith("/"):
                continue
            rel = Path(n[4:])
            if rel.is_absolute() or ".." in rel.parts:
                raise ValueError("Fichier de mise à jour invalide.")
            dest = tmp / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(n))
    old = config.DATA / "app.old"
    shutil.rmtree(old, ignore_errors=True)
    if UPDATES.exists() and UPDATES.resolve() != config.ROOT.resolve():
        UPDATES.rename(old)
    elif UPDATES.exists():
        shutil.copytree(UPDATES, old)
        shutil.rmtree(UPDATES)
    tmp.rename(UPDATES)
    return {"version": meta.get("version", "?"), "notes": meta.get("notes", ""), "current": config.VERSION,
            "downgrade": _vtuple(meta.get("version")) < _vtuple(config.VERSION)}


def reveal(path):
    path = Path(path)
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(path)] if path.is_file() else ["open", str(path)])
    elif os.name == "nt":
        subprocess.Popen(["explorer", "/select,", str(path)] if path.is_file() else ["explorer", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path if path.is_dir() else path.parent)])


# ---------- HTTP ----------
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, BrokenPipeError):
            pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _err(self, code, msg):
        self._send(code, {"error": msg})

    def _file(self, path, cache=False):
        if not path.is_file():
            return self._err(404, "Fichier introuvable.")
        size = path.stat().st_size
        start, end, code = 0, size - 1, 200
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
        if m and (m.group(1) or m.group(2)):
            if m.group(1):
                start = int(m.group(1))
                end = int(m.group(2)) if m.group(2) else end
            else:
                start = max(0, size - int(m.group(2)))
            end, code = min(end, size - 1), 206
            if start >= size or start > end:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
        self.send_response(code)
        self.send_header("Content-Type", mimetypes.guess_type(str(path))[0] or "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "max-age=3600" if cache else "no-store")
        if code == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.end_headers()
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _ok_host(self):
        return (self.headers.get("Host") or "").split(":")[0] in ("localhost", "127.0.0.1")

    def do_GET(self):
        if not self._ok_host():
            return self._err(403, "Hôte refusé.")
        u = urlparse(self.path)
        parts = [unquote(x) for x in u.path.strip("/").split("/")]
        q = parse_qs(u.query)
        try:
            if u.path == "/":
                return self._file(config.UI / "index.html")
            if u.path == "/favicon.ico":
                return self._send(204, b"", "image/x-icon")
            if parts[0] == "ui" and len(parts) > 1:
                f = (config.UI / "/".join(parts[1:])).resolve()
                if config.UI.resolve() not in f.parents:
                    return self._err(403, "Interdit.")
                return self._file(f)
            if parts[0] == "fonts" and len(parts) == 3:
                base = config.BUNDLED_FONTS if parts[1] == "app" else config.USER_FONTS
                f = (base / parts[2]).resolve()
                if base.resolve() not in f.parents:
                    return self._err(403, "Interdit.")
                return self._file(f, cache=True)
            if parts[0] == "sfx" and len(parts) == 3:
                base = config.BUNDLED_SFX if parts[1] == "app" else config.USER_SFX
                f = (base / parts[2]).resolve()
                if base.resolve() not in f.parents:
                    return self._err(403, "Interdit.")
                return self._file(f, cache=True)
            if parts[0] == "music" and len(parts) == 2:
                base = config.MUSIC
                f = (base / unquote(parts[1])).resolve()
                if base.resolve() not in f.parents:
                    return self._err(403, "Interdit.")
                return self._file(f, cache=True)
            if parts[0] == "pmedia" and len(parts) == 3:
                base = pdir(parts[1]) / "media"
                f = (base / parts[2]).resolve()
                if base.resolve() not in f.parents:
                    return self._err(403, "Interdit.")
                return self._file(f, cache=True)
            if u.path == "/api/avatar":
                return self._file(config.DATA / "avatar.png")
            if u.path == "/api/updates":
                return self._send(200, {"current": config.VERSION, "found": find_updates()})
            if parts[0] == "media" and len(parts) == 3:
                name = {"preview": "preview.mp4", "thumb": "thumb.jpg"}.get(parts[2])
                return self._file(pdir(parts[1]) / name) if name else self._err(404, "Introuvable.")
            if parts[0] == "thumb" and len(parts) == 3:
                d, t = pdir(parts[1]), float(q.get("t", ["0"])[0])
                f = d / "thumbs" / ("%s_%d.jpg" % (re.sub(r"\W", "", parts[2]), int(t * 10)))
                if not f.exists():
                    f.parent.mkdir(exist_ok=True)
                    media.thumbnail(d / "preview.mp4", t, f)
                return self._file(f, cache=True)
            if parts[0] == "file" and "path" in q:
                f = Path(q["path"][0])
                if f.suffix.lower() != ".mp4":
                    return self._err(403, "Interdit.")
                return self._file(f)
            if u.path == "/api/state":
                return self._send(200, {"ffmpeg": media.have_ffmpeg(), "ffmpeg_ass": media.HAS_ASS,
                                        "ffmpeg_path": media.FFMPEG, "brew": bool(media.brew_path()),
                                        "whisper": importlib.util.find_spec("faster_whisper") is not None,
                                        "native": os.environ.get("VLOGCLIPS_NATIVE") == "1",
                                        "davinci": davinci.installed(),
                                        "engine": transcribe.engine_name(),
                                        "settings": config.public_settings(), "projects": summaries(),
                                        "fonts": fonts.list_fonts(), "fonts_dir": str(config.USER_FONTS),
                                        "fonts_status": fonts.STATUS, "sfx": sfx.list_sfx(), "version": config.VERSION,
                                        "updated": (UPDATES / "app.py").exists() and config.ROOT.resolve() == UPDATES.resolve()})
            if parts[:2] == ["api", "preview-status"] and len(parts) == 3:
                p = load(parts[2])
                return self._send(200, {"ok": preview_ok(pdir(parts[2]), p.get("info"))})
            if parts[:2] == ["api", "project"] and len(parts) == 3:
                p = load(parts[2])
                p["source_missing"] = not _source_ok(pdir(parts[2]), p)
                return self._send(200, p)
            if parts[:2] == ["api", "wave"] and len(parts) == 3:
                d = pdir(parts[2])
                f, wav = d / "wave.json", d / "audio.wav"
                data = None
                if f.exists():
                    data = f.read_bytes()
                    if b'"v": 2' not in data[:40] and wav.exists():  # ancienne forme d'onde (10 points/s) : on la refait
                        data = None
                if data is None and wav.exists():
                    f.write_text(json.dumps(media.waveform(wav)), encoding="utf-8")
                    data = f.read_bytes()
                return self._send(200, data or b'{"per_sec":10,"peaks":[]}')
            if u.path == "/api/queue":
                with QLOCK:
                    return self._send(200, {"items": [dict(e) for e in QUEUE]})
            if parts[:2] == ["api", "job"] and len(parts) == 3:
                with JLOCK:
                    job = JOBS.get(parts[2])
                    if not job:
                        return self._err(404, "Tâche inconnue.")
                    data = {k: v for k, v in job.items() if k != "proc"}
                    data["items"] = [dict(i) for i in job["items"]]
                return self._send(200, data)
            return self._err(404, "Introuvable.")
        except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as e:
            return self._err(404, str(e))

    def _json(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n).decode("utf-8") or "{}") if n else {}

    def do_POST(self):
        if not self._ok_host() or self.headers.get("X-Requested-With") != "vlog-clips":
            return self._err(403, "Requête refusée.")
        u = urlparse(self.path)
        parts = [unquote(x) for x in u.path.strip("/").split("/")]
        try:
            if u.path == "/api/upload":
                return self._upload(parse_qs(u.query).get("name", ["video.mp4"])[0])
            b = self._json()
            if parts[:2] == ["api", "preview-fix"] and len(parts) == 3:
                pdir(parts[2])
                with JLOCK:
                    running = next((j for j in JOBS.values() if j["kind"] == "preview" and j["pid"] == parts[2] and not j["done"]), None)
                if running:
                    return self._send(200, {"job": running["id"]})
                job = new_job("preview", parts[2])
                threading.Thread(target=run_preview_fix, args=(job, parts[2]), daemon=True).start()
                return self._send(200, {"job": job["id"]})
            if u.path == "/api/relink":
                return self._send(200, relink(b["pid"], b["path"]))
            if u.path == "/api/queue-add":
                added = queue_add(b.get("paths") or [], b.get("auto"))
                if not added:
                    return self._err(400, "Aucune vidéo trouvée.")
                return self._send(200, {"added": len(added)})
            if u.path == "/api/queue-clear":
                with QLOCK:
                    QUEUE[:] = [e for e in QUEUE if e["state"] in ("wait", "run")]
                return self._send(200, {"ok": True})
            if u.path == "/api/import":
                src = Path(b["path"]).expanduser()
                if not src.is_file():
                    return self._err(400, "Fichier introuvable.")
                return self._send(200, {"pid": new_project(src.name, str(src.resolve()))})
            if u.path == "/api/settings":
                config.save_settings({k: v for k, v in b.items() if not (k == "api_key" and not v)})
                return self._send(200, config.public_settings())
            if u.path == "/api/analyze" or (parts[:2] == ["api", "redetect"] and len(parts) == 3):
                pid = b.get("pid") or parts[2]
                pdir(pid)
                job = new_job("analyze", pid)
                threading.Thread(target=run_analyze, args=(job, pid, u.path != "/api/analyze"), daemon=True).start()
                return self._send(200, {"job": job["id"]})
            if parts[:2] == ["api", "save"] and len(parts) == 3:
                p = load(parts[2])
                for k in ("moments", "name"):
                    if k in b:
                        p[k] = b[k]
                save(parts[2], p)
                return self._send(200, {"ok": True})
            if u.path == "/api/hooks":
                p = load(b["pid"])
                text = " ".join(l["text"] for l in p["lines"] if l["e"] > b["t0"] and l["s"] < b["t1"])
                return self._send(200, {"hooks": moments.suggest_hooks(config.load_settings(), text[:4000])})
            if u.path == "/api/make-dmg":
                job = new_job("dmg", None)

                def go(job=job, out=b.get("out_dir"), eng=b.get("engine", True)):
                    try:
                        r = installer.build_dmg(out or str(Path.home() / "Desktop"), lambda m, f: upd(job, message=m, progress=f), bool(eng))
                        upd(job, done=True, progress=1.0, result=r, message="Installateur prêt")
                    except Exception as e:
                        upd(job, done=True, error=str(e))
                threading.Thread(target=go, daemon=True).start()
                return self._send(200, {"job": job["id"]})
            if u.path == "/api/davinci":
                pid = b["pid"]
                pdir(pid)
                job = new_job("davinci", pid)
                threading.Thread(target=run_davinci, args=(job, pid, list(b.get("ids") or []), bool(b.get("open")), b.get("out_dir")), daemon=True).start()
                return self._send(200, {"job": job["id"]})
            if u.path == "/api/export":
                pid = b["pid"]
                pdir(pid)
                job = new_job("export", pid)
                threading.Thread(target=run_export, args=(job, pid, set(b["ids"]), b.get("opts") or {}), daemon=True).start()
                return self._send(200, {"job": job["id"]})
            if parts[:2] == ["api", "cancel"] and len(parts) == 3:
                with JLOCK:
                    job = JOBS.get(parts[2])
                if job:
                    job["cancel"] = True
                    if job.get("proc"):
                        job["proc"].terminate()
                return self._send(200, {"ok": True})
            if u.path == "/api/reveal":
                reveal(b.get("path") or config.load_settings()["out_dir"])
                return self._send(200, {"ok": True})
            if u.path == "/api/music-import":
                return self._send(200, import_music(Path(b["path"])))
            if u.path == "/api/media-import":
                return self._send(200, import_media(b["pid"], Path(b["path"])))
            if u.path == "/api/autocrop":
                pid = b["pid"]
                pdir(pid)
                job = new_job("autocrop", pid)
                threading.Thread(target=run_autocrop, args=(job, pid, b["mid"], float(b["t0"]), float(b["t1"]),
                                                            float(b.get("zoom", 1))), daemon=True).start()
                return self._send(200, {"job": job["id"]})
            if u.path == "/api/install-ffmpeg":
                job = new_job("ffmpeg", None)
                threading.Thread(target=run_install_ffmpeg, args=(job,), daemon=True).start()
                return self._send(200, {"job": job["id"]})
            if u.path == "/api/ffmpeg-recheck":
                return self._send(200, media.detect_ffmpeg())
            if u.path == "/api/profile":
                prof = {k: str(v)[:300] for k, v in (b.get("profile") or {}).items()
                        if k in ("first", "artist", "email", "tiktok", "instagram", "youtube", "hashtags", "created")}
                config.save_settings({"profile": prof})
                return self._send(200, config.public_settings())
            if u.path == "/api/avatar-set":
                from PIL import Image, ImageOps
                with Image.open(b["path"]) as im:
                    im = ImageOps.fit(ImageOps.exif_transpose(im).convert("RGB"), (256, 256))
                    im.save(config.DATA / "avatar.png")
                return self._send(200, {"ok": True})
            if u.path == "/api/font-import":
                fam = fonts.import_font(Path(b["path"]))
                return self._send(200, {"family": fam, "fonts": fonts.list_fonts()})
            if u.path == "/api/sfx-import":
                sid = sfx.import_sound(b["path"])
                return self._send(200, {"id": sid, "sfx": sfx.list_sfx()})
            if u.path == "/api/sfx-folder":
                reveal(config.USER_SFX)
                return self._send(200, {"ok": True})
            if u.path == "/api/update":
                path = Path(b["path"]) if b.get("path") else download_update(b.get("url") or "")
                return self._send(200, install_update(path))
            if u.path == "/api/update-reset":
                shutil.rmtree(UPDATES, ignore_errors=True)
                return self._send(200, {"ok": True})
            if u.path == "/api/fonts-folder":
                reveal(config.USER_FONTS)
                return self._send(200, {"ok": True})
            if parts[:2] == ["api", "delete"] and len(parts) == 3:
                shutil.rmtree(pdir(parts[2]), ignore_errors=True)
                return self._send(200, {"ok": True})
            return self._err(404, "Introuvable.")
        except (KeyError, ValueError, OSError) as e:
            return self._err(400, str(e))
        except RuntimeError as e:
            return self._err(502, str(e))

    def _upload(self, name):
        ext = Path(name).suffix.lower()
        ext = ext if ext in VIDEO_EXT else ".mp4"
        pid = new_project(name, "source" + ext)
        left = int(self.headers.get("Content-Length") or 0)
        with open(pdir(pid) / ("source" + ext), "wb") as f:
            while left > 0:
                chunk = self.rfile.read(min(1 << 20, left))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        self._send(200, {"pid": pid})


def start(port=0):
    fonts.ensure_fonts()
    transcribe.ensure_mlx()
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, "http://localhost:%d" % srv.server_address[1]


if __name__ == "__main__":
    srv, url = start(int(os.environ.get("PORT", "8765")))
    print("OMAGAD (mode navigateur) : %s" % url)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass
