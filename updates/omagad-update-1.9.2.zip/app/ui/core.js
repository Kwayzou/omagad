/* Noyau : état, appels au moteur, navigation, annuler/rétablir, dialogues. */
const VC = window.VC = {};
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const clone = o => JSON.parse(JSON.stringify(o));
function fmt(s, dec) {
  s = Math.max(0, s || 0);
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
  const xs = dec ? x.toFixed(1).padStart(4, '0') : String(Math.floor(x)).padStart(2, '0');
  return h ? h + ':' + String(m).padStart(2, '0') + ':' + xs : m + ':' + xs;
}
Object.assign(VC, { $, $$, esc, clamp, sleep, clone, fmt });

VC.api = async function (path, body) {
  const opt = body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'vlog-clips' }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || ('Erreur ' + r.status));
  return j;
};
VC.poll = async function (jobId, onTick) {
  for (;;) {
    const j = await VC.api('/api/job/' + jobId);
    onTick && onTick(j);
    if (j.done) return j;
    await sleep(700);
  }
};
let toastT = 0;
VC.toast = function (msg, ms) { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, ms || 3200); };
VC.confirm = function (title, text, yes) {
  return new Promise(res => {
    const d = $('#dlgConfirm'); $('#confirmTitle').textContent = title; $('#confirmText').textContent = text || ''; $('#confirmYes').textContent = yes || 'Confirmer';
    d.returnValue = ''; d.onclose = () => res(d.returnValue === 'yes'); d.showModal();
  });
};
VC.native = () => !!(window.pywebview && window.pywebview.api);

/* ---------- État ---------- */
VC.S = { state: null, project: null, wave: null, view: 'import', sel: null, filter: 'all' };
VC.style = m => Object.assign({}, VC.S.state.settings.style, m.style || {});

/* Groupes de mots des sous-titres (même règle que le moteur de rendu) */
VC.makeChunks = function (t0, t1, per) {
  const strip = /[.,;:«»"“”…()]/g, stop = /[.!?…,;]$/, ws = [], out = [];
  for (const w of VC.S.project.words || []) {
    const t = w.w.replace(strip, '').trim();
    if (t && /[\p{L}\p{N}]/u.test(t) && w.e > t0 && w.s < t1) ws.push({ w: t, s: w.s, e: w.e, stop: stop.test(w.w) });
  }
  let cur = [];
  ws.forEach((w, i) => {
    cur.push(w); const nx = ws[i + 1];
    if (!nx || cur.length >= per || cur.reduce((a, x) => a + x.w.length, 0) >= 18 || w.stop || nx.s - w.e > 0.5) {
      out.push({ s: cur[0].s, e: cur[cur.length - 1].e, words: cur.map(x => ({ w: x.w, s: x.s, e: x.e })) });
      cur = [];
    }
  });
  return out;
};
VC.chunksOf = function (m) { return m.subs || VC.makeChunks(m.t0, m.t1, VC.style(m).sub_words); };

/* ---------- Sauvegarde et historique ---------- */
const H = { undo: [], redo: [], last: null, timer: 0 };
VC.resetHistory = function () { H.undo = []; H.redo = []; H.last = JSON.stringify(VC.S.project.moments); updateUndo(); };
function persist() { return VC.api('/api/save/' + VC.S.project.id, { moments: VC.S.project.moments }).catch(e => VC.toast(e.message)); }
function flush() {
  clearTimeout(H.timer); H.timer = 0;
  const cur = JSON.stringify(VC.S.project.moments);
  if (cur === H.last) return;
  H.undo.push(H.last); if (H.undo.length > 200) H.undo.shift();
  H.redo = []; H.last = cur; persist(); updateUndo();
}
VC.commit = function (now) { if (!VC.S.project) return; clearTimeout(H.timer); if (now) flush(); else H.timer = setTimeout(flush, 400); };
function restore(json) { VC.S.project.moments = JSON.parse(json); H.last = json; persist(); updateUndo(); VC.refresh && VC.refresh(); }
VC.undo = function () { if (H.timer) flush(); if (!H.undo.length) return; H.redo.push(H.last); restore(H.undo.pop()); VC.toast('Modification annulée'); };
VC.redo = function () { if (!H.redo.length) return; H.undo.push(H.last); restore(H.redo.pop()); };
function updateUndo() { $('#btnUndo').disabled = !H.undo.length && !H.timer; $('#btnRedo').disabled = !H.redo.length; }

/* ---------- Navigation ---------- */
VC.screens = {};
VC.go = function (view) {
  if (view !== 'import' && !(VC.S.project && VC.S.project.lines)) return;
  if (VC.S.view === 'montage' && VC.leaveMontage) VC.leaveMontage();
  if (H.timer) flush();
  VC.S.view = view;
  $$('#steps button').forEach(b => {
    b.setAttribute('aria-current', b.dataset.go === view ? 'page' : 'false');
    b.disabled = b.dataset.go !== 'import' && !(VC.S.project && VC.S.project.lines);
  });
  $('#projName').textContent = VC.S.project ? VC.S.project.name : '';
  $('#btnUndo').hidden = $('#btnRedo').hidden = view === 'import';
  VC.refresh = null;
  VC.screens[view]();
};
$('#steps').addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b && !b.disabled) VC.go(b.dataset.go); });
$('#btnUndo').onclick = () => VC.undo();
$('#btnRedo').onclick = () => VC.redo();

VC.openProject = async function (pid, warning) {
  const p = await VC.api('/api/project/' + pid);
  VC.S.project = p; VC.S.sel = null;
  VC.S.wave = null;
  if (!p.lines) return VC.go('import');
  VC.S.wave = await VC.api('/api/wave/' + pid).catch(() => null);
  if (VC.S.wave && VC.S.wave.v === 2) {
    const dec = b => { const s = atob(b || ''), u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; };
    VC.S.wave.peaks = dec(VC.S.wave.peak); VC.S.wave.rmsA = dec(VC.S.wave.rms);
  }
  for (const m of p.moments) { if (!m.style) m.style = clone(VC.S.state.settings.style); VC.migrateStyle(m.style); if (!m.frame) m.frame = { mode: 'fill', fx: .5, fy: .5, zoom: 1, punch: true }; }
  VC.resetHistory();
  if (warning) VC.toast(warning, 6000);
  VC.go('montage');
};

/* ---------- Polices ---------- */
VC.loadFonts = function () {
  $('#fontFaces').textContent = (VC.S.state.fonts || []).map(f => '@font-face{font-family:"' + f.family.replace(/"/g, '') + '";src:url("' + f.url + '");font-weight:' + (f.weight >= 900 ? '800 1000' : f.weight >= 700 ? '600 799' : '100 599') + ';}').join('\n');
};
VC.fontList = function () {
  const sys = ['League Spartan', 'Montserrat', 'Futura', 'Impact', 'Arial Black', 'Helvetica Neue', 'Avenir Next', 'Avenir Next Condensed', 'Gill Sans', 'Arial Narrow', 'Georgia', 'Marker Felt'];
  return [...new Set(sys.concat((VC.S.state.fonts || []).map(f => f.family)))];
};

/* ---------- Réglages ---------- */
function openSettings() {
  const s = VC.S.state.settings;
  $('#sKey').value = ''; $('#sKeyNote').textContent = s.has_key ? 'Clé enregistrée (' + s.key_hint + '). Laisse vide pour la garder.' : 'Sans clé, les moments sont choisis automatiquement mais les accroches seront moins bonnes.';
  $('#sModel').value = s.claude_model; $('#sWhisper').value = s.whisper_model; $('#sLang').value = s.language || '';
  $('#sUiLang').value = VC.lang ? VC.lang() : 'fr'; $('#sRepo').value = s.update_repo || ''; $('#sClips').value = String(s.clips_target || 0); $('#sLen').value = s.clips_length || 'medium';
  $('#dlgSettings').showModal();
}
$('#btnSettings').onclick = openSettings;
$('#btnCloseSettings').onclick = () => $('#dlgSettings').close();
$('#btnKeysOpen').onclick = () => { $('#dlgSettings').close(); VC.openShortcuts(); };
VC.makeDmg = async function () {
  const b = $('#btnDmg'), msg = $('#dmgMsg');
  if (!VC.native()) return VC.toast('L\'installateur se crée dans l\'application OMAGAD sur Mac.');
  if (b) b.disabled = true;
  VC.toast('Création de l\'installateur… (1 à 3 minutes)', 4000);
  try {
    const r = await VC.api('/api/make-dmg', { engine: $('#dmgEngine') ? $('#dmgEngine').checked : true });
    const j = await VC.poll(r.job, x => { if (msg) msg.textContent = x.message || ''; });
    if (j.error) throw new Error(j.error);
    if (msg) msg.textContent = '';
    VC.toast('Installateur prêt sur ton Bureau : ' + j.result.file.split('/').pop() + (j.result.layout ? '' : ' (mise en page Finder refusée : autorise OMAGAD à contrôler le Finder)'), 8000);
  } catch (e) { VC.toast(e.message, 8000); if (msg) msg.textContent = ''; }
  if (b) b.disabled = false;
};
$('#btnDmg').onclick = () => VC.makeDmg();
$('#btnFontsDir').onclick = () => VC.api('/api/fonts-folder', {}).catch(e => VC.toast(e.message));
$('#formSettings').onsubmit = async () => {
  try {
    await VC.api('/api/settings', { api_key: $('#sKey').value.trim(), claude_model: $('#sModel').value.trim(), whisper_model: $('#sWhisper').value, language: $('#sLang').value,
      clips_target: +$('#sClips').value, clips_length: $('#sLen').value, update_repo: $('#sRepo').value.trim() });
    VC.S.state = await VC.api('/api/state');
    if ($('#sUiLang').value !== VC.lang()) VC.setLang($('#sUiLang').value, true); else VC.toast('Réglages enregistrés');
    if (VC.S.view === 'import') VC.go('import');
  } catch (e) { VC.toast(e.message); }
};
VC.saveSettings = async function (patch) { await VC.api('/api/settings', patch); VC.S.state = await VC.api('/api/state'); };

/* ---------- Menu natif de l'app (OMAGAD ▸ …) ---------- */
VC.menu = function (what) {
  document.querySelectorAll('dialog[open]').forEach(d => { if (d.id !== 'dlgKeys' || what !== 'shortcuts') d.close(); });
  if (what === 'settings') openSettings();
  else if (what === 'shortcuts') VC.openShortcuts();
  else if (what === 'account') VC.openAccount ? VC.openAccount() : $('#btnAccount').click();
  else if (what === 'update') $('#btnUpdate').click();
  else if (what === 'dmg') VC.makeDmg();
  else if (what === 'guide') VC.startGuide && VC.startGuide();
  else if (what === 'lang:en' || what === 'lang:fr') VC.setLang(what.slice(5), true);
};

/* ---------- Lecteur de clip exporté ---------- */
VC.play = function (file, title) {
  $('#playerTitle').textContent = title || ''; $('#playerVideo').src = '/file?path=' + encodeURIComponent(file);
  $('#playerReveal').onclick = () => VC.api('/api/reveal', { path: file });
  const d = $('#dlgPlayer'); d.onclose = () => $('#playerVideo').pause(); d.showModal();
};

/* ---------- Clavier ---------- */
document.addEventListener('keydown', e => { if (VC.handleShortcut) VC.handleShortcut(e); });

VC.boot = async function () {
  try { VC.S.state = await VC.api('/api/state'); } catch (e) { $('#view').innerHTML = '<div class="empty">' + esc(e.message) + '</div>'; return; }
  VC.initLang(VC.S.state.settings.lang);
  VC.loadFonts();
  VC.go('import');
};

/* Police avec remplaçant si elle n'est pas encore téléchargée */
VC.cssFont = function (fam) {
  const fb = { 'League Spartan': 'Futura', 'Montserrat': '"Avenir Next"' }[fam] || 'Impact';
  return '"' + fam + '", ' + fb + ', "Arial Black", sans-serif';
};

/* ---------- Règles du montage (mêmes que engine/edit.py) ---------- */
VC.hookAt = m => Math.max(0, +m.hook_at || 0);
VC.outOffset = st => VC.sfxOutOffset(st);
/* Sons du moment : liste explicite, sinon entrée/sortie de l'accroche définies dans le style */
VC.sfxOf = function (m) {
  if (Array.isArray(m.sfx)) return m.sfx;
  if (!(m.hook || '').trim()) return [];
  const st = VC.style(m), h = VC.hookAt(m), out = [];
  if (st.sfx_in && st.sfx_in !== 'none') out.push({ id: 'in', sound: st.sfx_in, at: h, vol: +st.sfx_in_vol, link: 'in' });
  if (st.sfx_out && st.sfx_out !== 'none') out.push({ id: 'out', sound: st.sfx_out, at: h + VC.outOffset(st), vol: +st.sfx_out_vol, link: 'out' });
  return out;
};
VC.ownSfx = function (m) { if (!Array.isArray(m.sfx)) m.sfx = VC.clone(VC.sfxOf(m)); return m.sfx; };
VC.sfxDur = id => { const s = (VC.S.state.sfx || []).find(x => x.id === id); return s ? Math.max(.12, s.dur || .5) : .5; };
VC.sfxLabel = id => { const s = (VC.S.state.sfx || []).find(x => x.id === id); return s ? VC.t(s.label) : id; };
VC.uid = p => p + Math.random().toString(36).slice(2, 8);
/* L'accroche bouge : les sons liés à son entrée/sortie suivent */
VC.moveHook = function (m, at, secs) {
  const st = VC.style(m), oldAt = VC.hookAt(m), oldOut = oldAt + VC.outOffset(st);
  m.hook_at = Math.round(Math.max(0, at) * 100) / 100;
  if (secs != null) { m.style = m.style || {}; m.style.hook_secs = Math.round(Math.max(.8, secs) * 100) / 100; }
  if (Array.isArray(m.sfx)) {
    const st2 = VC.style(m);
    m.sfx.forEach(s => { if (s.link === 'in') s.at += m.hook_at - oldAt; if (s.link === 'out') s.at = m.hook_at + VC.outOffset(st2) + (s.at - oldOut); });
  }
};
VC.ownSubs = function (m) { if (!m.subs) m.subs = VC.clone(VC.makeChunks(m.t0, m.t1, VC.style(m).sub_words)); return m.subs; };
VC.fxAt = function (m, rel) {
  const f = m.frame || {}, k = f.auto && f.keys;
  if (!k || !k.length) return f.fx == null ? .5 : f.fx;
  if (rel <= k[0][0]) return k[0][1];
  for (let i = 0; i < k.length - 1; i++) if (rel <= k[i + 1][0]) { const [ta, va] = k[i], [tb, vb] = k[i + 1]; return va + (vb - va) * (rel - ta) / Math.max(1e-6, tb - ta); }
  return k[k.length - 1][1];
};
