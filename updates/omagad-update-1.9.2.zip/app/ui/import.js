/* Écran Import : dépôt du vlog, analyse automatique, projets récents. */
(function () {
  const { $, $$, esc, fmt, api } = { ...VC, api: VC.api };
  const STEPS = [['prepare', 'Préparation', 'Vidéo et son'], ['transcribe', 'Transcription', 'Parole mot par mot'], ['moments', 'Moments forts', 'Choix et accroches'], ['done', 'Prêt', 'À vérifier']];
  let busy = false, pyDrop = false;

  VC.screens.import = function () {
    const s = VC.S.state, set = s.settings, view = $('#view');
    const checks = '<div class="checks"><span class="' + (!s.ffmpeg ? 'bad' : s.ffmpeg_ass ? '' : 'mid') + '">' + (s.ffmpeg && !s.ffmpeg_ass ? 'ffmpeg incomplet (voir Export)' : 'ffmpeg') + '</span><span class="' + (s.whisper ? '' : 'bad') + '">' + (s.engine === 'apple' ? 'Transcription · puce Apple' : s.engine === 'installing' ? 'Transcription · moteur rapide en installation' : 'Transcription') + '</span>' +
      '<span class="' + (set.has_key ? '' : 'mid') + '">' + (set.has_key ? 'Claude connecté' : 'Sans clé API') + '</span></div>';
    const projs = s.projects.length ? '<section><div class="section-head"><h2 style="font-size:16px">Projets récents</h2><span class="hint">' + s.projects.length + ' projet(s)</span></div><div class="projects">' +
      s.projects.map(p => '<div class="proj" role="button" tabindex="0" data-id="' + p.id + '"><div class="th" style="background-image:' + (p.thumb ? 'url(/media/' + p.id + '/thumb)' : 'none') + '"></div>' +
        '<div class="meta"><b>' + esc(p.name) + '</b><div class="row"><span class="hint mono">' + (p.duration ? fmt(p.duration) : '--') + ' · ' + p.moments + ' moments</span>' +
        (p.status === 'ready' ? '<span class="badge ' + (p.validated ? 'ok' : 'todo') + '">' + p.validated + '/' + p.moments + ' validés</span>' : '<span class="badge">Inachevé</span>') +
        (p.missing ? '</div><div class="row"><span class="badge skip">Vidéo introuvable</span><button class="btn small" type="button" data-relink="' + p.id + '">Retrouver la vidéo</button>' : '') +
        '</div><div class="row"><span></span><button class="btn ghost small danger" type="button" data-del="' + p.id + '">Supprimer</button></div></div></div>').join('') + '</div></section>' : '';
    view.innerHTML = '<div class="import"><div id="dropArea">' +
      '<div class="drop" id="drop"><div class="big-icon"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M6 10l6-6 6 6M4 20h16"/></svg></div>' +
      '<h1>Dépose ton vlog</h1><p>L\'application transcrit ce que tu dis, repère les meilleurs moments et prépare un clip vertical pour chacun, avec son accroche. Tu n\'as plus qu\'à vérifier.</p>' +
      '<button class="btn primary big" type="button" id="btnPick">Choisir une vidéo</button><span class="hint">MP4, MOV, MKV... La vidéo reste sur ton Mac.</span>' + checks + '</div></div>' +
      '<input type="file" id="fileInput" accept="video/*,.mkv,.mts" hidden>' + autoCard() + '<div id="queueBox"></div>' + projs + '</div>';
    bindAuto(); pollQueue();
    if (!s.ffmpeg) VC.toast('ffmpeg est introuvable. Installe-le avec Homebrew : brew install ffmpeg', 8000);
    const dz = $('#drop');
    $('#btnPick').onclick = async () => {
      if (busy) return;
      if (VC.native()) {
        const ps = window.pywebview.api.pick_videos ? await window.pywebview.api.pick_videos() : [await window.pywebview.api.pick_video()].filter(Boolean);
        if (ps && ps.length > 1) VC.queueVideos(ps); else if (ps && ps[0]) VC.importPath(ps[0]);
      }
      else $('#fileInput').click();
    };
    $('#fileInput').onchange = e => { if (e.target.files[0]) uploadFile(e.target.files[0]); };
    dz.ondragover = e => { e.preventDefault(); dz.classList.add('over'); };
    dz.ondragleave = () => dz.classList.remove('over');
    dz.ondrop = async e => {
      e.preventDefault(); dz.classList.remove('over');
      const f = e.dataTransfer.files[0]; if (!f || busy) return;
      if (f.pywebviewFullPath) return VC.importPath(f.pywebviewFullPath);
      if (VC.native()) { pyDrop = false; await VC.sleep(500); if (pyDrop) return; }
      uploadFile(f);
    };
    $$('.proj').forEach(el => {
      el.onclick = async e => {
        const rl = e.target.closest('[data-relink]');
        if (rl) { e.stopPropagation(); return VC.relink(rl.dataset.relink); }
        const del = e.target.closest('[data-del]');
        if (del) {
          e.stopPropagation();
          if (await VC.confirm('Supprimer ce projet ?', 'Les moments et la transcription seront effacés. Ta vidéo d\'origine et les clips exportés ne sont pas touchés.', 'Supprimer')) {
            await api('/api/delete/' + del.dataset.del, {}); VC.S.state = await api('/api/state'); VC.go('import');
          }
          return;
        }
        resume(el.dataset.id);
      };
      el.onkeydown = e => { if (e.key === 'Enter') el.click(); };
    });
  };

  /* ---------- Mode automatique ---------- */
  function autoCard() {
    const st = VC.S.state.settings, styles = st.styles || [];
    return '<section class="auto-card' + (st.auto_mode ? ' on' : '') + '"><div class="ac-head"><label class="switch"><input type="checkbox" id="acOn"' + (st.auto_mode ? ' checked' : '') + '><i></i></label>' +
      '<div><b>Mode automatique</b><span class="hint">Dépose un ou plusieurs vlogs : OMAGAD trouve les moments, garde les meilleurs, applique ton style et exporte tout seul. Tu retrouves les clips dans ton dossier d\'export.</span></div></div>' +
      '<div class="ac-opts"' + (st.auto_mode ? '' : ' hidden') + '>' +
      '<div class="field"><label for="acCount">Clips exportés par vlog</label><select id="acCount">' + [[5, '5 meilleurs'], [10, '10 meilleurs'], [15, '15 meilleurs'], [20, '20 meilleurs'], [0, 'Tous les moments trouvés']].map(o => '<option value="' + o[0] + '"' + (+st.auto_count === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></div>' +
      '<div class="field"><label for="acStyle">Style</label><select id="acStyle"><option value="">Style par défaut</option>' + styles.map(x => '<option' + (x.name === st.auto_style ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('') + '</select></div>' +
      '<label class="check"><input type="checkbox" id="acCrop"' + (st.auto_autocrop !== false ? ' checked' : '') + '> Recadrage automatique sur le visage</label></div></section>';
  }
  function bindAuto() {
    const on = $('#acOn'); if (!on) return;
    on.onchange = async () => { await VC.saveSettings({ auto_mode: on.checked }); $('.auto-card').classList.toggle('on', on.checked); $('.ac-opts').hidden = !on.checked; };
    $('#acCount').onchange = e => VC.saveSettings({ auto_count: +e.target.value });
    $('#acStyle').onchange = e => VC.saveSettings({ auto_style: e.target.value });
    $('#acCrop').onchange = e => VC.saveSettings({ auto_autocrop: e.target.checked });
  }

  /* ---------- File de vlogs (plusieurs vlogs à la suite) ---------- */
  let queueActive = false, qTimer = 0, wasActive = false;
  VC.queueVideos = async function (paths) {
    try {
      const r = await api('/api/queue-add', { paths, auto: !!VC.S.state.settings.auto_mode });
      VC.toast(r.added + ' vlog' + (r.added > 1 ? 's' : '') + ' ajouté' + (r.added > 1 ? 's' : '') + ' à la file', 2500);
      pollQueue();
    } catch (e) { VC.toast(e.message); }
  };
  async function pollQueue() {
    clearTimeout(qTimer);
    let q; try { q = (await api('/api/queue')).items; } catch (e) { return; }
    queueActive = q.some(e => e.state === 'wait' || e.state === 'run');
    const box = $('#queueBox');
    if (box) {
      box.innerHTML = q.length ? '<section class="queue"><div class="section-head"><h2 style="font-size:16px">File de vlogs</h2>' +
        (queueActive ? '<span class="hint">Tu peux continuer à travailler : tout se fait en arrière-plan.</span>' : '<button class="btn small ghost" type="button" id="qClear">Vider la liste</button>') + '</div>' +
        q.map(e => '<div class="q-item ' + e.state + '"><div class="q-main"><b>' + esc(e.name) + '</b>' + (e.auto ? '<span class="badge">Auto</span>' : '') +
          '<span class="hint">' + esc(e.state === 'wait' ? 'En attente' : e.state === 'done' ? (e.auto ? e.clips + ' clip(s) exporté(s)' : e.moments + ' moments trouvés') : e.message || '') + '</span></div>' +
          '<div class="bar-prog"><i style="width:' + Math.round((e.progress || 0) * 100) + '%"></i></div>' +
          '<div class="q-act">' + (e.state === 'done' ? (e.out_dir ? '<button class="btn small" type="button" data-qdir="' + esc(e.out_dir) + '">Voir les clips</button>' : '') + '<button class="btn small ghost" type="button" data-qopen="' + e.pid + '">Ouvrir</button>' : '') + '</div></div>').join('') + '</section>' : '';
      box.onclick = async ev => {
        const d = ev.target.closest('[data-qdir]'); if (d) return api('/api/reveal', { path: d.dataset.qdir });
        const o = ev.target.closest('[data-qopen]'); if (o) { VC.S.state = await api('/api/state'); return VC.openProject(o.dataset.qopen); }
        if (ev.target.closest('#qClear')) { await api('/api/queue-clear', {}); pollQueue(); }
      };
    }
    if (queueActive) qTimer = setTimeout(pollQueue, 1000);
    else if (wasActive) { VC.S.state = await api('/api/state'); if (VC.S.view === 'import') { wasActive = false; return VC.go('import'); } }
    wasActive = queueActive;
  }

  /* Vidéo déplacée ou renommée : on la retrouve */
  VC.relink = async function (pid) {
    if (!VC.native()) return VC.toast('Le choix de fichier fonctionne dans l\'application OMAGAD.');
    const path = await window.pywebview.api.pick_video(); if (!path) return false;
    try {
      await api('/api/relink', { pid, path }); VC.toast('Vidéo retrouvée', 2000);
      VC.S.state = await api('/api/state'); if (VC.S.project && VC.S.project.id === pid) VC.S.project.source_missing = false;
      if (VC.S.view === 'import') VC.go('import'); else VC.refresh && VC.refresh();
      return true;
    } catch (e) { VC.toast(e.message, 6000); return false; }
  };

  async function resume(pid) {
    const p = await api('/api/project/' + pid);
    if (p.lines) return VC.openProject(pid);
    analyze(pid, p.name);
  }
  VC.importPath = async function (path) {
    pyDrop = true;
    if (VC.S.state.settings.auto_mode || busy || queueActive) return VC.queueVideos([path]);
    try { const r = await api('/api/import', { path }); analyze(r.pid, path.split(/[\\/]/).pop()); } catch (e) { VC.toast(e.message); }
  };
  function uploadFile(file) {
    showAnalysis(file.name);
    setStage('prepare', 0, 'Copie du fichier dans l\'application...');
    const x = new XMLHttpRequest();
    x.open('POST', '/api/upload?name=' + encodeURIComponent(file.name));
    x.setRequestHeader('X-Requested-With', 'vlog-clips');
    x.upload.onprogress = e => { if (e.lengthComputable) setStage('prepare', e.loaded / e.total * .05, 'Copie : ' + Math.round(e.loaded / 1e6) + ' / ' + Math.round(e.total / 1e6) + ' Mo'); };
    x.onerror = () => fail('Copie impossible.');
    x.onload = () => { let j = {}; try { j = JSON.parse(x.responseText); } catch (e) {} if (x.status >= 300 || !j.pid) return fail(j.error || 'Copie impossible.'); analyze(j.pid, file.name, true); };
    x.send(file);
  }
  function showAnalysis(name) {
    busy = true;
    $('#dropArea').innerHTML = '<div class="analysis"><div><div class="label">Analyse en cours</div><h2>' + esc(name) + '</h2></div>' +
      '<div class="stepper">' + STEPS.map(s => '<div data-st="' + s[0] + '"><b>' + s[1] + '</b><span class="hint">' + s[2] + '</span></div>').join('') + '</div>' +
      '<div class="bar-prog"><i id="anaBar"></i></div><div class="hint" id="anaMsg"></div><div id="anaErr"></div>' +
      '<p class="hint" style="margin:0">Tu peux laisser l\'application tourner : la transcription d\'un vlog de 30 minutes prend en général 5 à 15 minutes. Au tout premier lancement, le modèle de transcription se télécharge.</p></div>';
  }
  function setStage(stage, frac, msg) {
    let before = true;
    $$('.stepper [data-st]').forEach(el => {
      const cur = el.dataset.st === stage;
      el.className = cur ? 'on' : before ? 'done' : '';
      if (cur) before = false;
    });
    const b = $('#anaBar'); if (b) b.style.width = Math.round(frac * 100) + '%';
    const m = $('#anaMsg'); if (m) m.textContent = msg || '';
  }
  function fail(msg, pid) {
    busy = false;
    const box = $('#anaErr'); if (!box) return VC.toast(msg);
    box.innerHTML = '<div class="analysis" style="border-color:var(--danger);padding:14px;flex-direction:row;align-items:center;justify-content:space-between"><span>' + esc(msg) + '</span><span style="display:flex;gap:6px">' +
      (pid ? '<button class="btn small" type="button" id="btnRetry">Réessayer</button>' : '') + '<button class="btn small ghost" type="button" id="btnHome">Retour</button></span></div>';
    if (pid) $('#btnRetry').onclick = () => analyze(pid, '');
    $('#btnHome').onclick = async () => { VC.S.state = await api('/api/state'); VC.go('import'); };
  }
  async function analyze(pid, name, keep) {
    if (!keep || !$('.analysis')) showAnalysis(name || 'Vlog');
    try {
      const r = await api('/api/analyze', { pid });
      const j = await VC.poll(r.job, j => setStage(j.stage || 'prepare', j.progress, j.message));
      if (j.error) return fail(j.error, pid);
      setStage('done', 1, 'Terminé');
      busy = false;
      VC.S.state = await api('/api/state');
      await VC.openProject(pid, j.warning);
    } catch (e) { fail(e.message, pid); }
  }
  VC.redetect = async function () {
    const p = VC.S.project;
    if (!await VC.confirm('Chercher de nouveaux moments ?', 'Les moments actuels seront remplacés. Tu pourras revenir en arrière avec Annuler.', 'Relancer')) return;
    VC.toast('Recherche des moments...', 20000);
    try {
      const r = await api('/api/redetect/' + p.id, {});
      const j = await VC.poll(r.job);
      if (j.error) throw new Error(j.error);
      const fresh = await api('/api/project/' + p.id);
      p.moments = fresh.moments.map(m => Object.assign(m, { style: VC.clone(VC.S.state.settings.style) }));
      VC.commit(true);
      VC.toast(j.warning || (p.moments.length + ' moments trouvés'), 5000);
      VC.refresh && VC.refresh();
    } catch (e) { VC.toast(e.message); }
  };
})();
