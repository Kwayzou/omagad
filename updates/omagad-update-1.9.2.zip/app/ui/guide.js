/* Petit guide au premier lancement : quelques bulles qui montrent où tout se trouve. */
(function () {
  const { $, esc } = VC;
  const STEPS = [
    { sel: '#drop', title: 'Dépose ton vlog ici', text: 'Glisse une vidéo (ou plusieurs à la fois) dans cette zone. OMAGAD transcrit ce que tu dis et trouve les meilleurs moments tout seul.' },
    { sel: '.auto-card', title: 'Mode automatique', text: 'Active-le pour que les clips soient exportés directement, sans passer par le montage. Pratique pour lancer plusieurs vlogs le soir.' },
    { sel: '[data-go="montage"]', title: 'Montage', text: 'Vérifie chaque moment : accroche, sous-titres mot par mot, sons, musique, photos, cadrage. Tout se règle à droite et sur la timeline.' },
    { sel: '[data-go="export"]', title: 'Export', text: 'Rends tes clips en 1080 × 1920 pour TikTok, Reels et Shorts, ou envoie la timeline dans DaVinci Resolve.' },
    { sel: '.pill-group', title: 'Mises à jour et compte', text: 'Les nouvelles versions d\'OMAGAD apparaissent ici. Ton compte ajoute ton nom d\'artiste et tes hashtags aux descriptions.' },
    { sel: null, title: 'Astuces', text: '⌘/ ouvre les raccourcis clavier (tous modifiables), ⌘, les réglages. Le menu OMAGAD en haut de l\'écran permet de changer de langue et de revoir ce guide.' }
  ];
  let i = 0, box = null;

  function place() {
    const s = STEPS[i], el = s.sel && document.querySelector(s.sel);
    const hole = box.querySelector('.g-hole'), tip = box.querySelector('.g-tip');
    tip.innerHTML = '<div class="g-n">' + (i + 1) + ' / ' + STEPS.length + '</div><b>' + esc(VC.t(s.title)) + '</b><p>' + esc(VC.t(s.text)) + '</p>' +
      '<div class="g-act"><button class="btn small ghost" type="button" data-g="skip">' + esc(VC.t('Passer')) + '</button>' +
      (i ? '<button class="btn small" type="button" data-g="prev">' + esc(VC.t('Retour')) + '</button>' : '') +
      '<button class="btn small primary" type="button" data-g="next">' + esc(VC.t(i === STEPS.length - 1 ? 'C\'est parti' : 'Suivant')) + '</button></div>';
    if (el) {
      const r = el.getBoundingClientRect(), pad = 8;
      Object.assign(hole.style, { display: 'block', left: r.left - pad + 'px', top: r.top - pad + 'px', width: r.width + pad * 2 + 'px', height: r.height + pad * 2 + 'px' });
      const tw = 340, below = r.bottom + 14 + 190 < innerHeight;
      Object.assign(tip.style, { left: Math.max(16, Math.min(innerWidth - tw - 16, r.left + r.width / 2 - tw / 2)) + 'px', top: (below ? r.bottom + 14 : Math.max(16, r.top - 14 - tip.offsetHeight)) + 'px', transform: 'none' });
    } else {
      hole.style.display = 'none';
      Object.assign(tip.style, { left: '50%', top: '40%', transform: 'translate(-50%, -50%)' });
    }
  }
  function close(done) {
    if (box) { box.remove(); box = null; }
    removeEventListener('resize', place);
    if (done) VC.saveSettings({ guide_done: true });
  }
  VC.startGuide = function () {
    if (VC.S.view !== 'import') VC.go('import');
    close(false); i = 0;
    box = document.createElement('div'); box.className = 'guide';
    box.innerHTML = '<div class="g-hole"></div><div class="g-tip" role="dialog" aria-live="polite"></div>';
    document.body.appendChild(box);
    box.onclick = e => {
      const g = (e.target.closest('[data-g]') || {}).dataset; if (!g) return;
      if (g.g === 'skip') return close(true);
      if (g.g === 'prev') i = Math.max(0, i - 1);
      if (g.g === 'next') { if (i === STEPS.length - 1) return close(true); i++; }
      place();
    };
    addEventListener('resize', place);
    setTimeout(place, 50);
  };
  document.addEventListener('keydown', e => { if (box && e.key === 'Escape') { e.stopPropagation(); close(true); } }, true);

  const boot = VC.boot;
  VC.boot = async function () {
    await boot();
    if (VC.S.state && VC.S.state.settings && !VC.S.state.settings.guide_done) setTimeout(VC.startGuide, 900);
  };
})();
