'use strict';
let E; try { E = require('electron/renderer'); } catch (e) { E = require('electron'); }  // anciennes versions de DaVinci
const { contextBridge, ipcRenderer } = E;
const call = ch => (...a) => ipcRenderer.invoke(ch, ...a);
contextBridge.exposeInMainWorld('omagad', {
  state: call('state'), dates: call('dates'), date: call('date'), job: call('job'), cancel: call('cancel'), port: call('port'),
  openOmagad: call('openOmagad'), editInOmagad: call('editInOmagad'), sendTimeline: call('sendTimeline'), runDate: call('runDate'),
  importTimelines: call('importTimelines'), importVideos: call('importVideos'), reveal: call('reveal'),
  onProgress: cb => { const l = (_e, d) => cb(d); ipcRenderer.on('progress', l); return () => ipcRenderer.removeListener('progress', l); },
  onJob: cb => { const l = (_e, d) => cb(d); ipcRenderer.on('job', l); return () => ipcRenderer.removeListener('job', l); }
});
