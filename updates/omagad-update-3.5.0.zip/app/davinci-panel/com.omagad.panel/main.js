'use strict';
/*
 * OMAGAD dans DaVinci Resolve Studio (Espace de travail ▸ Workflow Integrations ▸ OMAGAD).
 * - parle à DaVinci par WorkflowIntegration.node (fourni par DaVinci, copié ici à l'installation) ;
 * - parle à OMAGAD par son serveur local (le port est écrit dans ~/Library/Application Support/OMAGAD/server.json).
 */
const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const { execFile } = require('child_process');

const PLUGIN_ID = 'com.omagad.panel';
let WI = null, wiError = '';
try { WI = require('./WorkflowIntegration.node'); } catch (e) { wiError = e && e.message ? e.message : String(e); }

let win = null, resolvePromise = null;

/* ------------------------------------------------------------------ OMAGAD */
function dataDir() {
  if (process.env.OMAGAD_DATA) return process.env.OMAGAD_DATA;
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'OMAGAD');
  return path.join(process.env.APPDATA || os.homedir(), 'OMAGAD');
}
function omagadPort() {
  try { return JSON.parse(fs.readFileSync(path.join(dataDir(), 'server.json'), 'utf8')).port; } catch (e) { return null; }
}
function api(p, body, timeout) {
  return new Promise((resolve, reject) => {
    const port = omagadPort();
    if (!port) return reject(new Error('OMAGAD est fermé.'));
    const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const req = http.request({ host: '127.0.0.1', port, path: p, method: data ? 'POST' : 'GET', timeout: timeout || 15000,
      headers: Object.assign({ 'X-Requested-With': 'vlog-clips', Host: '127.0.0.1:' + port }, data ? { 'Content-Type': 'application/json', 'Content-Length': data.length } : {}) }, res => {
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', c => buf += c);
      res.on('end', () => {
        let j = null; try { j = JSON.parse(buf); } catch (e) { /* */ }
        if (res.statusCode >= 400) return reject(new Error((j && (j.error || j.message)) || ('Erreur OMAGAD ' + res.statusCode)));
        resolve(j);
      });
    });
    req.on('timeout', () => req.destroy(new Error('OMAGAD ne répond pas.')));
    req.on('error', e => reject(e.code === 'ECONNREFUSED' ? new Error('OMAGAD est fermé.') : e));
    if (data) req.write(data);
    req.end();
  });
}
async function pollJob(id, onTick) {
  for (;;) {
    const j = await api('/api/job/' + id);
    if (onTick) onTick(j);
    if (j.done) { if (j.error) throw new Error(j.error); return j; }
    await new Promise(r => setTimeout(r, 700));
  }
}
function openOmagad() {
  if (process.platform === 'darwin') execFile('open', ['-a', 'OMAGAD'], () => {});
}

/* ------------------------------------------------------------------ DaVinci */
async function getResolve() {
  if (!WI) throw new Error('Module DaVinci introuvable (' + wiError + '). Réinstalle le panneau depuis OMAGAD.');
  if (resolvePromise) return resolvePromise;
  resolvePromise = (async () => {
    const ok = WI.InitializePromise ? await WI.InitializePromise(PLUGIN_ID) : WI.Initialize(PLUGIN_ID);
    if (!ok) throw new Error('DaVinci refuse la connexion (scripting désactivé ?).');
    const r = WI.GetResolvePromise ? await WI.GetResolvePromise() : WI.GetResolve();
    if (!r) throw new Error('DaVinci ne répond pas.');
    return r;
  })().catch(e => { resolvePromise = null; throw e; });
  return resolvePromise;
}
async function ctx() {
  const resolve = await getResolve();
  const pm = await resolve.GetProjectManager();
  const project = pm && await pm.GetCurrentProject();
  if (!project) throw new Error('Ouvre un projet dans DaVinci.');
  return { resolve, project };
}
const send = (ch, data) => { if (win && !win.isDestroyed()) win.webContents.send(ch, data); };
const progress = (msg, frac) => send('progress', { msg, frac });

function tc(frame, fps) {
  const r = Math.round(fps), f = Math.round(frame), p = n => String(n).padStart(2, '0');
  return p(Math.floor(f / (3600 * r))) + ':' + p(Math.floor(f / (60 * r)) % 60) + ':' + p(Math.floor(f / r) % 60) + ':' + p(f % r);
}
async function subFolder(mp, name) {
  const root = await mp.GetRootFolder();
  const subs = (await root.GetSubFolderList()) || [];
  for (const f of subs) { if ((await f.GetName()) === name) return f; }
  return (await mp.AddSubFolder(root, name)) || root;
}
async function constant(resolve, name) {
  try { const v = await resolve[name]; return v; } catch (e) { return undefined; }
}

/* envoie la timeline ouverte à LIVEAGAD (comme le script, mais en un clic) */
async function sendTimeline(generate) {
  const { resolve, project } = await ctx();
  const tl = await project.GetCurrentTimeline();
  if (!tl) throw new Error('Ouvre la timeline de ta date dans DaVinci.');
  const name = ((await project.GetName()) + ' - ' + (await tl.GetName())).replace(/[\\/:*?"<>|]+/g, '-');
  const dir = path.join(dataDir(), 'davinci-inbox', 'panneau');
  fs.mkdirSync(dir, { recursive: true });
  progress('Export de la timeline depuis DaVinci…', .15);
  const names = {};
  const nv = (await tl.GetTrackCount('video')) || 0;
  for (let i = 1; i <= nv; i++) names[i] = (await tl.GetTrackName('video', i)) || '';
  const none = (await constant(resolve, 'EXPORT_NONE')) || 0;
  const tries = [['EXPORT_FCP_7_XML', '.xml'], ['EXPORT_FCPXML_1_10', '.fcpxml'], ['EXPORT_FCPXML_1_9', '.fcpxml']];
  let file = null;
  for (const [k, ext] of tries) {
    const c = await constant(resolve, k);
    if (c === undefined || c === null) continue;
    const f = path.join(dir, name + ext);
    try { if (await tl.Export(f, c, none)) { file = f; break; } } catch (e) { /* format suivant */ }
  }
  if (!file) throw new Error('DaVinci n\'a pas pu exporter la timeline. Utilise Fichier ▸ Exporter ▸ Timeline (FCP 7 XML) puis glisse-la dans OMAGAD.');
  progress('Import dans LIVEAGAD…', .5);
  const r = await api('/api/live/import', { path: file, names });
  if (generate) await runDate(r.lid);
  progress('Timeline envoyée à LIVEAGAD', 1);
  return r.lid;
}

async function runDate(lid) {
  const st = (await api('/api/state')).settings || {};
  const opts = { count: st.live_count || 100, length: st.live_length || 'mix', cams: st.live_cams || 'all',
    punch: st.live_punch !== false, tracking: st.live_tracking !== false, out_dir: st.out_dir };
  const r = await api('/api/live/run', { lid, opts });
  send('job', { lid, job: r.job });
  return r.job;
}

/* importe des clips comme timelines verticales retouchables (coupes, cadrage, couleur, LUT, texte) */
async function importTimelines(lid, ns) {
  const { resolve, project } = await ctx();
  progress('OMAGAD prépare les timelines…', .05);
  const r = await api('/api/live/davinci-prepare', { lid, ns });
  const j = await pollJob(r.job, x => progress(x.message || 'Préparation…', .05 + .25 * (x.progress || 0)));
  const rows = j.result.rows || [];
  const mp = await project.GetMediaPool();
  const folder = await subFolder(mp, 'LIVEAGAD - ' + j.result.name);
  await mp.SetCurrentFolder(folder);
  let done = 0, last = null;
  for (const row of rows) {
    progress('Timeline ' + (done + 1) + ' / ' + rows.length + ' : ' + row.name, .3 + .7 * done / rows.length);
    const tl = await mp.ImportTimelineFromFile(row.xml, { timelineName: row.name, importSourceClips: true });
    if (!tl) continue;
    await project.SetCurrentTimeline(tl);
    for (const [k, v] of [['useCustomSettings', '1'], ['timelineResolutionWidth', '1080'], ['timelineResolutionHeight', '1920'], ['timelineInputResMismatchBehavior', 'scaleToFill']]) {
      try { await tl.SetSetting(k, v); } catch (e) { /* réglage refusé */ }
    }
    const items = (await tl.GetItemListInTrack('video', 1)) || [];
    for (let i = 0; i < items.length; i++) {
      const it = items[i], f = row.frames[i];
      if (f) {
        try { await it.SetProperty('Pan', f.pan); await it.SetProperty('Tilt', f.tilt || 0); await it.SetProperty('ZoomX', f.zoom); await it.SetProperty('ZoomY', f.zoom); } catch (e) { /* */ }
      }
      if (row.cdl) {
        const c = row.cdl;
        try { await it.SetCDL({ NodeIndex: '1', Slope: c.slope.map(x => x.toFixed(4)).join(' '), Offset: [c.offset, c.offset, c.offset].map(x => x.toFixed(4)).join(' '), Power: '1 1 1', Saturation: c.sat.toFixed(4) }); } catch (e) { /* */ }
      }
      if (row.lut) {
        let ok = false;
        try { const g = it.GetNodeGraph ? await it.GetNodeGraph() : null; if (g && g.SetLUT) ok = await g.SetLUT(1, row.lut); } catch (e) { /* */ }
        if (!ok) { try { await it.SetLUT(1, row.lut); } catch (e) { /* */ } }
      }
    }
    if (row.text) await addText(tl, row.text);
    done++; last = tl;
  }
  if (last) { try { await project.SetCurrentTimeline(last); await resolve.OpenPage('edit'); } catch (e) { /* */ } }
  progress(done + ' timeline' + (done > 1 ? 's' : '') + ' importée' + (done > 1 ? 's' : '') + ' dans DaVinci', 1);
  return done;
}
async function addText(tl, t) {
  try {
    await tl.AddTrack('video');
    const nv = await tl.GetTrackCount('video');
    for (let v = 1; v < nv; v++) await tl.SetTrackLock('video', v, true);
    const fps = parseFloat(await tl.GetSetting('timelineFrameRate')) || 25;
    await tl.SetCurrentTimecode(tc((await tl.GetStartFrame()) + t.at, fps));
    const ti = await tl.InsertFusionTitleIntoTimeline('Text+');
    if (ti) {
      try {
        const comp = await ti.GetFusionCompByIndex(1);
        const tool = comp && await comp.FindToolByID('TextPlus');
        if (tool) { await tool.SetInput('StyledText', t.txt); await tool.SetInput('Center', [0.5, 1 - t.y]); await tool.SetInput('Size', 0.09); }
      } catch (e) { /* texte à écrire à la main dans l'inspecteur */ }
    }
    for (let v = 1; v < nv; v++) await tl.SetTrackLock('video', v, false);
  } catch (e) { /* pas de titre */ }
}

/* importe les vidéos exportées (1.mp4, 2.mp4…) dans le Media Pool, et les pose au bout de la timeline ouverte si demandé */
async function importVideos(lid, ns, append) {
  const { project } = await ctx();
  const d = await api('/api/live/' + lid);
  const files = d.clips.filter(c => (!ns || ns.includes(c.n)) && c.file && c.state === 'done').map(c => c.file).filter(f => fs.existsSync(f));
  if (!files.length) throw new Error('Aucun clip exporté à importer (exporte-les d\'abord dans OMAGAD).');
  progress('Import de ' + files.length + ' vidéo' + (files.length > 1 ? 's' : '') + '…', .3);
  const mp = await project.GetMediaPool();
  await mp.SetCurrentFolder(await subFolder(mp, 'LIVEAGAD - ' + d.name));
  const items = (await mp.ImportMedia(files)) || [];
  if (append && items.length) {
    const tl = await project.GetCurrentTimeline();
    if (!tl) throw new Error('Ouvre une timeline pour y poser les clips.');
    await mp.AppendToTimeline(items);
  }
  progress(items.length + ' vidéo' + (items.length > 1 ? 's' : '') + ' importée' + (items.length > 1 ? 's' : '') + (append ? ' et posée' + (items.length > 1 ? 's' : '') + ' sur la timeline' : ' dans le Media Pool'), 1);
  return items.length;
}

/* ------------------------------------------------------------------ IPC */
function wrap(fn) {
  return async (_e, ...args) => {
    try { return { ok: true, data: await fn(...args) }; } catch (e) { progress('', 0); return { ok: false, error: e && e.message ? e.message : String(e) }; }
  };
}
function registerIpc() {
  ipcMain.handle('state', wrap(async () => {
    const out = { omagad: null, resolve: null };
    try { const s = await api('/api/ping', undefined, 4000); out.omagad = { version: s.version, port: omagadPort() }; } catch (e) { out.omagad = { error: e.message }; }
    try {
      const { project } = await ctx();
      const tl = await project.GetCurrentTimeline();
      out.resolve = { project: await project.GetName(), timeline: tl ? await tl.GetName() : null };
    } catch (e) { out.resolve = { error: e.message }; }
    return out;
  }));
  ipcMain.handle('dates', wrap(async () => api('/api/live')));
  ipcMain.handle('date', wrap(async lid => api('/api/live/' + lid)));
  ipcMain.handle('job', wrap(async id => api('/api/job/' + id)));
  ipcMain.handle('cancel', wrap(async id => api('/api/cancel/' + id, {})));
  ipcMain.handle('port', wrap(async () => omagadPort()));
  ipcMain.handle('openOmagad', wrap(async () => openOmagad()));
  ipcMain.handle('editInOmagad', wrap(async (lid, n) => { await api('/api/ui/goto', { view: 'liveedit', lid, n }); openOmagad(); return true; }));
  ipcMain.handle('sendTimeline', wrap(async generate => sendTimeline(generate)));
  ipcMain.handle('runDate', wrap(async lid => runDate(lid)));
  ipcMain.handle('importTimelines', wrap(async (lid, ns) => importTimelines(lid, ns)));
  ipcMain.handle('importVideos', wrap(async (lid, ns, append) => importVideos(lid, ns, append)));
  ipcMain.handle('reveal', wrap(async p => shell.showItemInFolder(p)));
}

function createWindow() {
  win = new BrowserWindow({
    width: 470, height: 820, minWidth: 380, minHeight: 520, useContentSize: true, backgroundColor: '#05070d', title: 'OMAGAD',
    autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), sandbox: true, contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.on('closed', () => { win = null; });
  win.on('close', () => app.quit());
}

app.whenReady().then(() => { registerIpc(); createWindow(); });
app.on('window-all-closed', () => app.quit());
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
app.on('before-quit', () => { if (WI) { try { WI.CleanUp(); } catch (e) { /* */ } } });
