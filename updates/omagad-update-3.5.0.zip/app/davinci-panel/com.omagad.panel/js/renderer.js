'use strict';
/* Panneau OMAGAD dans DaVinci : état, envoi de la timeline, génération, import des clips. */
(function () {
  const $ = s => document.querySelector(s);
  const O = window.omagad;
  const S = { port: null, connected: false, dates: [], lid: null, data: null, sel: new Set(), job: null, busy: false };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = t => { t = Math.round(t || 0); return t >= 3600 ? Math.floor(t / 3600) + ':' + String(Math.floor(t / 60) % 60).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0') : Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  let store = {}; try { store = JSON.parse(localStorage.getItem('omagad') || '{}'); } catch (e) { store = {}; }
  const remember = () => { try { localStorage.setItem('omagad', JSON.stringify({ lid: S.lid })); } catch (e) { /* */ } };

  function foot(msg, kind) { const f = $('#foot'); f.textContent = msg || 'Clique un clip pour le sélectionner · double-clic pour le retoucher dans OMAGAD'; f.className = 'foot muted' + (kind ? ' ' + kind : ''); }
  function prog(msg, frac) {
    const p = $('#prog');
    if (!msg && !frac) { p.hidden = true; return; }
    p.hidden = false; $('#progBar').style.width = Math.round((frac || 0) * 100) + '%'; $('#progMsg').textContent = msg || '';
    if (frac >= 1) setTimeout(() => { if (!S.job && !S.busy) p.hidden = true; }, 2500);
  }
  O.onProgress(d => prog(d.msg, d.frac));
  O.onJob(d => { if (d.lid === S.lid) follow(d.job); });

  /* ---------- état d'OMAGAD et de DaVinci ---------- */
  async function refreshState() {
    const r = await O.state(); if (!r.ok) return;
    const s = r.data, om = $('#stOm'), dv = $('#stDv');
    const okOm = s.omagad && !s.omagad.error;
    om.className = 'chip ' + (okOm ? 'ok' : 'bad');
    om.querySelector('span').textContent = okOm ? 'OMAGAD ' + (s.omagad.version || '') : 'OMAGAD fermé';
    $('#btnOpenOm').hidden = okOm;
    const okDv = s.resolve && !s.resolve.error;
    dv.className = 'chip ' + (okDv ? 'ok' : 'bad');
    dv.querySelector('span').textContent = okDv ? s.resolve.project : s.resolve.error;
    dv.title = okDv ? s.resolve.project : s.resolve.error;
    $('#tlName').textContent = okDv ? (s.resolve.timeline || 'aucune timeline ouverte') : '—';
    $('#btnSend').disabled = !(okOm && okDv && s.resolve.timeline) || S.busy;
    if (okOm) { S.port = s.omagad.port; if (!S.connected) { S.connected = true; loadDates(); } }
    else S.connected = false;
  }

  /* ---------- dates et clips ---------- */
  async function loadDates(pick) {
    const r = await O.dates(); if (!r.ok) return foot(r.error, 'err');
    S.dates = r.data.items || [];
    const want = pick || S.lid || store.lid;
    S.lid = S.dates.some(d => d.id === want) ? want : (S.dates[0] || {}).id || null;
    $('#selDate').innerHTML = S.dates.length ? S.dates.map(d => '<option value="' + d.id + '"' + (d.id === S.lid ? ' selected' : '') + '>' + esc(d.name) + ' · ' + d.clips + ' clips</option>').join('') : '<option value="">Aucune date : envoie une timeline</option>';
    if (r.data.running && r.data.running.lid === S.lid && !S.job) follow(r.data.running.job);
    await loadDate();
  }
  async function loadDate() {
    if (S.loaded !== S.lid) { S.sel.clear(); S.data = null; }
    S.loaded = S.lid;
    if (!S.lid) { paint(); return; }
    remember();
    const r = await O.date(S.lid); if (!r.ok) { foot(r.error, 'err'); paint(); return; }
    S.data = r.data; paint();
  }
  function paint() {
    const d = S.data, g = $('#grid');
    $('#btnRun').disabled = !d || S.busy;
    $('#btnAll').disabled = !d || !d.clips.length;
    if (!d) { $('#dateFacts').textContent = ''; g.innerHTML = '<div class="empty">' + (S.connected ? 'Envoie la timeline de ta date pour commencer.' : 'Ouvre OMAGAD pour voir tes clips.') + '</div>'; selBar(); return; }
    const tl = d.timeline, an = d.analysis, done = d.clips.filter(c => c.state === 'done').length;
    $('#dateFacts').innerHTML = '<span>' + fmt(tl.duration) + '</span><span>' + tl.cams.length + ' caméra' + (tl.cams.length > 1 ? 's' : '') + '</span>' +
      (an ? '<span>' + Math.round(an.bpm) + ' BPM</span><span>' + an.drops.length + ' drops</span>' : '') + '<span>' + done + ' / ' + d.clips.length + ' exportés</span>';
    $('#btnRun').textContent = S.job ? 'Arrêter' : !d.clips.length ? 'Générer les clips' : done < d.clips.length ? 'Reprendre l\'export' : 'Regénérer les clips';
    $('#btnRun').disabled = false;
    g.innerHTML = d.clips.length ? d.clips.map(c => {
      const img = c.file && (c.state === 'done' || c.state === 'edited') && S.port ? '<img loading="lazy" src="http://127.0.0.1:' + S.port + '/livethumb/' + S.lid + '/' + c.n + '.jpg?v=' + encodeURIComponent((c.file || '').length + c.state) + '" alt="">' : '';
      const st = c.state === 'edited' ? '<span class="stt edited">à réexporter</span>' : c.state === 'error' ? '<span class="stt error">erreur</span>' : c.state === 'done' ? '' : '<span class="stt wait">en attente</span>';
      return '<div class="clip' + (S.sel.has(c.n) ? ' sel' : '') + '" data-n="' + c.n + '" title="' + esc(c.error || c.label) + '"><div class="th">' + img + '<span class="n">' + c.n + '</span><span class="ck">✓</span>' + st + '</div><div class="lab">' + esc(c.label) + '</div></div>';
    }).join('') : '<div class="empty">' + (S.job ? 'Génération en cours…' : 'Pas encore de clips : clique « Générer les clips ».') + '</div>';
    selBar();
  }
  function selBar() {
    const n = S.sel.size; $('#selBar').hidden = !n;
    $('#selCount').textContent = n + ' clip' + (n > 1 ? 's' : '') + ' → DaVinci';
    $('#btnAll').textContent = S.data && S.data.clips.length && n === S.data.clips.length ? 'Tout désélectionner' : 'Tout sélectionner';
    $$btns();
  }
  function $$btns() { ['#btnImpTl', '#btnImpVid', '#btnImpApp'].forEach(s => { $(s).disabled = S.busy; }); }

  /* ---------- génération (suivi de la tâche OMAGAD) ---------- */
  async function follow(job) {
    if (S.job === job) return;
    S.job = job; paint();
    let lastRefresh = 0;
    for (;;) {
      const r = await O.job(job);
      if (!r.ok) break;
      const j = r.data;
      prog(j.message || 'Génération…', j.progress || 0);
      if (Date.now() - lastRefresh > 4000) { lastRefresh = Date.now(); const x = await O.date(S.lid); if (x.ok) { S.data = x.data; paint(); } }
      if (j.done) { foot(j.error || j.message, j.error ? 'err' : 'ok'); break; }
      await new Promise(res => setTimeout(res, 1000));
    }
    S.job = null; prog('', 0); await loadDates(S.lid);
  }

  /* ---------- actions ---------- */
  async function busy(fn) {
    if (S.busy) return; S.busy = true; paint(); $('#btnSend').disabled = true;
    try { await fn(); } finally { S.busy = false; paint(); refreshState(); }
  }
  $('#btnOpenOm').onclick = () => { O.openOmagad(); foot('Ouverture d\'OMAGAD…'); };
  $('#btnRefresh').onclick = () => loadDates(S.lid);
  $('#selDate').onchange = e => { S.lid = e.target.value; loadDate(); };
  $('#btnSend').onclick = () => busy(async () => {
    foot('');
    const r = await O.sendTimeline($('#chkGen').checked);
    if (!r.ok) return foot(r.error, 'err');
    foot('Timeline envoyée à LIVEAGAD' + ($('#chkGen').checked ? ' : génération lancée' : ''), 'ok');
    await loadDates(r.data);
  });
  $('#btnRun').onclick = async () => {
    if (S.job) { await O.cancel(S.job); return; }
    const r = await O.runDate(S.lid);
    if (!r.ok) return foot(r.error, 'err');
    follow(r.data);
  };
  $('#btnAll').onclick = () => {
    if (!S.data) return;
    if (S.sel.size === S.data.clips.length) S.sel.clear(); else S.data.clips.forEach(c => S.sel.add(c.n));
    paint();
  };
  $('#grid').onclick = e => {
    const el = e.target.closest('.clip'); if (!el) return;
    const n = +el.dataset.n; S.sel.has(n) ? S.sel.delete(n) : S.sel.add(n);
    el.classList.toggle('sel', S.sel.has(n)); selBar();
  };
  $('#grid').ondblclick = async e => {
    const el = e.target.closest('.clip'); if (!el) return;
    const r = await O.editInOmagad(S.lid, +el.dataset.n);
    foot(r.ok ? 'Clip ' + el.dataset.n + ' ouvert dans OMAGAD' : r.error, r.ok ? 'ok' : 'err');
  };
  const ns = () => [...S.sel].sort((a, b) => a - b);
  $('#btnImpTl').onclick = () => busy(async () => { const r = await O.importTimelines(S.lid, ns()); foot(r.ok ? r.data + ' timeline(s) importée(s) dans DaVinci' : r.error, r.ok ? 'ok' : 'err'); });
  $('#btnImpVid').onclick = () => busy(async () => { const r = await O.importVideos(S.lid, ns(), false); foot(r.ok ? r.data + ' vidéo(s) dans le Media Pool' : r.error, r.ok ? 'ok' : 'err'); });
  $('#btnImpApp').onclick = () => busy(async () => { const r = await O.importVideos(S.lid, ns(), true); foot(r.ok ? r.data + ' vidéo(s) posée(s) sur la timeline' : r.error, r.ok ? 'ok' : 'err'); });

  refreshState();
  setInterval(refreshState, 2500);
  setInterval(() => { if (S.connected && !S.job && !S.busy && document.hasFocus()) loadDates(S.lid); }, 15000);
})();
