"""LIVEAGAD : montage d'un clip directement dans l'app (comme Dropfinder, ou la page Cut de DaVinci).

- proxies : chaque caméra est réduite (540p, image clé toutes les 0,5 s) sur la fenêtre du clip ± PAD secondes,
  pour lire tous les angles en même temps et couper en direct ;
- montage : plans (coupes, angle, cadrage, zoom), zooms « punch », couleur (look / LUT .cube, exposition, contraste,
  saturation, température), son (gain, fondus), texte (accroche animée au style de CLIPAGAD) ;
- les mêmes réglages servent au rendu (live.render_clip) et à l'envoi dans DaVinci (live_resolve).
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

from . import media
from .config import DATA
from .media import NOWIN

PAD = 6.0
PH = 540
LUTS = DATA / "luts"
LOOKS = [("club", "Club chaud"), ("nuit", "Nuit froide"), ("teal", "Teal & orange"), ("punch", "Vif"),
         ("vintage", "Vintage"), ("nb", "Noir & blanc")]
COLOR_DEF = {"look": "", "mix": 1.0, "exposure": 0.0, "contrast": 1.0, "saturation": 1.0, "temp": 0.0}
AUDIO_DEF = {"gain_db": 0.0, "fade_in": 0.04, "fade_out": 0.35}


def _f(v, lo, hi, default):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return default
    if v != v:
        return default
    return min(hi, max(lo, v))


def edir(d, clip):
    if not re.match(r"^[a-z]\d{3,4}$", clip.get("id") or ""):
        raise ValueError("Clip inconnu.")
    return d / "edit" / clip["id"]


def window(tl, clip):
    return max(0.0, clip["t0"] - PAD), min(tl["duration"], clip["t1"] + PAD)


# ====================================================================== proxies
def _encoder():
    av = media.encoders()
    if "libx264" in av:
        return ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "27", "-g", "15", "-keyint_min", "15", "-tune", "fastdecode"]
    if "h264_videotoolbox" in av:
        return ["-c:v", "h264_videotoolbox", "-b:v", "2500k", "-g", "15", "-allow_sw", "1"]
    return ["-c:v", "mpeg4", "-q:v", "5", "-g", "15"]


def _run(cmd, job=None):
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, **NOWIN)
    if job is not None:
        job["proc"] = p
    _, err = p.communicate()
    if job is not None:
        job["proc"] = None
    if p.returncode != 0:
        if job is not None and job.get("cancel"):
            raise InterruptedError("Annulé.")
        raise RuntimeError("ffmpeg : " + (err or b"").decode("utf-8", "replace").strip()[-300:])


def _wave(path, per_sec=100):
    """Crêtes du son (0-1) pour la piste A1 de l'éditeur."""
    import numpy as np
    try:
        raw = subprocess.run([media.FFMPEG, "-v", "error", "-i", str(path), "-ac", "1", "-ar", "8000", "-f", "s16le", "-"],
                             capture_output=True, timeout=120, **NOWIN).stdout
    except Exception:
        return []
    x = np.abs(np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0)
    n = 8000 // per_sec
    if len(x) < n:
        return []
    x = x[: len(x) // n * n].reshape(-1, n).max(axis=1)
    top = float(np.percentile(x, 99.5)) or 1.0
    return [round(float(v), 3) for v in np.clip(x / top, 0, 1)]


def ensure_proxies(tl, d, clip, tracker, an=None, job=None, on_progress=lambda f, m="": None, tracking=True):
    """Prépare (ou réutilise) les proxies des caméras et le son de la fenêtre du clip. Renvoie les infos de l'éditeur."""
    from .live import _covering, beat_grid
    w0, w1 = window(tl, clip)
    e = edir(d, clip)
    sig = json.dumps([round(w0, 2), round(w1, 2), PH, bool(tracking),
                      [[[it["src"], round(it["in"], 3), round(a, 3), round(b, 3)] for a, b, it in _covering(c, w0, w1)] for c in tl["cams"]]])
    mf = e / "meta.json"
    if mf.exists():
        try:
            meta = json.loads(mf.read_text(encoding="utf-8"))
            if meta.get("sig") == sig and all((e / ("cam%d.mp4" % c["k"])).exists() for c in meta["cams"]) and (e / "audio.m4a").exists():
                return meta
        except (OSError, ValueError):
            pass
    shutil.rmtree(e, ignore_errors=True)
    e.mkdir(parents=True, exist_ok=True)
    D = w1 - w0
    steps = len(tl["cams"]) * (2 if tracking else 1) + 1
    done = [0]

    def tick(msg):
        done[0] += 1
        on_progress(min(0.99, done[0] / steps), msg)
    _run([media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", "%.3f" % w0, "-t", "%.3f" % D, "-i", str(d / "mix.m4a"),
          "-c:a", "aac", "-b:a", "160k", "-ar", "48000", str(e / "audio.m4a")], job)
    tick("Son du clip prêt")
    cams = []
    for k, cam in enumerate(tl["cams"]):
        cov = [(a, b, it) for a, b, it in _covering(cam, w0, w1) if Path(it["src"]).exists()]
        sw, sh = 1920, 1080
        if cov:
            try:
                inf = tracker.probe(cov[0][2]["src"])
                sw, sh = inf["width"] or sw, inf["height"] or sh
            except Exception:
                pass
        pw = max(2, int(round(PH * sw / max(1, sh) / 2)) * 2)
        cmd = [media.FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
               "-f", "lavfi", "-i", "color=c=black:s=%dx%d:r=30:d=%.3f" % (pw, PH, D)]
        graph, last = "", "0:v"
        for i, (a, b, it) in enumerate(cov):
            src_in = it["in"] + (a - it["t0"])
            cmd += (["-hwaccel", "videotoolbox"] if sys.platform == "darwin" else []) + \
                ["-ss", "%.3f" % max(0.0, src_in), "-t", "%.3f" % (b - a), "-i", it["src"]]
            graph += ("[%d:v:0]fps=30,scale=%d:%d:force_original_aspect_ratio=decrease,pad=%d:%d:(ow-iw)/2:(oh-ih)/2,setsar=1,"
                      "setpts=PTS-STARTPTS+%.3f/TB[p%d];[%s][p%d]overlay=eof_action=pass:repeatlast=0[b%d];"
                      % (i + 1, pw, PH, pw, PH, a - w0, i, last, i, i))
            last = "b%d" % i
        graph += "[%s]format=yuv420p[out]" % last
        _run(cmd + ["-filter_complex", graph, "-map", "[out]", "-t", "%.3f" % D, "-an"] + _encoder() +
             ["-pix_fmt", "yuv420p", "-movflags", "+faststart", str(e / ("cam%d.mp4" % k))], job)
        tick("Caméra %d / %d prête" % (k + 1, len(tl["cams"])))
        keys = []
        if tracking and cov and sw > sh:
            for a, b, it in cov:
                src_in = it["in"] + (a - it["t0"])
                for t, v in tracker.keys(it["src"], src_in, src_in + (b - a)):
                    if -0.01 <= t <= b - a + 0.01:
                        keys.append([round(a - w0 + t, 3), round(float(v), 4)])
            tick("Suivi du sujet · caméra %d" % (k + 1))
        elif tracking:
            tick("")
        cams.append({"k": k, "name": cam["name"], "role": cam.get("role") or "other", "track": cam.get("track"),
                     "w": pw, "h": PH, "src_w": sw, "src_h": sh, "cover": [[round(a - w0, 3), round(b - w0, 3)] for a, b, _ in cov],
                     "keys": sorted(keys)})
    try:
        tracker.save()
    except Exception:
        pass
    period = (an or {}).get("period") or 60.0 / 125
    anchor = clip["t0"] + (clip.get("drop_rel") or 0.0)
    try:
        beat0 = beat_grid(d, anchor, period)
    except Exception:
        beat0 = anchor
    meta = {"sig": sig, "w0": round(w0, 3), "w1": round(w1, 3), "dur": round(D, 3), "cams": cams, "period": period,
            "beat0": round(beat0 - w0, 4), "wave": _wave(e / "audio.m4a"), "per_sec": 100}
    mf.write_text(json.dumps(meta), encoding="utf-8")
    on_progress(1.0, "Prêt")
    return meta


# ====================================================================== nettoyage d'un montage envoyé par l'interface
def _fill(tl, t0, t1, shots):
    """Plans contigus de t0 à t1 ; là où la caméra choisie n'a pas d'image, on prend une autre caméra (comme _shots)."""
    from .live import _covering
    cams = tl["cams"]
    active = [k for k, c in enumerate(cams) if c.get("role") != "off"] or list(range(len(cams)))
    out = []
    for a, b, j, fr in shots:
        pos = a
        while pos < b - 0.04:
            seg = None
            for k in [j] + [c for c in active if c != j] + [c for c in range(len(cams)) if c not in active and c != j]:
                cov = [c for c in _covering(cams[k], pos, b) if c[0] <= pos + 0.04]
                if cov:
                    seg = (k, cov[0])
                    break
            if seg is None:
                raise ValueError("Aucune caméra n'a d'image à %d:%02d : raccourcis le clip." % (int(pos) // 60, int(pos) % 60))
            k, (sa, sb, it) = seg
            f = dict(fr) if k == j else {}
            if out and out[-1][2] == k and abs(out[-1][1] - pos) < 0.01 and out[-1][3] == f:
                out[-1][1] = round(sb, 3)
            else:
                out.append([round(pos, 3), round(sb, 3), k, f])
            pos = sb
    return out


def clean(tl, clip, data):
    """Valide le montage reçu de l'interface et l'applique au clip."""
    dur = tl["duration"]
    drop_abs = clip["t0"] + clip["drop_rel"] if clip.get("drop_rel") is not None else None
    t0 = _f(data.get("t0"), 0.0, dur, clip["t0"])
    t1 = _f(data.get("t1"), 0.0, dur, clip["t1"])
    if t1 - t0 < 2.0:
        raise ValueError("Un clip doit durer au moins 2 secondes.")
    if t1 - t0 > 180:
        raise ValueError("Un clip ne peut pas dépasser 3 minutes.")
    ncam = len(tl["cams"])
    raw = []
    for sh in data.get("shots") or []:
        try:
            a, b, j = float(sh[0]), float(sh[1]), int(sh[2])
        except (TypeError, ValueError, IndexError):
            continue
        if not 0 <= j < ncam:
            continue
        a, b = max(t0, a), min(t1, b)
        if b - a < 0.05:
            continue
        fr = sh[3] if len(sh) > 3 and isinstance(sh[3], dict) else {}
        f = {}
        if fr.get("x") is not None:
            f["x"] = round(_f(fr.get("x"), 0.0, 1.0, 0.5), 4)
        z = _f(fr.get("zoom"), 1.0, 3.0, 1.0)
        if abs(z - 1.0) > 1e-3:
            f["zoom"] = round(z, 3)
        if fr.get("y") is not None:
            f["y"] = round(_f(fr.get("y"), 0.0, 1.0, 0.5), 4)
        raw.append([a, b, j, f])
    raw.sort(key=lambda s: s[0])
    if not raw:
        raise ValueError("Le clip n'a aucun plan.")
    # contigus : chaque plan commence où le précédent finit
    raw[0][0] = t0
    for p, q in zip(raw, raw[1:]):
        q[0] = p[1] = round((p[1] + q[0]) / 2, 3) if abs(p[1] - q[0]) > 1e-3 else q[0]
    raw[-1][1] = t1
    raw = [s for s in raw if s[1] - s[0] >= 0.05]
    shots = _fill(tl, t0, t1, raw)
    L = t1 - t0
    zooms = sorted({round(_f(z, 0.0, L, 0.0), 3) for z in data.get("zooms") or [] if isinstance(z, (int, float)) and 0 <= z <= L})
    col = dict(COLOR_DEF)
    c = data.get("color") or {}
    col.update({"look": str(c.get("look") or "")[:80], "mix": _f(c.get("mix"), 0, 1, 1.0), "exposure": _f(c.get("exposure"), -2, 2, 0.0),
                "contrast": _f(c.get("contrast"), 0.5, 1.8, 1.0), "saturation": _f(c.get("saturation"), 0, 2, 1.0),
                "temp": _f(c.get("temp"), -1, 1, 0.0)})
    if col["look"] and not lut_path(col["look"]):
        col["look"] = ""
    au = data.get("audio") or {}
    audio = {"gain_db": _f(au.get("gain_db"), -12, 12, 0.0), "fade_in": _f(au.get("fade_in"), 0, 3, 0.04),
             "fade_out": _f(au.get("fade_out"), 0, 5, 0.35)}
    tx = data.get("text") or {}
    text = {"hook": str(tx.get("hook") or "")[:240], "at": _f(tx.get("at"), 0, L, 0.2), "secs": _f(tx.get("secs"), 0.5, L, 3.0),
            "y": _f(tx.get("y"), 0.08, 0.92, 0.3), "sfx": bool(tx.get("sfx"))}
    clip.update(t0=round(t0, 3), t1=round(t1, 3), shots=shots, zooms=zooms, punch=_f(data.get("punch"), 0, 2.5, 1.0),
                color=col, audio=audio, text=text, edited=True)
    clip["drop_rel"] = round(drop_abs - t0, 3) if drop_abs is not None and t0 <= drop_abs <= t1 else None
    clip["state"] = "edited" if clip.get("state") in ("done", "edited") and clip.get("file") else "wait"
    return clip


# ====================================================================== couleur
def _look_fn(name):
    import numpy as np

    def luma(x):
        return (x * np.array([0.2126, 0.7152, 0.0722])).sum(-1, keepdims=True)

    def sat(x, s):
        lum = luma(x)
        return lum + (x - lum) * s

    def curve(x, k):
        return x + k * (x * x * (3 - 2 * x) - x)
    if name == "club":
        return lambda x: sat(curve(x * np.array([1.07, 1.0, 0.88]) + np.array([0.02, 0.005, 0.0]), 0.35), 1.12)
    if name == "nuit":
        return lambda x: sat(curve(x * np.array([0.9, 0.98, 1.08]) + np.array([0.0, 0.01, 0.035]), 0.3), 0.95)
    if name == "teal":
        def f(x):
            lum = luma(x)
            y = x + (1 - lum) * np.array([-0.05, 0.025, 0.06]) + lum * np.array([0.06, 0.012, -0.06])
            return sat(curve(y, 0.25), 1.1)
        return f
    if name == "punch":
        return lambda x: sat(curve(x, 0.55), 1.32)
    if name == "vintage":
        return lambda x: sat(x * np.array([0.86, 0.84, 0.78]) + np.array([0.09, 0.075, 0.07]), 0.78)
    if name == "nb":
        return lambda x: np.repeat(curve(luma(x), 0.45), 3, axis=-1)
    return None


def _write_cube(path, fn, n=33):
    import numpy as np
    g = np.linspace(0, 1, n)
    b, gg, r = np.meshgrid(g, g, g, indexing="ij")  # rouge varie le plus vite (format .cube)
    x = np.stack([r, gg, b], -1).reshape(-1, 3)
    y = np.clip(fn(x), 0, 1)
    lines = ["TITLE \"OMAGAD\"", "LUT_3D_SIZE %d" % n] + ["%.5f %.5f %.5f" % tuple(v) for v in y]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def list_luts():
    out = [{"id": k, "name": n, "builtin": True} for k, n in LOOKS]
    u = LUTS / "user"
    if u.exists():
        for f in sorted(u.glob("*.cube"), key=lambda p: p.name.lower()):
            out.append({"id": "u:" + f.name, "name": f.stem, "builtin": False})
    return out


def lut_path(lid):
    """Fichier .cube d'un look (généré à la demande) ou d'une LUT importée."""
    if not lid:
        return None
    if lid.startswith("u:"):
        f = LUTS / "user" / Path(lid[2:]).name
        return f if f.exists() else None
    if lid not in dict(LOOKS):
        return None
    f = LUTS / ("omagad-%s.cube" % lid)
    if not f.exists():
        _write_cube(f, _look_fn(lid))
    return f


def import_lut(src):
    src = Path(src).expanduser()
    if src.suffix.lower() != ".cube":
        raise ValueError("Choisis une LUT au format .cube (celui de DaVinci).")
    txt = src.read_text(encoding="utf-8", errors="replace")
    if not re.search(r"^\s*LUT_3D_SIZE\s+\d+", txt, re.M):
        raise ValueError("Cette LUT n'est pas une LUT 3D (.cube avec LUT_3D_SIZE).")
    name = re.sub(r"[^A-Za-z0-9 ._-]+", "-", src.stem).strip(" .-")[:60] or "LUT"
    dst = LUTS / "user" / (name + ".cube")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    return "u:" + dst.name


def gains(col):
    ev, t = 2 ** col.get("exposure", 0.0), col.get("temp", 0.0)
    return ev * (1 + 0.12 * t), ev * (1 + 0.015 * t), ev * (1 - 0.12 * t)


def parse_cube(path):
    """LUT 3D .cube → tableau (N, N, N, 3) indexé [b][g][r] (le rouge varie le plus vite dans le fichier)."""
    import numpy as np
    n, rows, lo, hi = 0, [], [0.0, 0.0, 0.0], [1.0, 1.0, 1.0]
    for line in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        up = line.upper()
        if up.startswith("LUT_3D_SIZE"):
            n = int(line.split()[1])
        elif up.startswith("DOMAIN_MIN"):
            lo = [float(x) for x in line.split()[1:4]]
        elif up.startswith("DOMAIN_MAX"):
            hi = [float(x) for x in line.split()[1:4]]
        elif up[0].isdigit() or up[0] in "-.":
            parts = line.split()
            if len(parts) >= 3:
                rows.append([float(parts[0]), float(parts[1]), float(parts[2])])
    if n < 2 or len(rows) < n ** 3:
        raise ValueError("LUT illisible.")
    return np.array(rows[: n ** 3], dtype=np.float32).reshape(n, n, n, 3), np.array(lo), np.array(hi)


def _apply_lut(x, lut):
    """Interpolation trilinéaire d'une LUT sur des couleurs x (…, 3) entre 0 et 1."""
    import numpy as np
    table, lo, hi = lut
    n = table.shape[0]
    p = np.clip((x - lo) / np.maximum(1e-6, hi - lo), 0, 1) * (n - 1)
    i0 = np.clip(np.floor(p).astype(int), 0, n - 2)
    f = p - i0
    r0, g0, b0 = i0[..., 0], i0[..., 1], i0[..., 2]
    fr, fg, fb = f[..., 0:1], f[..., 1:2], f[..., 2:3]
    out = 0
    for db in (0, 1):
        for dg in (0, 1):
            for dr in (0, 1):
                w = (fr if dr else 1 - fr) * (fg if dg else 1 - fg) * (fb if db else 1 - fb)
                out = out + w * table[b0 + db, g0 + dg, r0 + dr]
    return out


def grade(x, col):
    """Même calcul que l'aperçu (ui/liveedit.js) : gains → contraste → saturation → look/LUT (dosé)."""
    import numpy as np
    col = dict(COLOR_DEF, **(col or {}))
    g = np.array(gains(col), dtype=np.float32)
    y = np.clip((x * g - 0.5) * col["contrast"] + 0.5, 0, 1)
    lum = (y * np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)).sum(-1, keepdims=True)
    y = np.clip(lum + (y - lum) * col["saturation"], 0, 1)
    lp = lut_path(col.get("look"))
    if lp and col["mix"] > 0.001:
        y = y + (np.clip(_apply_lut(y, parse_cube(lp)), 0, 1) - y) * col["mix"]
    return y


def is_neutral(col):
    col = dict(COLOR_DEF, **(col or {}))
    return (not col.get("look") or col["mix"] <= 0.001) and abs(col["exposure"]) < 1e-3 and abs(col["contrast"] - 1) < 1e-3 \
        and abs(col["saturation"] - 1) < 1e-3 and abs(col["temp"]) < 1e-3


def color_chain(col, d):
    """Filtre ffmpeg de la couleur : tous les réglages sont « cuits » dans une seule LUT 3D (rapide, identique à l'aperçu)."""
    if not col or is_neutral(col):
        return ""
    import hashlib
    col = dict(COLOR_DEF, **col)
    lp = lut_path(col.get("look"))
    key = json.dumps([col, str(lp), lp.stat().st_mtime if lp else 0], sort_keys=True)
    f = d / "luts" / ("grade-%s.cube" % hashlib.sha1(key.encode()).hexdigest()[:12])
    if not f.exists():
        _write_cube(f, lambda x: grade(x.astype("float32"), col), n=33)
    path = str(f).replace("\\", "/").replace("'", "")
    return "format=rgb24,lut3d=file='%s':interp=tetrahedral" % path


def cdl(col):
    """Équivalent CDL (DaVinci) : pente = gains × contraste, décalage = 0,5 × (1 − contraste), saturation."""
    col = dict(COLOR_DEF, **(col or {}))
    c = col["contrast"]
    g = gains(col)
    return {"slope": [round(x * c, 4) for x in g], "offset": round(0.5 * (1 - c), 4), "sat": round(col["saturation"], 4)}


# ====================================================================== nouveau clip à la main
def new_clip(p, d, t, rules=None, roles=None):
    from . import live
    tl, an = p["timeline"], p.get("analysis") or {}
    period = an.get("period") or 60.0 / max(60.0, an.get("bpm") or 125)
    bar = 4 * period
    dur = tl["duration"]
    drop = min((x["t"] for x in an.get("drops") or []), key=lambda x: abs(x - t), default=None)
    near = drop is not None and abs(drop - t) < 2.5 * bar
    anchor = live.beat_grid(d, drop if near else t, period)
    t0, t1 = (anchor - 4 * bar, anchor + 8 * bar) if near else (anchor - 2 * bar, anchor + 6 * bar)
    t0, t1 = max(0.0, t0), min(dur, t1)
    if t1 - t0 < 3:
        raise ValueError("Trop près du début ou de la fin du set.")
    live._NAMES = roles or live.DEFAULT_ROLES
    active = live._active(tl) or list(range(len(tl["cams"])))
    has_roles = any(tl["cams"][k].get("role") not in (None, "other", "off") for k in active)
    style = "multicam" if len(active) >= 2 else "cam"
    shots, desc = live._shots(tl, t0, t1, anchor if near else None, bar, style, active[0], rules, has_roles)
    if not shots:
        shots, desc = live._shots(tl, t0, t1, None, bar, "cam", active[0], rules, has_roles)
    if not shots:
        raise ValueError("Aucune caméra n'a d'image à cet endroit.")
    used = {c.get("n") for c in p.get("clips") or []}
    n = max(used | {0}) + 1
    ids = {c.get("id") for c in p.get("clips") or []}
    k = 1
    while "m%03d" % k in ids:
        k += 1
    zooms = [round(anchor - t0 + b * bar, 3) for b in range(0, int((t1 - anchor) / bar) + 1, 2)] if near else []
    c = {"id": "m%03d" % k, "kind": "drop" if near else "manual", "t": round(anchor, 3), "t0": round(t0, 3), "t1": round(t1, 3),
         "style": style, "cam": active[0], "shots": shots, "zooms": zooms, "score": 0.0, "n": n, "state": "wait", "edited": True,
         "label": "Manuel " + live._fmt(t) + " · " + desc + " · %d s" % round(t1 - t0), "drop_rel": round(anchor - t0, 3) if near else None}
    return c
