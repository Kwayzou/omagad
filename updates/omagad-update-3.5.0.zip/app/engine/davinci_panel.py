"""Panneau OMAGAD dans DaVinci Resolve Studio (Espace de travail ▸ Workflow Integrations ▸ OMAGAD).

C'est un plugin « Workflow Integration » (une petite app Electron lancée par DaVinci). Il parle à DaVinci par
WorkflowIntegration.node (fourni avec DaVinci) et à OMAGAD par son serveur local (port écrit dans server.json).
"""
import json
import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from .config import ROOT, DATA

PLUGIN_ID = "com.omagad.panel"
SRC = ROOT / "davinci-panel" / PLUGIN_ID
if sys.platform == "darwin":
    PLUGINS = Path("/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins")
    NODE_CANDIDATES = [
        Path("/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Workflow Integrations/Examples/SamplePlugin/WorkflowIntegration.node"),
        Path("/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Resources/Developer/Workflow Integrations/Examples/SamplePlugin/WorkflowIntegration.node"),
        Path("/Applications/DaVinci Resolve Studio/DaVinci Resolve.app/Contents/Resources/Developer/Workflow Integrations/Examples/SamplePlugin/WorkflowIntegration.node"),
    ]
else:
    PLUGINS = Path(os.environ.get("PROGRAMDATA", "C:/ProgramData")) / "Blackmagic Design/DaVinci Resolve/Support/Workflow Integration Plugins"
    NODE_CANDIDATES = [Path(os.environ.get("PROGRAMDATA", "C:/ProgramData")) /
                       "Blackmagic Design/DaVinci Resolve/Support/Developer/Workflow Integrations/Examples/SamplePlugin/WorkflowIntegration.node"]
DEST = PLUGINS / PLUGIN_ID


def _version(folder):
    try:
        txt = (folder / "manifest.xml").read_text(encoding="utf-8")
        return txt.split("<Version>")[1].split("</Version>")[0].strip()
    except (OSError, IndexError):
        return None


def find_node():
    for p in NODE_CANDIDATES:
        if p.exists():
            return p
    # au cas où : on cherche dans les dossiers de DaVinci (versions récentes)
    for base in (Path("/Library/Application Support/Blackmagic Design/DaVinci Resolve"), Path("/Applications")):
        if not base.exists():
            continue
        try:
            out = subprocess.run(["find", str(base), "-maxdepth", "8", "-name", "WorkflowIntegration.node", "-not", "-path", "*" + PLUGIN_ID + "*"],
                                 capture_output=True, text=True, timeout=20).stdout.split("\n")
            hit = next((x for x in out if x.strip()), None)
            if hit:
                return Path(hit.strip())
        except Exception:
            pass
    return None


def status():
    resolve = any(Path(p).exists() for p in ("/Applications/DaVinci Resolve/DaVinci Resolve.app", "/Applications/DaVinci Resolve Studio/DaVinci Resolve.app")) \
        if sys.platform == "darwin" else PLUGINS.parent.exists()
    inst = _version(DEST) if DEST.exists() else None
    return {"supported": sys.platform in ("darwin", "win32"), "resolve": resolve, "installed": inst, "available": _version(SRC),
            "uptodate": bool(inst and inst == _version(SRC) and (DEST / "WorkflowIntegration.node").exists()),
            "node": bool(find_node() or (DEST / "WorkflowIntegration.node").exists()), "folder": str(DEST)}


def _stage():
    """Copie du plugin prête à installer (avec WorkflowIntegration.node de DaVinci)."""
    st = DATA / "davinci-panel" / PLUGIN_ID
    shutil.rmtree(st, ignore_errors=True)
    shutil.copytree(SRC, st)
    node = find_node()
    if node is None and (DEST / "WorkflowIntegration.node").exists():
        node = DEST / "WorkflowIntegration.node"
    if node is None:
        raise RuntimeError("Le module de DaVinci (WorkflowIntegration.node) est introuvable. Installe ou mets à jour DaVinci Resolve Studio "
                           "(il est fourni avec : Developer ▸ Workflow Integrations ▸ Examples ▸ SamplePlugin).")
    shutil.copy2(node, st / "WorkflowIntegration.node")
    return st


def install():
    if sys.platform not in ("darwin", "win32"):
        raise RuntimeError("Le panneau DaVinci existe sur Mac et Windows seulement.")
    st = _stage()
    # 1) sans mot de passe si le dossier est accessible
    try:
        PLUGINS.mkdir(parents=True, exist_ok=True)
        shutil.rmtree(DEST, ignore_errors=True)
        shutil.copytree(st, DEST)
        return dict(status(), ok=True, admin=False)
    except OSError:
        pass
    if sys.platform != "darwin":
        raise RuntimeError("Accès refusé au dossier des plugins de DaVinci : relance OMAGAD en administrateur.")
    # 2) dossier système : macOS demande le mot de passe de l'ordinateur
    sh = "mkdir -p %s && rm -rf %s && cp -R %s %s && chmod -R a+rX %s" % (
        shlex.quote(str(PLUGINS)), shlex.quote(str(DEST)), shlex.quote(str(st)), shlex.quote(str(DEST)), shlex.quote(str(DEST)))
    osa = 'do shell script "%s" with administrator privileges with prompt "OMAGAD veut installer son panneau dans DaVinci Resolve."' % (
        sh.replace("\\", "\\\\").replace('"', '\\"'))
    r = subprocess.run(["osascript", "-e", osa], capture_output=True, text=True, timeout=300)
    if r.returncode != 0:
        if "-128" in (r.stderr or ""):
            raise RuntimeError("Installation annulée.")
        raise RuntimeError("Installation impossible : " + (r.stderr or "").strip()[-200:])
    return dict(status(), ok=True, admin=True)


def server_info():
    try:
        return json.loads((DATA / "server.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
