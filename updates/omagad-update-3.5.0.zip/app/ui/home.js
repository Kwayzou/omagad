/* Accueil : les trois modules côte à côte (Clipagad, Liveagad, Sonagad). */
(function () {
  const { $ } = VC;
  VC.screens.home = function () {
    $('#view').innerHTML = '<div class="home">' +
      '<button type="button" class="mod mod-clip" id="modClip">' +
      '<span class="mod-glow"></span>' +
      '<img src="/ui/logo.png" alt="" class="mod-logo" width="132" height="132">' +
      '<span class="mod-name">CLIPAGAD</span>' +
      '<span class="mod-sub">Tes vlogs transformés en clips verticaux pour TikTok, Reels et Shorts</span>' +
      '<span class="btn primary big mod-go">Ouvrir</span></button>' +
      '<button type="button" class="mod mod-live" id="modLive">' +
      '<span class="mod-glow live"></span>' +
      '<span class="mod-eq" aria-hidden="true">' + Array.from({ length: 9 }, (_, i) => '<i style="--i:' + i + '"></i>').join('') + '</span>' +
      '<span class="mod-name">LIVEAGAD</span>' +
      '<span class="mod-sub">Glisse la timeline DaVinci de ta date : des dizaines de clips de ton set, montés et exportés tout seuls</span>' +
      '<span class="btn primary big mod-go">Ouvrir</span></button>' +
      '<button type="button" class="mod mod-clip mod-sona" id="modSona">' +
      '<span class="mod-glow"></span>' +
      '<span class="mod-logo mod-sona-logo"><svg viewBox="0 0 24 24" width="64" height="64" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><path d="M3 12h2M7 8v8M11 4v16M15 7v10M19 10v4"/></svg></span>' +
      '<span class="mod-name">SONAGAD</span>' +
      '<span class="mod-sub">Répare le son saturé d\'un set ou d\'un concert filmé, et rééquilibre le volume</span>' +
      '<span class="btn primary big mod-go">Ouvrir</span></button>' +
      '</div>';
    $('#modClip').onclick = () => { VC.sound('tick'); VC.go('import'); };
    $('#modLive').onclick = () => { VC.sound('tick'); VC.go('live'); };
    $('#modSona').onclick = () => { VC.sound('tick'); VC.go('sonagad'); };
    VC._homeReady && VC._homeReady();
  };
})();
