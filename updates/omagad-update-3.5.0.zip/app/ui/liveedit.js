/* LIVEAGAD · éditeur de clip (comme Dropfinder ou la page Cut de DaVinci) :
   tous les angles en même temps, coupe en direct en cliquant un angle, cadrage, zooms punch, couleur / LUT, son, texte. */
(function () {
  const { $, $$, esc } = VC;
  const W = 1080, H = 1920;
  const E = VC.LE = { open: false };
  const BASE_TYPES = [{ id: 'booth', name: 'Booth', color: '#f0a53a' }, { id: 'crowd', name: 'Fosse', color: '#e2508c' }, { id: 'foh', name: 'FOH', color: '#3fa9f0' }];
  const TYPES = () => { const t = (VC.S.state.settings || {}).live_roles; return Array.isArray(t) && t.length ? t : BASE_TYPES; };
  const RCOL = r => (TYPES().find(t => t.id === r) || {}).color || (r === 'off' ? '#4a4f5a' : '#8e95a3');
  const RNAME = r => (TYPES().find(t => t.id === r) || {}).name || (r === 'off' ? 'Ignorée' : 'Autre');
  const COLOR_DEF = { look: '', mix: 1, exposure: 0, contrast: 1, saturation: 1, temp: 0 };
  const AUDIO_DEF = { gain_db: 0, fade_in: .04, fade_out: .35 };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const r3 = v => Math.round(v * 1000) / 1000;

  /* ================================================================ ouverture */
  VC.liveEdit = async function (lid, n) {
    E.lid = lid; E.n = n; E.open = true; E.ready = false;
    E.setDur = (VC.L && VC.L.data && VC.L.data.timeline && VC.L.data.timeline.duration) || 1e9;
    $('#view').innerHTML = '<div class="le le-loading"><div class="le-prep"><div class="le-prep-ico">' + ICON.cams + '</div><h2>Préparation du montage</h2>' +
      '<p class="hint" id="lePrepMsg">OMAGAD prépare chaque caméra pour les lire toutes en même temps…</p><div class="bar-prog"><i id="lePrepBar"></i></div>' +
      '<button class="btn ghost" type="button" id="lePrepBack">Retour aux clips</button></div></div>';
    $('#lePrepBack').onclick = close;
    try { await load(false); } catch (e) { VC.toast(e.message, 7000); VC.sound('error'); close(); }
  };

  async function load(rebuild, keepTime) {
    let r = await VC.api('/api/live/edit/open', { lid: E.lid, n: E.n, rebuild: !!rebuild });
    if (!r.ready) {
      const j = await VC.poll(r.job, x => {
        const b = $('#lePrepBar'), m = $('#lePrepMsg');
        if (b) b.style.width = Math.round((x.progress || 0) * 100) + '%';
        if (m && x.message) m.textContent = VC.t(x.message);
      });
      if (j.error) throw new Error(j.error);
      if (!E.open) return;
      r = await VC.api('/api/live/edit/open', { lid: E.lid, n: E.n });
    }
    if (!E.open) return;
    E.meta = r.meta; E.style = Object.assign({}, VC.S.state.settings.style || {}, {}); E.fps = r.fps || 25;
    E.drops = (r.drops || []).filter(t => t >= r.meta.w0 && t <= r.meta.w1);
    E.server = r.clip;
    fromClip(r.clip);
    E.hist = { undo: [], redo: [] }; E.last = snap();
    E.sel = { kind: 'shot', i: 0 }; E.tool = E.tool || 'select';
    E.tab = E.tab || 'plan';
    E.t = keepTime != null ? clamp(keepTime, E.meta.w0, E.meta.w1) : E.c.t0;
    E.ready = true;
    paint();
  }

  /* montage en temps absolus (secondes du set) */
  function fromClip(c) {
    const t0 = c.t0;
    E.c = {
      t0: c.t0, t1: c.t1, label: c.label, n: c.n, id: c.id, state: c.state, file: c.file,
      shots: (c.shots || []).map(s => [s[0], s[1], s[2], Object.assign({}, s[3] || {})]),
      zooms: (c.zooms || []).map(z => r3(z + t0)),
      punch: c.punch == null ? 1 : +c.punch,
      color: Object.assign({}, COLOR_DEF, c.color || {}),
      audio: Object.assign({}, AUDIO_DEF, c.audio || {}),
      text: c.text && c.text.hook ? { hook: c.text.hook, at: r3(t0 + (+c.text.at || 0)), secs: +c.text.secs || 3, y: c.text.y == null ? .3 : +c.text.y, sfx: !!c.text.sfx } : null,
      drop: c.drop_rel != null ? r3(t0 + c.drop_rel) : null
    };
  }
  function toEdit() {
    const c = E.c, t0 = c.t0;
    return {
      t0: c.t0, t1: c.t1, shots: c.shots, zooms: c.zooms.filter(z => z >= c.t0 && z <= c.t1).map(z => r3(z - t0)), punch: c.punch,
      color: c.color, audio: c.audio,
      text: c.text ? { hook: c.text.hook, at: r3(Math.max(0, c.text.at - t0)), secs: c.text.secs, y: c.text.y, sfx: c.text.sfx } : { hook: '' }
    };
  }
  const snap = () => JSON.stringify(E.c);

  /* ================================================================ historique + enregistrement */
  function commit(now) {
    const s = snap();
    if (s === E.last) return;
    E.hist.undo.push(E.last); if (E.hist.undo.length > 200) E.hist.undo.shift();
    E.hist.redo = []; E.last = s;
    E.c.state = E.c.file ? 'edited' : 'wait';
    paintTop(); scheduleSave(now);
  }
  function restore(s) { E.c = JSON.parse(s); E.last = s; fixSel(); scheduleSave(); paintAll(); }
  function undo() { if (!E.hist.undo.length) return; E.hist.redo.push(E.last); restore(E.hist.undo.pop()); VC.toast('Modification annulée', 1500); }
  function redo() { if (!E.hist.redo.length) return; E.hist.undo.push(E.last); restore(E.hist.redo.pop()); }
  let saveT = null, saving = null;
  function scheduleSave(now) { clearTimeout(saveT); saveT = setTimeout(save, now ? 0 : 500); }
  async function save() {
    clearTimeout(saveT); saveT = null;
    const body = { lid: E.lid, n: E.n, edit: toEdit() }, sent = snap();
    const p = (saving || Promise.resolve()).then(async () => {
      try {
        const r = await VC.api('/api/live/edit/save', body);
        E.server = r.clip;
        // le serveur a pu compléter un plan (caméra sans image à cet endroit) : on reprend sa version
        if (snap() === sent && JSON.stringify(r.clip.shots) !== JSON.stringify(E.c.shots) && !drag) {
          E.c.shots = r.clip.shots.map(s => [s[0], s[1], s[2], Object.assign({}, s[3] || {})]); E.last = snap(); fixSel(); paintAll();
        }
        setSaved(true);
      } catch (e) { setSaved(false, e.message); }
    });
    saving = p; await p;
  }
  async function flush() { if (saveT) await save(); else if (saving) await saving; }
  function setSaved(ok, msg) { const el = $('#leSaved'); if (el) { el.textContent = ok ? 'Enregistré' : msg || 'Non enregistré'; el.classList.toggle('err', !ok); } }

  async function close() {
    if (E.ready) { try { await flush(); } catch (e) { /* tant pis */ } }
    stop(); E.open = false; E.ready = false;
    if (E.au) { E.au.pause(); E.au.src = ''; E.au = null; }
    E.vids = [];
    VC.L.lid = E.lid; VC.screens.live();
  }

  /* ================================================================ écran */
  function paint() {
    const m = E.meta;
    $('#view').innerHTML = '<div class="le" id="le">' +
      '<div class="le-top" id="leTop"></div>' +
      '<section class="le-angles"><div class="le-h"><b>Angles</b><span class="hint"><span>clic = couper ici</span> · 1-' + Math.min(9, m.cams.length) + '</span></div><div class="le-grid" id="leAngles"></div>' +
      '<p class="hint le-tip">En lecture, clique un angle pour couper en direct (comme le multicam de DaVinci). À l\'arrêt, il remplace la caméra du plan sous la tête de lecture.</p></section>' +
      '<section class="le-viewer"><div class="le-screen" id="leScreen"><div class="le-phone" id="lePhone"><canvas id="leCv" width="540" height="960"></canvas><div class="ov" id="leHook"></div>' +
      '<div class="le-camtag" id="leCamTag"></div></div></div>' +
      '<div class="le-transport"><button class="icon-btn" type="button" id="lePrev" title="Coupe précédente (↑)">' + ICON.prev + '</button>' +
      '<button class="icon-btn le-play" type="button" id="lePlay" title="Lecture / pause (Espace)">' + ICON.play + '</button>' +
      '<button class="icon-btn" type="button" id="leNext" title="Coupe suivante (↓)">' + ICON.next + '</button>' +
      '<span class="le-tc" id="leTc">00:00:00:00</span>' +
      '<label class="le-tog" title="Lire en boucle entre le début et la fin du clip (L)"><input type="checkbox" id="leLoop" checked> Boucle</label></div></section>' +
      '<section class="le-insp" id="leInsp"></section>' +
      '<section class="le-tl"><div class="le-tlbar"><div class="le-tools"><button type="button" data-tool="select" title="Sélection (A)">' + ICON.select + '</button>' +
      '<button type="button" data-tool="blade" title="Lame : couper un plan (B)">' + ICON.blade + '</button></div>' +
      '<button class="btn small" type="button" id="leSplit" title="Couper à la tête de lecture (Cmd+B)">Couper ici</button>' +
      '<button class="btn small" type="button" id="leAddZoom" title="Zoom punch à la tête de lecture (Z)">+ Zoom</button>' +
      '<button class="btn small" type="button" id="leSetIn" title="Début du clip ici (I)">Début ici</button><button class="btn small" type="button" id="leSetOut" title="Fin du clip ici (O)">Fin ici</button>' +
      '<label class="le-tog" title="Les coupes, zooms et bords se calent sur les temps de la musique"><input type="checkbox" id="leSnap" checked> Caler sur les temps</label>' +
      '<span class="hint le-keys">Espace lecture · 1-9 angle · B lame · Z zoom · I / O début / fin · ⌘Z annuler</span>' +
      '<span class="hint le-tlinfo" id="leTlInfo"></span></div><canvas id="leTl"></canvas></section></div>';
    E.snapOn = true;
    paintTop(); paintAngles(); paintInsp(); setupGL(); bindAll(); setupMedia();
    drawTl(); frame(true);
  }
  function paintAll() { paintTop(); paintAngles(); paintInsp(); drawTl(); frame(true); }

  function stateBadge() {
    const s = E.c.state;
    return s === 'done' ? '<span class="le-st ok">Exporté</span>' : s === 'edited' ? '<span class="le-st warn">Modifié · à réexporter</span>' : '<span class="le-st">Pas encore exporté</span>';
  }
  function paintTop() {
    const el = $('#leTop'); if (!el) return;
    const c = E.c;
    el.innerHTML = '<button class="btn ghost" type="button" id="leBack">' + ICON.back + ' Clips</button>' +
      '<div class="le-title"><b>Clip ' + c.n + '</b><span class="hint">' + esc(c.label || '') + '</span></div>' + stateBadge() +
      '<span class="hint le-saved" id="leSaved"></span>' +
      '<div class="le-acts"><button class="icon-btn" type="button" id="leUndo" title="Annuler (Cmd+Z)"' + (E.hist.undo.length ? '' : ' disabled') + '>' + ICON.undo + '</button>' +
      '<button class="icon-btn" type="button" id="leRedo" title="Rétablir (Cmd+Maj+Z)"' + (E.hist.redo.length ? '' : ' disabled') + '>' + ICON.redo + '</button>' +
      (c.file ? '<button class="btn small" type="button" id="leWatch">Voir l\'export</button>' : '') +
      '<button class="btn small" type="button" id="leDv" title="Envoie ce clip dans DaVinci : timeline verticale avec tes coupes, cadrages, couleur et texte">' + ICON.dv + ' DaVinci</button>' +
      '<button class="btn small danger-ghost" type="button" id="leDel" title="Supprimer ce clip">' + ICON.trash + '</button>' +
      '<button class="btn primary" type="button" id="leExport">' + (E.exporting ? 'Export…' : 'Exporter ce clip') + '</button></div>' +
      '<div class="le-xprog" id="leXprog"' + (E.exporting ? '' : ' hidden') + '><i id="leXbar"></i></div>';
    $('#leBack').onclick = close;
    $('#leUndo').onclick = undo; $('#leRedo').onclick = redo;
    const w = $('#leWatch'); if (w) w.onclick = () => { pause(); VC.play(c.file, 'Clip ' + c.n); };
    $('#leExport').onclick = exportClip; $('#leDv').onclick = sendDavinci; $('#leDel').onclick = delClip;
  }

  /* ---------- angles (multicam) ---------- */
  function paintAngles() {
    const g = $('#leAngles'); if (!g) return;
    const m = E.meta, n = m.cams.length;
    g.style.gridTemplateColumns = 'repeat(' + (n <= 1 ? 1 : n <= 4 ? 2 : 3) + ', minmax(0, 1fr))';
    if (!g.children.length) {
      g.innerHTML = m.cams.map((c, k) => '<button type="button" class="le-ang" data-k="' + k + '" style="--rc:' + RCOL(c.role) + '">' +
        '<video muted playsinline preload="auto" src="/liveedit/' + E.lid + '/' + E.c.id + '/cam' + c.k + '.mp4"></video>' +
        '<span class="le-an">' + (k + 1) + '</span><b>' + esc(RNAME(c.role)) + '</b><i class="le-nocov" hidden>Pas d\'image ici</i></button>').join('');
      E.vids = $$('.le-ang video', g);
    }
    markAngles();
  }
  function markAngles() {
    const sh = shotAt(E.t), act = sh ? sh[2] : -1;
    $$('.le-ang').forEach((b, k) => {
      b.classList.toggle('live', k === act);
      const nc = !hasCover(k, E.t); const i = b.querySelector('.le-nocov'); if (i && i.hidden !== !nc) i.hidden = !nc;
    });
  }
  const hasCover = (k, t) => (E.meta.cams[k].cover || []).some(c => t - E.meta.w0 >= c[0] - .02 && t - E.meta.w0 <= c[1] + .02);

  /* ---------- inspecteur ---------- */
  const TABS = [['plan', 'Plan'], ['color', 'Couleur'], ['zoom', 'Zooms'], ['text', 'Texte'], ['audio', 'Son']];
  function paintInsp() {
    const el = $('#leInsp'); if (!el) return;
    el.innerHTML = '<div class="dv-tabs le-tabs">' + TABS.map(t => '<button type="button" data-tab="' + t[0] + '" aria-pressed="' + (E.tab === t[0]) + '">' + t[1] + '</button>').join('') + '</div>' +
      '<div class="le-ib" id="leIb">' + ({ plan: tabPlan, color: tabColor, zoom: tabZoom, text: tabText, audio: tabAudio }[E.tab])() + '</div>';
    $$('[data-tab]', el).forEach(b => b.onclick = () => { E.tab = b.dataset.tab; paintInsp(); });
    ({ plan: bindPlan, color: bindColor, zoom: bindZoom, text: bindText, audio: bindAudio }[E.tab])();
  }
  const slider = (id, label, min, max, step, val, fmtv) => '<div class="le-sl"><label for="' + id + '">' + label + '</label><input type="range" id="' + id + '" min="' + min + '" max="' + max + '" step="' + step + '" value="' + val + '"><output id="' + id + 'O">' + fmtv(val) + '</output></div>';
  function bindSlider(id, fmtv, set) {
    const el = $('#' + id); if (!el) return;
    el.oninput = () => { set(+el.value); $('#' + id + 'O').textContent = fmtv(+el.value); frame(true); drawTl(); };
    el.onchange = () => commit();
    el.ondblclick = () => { el.value = el.dataset.def || el.defaultValue; el.oninput(); commit(); };
  }
  const pct = v => Math.round(v * 100) + ' %';
  const secs = v => (+v).toFixed(2).replace('.', ',') + ' s';

  function selShot() { if (E.sel.kind === 'shot' && E.c.shots[E.sel.i]) return E.sel.i; const t = E.t; const i = E.c.shots.findIndex(s => t >= s[0] && t < s[1]); return i < 0 ? E.c.shots.length - 1 : i; }
  function tabPlan() {
    const i = selShot(), s = E.c.shots[i], fr = s[3] || {}, cam = E.meta.cams[s[2]];
    const auto = fr.x == null;
    return '<div class="le-shothead" style="--rc:' + RCOL(cam.role) + '"><b>Plan ' + (i + 1) + ' / ' + E.c.shots.length + '</b><span class="hint">' + rel(s[0]) + ' → ' + rel(s[1]) + ' · ' + secs(s[1] - s[0]) + '</span></div>' +
      '<div class="field"><label for="lpCam">Caméra</label><select id="lpCam">' + E.meta.cams.map((c, k) => '<option value="' + k + '"' + (k === s[2] ? ' selected' : '') + '>' + (k + 1) + ' · ' + esc(RNAME(c.role)) + ' (V' + (c.track || k + 1) + ')</option>').join('') + '</select></div>' +
      '<div class="le-seg"><button type="button" id="lpAuto" aria-pressed="' + auto + '">Suivi auto du sujet</button><button type="button" id="lpMan" aria-pressed="' + !auto + '">Cadrage manuel</button></div>' +
      slider('lpX', 'Position', 0, 1, .005, auto ? xAuto(s, E.t) : fr.x, v => Math.round((v - .5) * 200) + '') +
      slider('lpY', 'Hauteur', 0, 1, .005, fr.y == null ? .5 : fr.y, v => Math.round((v - .5) * 200) + '') +
      slider('lpZ', 'Zoom', 1, 3, .01, fr.zoom || 1, pct) +
      '<p class="hint">Astuce : glisse l\'image dans l\'aperçu pour la cadrer, molette pour zoomer.</p>' +
      '<div class="le-row2"><button class="btn small" type="button" id="lpAll">Appliquer à tous les plans de cette caméra</button><button class="btn small ghost" type="button" id="lpReset">Réinitialiser</button></div>' +
      '<div class="le-row2"><button class="btn small" type="button" id="lpSplit">Couper ici</button><button class="btn small" type="button" id="lpMerge"' + (i ? '' : ' disabled') + '>Supprimer la coupe d\'avant</button></div>';
  }
  function bindPlan() {
    const i = selShot(), s = E.c.shots[i];
    $('#lpCam').onchange = e => { s[2] = +e.target.value; s[3] = {}; commit(); paintAll(); };
    $('#lpAuto').onclick = () => { delete s[3].x; commit(); paintInsp(); frame(true); };
    $('#lpMan').onclick = () => { s[3].x = r3(xAuto(s, E.t)); commit(); paintInsp(); frame(true); };
    bindSlider('lpX', v => Math.round((v - .5) * 200) + '', v => { s[3].x = r3(v); $('#lpAuto').setAttribute('aria-pressed', 'false'); $('#lpMan').setAttribute('aria-pressed', 'true'); });
    bindSlider('lpY', v => Math.round((v - .5) * 200) + '', v => { if (Math.abs(v - .5) < .004) delete s[3].y; else s[3].y = r3(v); });
    bindSlider('lpZ', pct, v => { if (v <= 1.001) delete s[3].zoom; else s[3].zoom = r3(v); });
    $('#lpX').dataset.def = .5; $('#lpY').dataset.def = .5; $('#lpZ').dataset.def = 1;
    $('#lpAll').onclick = () => { E.c.shots.forEach(x => { if (x[2] === s[2]) x[3] = Object.assign({}, s[3]); }); commit(); frame(true); VC.toast('Cadrage appliqué à tous les plans de la caméra ' + (s[2] + 1), 2000); };
    $('#lpReset').onclick = () => { s[3] = {}; commit(); paintInsp(); frame(true); };
    $('#lpSplit').onclick = () => splitAt(E.t);
    $('#lpMerge').onclick = () => mergeShot(i);
  }

  function tabColor() {
    const c = E.c.color, luts = E.luts || [];
    return '<div class="le-looks">' + [{ id: '', name: 'Aucun' }].concat(luts).map(l => '<button type="button" data-look="' + esc(l.id) + '" aria-pressed="' + ((c.look || '') === l.id) + '"><i style="background:' + lookSwatch(l.id) + '"></i>' + esc(l.name) + '</button>').join('') + '</div>' +
      '<button class="btn small" type="button" id="lcImport">Importer une LUT (.cube)</button>' +
      slider('lcMix', 'Intensité', 0, 1, .01, c.mix, pct) +
      slider('lcExp', 'Exposition', -2, 2, .05, c.exposure, v => (v > 0 ? '+' : '') + v.toFixed(2).replace('.', ',') + ' ' + VC.t('IL')) +
      slider('lcCon', 'Contraste', .5, 1.8, .01, c.contrast, pct) +
      slider('lcSat', 'Saturation', 0, 2, .01, c.saturation, pct) +
      slider('lcTmp', 'Température', -1, 1, .01, c.temp, v => v < -.01 ? VC.t('froid') + ' ' + Math.round(-v * 100) : v > .01 ? VC.t('chaud') + ' ' + Math.round(v * 100) : '0') +
      '<p class="hint">Double-clic sur un curseur pour le remettre à zéro. Les mêmes réglages partent dans DaVinci (CDL + LUT sur le nœud 1).</p>' +
      '<div class="le-row2"><button class="btn small" type="button" id="lcAll">Appliquer à tous les clips de la date</button><button class="btn small ghost" type="button" id="lcReset">Réinitialiser</button></div>';
  }
  function lookSwatch(id) {
    return { '': '#555', club: 'linear-gradient(135deg,#ffb35c,#7a2c12)', nuit: 'linear-gradient(135deg,#7fb2ff,#0d1d3a)', teal: 'linear-gradient(135deg,#ff9f5a 30%,#1e8c94)',
      punch: 'linear-gradient(135deg,#ff3d7f,#ffd23f)', vintage: 'linear-gradient(135deg,#e8d3a8,#8a6c4f)', nb: 'linear-gradient(135deg,#eee,#111)' }[id] || 'linear-gradient(135deg,#9b6bff,#2a1650)';
  }
  function bindColor() {
    const c = E.c.color;
    if (!E.luts) VC.api('/api/live/luts').then(r => { E.luts = r.items; if (E.tab === 'color') paintInsp(); });
    $$('[data-look]').forEach(b => b.onclick = async () => { c.look = b.dataset.look; if (c.look && !(c.mix > 0)) c.mix = 1; await loadLut(c.look); commit(); paintInsp(); frame(true); });
    $('#lcImport').onclick = async () => {
      if (!VC.native() || !window.pywebview.api.pick_lut) return VC.toast('Disponible dans l\'app OMAGAD sur Mac.');
      const p = await window.pywebview.api.pick_lut(); if (!p) return;
      try { const r = await VC.api('/api/live/luts/import', { path: p }); E.luts = r.items; c.look = r.id; await loadLut(c.look); commit(); paintInsp(); frame(true); }
      catch (e) { VC.toast(e.message, 5000); }
    };
    bindSlider('lcMix', pct, v => c.mix = v); $('#lcMix').dataset.def = 1;
    bindSlider('lcExp', v => (v > 0 ? '+' : '') + v.toFixed(2).replace('.', ',') + ' ' + VC.t('IL'), v => c.exposure = v); $('#lcExp').dataset.def = 0;
    bindSlider('lcCon', pct, v => c.contrast = v); $('#lcCon').dataset.def = 1;
    bindSlider('lcSat', pct, v => c.saturation = v); $('#lcSat').dataset.def = 1;
    bindSlider('lcTmp', v => v < -.01 ? VC.t('froid') + ' ' + Math.round(-v * 100) : v > .01 ? VC.t('chaud') + ' ' + Math.round(v * 100) : '0', v => c.temp = v); $('#lcTmp').dataset.def = 0;
    $('#lcReset').onclick = () => { E.c.color = Object.assign({}, COLOR_DEF); commit(); paintInsp(); frame(true); };
    $('#lcAll').onclick = async () => {
      if (!await VC.confirm('Même couleur pour toute la date ?', 'Le look et les réglages de ce clip sont copiés sur tous les clips de cette date (ils seront à réexporter).', 'Appliquer')) return;
      await flush();
      try { const r = await VC.api('/api/live/edit/apply-color', { lid: E.lid, color: E.c.color }); VC.toast(r.count + ' clips mis à jour', 2500); } catch (e) { VC.toast(e.message, 5000); }
    };
  }

  function tabZoom() {
    const zs = E.c.zooms.filter(z => z >= E.c.t0 && z <= E.c.t1);
    return slider('lzAmt', 'Force des zooms', 0, 2.5, .05, E.c.punch, v => v < .01 ? VC.t('aucun') : pct(v)) +
      '<p class="hint">Un zoom « punch » donne un coup d\'image sur le temps (plus fort sur le drop). Les losanges de la timeline se déplacent à la souris ; Suppr pour en retirer un.</p>' +
      '<div class="le-row2"><button class="btn small" type="button" id="lzAdd">+ Zoom à la tête de lecture (Z)</button><button class="btn small" type="button" id="lzAuto">Un zoom toutes les 2 mesures</button></div>' +
      '<div class="le-zlist">' + (zs.length ? zs.map(z => '<span class="le-zi' + (E.sel.kind === 'zoom' && Math.abs(E.c.zooms[E.sel.i] - z) < 1e-4 ? ' on' : '') + '" data-z="' + z + '">' + rel(z) + (E.c.drop != null && Math.abs(z - E.c.drop) < .06 ? ' · drop' : '') + '<button type="button" title="Retirer">×</button></span>').join('') : '<span class="hint">Aucun zoom</span>') + '</div>' +
      '<button class="btn small ghost" type="button" id="lzClear"' + (zs.length ? '' : ' disabled') + '>Retirer tous les zooms</button>';
  }
  function bindZoom() {
    bindSlider('lzAmt', v => v < .01 ? VC.t('aucun') : pct(v), v => E.c.punch = r3(v)); $('#lzAmt').dataset.def = 1;
    $('#lzAdd').onclick = () => addZoom(E.t);
    $('#lzAuto').onclick = () => {
      const bar = 4 * E.meta.period, a = E.c.drop != null ? E.c.drop : snapBeat(E.c.t0, 1e9, 4);
      const out = []; for (let t = a; t <= E.c.t1 + 1e-3; t += 2 * bar) if (t >= E.c.t0) out.push(r3(t));
      for (let t = a - 2 * bar; t >= E.c.t0; t -= 2 * bar) out.push(r3(t));
      E.c.zooms = out.sort((x, y) => x - y); commit(); paintInsp(); drawTl();
    };
    $('#lzClear').onclick = () => { E.c.zooms = []; commit(); paintInsp(); drawTl(); };
    $$('.le-zi').forEach(el => el.onclick = e => {
      const z = +el.dataset.z, i = E.c.zooms.findIndex(x => Math.abs(x - z) < 1e-4);
      if (e.target.closest('button')) { E.c.zooms.splice(i, 1); commit(); paintInsp(); drawTl(); return; }
      E.sel = { kind: 'zoom', i }; seek(z); paintInsp(); drawTl();
    });
  }

  function tabText() {
    const t = E.c.text;
    if (!t) return '<p class="hint">Ajoute un texte accrocheur sur le clip (le style est celui de ton accroche CLIPAGAD : police, couleur, lueur, animation).</p>' +
      '<button class="btn primary" type="button" id="ltAdd">+ Ajouter un texte</button>';
    return '<div class="field"><label for="ltTxt">Texte</label><textarea id="ltTxt" rows="3" maxlength="240">' + esc(t.hook) + '</textarea><span class="hint">Entrée = retour à la ligne</span></div>' +
      slider('ltAt', 'Début', 0, Math.max(.5, E.c.t1 - E.c.t0 - .5), .05, clamp(t.at - E.c.t0, 0, E.c.t1 - E.c.t0), secs) +
      slider('ltSecs', 'Durée', .5, Math.max(1, Math.min(12, E.c.t1 - E.c.t0)), .05, t.secs, secs) +
      slider('ltY', 'Hauteur', .08, .92, .01, t.y, v => Math.round((1 - v) * 100) + ' %') +
      '<label class="check"><input type="checkbox" id="ltSfx"' + (t.sfx ? ' checked' : '') + '> Sons d\'entrée / de sortie de ton accroche</label>' +
      '<div class="le-row2"><button class="btn small" type="button" id="ltHere">Commencer à la tête de lecture</button><button class="btn small ghost" type="button" id="ltDel">Supprimer le texte</button></div>';
  }
  function bindText() {
    const add = $('#ltAdd');
    if (add) { add.onclick = () => { E.c.text = { hook: 'LE DROP', at: r3(Math.max(E.c.t0, Math.min(E.t, E.c.t1 - 3))), secs: 3, y: .3, sfx: false }; commit(); paintInsp(); drawTl(); frame(true); setTimeout(() => { const a = $('#ltTxt'); if (a) { a.focus(); a.select(); } }, 30); }; return; }
    const t = E.c.text;
    const ta = $('#ltTxt');
    ta.oninput = () => { t.hook = ta.value; frame(true); drawTl(); };
    ta.onchange = () => commit();
    ta.onkeydown = e => e.stopPropagation();
    bindSlider('ltAt', secs, v => t.at = r3(E.c.t0 + v));
    bindSlider('ltSecs', secs, v => t.secs = r3(v));
    bindSlider('ltY', v => Math.round((1 - v) * 100) + ' %', v => t.y = r3(v));
    $('#ltSfx').onchange = e => { t.sfx = e.target.checked; commit(); };
    $('#ltHere').onclick = () => { t.at = r3(clamp(E.t, E.c.t0, E.c.t1 - .5)); commit(); paintInsp(); drawTl(); frame(true); };
    $('#ltDel').onclick = () => { E.c.text = null; commit(); paintInsp(); drawTl(); frame(true); };
  }

  function tabAudio() {
    const a = E.c.audio;
    return slider('laGain', 'Volume', -12, 12, .5, a.gain_db, v => (v > 0 ? '+' : '') + v.toFixed(1).replace('.', ',') + ' dB') +
      slider('laIn', 'Fondu d\'entrée', 0, 3, .05, a.fade_in, secs) +
      slider('laOut', 'Fondu de sortie', 0, 5, .05, a.fade_out, secs) +
      '<p class="hint">' + (VC.S.state.settings.loudnorm !== false ? 'À l\'export, le son est aussi mis au niveau des réseaux (−14 LUFS).' : 'Mise au niveau des réseaux désactivée dans les réglages.') + '</p>';
  }
  function bindAudio() {
    const a = E.c.audio;
    bindSlider('laGain', v => (v > 0 ? '+' : '') + v.toFixed(1).replace('.', ',') + ' dB', v => a.gain_db = v); $('#laGain').dataset.def = 0;
    bindSlider('laIn', secs, v => a.fade_in = v); $('#laIn').dataset.def = .04;
    bindSlider('laOut', secs, v => a.fade_out = v); $('#laOut').dataset.def = .35;
  }

  /* ================================================================ outils de montage */
  const shotAt = t => { const s = E.c.shots; for (let i = 0; i < s.length; i++) if (t < s[i][1] - 1e-6) return s[i]; return s[s.length - 1]; };
  const shotIdx = t => { const s = E.c.shots; for (let i = 0; i < s.length; i++) if (t < s[i][1] - 1e-6) return i; return s.length - 1; };
  function fixSel() { if (E.sel.kind === 'shot' && !E.c.shots[E.sel.i]) E.sel = { kind: 'shot', i: E.c.shots.length - 1 }; if (E.sel.kind === 'zoom' && E.c.zooms[E.sel.i] == null) E.sel = { kind: 'shot', i: shotIdx(E.t) }; }
  function splitAt(t, cam) {
    t = r3(t);
    if (t <= E.c.t0 + .05 || t >= E.c.t1 - .05) return false;
    const i = shotIdx(t), s = E.c.shots[i];
    if (t - s[0] < .1 || s[1] - t < .1) { if (cam != null) { const j = t - s[0] < .1 ? i : i + 1; if (E.c.shots[j]) { E.c.shots[j][2] = cam; E.c.shots[j][3] = {}; } } return true; }
    const right = [t, s[1], cam == null ? s[2] : cam, cam == null ? Object.assign({}, s[3]) : {}];
    s[1] = t; E.c.shots.splice(i + 1, 0, right);
    E.sel = { kind: 'shot', i: i + 1 };
    return true;
  }
  function mergeShot(i) {
    if (i <= 0) return;
    const s = E.c.shots; s[i - 1][1] = s[i][1]; s.splice(i, 1);
    E.sel = { kind: 'shot', i: i - 1 }; commit(); paintAll();
  }
  function addZoom(t) {
    t = r3(snapBeat(t, E.snapOn ? .25 : 0));
    if (t < E.c.t0 || t > E.c.t1) return VC.toast('Place la tête de lecture dans le clip.');
    if (E.c.zooms.some(z => Math.abs(z - t) < .05)) return;
    E.c.zooms.push(t); E.c.zooms.sort((a, b) => a - b);
    if (!(E.c.punch > 0)) E.c.punch = 1;
    E.sel = { kind: 'zoom', i: E.c.zooms.indexOf(t) }; commit(); if (E.tab === 'zoom') paintInsp(); drawTl();
  }
  /* angle cliqué : en lecture on coupe à la tête de lecture (calé sur le temps le plus proche), à l'arrêt on remplace la caméra du plan */
  function pickAngle(k, forceCut) {
    if (!E.meta.cams[k]) return;
    const t = E.t;
    if (t < E.c.t0 || t > E.c.t1) return VC.toast('Place la tête de lecture dans le clip.');
    if (!hasCover(k, t)) return VC.toast('La caméra ' + (k + 1) + ' n\'a pas d\'image à cet endroit.');
    if (playing() || forceCut) {
      const tc = E.snapOn ? snapBeat(t, .3) : t;
      splitAt(tc, k);
    } else {
      const i = shotIdx(t); E.c.shots[i][2] = k; E.c.shots[i][3] = {}; E.sel = { kind: 'shot', i };
    }
    // deux plans voisins sur la même caméra = un seul plan
    const s = E.c.shots;
    for (let i = s.length - 1; i > 0; i--) if (s[i][2] === s[i - 1][2] && JSON.stringify(s[i][3]) === JSON.stringify(s[i - 1][3])) { s[i - 1][1] = s[i][1]; s.splice(i, 1); }
    fixSel(); commit(); markAngles(); drawTl(); if (E.tab === 'plan') paintInsp(); frame(true);
  }
  function setIn(t) { t = r3(E.snapOn ? snapBeat(t, .25) : t); if (E.c.t1 - t < 2) return VC.toast('Un clip doit durer au moins 2 s.'); trimTo(t, E.c.t1); }
  function setOut(t) { t = r3(E.snapOn ? snapBeat(t, .25) : t); if (t - E.c.t0 < 2) return VC.toast('Un clip doit durer au moins 2 s.'); trimTo(E.c.t0, t); }
  function trimTo(a, b, noCommit) {
    a = clamp(a, E.meta.w0, E.meta.w1); b = clamp(b, E.meta.w0, E.meta.w1);
    const s = E.c.shots;
    // on coupe / rallonge les plans du bord
    const keep = s.filter(x => x[1] > a + .05 && x[0] < b - .05);
    if (!keep.length) return;
    keep[0][0] = a; keep[keep.length - 1][1] = b;
    E.c.shots = keep; E.c.t0 = r3(a); E.c.t1 = r3(b);
    fixSel();
    if (!noCommit) { commit(); paintAll(); maybeWiden(); }
  }
  /* si le clip arrive au bord des caméras préparées, on en prépare un peu plus */
  function maybeWiden() {
    const m = E.meta;
    if ((E.c.t0 - m.w0 < 1.5 && m.w0 > .05) || (m.w1 - E.c.t1 < 1.5 && m.w1 < (E.setDur || 1e9) - .05)) {
      VC.toast('Préparation des caméras autour du nouveau clip…', 2500);
      save().then(() => { stop(); return load(false, E.t); }).catch(e => VC.toast(e.message, 5000));
    }
  }

  /* calage sur la grille des temps (beat0 = un temps fort, en général le drop) */
  function snapBeat(t, within, every) {
    const m = E.meta, p = m.period * (every || 1), b0 = m.w0 + m.beat0;
    const tb = b0 + Math.round((t - b0) / p) * p;
    return Math.abs(tb - t) <= (within == null ? 1e9 : within) ? tb : t;
  }

  /* ================================================================ lecture */
  function setupMedia() {
    E.au = new Audio('/liveedit/' + E.lid + '/' + E.c.id + '/audio.m4a');
    E.au.preload = 'auto';
    E.au.addEventListener('loadedmetadata', () => { try { E.au.currentTime = E.t - E.meta.w0; } catch (e) {} });
    E.vids.forEach(v => {
      v.addEventListener('loadeddata', () => { try { v.currentTime = E.t - E.meta.w0; } catch (e) {} frame(true); });
      v.addEventListener('seeked', () => { if (!playing()) frame(true); });
    });
    applyGain();
  }
  const playing = () => E.au && !E.au.paused;
  function applyGain() {
    if (!E.au) return;
    const a = E.c.audio, rt = E.t - E.c.t0, L = E.c.t1 - E.c.t0;
    let g = Math.pow(10, (+a.gain_db || 0) / 20);
    if (rt < a.fade_in) g *= clamp(rt / Math.max(.01, a.fade_in), 0, 1);
    if (a.fade_out > .01 && rt > L - a.fade_out) g *= clamp((L - rt) / a.fade_out, 0, 1);
    if (rt < 0 || rt > L) g *= .35;  // en dehors du clip : plus bas
    E.au.volume = clamp(g * .9, 0, 1);
  }
  function play() {
    if (!E.au) return;
    if (E.t >= E.c.t1 - .05 || E.t < E.c.t0 - .01) seek(E.c.t0);
    E.au.play().catch(() => {}); E.vids.forEach(v => v.play().catch(() => {}));
    $('#lePlay').innerHTML = ICON.pause; loop();
  }
  function pause() {
    if (!E.au) return;
    E.au.pause(); E.vids.forEach(v => v.pause());
    const b = $('#lePlay'); if (b) b.innerHTML = ICON.play;
    seek(E.t);
  }
  function stop() { cancelAnimationFrame(E.raf); if (E.au) E.au.pause(); (E.vids || []).forEach(v => v.pause()); }
  function toggle() { playing() ? pause() : play(); }
  function seek(t) {
    E.t = clamp(t, E.meta.w0, E.meta.w1 - .02);
    const wt = E.t - E.meta.w0;
    if (E.au) { try { E.au.currentTime = wt; } catch (e) {} }
    E.vids.forEach(v => { try { v.currentTime = wt; } catch (e) {} });
    markAngles(); drawTl(); frame(true); tcRead(); applyGain();
  }
  function loop() {
    cancelAnimationFrame(E.raf);
    const tick = () => {
      if (!E.open || !E.ready) return;
      if (playing()) {
        const wt = E.au.currentTime; E.t = E.meta.w0 + wt;
        if ($('#leLoop') && $('#leLoop').checked && E.t >= E.c.t1) { seek(E.c.t0); }
        else if (E.t >= E.meta.w1 - .05) { pause(); }
        // les angles suivent le son
        E.vids.forEach(v => {
          const d = v.currentTime - wt;
          if (v.paused) v.play().catch(() => {});
          if (Math.abs(d) > .2) { try { v.currentTime = wt; } catch (e) {} v.playbackRate = 1; }
          else v.playbackRate = Math.abs(d) > .03 ? (d > 0 ? .95 : 1.05) : 1;
        });
        markAngles(); drawTl(); tcRead(); applyGain();
      }
      frame();
      E.raf = requestAnimationFrame(tick);
    };
    E.raf = requestAnimationFrame(tick);
  }
  function tcRead() { const el = $('#leTc'); if (el) el.textContent = tc(E.t) + '  ·  ' + rel(E.t); }
  function tc(t) {
    const fps = Math.round(E.fps || 25), f = Math.floor(t * fps + 1e-6), tot = 3600 * fps + f, p2 = n => String(n).padStart(2, '0');
    return p2(Math.floor(tot / (3600 * fps))) + ':' + p2(Math.floor(tot / (60 * fps)) % 60) + ':' + p2(Math.floor(tot / fps) % 60) + ':' + p2(tot % fps);
  }
  function rel(t) { const r = t - E.c.t0, s = Math.abs(r); return (r < 0 ? '−' : '') + Math.floor(s / 60) + ':' + (s % 60).toFixed(1).padStart(4, '0').replace('.', ','); }

  /* ================================================================ aperçu (WebGL : même calcul que le rendu) */
  const VS = 'attribute vec2 p;varying vec2 uv;void main(){uv=vec2(p.x*.5+.5,.5-p.y*.5);gl_Position=vec4(p,0.,1.);}';
  const FS = 'precision mediump float;varying vec2 uv;uniform sampler2D v;uniform sampler2D lut;uniform vec4 crop;uniform vec3 gain;uniform float con,sat,mixv,n,has;' +
    'vec3 L(float r,float g,float b){return texture2D(lut,vec2((r+b*n+.5)/(n*n),(g+.5)/n)).rgb;}' +
    'vec3 tri(vec3 c){vec3 p=c*(n-1.);vec3 i=min(floor(p),vec3(n-2.));vec3 f=p-i;' +
    'vec3 c00=mix(L(i.r,i.g,i.b),L(i.r+1.,i.g,i.b),f.r);vec3 c10=mix(L(i.r,i.g+1.,i.b),L(i.r+1.,i.g+1.,i.b),f.r);' +
    'vec3 c01=mix(L(i.r,i.g,i.b+1.),L(i.r+1.,i.g,i.b+1.),f.r);vec3 c11=mix(L(i.r,i.g+1.,i.b+1.),L(i.r+1.,i.g+1.,i.b+1.),f.r);' +
    'return mix(mix(c00,c10,f.g),mix(c01,c11,f.g),f.b);}' +
    'void main(){vec2 q=crop.xy+uv*crop.zw;vec3 c=texture2D(v,q).rgb;if(q.x<0.||q.y<0.||q.x>1.||q.y>1.)c=vec3(0.);' +
    'c=clamp((c*gain-.5)*con+.5,0.,1.);float l=dot(c,vec3(.2126,.7152,.0722));c=clamp(l+(c-l)*sat,0.,1.);' +
    'if(has>.5){c=mix(c,clamp(tri(c),0.,1.),mixv);}gl_FragColor=vec4(c,1.);}';
  function setupGL() {
    const cv = $('#leCv'); E.gl = null; E.ctx2d = null;
    let gl = null;
    try { gl = cv.getContext('webgl', { preserveDrawingBuffer: true }) || cv.getContext('experimental-webgl'); } catch (e) { gl = null; }
    if (!gl) { E.ctx2d = cv.getContext('2d'); return; }
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    try {
      const pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
      const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      const tex = (unit) => { const t = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, unit ? gl.NEAREST : gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, unit ? gl.NEAREST : gl.LINEAR); return t; };
      E.texV = tex(0); E.texL = tex(1);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 255]));
      E.u = {}; ['v', 'lut', 'crop', 'gain', 'con', 'sat', 'mixv', 'n', 'has'].forEach(k => E.u[k] = gl.getUniformLocation(pr, k));
      gl.uniform1i(E.u.v, 0); gl.uniform1i(E.u.lut, 1);
      E.gl = gl; E.lutN = 0; E.lutId = null;
      loadLut(E.c.color.look);
    } catch (e) { console.warn('WebGL', e); E.gl = null; E.ctx2d = cv.getContext('2d'); }
  }
  const lutCache = {};
  async function loadLut(id) {
    if (!E.gl) return;
    if (!id) { E.lutId = null; E.lutN = 0; return; }
    try {
      if (!lutCache[id]) {
        const txt = await (await fetch('/lut/' + encodeURIComponent(id))).text();
        let n = 0; const vals = [];
        for (const line of txt.split('\n')) {
          const l = line.trim(); if (!l || l[0] === '#') continue;
          if (/^LUT_3D_SIZE/i.test(l)) n = +l.split(/\s+/)[1];
          else if (/^[-\d.]/.test(l)) { const p = l.split(/\s+/); if (p.length >= 3) vals.push(+p[0], +p[1], +p[2]); }
        }
        if (!n || vals.length < n * n * n * 3) throw new Error('LUT illisible');
        // atlas : x = r + b·n, y = g
        const px = new Uint8Array(n * n * n * 4);
        for (let b = 0; b < n; b++) for (let g = 0; g < n; g++) for (let r = 0; r < n; r++) {
          const i = ((b * n + g) * n + r) * 3, o = (g * n * n + b * n + r) * 4;
          px[o] = clamp(vals[i] * 255, 0, 255); px[o + 1] = clamp(vals[i + 1] * 255, 0, 255); px[o + 2] = clamp(vals[i + 2] * 255, 0, 255); px[o + 3] = 255;
        }
        lutCache[id] = { n, px };
      }
      const L = lutCache[id], gl = E.gl;
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, E.texL);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, L.n * L.n, L.n, 0, gl.RGBA, gl.UNSIGNED_BYTE, L.px);
      E.lutId = id; E.lutN = L.n; frame(true);
    } catch (e) { E.lutId = null; E.lutN = 0; }
  }
  /* position du cadre en suivi auto (images clés du suivi de la caméra) */
  function xAuto(s, t) {
    const keys = (E.meta.cams[s[2]] || {}).keys || [];
    if (!keys.length) return .5;
    const wt = t - E.meta.w0;
    if (wt <= keys[0][0]) return keys[0][1];
    for (let i = 1; i < keys.length; i++) if (wt <= keys[i][0]) { const a = keys[i - 1], b = keys[i]; return a[1] + (b[1] - a[1]) * (wt - a[0]) / Math.max(1e-6, b[0] - a[0]); }
    return keys[keys.length - 1][1];
  }
  function zoomAt(t) {
    const rl = t - E.c.t0, L = E.c.t1 - E.c.t0, amt = E.c.punch == null ? 1 : E.c.punch;
    let z = 1 + .05 * rl / Math.max(1, L);
    if (amt > .01) for (const zz of E.c.zooms) { const r = zz - E.c.t0; if (rl >= r) z += (E.c.drop != null && Math.abs(zz - E.c.drop) < .05 ? .14 : .07) * amt * Math.exp(-(rl - r) / .32); }
    return z;
  }
  function cropOf(t) {
    const s = shotAt(t), cam = E.meta.cams[s[2]], fr = s[3] || {};
    const iw = cam.src_w || 1920, ih = cam.src_h || 1080;
    const sc = Math.max(W / iw, H / ih) * (fr.zoom || 1) * zoomAt(t);
    const sw = iw * sc, shh = ih * sc, fx = fr.x == null ? xAuto(s, t) : fr.x, fy = fr.y == null ? .5 : fr.y;
    // la vidéo proxy garde l'image entière (même rapport largeur/hauteur que le rush)
    const pw = cam.w, ph = cam.h, ar = iw / ih, par = pw / ph;
    let ox = 0, oy = 0, kx = 1, ky = 1;  // si le proxy a des bandes noires
    if (Math.abs(ar - par) > .01) { if (ar < par) { kx = ar / par; ox = (1 - kx) / 2; } else { ky = par / ar; oy = (1 - ky) / 2; } }
    return { k: s[2], x: ox + kx * (sw - W) * fx / sw, y: oy + ky * (shh - H) * fy / shh, w: kx * W / sw, h: ky * H / shh, sw, shh };
  }
  let lastKey = '';
  function frame(force) {
    if (!E.ready) return;
    const t = E.t, inClip = t >= E.c.t0 - 1e-3 && t <= E.c.t1 + 1e-3;
    const cr = cropOf(clamp(t, E.c.t0, E.c.t1)), v = E.vids[cr.k];
    const cv = $('#leCv'); if (!cv || !v) return;
    const key = [t.toFixed(3), JSON.stringify(cr), snap(), v.readyState].join('|');
    if (!force && key === lastKey && !playing()) return;
    lastKey = key;
    const tag = $('#leCamTag'), cam = E.meta.cams[cr.k];
    if (tag) { tag.textContent = (cr.k + 1) + ' · ' + VC.t(RNAME(cam.role)); tag.style.setProperty('--rc', RCOL(cam.role)); }
    $('#lePhone').classList.toggle('out', !inClip);
    const c = E.c.color;
    if (E.gl) {
      const gl = E.gl;
      if (v.readyState >= 2) {
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, E.texV);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
        try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, v); } catch (e) { /* image pas prête */ }
      }
      const ev = Math.pow(2, +c.exposure || 0), tp = +c.temp || 0;
      gl.viewport(0, 0, cv.width, cv.height);
      gl.uniform4f(E.u.crop, cr.x, cr.y, cr.w, cr.h);
      gl.uniform3f(E.u.gain, ev * (1 + .12 * tp), ev * (1 + .015 * tp), ev * (1 - .12 * tp));
      gl.uniform1f(E.u.con, +c.contrast); gl.uniform1f(E.u.sat, +c.saturation);
      const useL = c.look && E.lutId === c.look && E.lutN > 1 && c.mix > .001;
      gl.uniform1f(E.u.has, useL ? 1 : 0); gl.uniform1f(E.u.n, E.lutN || 2); gl.uniform1f(E.u.mixv, +c.mix);
      if (c.look && E.lutId !== c.look) loadLut(c.look);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    } else if (E.ctx2d) {
      const g = E.ctx2d, vw = v.videoWidth || 960, vh = v.videoHeight || 540;
      g.filter = 'brightness(' + Math.pow(2, +c.exposure || 0) + ') contrast(' + c.contrast + ') saturate(' + c.saturation + ')';
      g.fillStyle = '#000'; g.fillRect(0, 0, cv.width, cv.height);
      try { g.drawImage(v, cr.x * vw, cr.y * vh, cr.w * vw, cr.h * vh, 0, 0, cv.width, cv.height); } catch (e) {}
      g.filter = 'none';
    }
    drawHook(t);
  }
  /* texte : même rendu que l'aperçu de CLIPAGAD */
  let lastHookKey = null;
  function drawHook(t) {
    const el = $('#leHook'); if (!el) return;
    const tx = E.c.text;
    const st = Object.assign({}, VC.S.state.settings.style || {}, tx ? { hook_secs: tx.secs, hook_y: tx.y } : {});
    if (!tx || !tx.hook.trim() || t < tx.at || t >= tx.at + tx.secs) { if (lastHookKey !== '') { el.innerHTML = ''; lastHookKey = ''; } return; }
    const key = JSON.stringify([tx.hook, st]);
    if (key !== lastHookKey) {
      lastHookKey = key;
      if (VC.styleOv) VC.styleOv(el, 'hook', st);
      let i = 0;
      el.innerHTML = '<span class="hook-inner">' + tx.hook.split('\n').map(line => line.split(/\s+/).filter(Boolean).map(w => '<span class="w" data-i="' + (i++) + '">' + esc(w) + '</span>').join(' ')).join('<br>') + '</span>';
    }
    const inner = el.firstChild; if (!inner) return;
    const ms = (t - tx.at) * 1000, tr = VC.hookTransform(st, ms, tx.secs * 1000), px = n => (n / 1080 * 100).toFixed(3) + 'cqw';
    inner.style.transform = 'translate(' + px(tr.dx) + ',' + px(tr.dy) + ') scale(' + tr.sc.toFixed(4) + ') rotate(' + (-tr.rot).toFixed(2) + 'deg)';
    inner.style.opacity = tr.al.toFixed(3);
    if (st.hook_words) $$('.w', el).forEach(w => { w.style.visibility = ms >= 120 + w.dataset.i * 140 ? 'visible' : 'hidden'; });
  }

  /* ================================================================ timeline */
  const HEAD = 78, RUL = 24, VT = 46, ZT = 18, TT = 22, AT = 44;
  const ROWS = () => ({ rul: 0, v: RUL, z: RUL + VT, t: RUL + VT + ZT, a: RUL + VT + ZT + TT, h: RUL + VT + ZT + TT + AT + 4 });
  function geom() {
    const cv = $('#leTl'); const w = cv.clientWidth, m = E.meta;
    return { cv, w, X: t => HEAD + (t - m.w0) / (m.w1 - m.w0) * (w - HEAD - 10), T: x => m.w0 + (x - HEAD) / (w - HEAD - 10) * (m.w1 - m.w0) };
  }
  function drawTl() {
    const cv = $('#leTl'); if (!cv || !E.ready) return;
    const R = ROWS(), m = E.meta, c = E.c;
    const dpr = devicePixelRatio || 1, w = cv.clientWidth, h = R.h;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); cv.style.height = h + 'px'; }
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const { X } = geom(), font = getComputedStyle(document.body).fontFamily;
    g.fillStyle = '#18181c'; g.fillRect(0, 0, w, h);
    // en-têtes de pistes
    const head = (y, hh, lab, col) => { g.fillStyle = '#24242a'; g.fillRect(0, y, HEAD - 2, hh - 1); g.fillStyle = col; g.fillRect(0, y, 3, hh - 1); g.fillStyle = '#cfd2d9'; g.font = '600 11px ' + font; g.textBaseline = 'middle'; g.fillText(lab, 10, y + hh / 2); };
    head(R.v, VT, 'V1', '#5b8def'); head(R.z, ZT, VC.t('Zooms'), '#ffd23f'); head(R.t, TT, VC.t('Texte'), '#b07bff'); head(R.a, AT, 'A1', '#4caf6a');
    // règle + grille des temps
    g.fillStyle = '#202026'; g.fillRect(HEAD, 0, w - HEAD, RUL);
    const p = m.period, b0 = m.w0 + m.beat0, px = (X(m.w0 + 1) - X(m.w0));
    const kFirst = Math.ceil((m.w0 - b0) / p), kLast = Math.floor((m.w1 - b0) / p);
    for (let k = kFirst; k <= kLast; k++) {
      const t = b0 + k * p, x = Math.round(X(t)) + .5, bar = ((k % 4) + 4) % 4 === 0;
      if (!bar && p * px < 7) continue;
      g.fillStyle = bar ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.028)'; g.fillRect(x, RUL, 1, h - RUL);
      g.fillStyle = bar ? '#6b6e78' : '#3d3f47'; g.fillRect(x, bar ? RUL - 9 : RUL - 4, 1, bar ? 9 : 4);
      if (bar && 4 * p * px > 34) { const n = Math.round(k / 4) + (k >= 0 ? 1 : 0); g.fillStyle = '#8c8f99'; g.font = '10px ' + font; g.fillText(String(n), x + 3, 8); }
    }
    g.fillStyle = '#7d808a'; g.font = '10px ' + font; g.fillText(tc(c.t0), X(c.t0) + 3, RUL - 7);
    // pistes
    g.fillStyle = '#1d1d22'; g.fillRect(HEAD, R.v, w - HEAD, VT); g.fillRect(HEAD, R.t, w - HEAD, TT);
    g.fillStyle = '#1a1a1f'; g.fillRect(HEAD, R.z, w - HEAD, ZT); g.fillRect(HEAD, R.a, w - HEAD, AT);
    // plans
    c.shots.forEach((s, i) => {
      const x0 = X(s[0]), x1 = X(s[1]), cam = m.cams[s[2]], col = RCOL(cam.role), sel = E.sel.kind === 'shot' && E.sel.i === i;
      g.fillStyle = shade(col, .42); g.fillRect(x0 + .5, R.v + 3, Math.max(1, x1 - x0 - 1), VT - 6);
      g.fillStyle = col; g.fillRect(x0 + .5, R.v + 3, Math.max(1, x1 - x0 - 1), 4);
      if (x1 - x0 > 26) {
        g.save(); g.beginPath(); g.rect(x0 + 2, R.v + 3, x1 - x0 - 4, VT - 6); g.clip();
        g.fillStyle = '#fff'; g.font = '700 11px ' + font; g.fillText((s[2] + 1) + ' ' + VC.t(RNAME(cam.role)).toUpperCase(), x0 + 6, R.v + 20);
        const fr = s[3] || {}, tags = [VC.t(fr.x == null ? 'suivi' : 'cadré'), fr.zoom ? Math.round(fr.zoom * 100) + '%' : ''].filter(Boolean).join(' · ');
        g.fillStyle = 'rgba(255,255,255,.6)'; g.font = '10px ' + font; g.fillText(tags, x0 + 6, R.v + 34); g.restore();
      }
      if (sel) { g.strokeStyle = '#fff'; g.lineWidth = 2; g.strokeRect(x0 + 1.5, R.v + 2, Math.max(2, x1 - x0 - 3), VT - 4); }
      if (i) { g.fillStyle = '#0d0d10'; g.fillRect(Math.round(x0) - 1, R.v + 2, 2, VT - 4); }
    });
    // texte
    if (c.text) {
      const x0 = X(c.text.at), x1 = X(Math.min(c.text.at + c.text.secs, m.w1)), sel = E.sel.kind === 'text';
      g.fillStyle = sel ? '#9a6bff' : '#6c4bb3'; roundRect(g, x0, R.t + 3, Math.max(4, x1 - x0), TT - 6, 4); g.fill();
      g.save(); g.beginPath(); g.rect(x0, R.t, x1 - x0, TT); g.clip(); g.fillStyle = '#fff'; g.font = '600 10.5px ' + font; g.fillText(c.text.hook.replace(/\n/g, ' '), x0 + 6, R.t + TT / 2); g.restore();
    }
    // son (crêtes)
    const wv = m.wave || [], ps = m.per_sec || 100, mid = R.a + AT / 2;
    g.fillStyle = '#2b5a39';
    for (let x = HEAD; x < w - 10; x++) {
      const { T } = geom(), t0 = T(x) - m.w0, t1 = T(x + 1) - m.w0;
      let pk = 0; for (let i = Math.floor(t0 * ps); i <= Math.ceil(t1 * ps) && i < wv.length; i++) if (i >= 0 && wv[i] > pk) pk = wv[i];
      const tt = m.w0 + t0, inC = tt >= c.t0 && tt <= c.t1;
      g.fillStyle = inC ? '#6fcf8c' : '#2f5a3c';
      const hh = Math.max(1, pk * (AT / 2 - 4)); g.fillRect(x, mid - hh, 1, hh * 2);
    }
    // zooms
    c.zooms.forEach((z, i) => {
      const x = X(z), y = R.z + ZT / 2, sel = E.sel.kind === 'zoom' && E.sel.i === i, inC = z >= c.t0 && z <= c.t1;
      g.fillStyle = !inC ? '#555' : sel ? '#fff' : (c.drop != null && Math.abs(z - c.drop) < .06 ? '#ff7a45' : '#ffd23f');
      g.beginPath(); g.moveTo(x, y - 6); g.lineTo(x + 6, y); g.lineTo(x, y + 6); g.lineTo(x - 6, y); g.closePath(); g.fill();
    });
    // en dehors du clip : grisé, poignées début / fin
    g.fillStyle = 'rgba(10,10,12,.62)';
    g.fillRect(HEAD, RUL, Math.max(0, X(c.t0) - HEAD), h - RUL); g.fillRect(X(c.t1), RUL, Math.max(0, w - X(c.t1)), h - RUL);
    [[c.t0, 1], [c.t1, -1]].forEach(([t, d]) => {
      const x = X(t); g.fillStyle = '#f2c94c'; g.fillRect(x - (d < 0 ? 3 : 0), RUL, 3, h - RUL);
      g.beginPath(); g.moveTo(x, RUL); g.lineTo(x + 9 * d, RUL); g.lineTo(x, RUL + 9); g.closePath(); g.fill();
    });
    // drops
    for (const dt of E.drops) {
      const x = X(dt); g.fillStyle = 'rgba(255,80,90,.5)'; g.fillRect(Math.round(x), RUL, 1, h - RUL);
      g.fillStyle = '#ff4f5e'; g.beginPath(); g.moveTo(x - 5, 2); g.lineTo(x + 5, 2); g.lineTo(x + 5, 10); g.lineTo(x, 15); g.lineTo(x - 5, 10); g.closePath(); g.fill();
    }
    // tête de lecture
    const xp = Math.round(X(E.t)) + .5;
    g.fillStyle = '#ff3b47'; g.fillRect(xp - .5, 0, 1.5, h);
    g.beginPath(); g.moveTo(xp - 6, 0); g.lineTo(xp + 6, 0); g.lineTo(xp + 6, 7); g.lineTo(xp, 13); g.lineTo(xp - 6, 7); g.closePath(); g.fill();
    const info = $('#leTlInfo'); if (info) info.textContent = Math.round(60 / p) + ' BPM · ' + c.shots.length + ' plan' + (c.shots.length > 1 ? 's' : '') + ' · ' + secs(c.t1 - c.t0);
  }
  function shade(hex, k) { const n = parseInt(hex.slice(1), 16); return 'rgb(' + Math.round((n >> 16) * k) + ',' + Math.round((n >> 8 & 255) * k) + ',' + Math.round((n & 255) * k) + ')'; }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  /* souris sur la timeline : tête de lecture, coupes, bords du clip, zooms, texte, lame */
  let drag = null;
  function hit(e) {
    const { cv, X } = geom(), r = cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, R = ROWS(), c = E.c, near = t => Math.abs(X(t) - x) <= 6;
    if (x < HEAD) return { kind: 'none' };
    if (y >= RUL && (near(c.t0) || near(c.t1)) && y < R.a + AT) return { kind: near(c.t0) ? 'in' : 'out', x };
    if (y < RUL) return { kind: 'scrub', x };
    if (y < R.v + VT) {
      if (E.tool !== 'blade') for (let i = 1; i < c.shots.length; i++) if (near(c.shots[i][0])) return { kind: 'cut', i, x };
      const { T } = geom(), t = T(x);
      if (t < c.t0 || t > c.t1) return { kind: 'scrub', x };
      return { kind: E.tool === 'blade' ? 'blade' : 'shot', i: shotIdx(t), x };
    }
    if (y < R.z + ZT) { for (let i = 0; i < c.zooms.length; i++) if (near(c.zooms[i])) return { kind: 'zoom', i, x }; return { kind: 'zoomadd', x }; }
    if (y < R.t + TT) {
      if (c.text) { if (near(c.text.at + c.text.secs)) return { kind: 'textend', x }; if (x >= X(c.text.at) && x <= X(c.text.at + c.text.secs)) return { kind: 'text', x }; }
      return { kind: 'textadd', x };
    }
    return { kind: 'scrub', x };
  }
  const CURSOR = { in: 'ew-resize', out: 'ew-resize', cut: 'col-resize', zoom: 'grab', text: 'grab', textend: 'ew-resize', blade: 'crosshair', shot: 'pointer', zoomadd: 'copy', textadd: 'copy' };
  function bindTl() {
    const cv = $('#leTl');
    cv.onpointermove = e => { if (drag) return dragMove(e); cv.style.cursor = CURSOR[hit(e).kind] || 'default'; };
    cv.onpointerdown = e => {
      if (e.button !== 0) return;
      const h = hit(e), { T } = geom(), t = T(h.x);
      cv.setPointerCapture(e.pointerId);
      const was = playing();
      drag = { kind: h.kind, i: h.i, x0: h.x, t0: t, moved: false, was, snap: snap() };
      if (h.kind === 'scrub') { if (was) pause(); seek(t); }
      else if (h.kind === 'blade') { const tt = E.snapOn && !e.altKey ? snapBeat(t, .35) : t; if (splitAt(tt)) { commit(); paintAll(); } drag = null; }
      else if (h.kind === 'shot') { E.sel = { kind: 'shot', i: h.i }; if (!was) seek(t); if (E.tab !== 'plan') E.tab = 'plan'; paintInsp(); drawTl(); }
      else if (h.kind === 'zoom') { E.sel = { kind: 'zoom', i: h.i }; drag.orig = E.c.zooms[h.i]; if (E.tab === 'zoom') paintInsp(); drawTl(); }
      else if (h.kind === 'zoomadd') { addZoom(t); drag = null; }
      else if (h.kind === 'text' || h.kind === 'textend') { E.sel = { kind: 'text' }; drag.orig = Object.assign({}, E.c.text); drawTl(); }
      else if (h.kind === 'textadd') { E.tab = 'text'; if (!E.c.text) { E.c.text = { hook: 'LE DROP', at: r3(clamp(t, E.c.t0, E.c.t1 - 1)), secs: 3, y: .3, sfx: false }; commit(); } paintInsp(); drawTl(); frame(true); drag = null; }
      else if (h.kind === 'cut') { drag.orig = E.c.shots[h.i][0]; }
      else if (h.kind === 'in' || h.kind === 'out') { drag.orig = [E.c.t0, E.c.t1]; drag.shots = JSON.stringify(E.c.shots); }
    };
    cv.onpointerup = e => {
      if (!drag) return;
      const d = drag; drag = null;
      if (d.moved && ['cut', 'in', 'out', 'zoom', 'text', 'textend'].includes(d.kind)) {
        if (d.kind === 'zoom') E.c.zooms.sort((a, b) => a - b);
        commit(); paintAll();
        if (d.kind === 'in' || d.kind === 'out') maybeWiden();
      }
    };
    cv.ondblclick = e => { const h = hit(e); if (h.kind === 'zoom') { E.c.zooms.splice(h.i, 1); E.sel = { kind: 'shot', i: shotIdx(E.t) }; commit(); drawTl(); if (E.tab === 'zoom') paintInsp(); } };
    cv.onwheel = e => { if (Math.abs(e.deltaX) > Math.abs(e.deltaY) || e.shiftKey) { e.preventDefault(); seek(E.t + (e.deltaX || e.deltaY) / 400); } };
  }
  function dragMove(e) {
    const { cv, T, X } = geom(), r = cv.getBoundingClientRect(), x = e.clientX - r.left, d = drag, c = E.c;
    let t = T(x); if (Math.abs(x - d.x0) > 2) d.moved = true;
    const sn = tt => E.snapOn && !e.altKey ? snapBeat(tt, (X(tt + 1) - X(tt)) > 0 ? 9 / (X(E.meta.w0 + 1) - X(E.meta.w0)) : .2) : tt;
    if (d.kind === 'scrub') { seek(t); return; }
    if (d.kind === 'cut') {
      const i = d.i, s = c.shots; t = clamp(sn(t), s[i - 1][0] + .1, s[i][1] - .1);
      s[i - 1][1] = s[i][0] = r3(t); drawTl(); seek(t); return;
    }
    if (d.kind === 'in') { t = clamp(sn(t), E.meta.w0, d.orig[1] - 2); E.c.shots = JSON.parse(d.shots); trimTo(t, d.orig[1], true); drawTl(); seek(t); return; }
    if (d.kind === 'out') { t = clamp(sn(t), d.orig[0] + 2, E.meta.w1); E.c.shots = JSON.parse(d.shots); trimTo(d.orig[0], t, true); drawTl(); seek(Math.max(E.c.t0, t - .5)); return; }
    if (d.kind === 'zoom') { c.zooms[d.i] = r3(clamp(sn(d.orig + (t - d.t0)), c.t0, c.t1)); drawTl(); return; }
    if (d.kind === 'text') { c.text.at = r3(clamp(sn(d.orig.at + (t - d.t0)), c.t0, c.t1 - .5)); drawTl(); seek(c.text.at + .3); return; }
    if (d.kind === 'textend') { c.text.secs = r3(clamp(sn(t) - c.text.at, .5, c.t1 - c.text.at)); drawTl(); return; }
  }

  /* cadrage à la souris dans l'aperçu (comme l'outil Transform du viewer de DaVinci) */
  function bindViewer() {
    const cv = $('#leCv'); let vd = null;
    cv.onpointerdown = e => {
      if (E.t < E.c.t0 || E.t > E.c.t1) return;
      const i = shotIdx(E.t), s = E.c.shots[i], cr = cropOf(E.t);
      E.sel = { kind: 'shot', i };
      vd = { x: e.clientX, y: e.clientY, s, fx: s[3].x == null ? xAuto(s, E.t) : s[3].x, fy: s[3].y == null ? .5 : s[3].y, cr, w: cv.clientWidth };
      cv.setPointerCapture(e.pointerId); cv.style.cursor = 'grabbing';
    };
    cv.onpointermove = e => {
      if (!vd) return;
      const k = W / vd.w, dx = (e.clientX - vd.x) * k, dy = (e.clientY - vd.y) * k;
      const s = vd.s;
      if (vd.cr.sw - W > 1) s[3].x = r3(clamp(vd.fx - dx / (vd.cr.sw - W), 0, 1));
      if (vd.cr.shh - H > 1) s[3].y = r3(clamp(vd.fy - dy / (vd.cr.shh - H), 0, 1));
      frame(true); drawTl();
    };
    cv.onpointerup = () => { if (!vd) return; vd = null; cv.style.cursor = ''; commit(); if (E.tab === 'plan') paintInsp(); };
    cv.onwheel = e => {
      if (E.t < E.c.t0 || E.t > E.c.t1) return;
      e.preventDefault();
      const s = E.c.shots[shotIdx(E.t)], z = clamp((s[3].zoom || 1) * Math.exp(-e.deltaY / 600), 1, 3);
      if (z <= 1.001) delete s[3].zoom; else s[3].zoom = r3(z);
      frame(true); drawTl(); clearTimeout(E.wheelT); E.wheelT = setTimeout(() => { commit(); if (E.tab === 'plan') paintInsp(); }, 350);
    };
  }

  function bindAll() {
    $('#lePlay').onclick = toggle;
    $('#lePrev').onclick = () => jumpCut(-1); $('#leNext').onclick = () => jumpCut(1);
    $('#leSplit').onclick = () => { if (splitAt(E.snapOn ? snapBeat(E.t, .2) : E.t)) { commit(); paintAll(); } };
    $('#leAddZoom').onclick = () => addZoom(E.t);
    $('#leSetIn').onclick = () => setIn(E.t); $('#leSetOut').onclick = () => setOut(E.t);
    $('#leSnap').onchange = e => { E.snapOn = e.target.checked; };
    $$('[data-tool]').forEach(b => b.onclick = () => setTool(b.dataset.tool)); setTool(E.tool);
    $$('.le-ang').forEach(b => b.onclick = e => pickAngle(+b.dataset.k, e.shiftKey));
    bindTl(); bindViewer(); tcRead();
    new ResizeObserver(() => { if (E.open) { drawTl(); fitPhone(); } }).observe($('#le'));
    fitPhone();
  }
  function fitPhone() {
    const sc = $('#leScreen'), ph = $('#lePhone'); if (!sc || !ph) return;
    const h = sc.clientHeight - 16, w = sc.clientWidth - 16, ph_h = Math.min(h, w * 16 / 9);
    ph.style.height = ph_h + 'px'; ph.style.width = (ph_h * 9 / 16) + 'px';
    const cv = $('#leCv'), dpr = Math.min(2, devicePixelRatio || 1), cw = Math.round(ph_h * 9 / 16 * dpr), ch = Math.round(ph_h * dpr);
    if (cv.width !== cw || cv.height !== ch) { cv.width = cw; cv.height = ch; frame(true); }
  }
  function setTool(t) { E.tool = t; $$('[data-tool]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.tool === t))); }
  function jumpCut(d) {
    const pts = [E.c.t0].concat(E.c.shots.slice(1).map(s => s[0]), [E.c.t1]);
    const t = d > 0 ? pts.find(p => p > E.t + .01) : pts.slice().reverse().find(p => p < E.t - .01);
    if (t != null) seek(t);
  }

  /* ================================================================ clavier (prioritaire quand l'éditeur est ouvert) */
  document.addEventListener('keydown', e => {
    if (!E.open || !E.ready || VC.S.view !== 'live') return;
    if (document.querySelector('dialog[open]')) return;
    const tg = e.target, typing = tg && (tg.tagName === 'TEXTAREA' || (tg.tagName === 'INPUT' && !['range', 'checkbox'].includes(tg.type)) || tg.isContentEditable);
    if (typing) return;
    const mod = e.metaKey || e.ctrlKey, k = e.key;
    let done = true;
    if (k === ' ') toggle();
    else if (mod && (k === 'z' || k === 'Z')) e.shiftKey ? redo() : undo();
    else if (mod && (k === 'b' || k === 'B')) { if (splitAt(E.snapOn ? snapBeat(E.t, .2) : E.t)) { commit(); paintAll(); } }
    else if (mod && (k === 'e' || k === 'E')) exportClip();
    else if (mod) done = false;
    else if (k === 'ArrowLeft') seek(E.t - (e.shiftKey ? 1 : 1 / 30));
    else if (k === 'ArrowRight') seek(E.t + (e.shiftKey ? 1 : 1 / 30));
    else if (k === 'ArrowUp') jumpCut(-1);
    else if (k === 'ArrowDown') jumpCut(1);
    else if (/^[1-9]$/.test(k)) pickAngle(+k - 1, e.shiftKey);
    else if (k === 'b' || k === 'B') setTool(E.tool === 'blade' ? 'select' : 'blade');
    else if (k === 'a' || k === 'A') setTool('select');
    else if (k === 'z' || k === 'Z') addZoom(E.t);
    else if (k === 'i' || k === 'I') setIn(E.t);
    else if (k === 'o' || k === 'O') setOut(E.t);
    else if (k === 'l' || k === 'L') { const l = $('#leLoop'); l.checked = !l.checked; }
    else if (k === 'Home') seek(E.c.t0);
    else if (k === 'End') seek(E.c.t1 - .05);
    else if (k === 'Backspace' || k === 'Delete') {
      if (E.sel.kind === 'zoom' && E.c.zooms[E.sel.i] != null) { E.c.zooms.splice(E.sel.i, 1); E.sel = { kind: 'shot', i: shotIdx(E.t) }; commit(); drawTl(); if (E.tab === 'zoom') paintInsp(); }
      else if (E.sel.kind === 'text') { E.c.text = null; E.sel = { kind: 'shot', i: shotIdx(E.t) }; commit(); paintAll(); }
      else if (E.sel.kind === 'shot' && E.sel.i > 0) mergeShot(E.sel.i);
    }
    else if (k === 'Escape') close();
    else done = false;
    if (done) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);

  /* ================================================================ export, DaVinci, suppression */
  async function exportClip() {
    if (E.exporting) return;
    pause(); E.exporting = true; paintTop();
    try {
      await flush();
      const r = await VC.api('/api/live/edit/export', { lid: E.lid, n: E.n });
      const j = await VC.poll(r.job, x => { const b = $('#leXbar'); if (b) b.style.width = Math.round((x.progress || 0) * 100) + '%'; });
      if (j.error) throw new Error(j.error);
      E.c.file = j.result.file; E.c.state = snap() === E.last && !saveT ? 'done' : 'edited';
      VC.sound('done'); VC.toast('Clip ' + E.c.n + ' exporté', 3000);
    } catch (e) { VC.toast(e.message, 7000); VC.sound('error'); }
    E.exporting = false; if (E.open) paintTop();
  }
  async function sendDavinci() {
    pause();
    try {
      await flush();
      VC.toast('Préparation de la timeline pour DaVinci…', 2500);
      const r = await VC.api('/api/live/edit/davinci', { lid: E.lid, n: E.n });
      const j = await VC.poll(r.job);
      if (j.error) throw new Error(j.error);
      VC.sound('ready');
      if (j.result.auto) VC.toast('Clip ' + E.c.n + ' ouvert dans DaVinci (timeline verticale, couleur et texte compris).', 6000);
      else await VC.confirm('Clip prêt pour DaVinci', 'Dans DaVinci, ouvre ton projet puis Espace de travail ▸ Scripts ▸ OMAGAD - Importer les clips LIVEAGAD. Le clip arrive dans sa timeline verticale avec tes coupes, cadrages, couleur et texte.', 'OK');
    } catch (e) { VC.toast(e.message, 7000); VC.sound('error'); }
  }
  async function delClip() {
    if (!await VC.confirm('Supprimer le clip ' + E.c.n + ' ?', 'Il disparaît de la liste. Le fichier déjà exporté n\'est pas effacé.', 'Supprimer')) return;
    clearTimeout(saveT); saveT = null;
    try { await VC.api('/api/live/edit/delete', { lid: E.lid, n: E.n }); } catch (e) { return VC.toast(e.message); }
    E.ready = false; close();
  }

  const ICON = {
    cams: '<svg viewBox="0 0 48 48" width="44" height="44"><g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><rect x="4" y="8" width="18" height="13" rx="2"/><rect x="26" y="8" width="18" height="13" rx="2"/><rect x="4" y="27" width="18" height="13" rx="2"/><rect x="26" y="27" width="18" height="13" rx="2"/></g></svg>',
    play: '<svg viewBox="0 0 20 20" width="18" height="18"><path d="M6 4l10 6-10 6z" fill="currentColor"/></svg>',
    pause: '<svg viewBox="0 0 20 20" width="18" height="18"><path d="M5 4h3.5v12H5zM11.5 4H15v12h-3.5z" fill="currentColor"/></svg>',
    prev: '<svg viewBox="0 0 20 20" width="16" height="16"><path d="M5 4v12M16 4l-8 6 8 6z" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    next: '<svg viewBox="0 0 20 20" width="16" height="16"><path d="M15 4v12M4 4l8 6-8 6z" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    back: '<svg viewBox="0 0 20 20" width="14" height="14"><path d="M12.5 5l-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    undo: '<svg viewBox="0 0 20 20"><path d="M7 5L3 9l4 4M3 9h9a5 5 0 010 10h-2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    redo: '<svg viewBox="0 0 20 20"><path d="M13 5l4 4-4 4M17 9H8a5 5 0 000 10h2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    select: '<svg viewBox="0 0 20 20" width="15" height="15"><path d="M5 3l10 7-4.5 1 2.5 5-2 1-2.5-5L5 15z" fill="currentColor"/></svg>',
    blade: '<svg viewBox="0 0 20 20" width="15" height="15"><path d="M4 16L14 3l2 2L6 18z" fill="currentColor"/><path d="M3 17l2 1" stroke="currentColor" stroke-width="2"/></svg>',
    dv: '<svg viewBox="0 0 20 20" width="14" height="14"><circle cx="7" cy="7" r="3.2" fill="#e64b3c"/><circle cx="13" cy="7" r="3.2" fill="#3fa9f0"/><circle cx="10" cy="12.5" r="3.2" fill="#f2c94c"/></svg>',
    trash: '<svg viewBox="0 0 20 20" width="15" height="15"><path d="M4 6h12M8 6V4h4v2M6 6l1 10h6l1-10" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };
})();
