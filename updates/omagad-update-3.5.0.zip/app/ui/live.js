/* LIVEAGAD : une timeline DaVinci d'une date → des dizaines de clips verticaux du set, montés et exportés tout seuls. */
(function () {
  const { $, $$, esc, fmt } = VC;
  const L = VC.L = { lid: null, data: null, job: null, list: [] };
  const LEN = [['mix', 'Mélange (15 à 45 s)'], ['short', 'Courts (≈ 15 s)'], ['medium', 'Moyens (≈ 30 s)'], ['long', 'Longs (≈ 45 s)']];
  const CAMS = [['all', 'Multicam + chaque caméra'], ['multi', 'Multicam seulement'], ['single', 'Une caméra par clip']];
  const COUNTS = [20, 30, 50, 75, 100, 150, 200];
  const S = () => VC.S.state.settings;

  VC.screens.live = async function () {
    $('#view').innerHTML = '<div class="live"><section class="lv-side" id="lvSide"></section><section class="lv-main" id="lvMain"></section></div>';
    try {
      const r = await VC.api('/api/live'); L.list = r.items;
      if (r.running) { L.lid = r.running.lid; L.job = r.running.job; }
    } catch (e) { L.list = []; }
    if (L.lid && !L.list.find(x => x.id === L.lid)) L.lid = null;
    await loadCurrent();
    if (L.job) follow(L.job);
  };

  async function loadCurrent() {
    L.data = null;
    if (L.lid) { try { L.data = await VC.api('/api/live/' + L.lid); } catch (e) { L.lid = null; } }
    paint();
  }

  /* ---------- Import d'une timeline ---------- */
  VC.liveImport = async function (path) {
    try {
      const r = await VC.api('/api/live/import', { path });
      L.lid = r.lid; VC.sound('ready');
      if (VC.S.view === 'live') { const x = await VC.api('/api/live'); L.list = x.items; await loadCurrent(); }
    } catch (e) { VC.toast(e.message, 7000); VC.sound('error'); }
  };
  async function pick() {
    if (!VC.native() || !window.pywebview.api.pick_timeline) return VC.toast('Glisse ta timeline (.xml ou .fcpxml) dans la fenêtre d\'OMAGAD.');
    const p = await window.pywebview.api.pick_timeline(); if (p) VC.liveImport(p);
  }

  /* ---------- Affichage ---------- */
  function paint() {
    const side = $('#lvSide'), main = $('#lvMain'); if (!side) return;
    const d = L.data;
    if (!d) {
      side.innerHTML = '<div class="lv-drop" id="lvDrop"><div class="lv-drop-ico">' + EQ + '</div><h2>Dépose la timeline de ta date</h2>' +
        '<p class="hint">Dans DaVinci : <b>Fichier ▸ Exporter ▸ Timeline…</b> puis <b>FCPXML</b> ou <b>FCP 7 XML</b>. Les caméras sont les pistes vidéo (V1, V2…), elles doivent être synchronisées.</p>' +
        '<div class="lv-dvbtns"><button class="btn primary big" type="button" id="lvPick">Choisir la timeline</button>' +
        '<button class="btn big" type="button" id="lvFromDv">Récupérer depuis DaVinci</button></div><p class="hint" id="lvDvMsg" style="margin:0"></p></div>' + recents();
      main.innerHTML = '<div class="lv-empty"><b>Comment ça marche</b><ol class="hint"><li>OMAGAD écoute ton set : tempo, montées, drops, passages les plus forts.</li>' +
        '<li>Pour chaque moment fort, il monte plusieurs clips : multicam coupé sur les mesures, chaque caméra seule, versions courtes et longues, zooms sur le drop.</li>' +
        '<li>Le cadre suit le sujet (recadrage vertical automatique), le son est mis au niveau des réseaux.</li>' +
        '<li>Tout est exporté dans un dossier au nom de la date : 1.mp4, 2.mp4… du meilleur au moins bon.</li></ol></div>';
      $('#lvPick').onclick = pick; $('#lvFromDv').onclick = getFromResolve;
      bindRecents();
      return;
    }
    const tl = d.timeline, st = S(), running = !!L.job;
    const done = d.clips.filter(c => c.state === 'done').length;
    side.innerHTML = '<div class="lv-card"><div class="lv-head"><button class="icon-btn" type="button" id="lvBack" title="Autres timelines"><svg viewBox="0 0 20 20" width="16" height="16"><path d="M12.5 5l-5 5 5 5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
      '<input type="text" id="lvName" value="' + esc(d.name) + '" maxlength="80" title="Nom de la date (et du dossier d\'export)"></div>' +
      '<div class="lv-facts"><span><b>' + fmt(tl.duration) + '</b> de timeline</span><span><b>' + tl.cams.length + '</b> caméra' + (tl.cams.length > 1 ? 's' : '') + '</span>' +
      '<span><b>' + tl.files + '</b> rushes</span>' + (d.analysis ? '<span><b>' + Math.round(d.analysis.bpm) + '</b> BPM</span><span><b>' + d.analysis.drops.length + '</b> drops</span>' : '') + '</div>' +
      '</div>' + '<div class="lv-warns">' +
      (tl.ignored_tracks ? '<p class="hint" style="margin:0">' + tl.ignored_tracks + ' piste(s) ignorée(s) (logos, images, pistes presque vides).</p>' : '') +
      (tl.missing.length ? '<div class="ff-warn"><b>' + tl.missing.length + ' rush(es) introuvable(s)</b><span class="hint">Ils ont été déplacés depuis le montage. Choisis le dossier où ils se trouvent (les sous-dossiers sont fouillés).</span>' +
        '<button class="btn small primary" type="button" id="lvRelink">Retrouver les rushes</button></div>' : '') +
      '</div>' +
      camsCard(d) + rulesCard() +
      '<div class="lv-card"><span class="label">Clips à fabriquer</span>' +
      '<div class="field"><label for="lvCount">Nombre de clips</label><select id="lvCount">' + COUNTS.map(n => '<option value="' + n + '"' + ((st.live_count || 100) === n ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></div>' +
      '<div class="field"><label for="lvLen">Durée</label><select id="lvLen">' + LEN.map(o => '<option value="' + o[0] + '"' + ((st.live_length || 'mix') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></div>' +
      '<div class="field"><label for="lvCams">Caméras</label><select id="lvCams"' + (tl.cams.length < 2 ? ' disabled' : '') + '>' + CAMS.map(o => '<option value="' + o[0] + '"' + ((st.live_cams || 'all') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></div>' +
      '<label class="check"><input type="checkbox" id="lvPunch"' + (st.live_punch !== false ? ' checked' : '') + '> Zooms « punch » sur le drop et les mesures</label>' +
      '<label class="check"><input type="checkbox" id="lvTrack"' + (st.live_tracking !== false ? ' checked' : '') + '> Recadrage automatique sur le sujet</label>' +
      '<div class="field"><label for="lvOut">Dossier d\'export</label><div class="path"><input type="text" id="lvOut" value="' + esc(st.out_dir) + '"><button class="btn small" type="button" id="lvDir">Parcourir</button></div>' +
      '<span class="hint" id="lvPath"></span></div></div>' +
      davinciCard(d) +
      '<div class="lv-run"><div id="lvProg"' + (running ? '' : ' hidden') + '><div class="bar-prog"><i id="lvBar"></i></div><div class="hint" id="lvMsg"></div></div>' +
      '<button class="btn ' + (running ? 'danger' : 'primary') + ' big" type="button" id="lvGo"' + (tl.missing.length && !running ? ' disabled' : '') + '>' +
      (running ? 'Arrêter' : done && done < d.clips.length ? 'Reprendre l\'export' : done ? 'Tout refaire et exporter' : 'Générer et exporter') + '</button>' +
      (d.out_dir && done ? '<button class="btn ghost" type="button" id="lvOpen">Ouvrir le dossier (' + done + ' clips)</button>' : '') + '</div>';
    main.innerHTML = '<div class="lv-graph dv-tl"><div class="lv-gh"><b>Timeline</b><span class="hint" id="lvTc">' + (d.analysis ? '<i class="lg-drop"></i> drops · <i class="lg-clip"></i> clips générés · survole un clip pour voir ses plans' : 'Les drops et l\'énergie s\'affichent après l\'analyse') + '</span></div><canvas id="lvCanvas"></canvas></div>' +
      '<div class="lv-grid-head"><b>Clips</b><span class="hint">Clique un clip pour le monter · double-clic sur la timeline pour créer un clip à cet endroit</span><span class="hint" id="lvCount2"></span></div><div class="lv-grid" id="lvGrid"></div>';
    bindSide(); bindCams(); bindRules(); bindDavinci(); drawGraph(); paintGrid();
  }

  /* ---------- Caméras : rôle de chaque piste (comme les pistes dans DaVinci) ---------- */
  /* types de caméra : Booth, Fosse, FOH + ceux que tu ajoutes (Drone, Scène, Platines…), jusqu'à 8 caméras et plus */
  const BASE_TYPES = [{ id: 'booth', name: 'Booth', color: '#f0a53a' }, { id: 'crowd', name: 'Fosse', color: '#e2508c' }, { id: 'foh', name: 'FOH', color: '#3fa9f0' }];
  const PALETTE = ['#9b6bff', '#3ddc97', '#ffd23f', '#ff7a45', '#5ce1e6', '#c3e85b', '#ff5cf0', '#7aa2ff', '#ffa3a3', '#b0f2b4'];
  const TYPES = () => { const t = S().live_roles; return Array.isArray(t) && t.length ? t : BASE_TYPES; };
  const ROLES_ALL = () => TYPES().map(t => [t.id, t.name]).concat([['other', 'Autre'], ['off', 'Ignorée']]);
  const RCOL = new Proxy({}, { get: (_, r) => (TYPES().find(t => t.id === r) || {}).color || (r === 'off' ? '#3a3f4a' : '#8e95a3') });
  const RL = r => (ROLES_ALL().find(x => x[0] === r) || ['', 'Autre'])[1];
  function camsCard(d) {
    const tl = d.timeline;
    return '<div class="lv-card"><span class="label">Caméras</span>' +
      '<p class="hint" style="margin:0">Dis à OMAGAD quelle piste est quelle caméra : il s\'en sert pour monter tous les clips.</p>' +
      '<div class="lv-types">' + TYPES().map(t => '<span class="lv-type" style="--rc:' + t.color + '">' + esc(t.name) + '<button type="button" data-deltype="' + t.id + '" title="Supprimer ce type">×</button></span>').join('') +
      '<button class="btn small" type="button" id="lvAddType">+ Ajouter une caméra</button></div>' +
      tl.cams.map((c, k) => '<div class="lv-camrow" style="--rc:' + RCOL[c.role || 'other'] + '"><img src="/livecam/' + L.lid + '/' + k + '.jpg" alt="" loading="lazy">' +
        '<div class="lv-camtxt"><b>V' + (c.track || k + 1) + '</b><span>' + esc(c.name.replace(/\s*\(V\d+\)$/, '')) + ' · ' + c.items + ' plan' + (c.items > 1 ? 's' : '') + '</span></div>' +
        '<select data-cam="' + k + '">' + ROLES_ALL().map(r => '<option value="' + r[0] + '"' + ((c.role || 'other') === r[0] ? ' selected' : '') + '>' + r[1] + '</option>').join('') + '</select></div>').join('') + '</div>';
  }
  async function saveTypes(list) {
    VC.S.state.settings.live_roles = list; await VC.saveSettings({ live_roles: list }); paint();
  }
  function bindCams() {
    $('#lvAddType').onclick = async () => {
      const name = await VC.prompt('Nouvelle caméra', 'Donne-lui un nom (ex. Drone, Scène, Platines, Backstage). Tu pourras ensuite l\'attribuer à une piste et l\'utiliser dans les règles du multicam.', '', 'Ajouter');
      if (!name) return;
      const list = TYPES().slice();
      if (list.some(t => t.name.toLowerCase() === name.trim().toLowerCase())) return VC.toast('« ' + name + ' » existe déjà.');
      let id = name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'cam';
      while (list.some(t => t.id === id) || ['other', 'off'].includes(id)) id += '2';
      const used = list.map(t => t.color), color = PALETTE.find(c => !used.includes(c)) || PALETTE[list.length % PALETTE.length];
      list.push({ id, name: name.slice(0, 24), color });
      const r = rules(); r.after = r.after.concat([id]);  // la nouvelle caméra entre dans l'alternance après le drop
      VC.S.state.settings.live_rules = r; VC.saveSettings({ live_rules: r });
      await saveTypes(list);
    };
    $$('[data-deltype]').forEach(b => b.onclick = async () => {
      const id = b.dataset.deltype, t = TYPES().find(x => x.id === id);
      if (TYPES().length <= 1) return VC.toast('Garde au moins un type de caméra.');
      if (!await VC.confirm('Supprimer « ' + t.name + ' » ?', 'Les pistes qui avaient ce type passent en « Autre ».', 'Supprimer')) return;
      const roles = L.data.timeline.cams.map(c => c.role === id ? 'other' : c.role);
      await VC.api('/api/live/roles', { lid: L.lid, roles });
      L.data.timeline.cams.forEach((c, k) => c.role = roles[k]);
      const r = rules(); ['pre', 'drop', 'after'].forEach(k => r[k] = r[k].filter(x => x !== id));
      VC.S.state.settings.live_rules = r; VC.saveSettings({ live_rules: r });
      await saveTypes(TYPES().filter(x => x.id !== id));
    });
    $$('.lv-camrow select').forEach(sel => sel.onchange = async () => {
      const roles = $$('.lv-camrow select').map(x => x.value);
      L.data.timeline.cams.forEach((c, k) => c.role = roles[k]);
      sel.closest('.lv-camrow').style.setProperty('--rc', RCOL[sel.value]);
      await VC.api('/api/live/roles', { lid: L.lid, roles }); drawGraph(); paintRules();
    });
  }

  /* ---------- Règles du montage multicam (appliquées à tous les clips et à toutes les dates) ---------- */
  const DEF = { pre: ['booth'], pre_bars: 0, drop: ['foh', 'crowd'], after: ['crowd', 'booth', 'foh'], after_bars: 4 };
  const rules = () => Object.assign({}, DEF, S().live_rules || {});
  function chips(id, sel, list) {
    return '<div class="lv-chips" id="' + id + '">' + list.map(r => '<label class="lv-chip" style="--rc:' + RCOL[r] + '"><input type="checkbox" value="' + r + '"' + (sel.includes(r) ? ' checked' : '') + '><span>' + RL(r) + '</span></label>').join('') + '</div>';
  }
  const ids = () => TYPES().map(t => t.id);
  function rulesCard() {
    const r = rules();
    return '<div class="lv-card"><span class="label">Montage multicam</span>' +
      '<div class="lv-rule"><span>Pendant la montée</span>' + chips('ruPre', r.pre, ids()) + '</div>' +
      '<div class="lv-rule"><span>Couper pendant la montée</span><select id="ruPreBars"><option value="0">Jamais (on reste sur la même caméra)</option><option value="2">Toutes les 2 mesures</option><option value="4">Toutes les 4 mesures</option><option value="8">Toutes les 8 mesures</option></select></div>' +
      '<div class="lv-rule"><span>Pile sur le drop</span>' + chips('ruDrop', r.drop, ids()) + '<i class="hint">une version du clip par caméra cochée</i></div>' +
      '<div class="lv-rule"><span>Après le drop, alterner</span>' + chips('ruAfter', r.after, ids()) + '</div>' +
      '<div class="lv-rule"><span>Changer de caméra</span><select id="ruAfterBars"><option value="2">Toutes les 2 mesures</option><option value="4">Toutes les 4 mesures</option><option value="8">Toutes les 8 mesures</option></select></div>' +
      '<div class="lv-scheme" id="ruScheme"></div></div>';
  }
  function bindRules() {
    const r = rules();
    $('#ruPreBars').value = String(r.pre_bars || 0); $('#ruAfterBars').value = String(r.after_bars || 4);
    const save = () => {
      const pick = id => $$('#' + id + ' input:checked').map(x => x.value);
      const nr = { pre: pick('ruPre'), pre_bars: +$('#ruPreBars').value, drop: pick('ruDrop'), after: pick('ruAfter'), after_bars: +$('#ruAfterBars').value };
      if (!nr.pre.length) nr.pre = ['booth']; if (!nr.drop.length) nr.drop = ['foh']; if (!nr.after.length) nr.after = ['crowd'];
      VC.S.state.settings.live_rules = nr; VC.saveSettings({ live_rules: nr }); paintRules();
    };
    $$('#ruPre input, #ruDrop input, #ruAfter input').forEach(x => x.onchange = save);
    $('#ruPreBars').onchange = save; $('#ruAfterBars').onchange = save;
    paintRules();
  }
  function paintRules() {
    const el = $('#ruScheme'); if (!el || !L.data) return;
    const r = rules(), have = new Set(L.data.timeline.cams.map(c => c.role));
    const ok = x => have.has(x);
    const seg = (role, w, txt) => '<i style="flex:' + w + ';--rc:' + RCOL[role] + '" class="' + (ok(role) ? '' : 'miss') + '">' + (txt || RL(role)) + '</i>';
    const pre = r.pre_bars ? r.pre.concat(r.pre).slice(0, 2) : [r.pre[0]];
    const after = r.after.filter(x => x !== r.drop[0]);
    el.innerHTML = '<div class="lv-sch">' + pre.map(x => seg(x, 4 / pre.length)).join('') + '<b>DROP</b>' + seg(r.drop[0], 2) + (after.length ? after.slice(0, 2).map(x => seg(x, 2)).join('') : '') + '</div>' +
      (r.drop.length > 1 ? '<span class="hint">+ ' + (r.drop.length - 1) + ' autre(s) version(s) : drop sur ' + r.drop.slice(1).map(RL).join(', ') + '</span>' : '') +
      ([...r.pre, ...r.drop, ...r.after].some(x => !ok(x)) ? '<span class="hint warn">Les rôles grisés n\'ont pas de caméra : OMAGAD prend la suivante.</span>' : '');
  }

  /* ---------- DaVinci : récupérer la timeline ouverte, renvoyer les clips ---------- */
  function davinciCard(d) {
    return '<div class="lv-card"><span class="label">DaVinci Resolve</span>' +
      '<div class="lv-dvbtns"><button class="btn small" type="button" id="dvGet">Récupérer depuis DaVinci</button>' +
      '<button class="btn small" type="button" id="dvSend"' + (d.clips.length ? '' : ' disabled') + '>Envoyer les clips dans DaVinci</button></div>' +
      '<p class="hint" style="margin:0" id="dvLiveMsg">Récupère la timeline ouverte dans DaVinci sans l\'exporter, ou renvoie chaque clip en timeline verticale (mêmes rushes, mêmes coupes) pour le retoucher dans DaVinci.</p>' +
      '<div class="lv-panel" id="dvPanel"><b>Panneau OMAGAD dans DaVinci</b><span class="hint" id="dvPanelTxt">…</span><button class="btn small" type="button" id="dvPanelBtn" hidden></button></div></div>';
  }
  async function paintPanel() {
    const txt = $('#dvPanelTxt'), btn = $('#dvPanelBtn'); if (!txt) return;
    let st; try { st = await VC.api('/api/davinci/panel'); } catch (e) { txt.textContent = e.message; return; }
    if (!st.supported) { txt.textContent = 'Disponible sur Mac avec DaVinci Resolve Studio.'; return; }
    btn.hidden = false;
    if (st.uptodate) { txt.innerHTML = 'Installé. Dans DaVinci : <b>Espace de travail ▸ Workflow Integrations ▸ OMAGAD</b>.'; btn.textContent = 'Réinstaller'; }
    else if (st.installed) { txt.textContent = 'Une nouvelle version du panneau est prête (' + st.available + ').'; btn.textContent = 'Mettre à jour le panneau'; }
    else { txt.textContent = 'Envoie ta timeline, génère et importe tes clips sans quitter DaVinci (Studio).'; btn.textContent = 'Installer le panneau'; }
    btn.onclick = async () => {
      btn.disabled = true; txt.textContent = 'Installation… (macOS peut demander le mot de passe de ton Mac)';
      try { await VC.api('/api/davinci/panel-install', {}); VC.sound('ready'); await paintPanel();
        txt.innerHTML = 'Installé. <b>Redémarre DaVinci</b>, puis <b>Espace de travail ▸ Workflow Integrations ▸ OMAGAD</b>.'; }
      catch (e) { txt.textContent = e.message; VC.sound('error'); }
      btn.disabled = false;
    };
  }
  function bindDavinci() {
    paintPanel();
    $('#dvGet').onclick = getFromResolve;
    $('#dvSend').onclick = async () => {
      const msg = $('#dvLiveMsg'); msg.textContent = 'Préparation des timelines pour DaVinci…';
      try {
        const r = await VC.api('/api/live/davinci-send', { lid: L.lid });
        const j = await VC.poll(r.job, x => { if ($('#dvLiveMsg')) $('#dvLiveMsg').textContent = x.message || ''; });
        if (j.error) throw new Error(j.error);
        VC.sound('ready');
        if ($('#dvLiveMsg')) $('#dvLiveMsg').innerHTML = j.result.auto ? j.result.count + ' clips importés dans DaVinci, chacun dans sa timeline verticale.' :
          j.result.count + ' timelines prêtes. Dans DaVinci, ouvre ton projet puis <b>Espace de travail ▸ Scripts ▸ OMAGAD - Importer les clips LIVEAGAD</b>.';
      } catch (e) { if ($('#dvLiveMsg')) $('#dvLiveMsg').textContent = e.message; VC.sound('error'); }
    };
  }
  async function getFromResolve() {
    const msg = $('#dvLiveMsg') || $('#lvDvMsg');
    try {
      const r = await VC.api('/api/live/davinci-get', {});
      if (r.auto) { if (msg) msg.textContent = 'Timeline reçue de DaVinci…'; return pollInbox(); }
      if (msg) msg.innerHTML = r.installed ? 'Dans DaVinci, ouvre la timeline de ta date puis <b>Espace de travail ▸ Scripts ▸ OMAGAD - Envoyer la timeline a LIVEAGAD</b>. Elle arrive ici toute seule.'
        : 'Le script DaVinci n\'a pas pu être installé (OMAGAD sur Mac uniquement).';
    } catch (e) { if (msg) msg.textContent = e.message; }
  }
  /* Timelines envoyées par le script DaVinci : importées automatiquement */
  let inboxBusy = false;
  async function pollInbox() {
    if (inboxBusy) return; inboxBusy = true;
    try {
      const r = await VC.api('/api/live/inbox');
      if (r.files.length) {
        const x = await VC.api('/api/live/inbox-import', {});
        if (x.lids.length) { L.lid = x.lids[x.lids.length - 1]; VC.sound('ready'); VC.toast('Timeline reçue de DaVinci', 2500); const y = await VC.api('/api/live'); L.list = y.items; await loadCurrent(); }
      }
    } catch (e) { /* on réessaie plus tard */ }
    inboxBusy = false;
  }
  setInterval(() => { if (VC.S.view === 'live' && !L.job) pollInbox(); }, 2500);

  function recents() {
    if (!L.list.length) return '';
    return '<div class="lv-recents"><span class="label">Dates récentes</span>' + L.list.map(x =>
      '<div class="lv-rec" data-lid="' + x.id + '">' + (x.thumb ? '<img src="/livethumb/' + x.id + '/' + x.thumb + '.jpg" alt="">' : '<span class="lv-rec-ph">' + EQ + '</span>') +
      '<div><b>' + esc(x.name) + '</b><span class="hint">' + fmt(x.duration) + ' · ' + x.cams + ' cam · ' + x.clips + ' clips</span></div>' +
      '<button class="icon-btn" type="button" data-del="' + x.id + '" title="Supprimer">×</button></div>').join('') + '</div>';
  }
  function bindRecents() {
    $$('.lv-rec').forEach(el => el.onclick = async e => {
      const del = e.target.closest('[data-del]');
      if (del) {
        e.stopPropagation();
        if (!await VC.confirm('Supprimer cette date ?', 'L\'analyse et la liste des clips sont effacées. Les clips déjà exportés et tes rushes ne sont pas touchés.', 'Supprimer')) return;
        await VC.api('/api/live/delete', { lid: del.dataset.del }); return VC.screens.live();
      }
      L.lid = el.dataset.lid; loadCurrent();
    });
  }

  function opts() {
    return { count: +$('#lvCount').value, length: $('#lvLen').value, cams: $('#lvCams').value, punch: $('#lvPunch').checked,
      tracking: $('#lvTrack').checked, out_dir: $('#lvOut').value.trim() };
  }
  function pathHint() {
    const el = $('#lvPath'); if (!el) return;
    const name = ($('#lvName').value || 'set').replace(/[\\/:*?"<>|]+/g, '-');
    el.textContent = ($('#lvOut').value || S().out_dir).replace(/^\/Users\/[^/]+/, '~').replace(/\/$/, '') + '/' + name + '/1.mp4, 2.mp4…';
  }
  function bindSide() {
    $('#lvBack').onclick = () => { if (L.job) return VC.toast('Une génération est en cours.'); L.lid = null; VC.screens.live(); };
    $('#lvName').onchange = e => { VC.api('/api/live/rename', { lid: L.lid, name: e.target.value }); L.data.name = e.target.value; pathHint(); };
    $('#lvName').onkeydown = e => e.stopPropagation();
    const save = () => VC.saveSettings({ live_count: +$('#lvCount').value, live_length: $('#lvLen').value, live_cams: $('#lvCams').value,
      live_punch: $('#lvPunch').checked, live_tracking: $('#lvTrack').checked });
    ['#lvCount', '#lvLen', '#lvCams', '#lvPunch', '#lvTrack'].forEach(s => $(s).onchange = save);
    $('#lvOut').oninput = pathHint;
    $('#lvDir').onclick = async () => { if (!VC.native()) return; const d = await window.pywebview.api.pick_folder($('#lvOut').value); if (d) { $('#lvOut').value = d; pathHint(); } };
    pathHint();
    const rl = $('#lvRelink');
    if (rl) rl.onclick = async () => {
      if (!VC.native()) return;
      const f = await window.pywebview.api.pick_folder(''); if (!f) return;
      const r = await VC.api('/api/live/relink', { lid: L.lid, folder: f });
      VC.toast(r.found + ' rush(es) retrouvé(s)' + (r.missing ? ', ' + r.missing + ' encore introuvable(s)' : ''), 5000);
      loadCurrent();
    };
    $('#lvGo').onclick = async () => {
      if (L.job) { await VC.api('/api/cancel/' + L.job, {}); return; }
      try { const r = await VC.api('/api/live/run', { lid: L.lid, opts: opts() }); L.job = r.job; paint(); follow(r.job); }
      catch (e) { VC.toast(e.message, 6000); }
    };
    const op = $('#lvOpen'); if (op) op.onclick = () => VC.api('/api/reveal', { path: L.data.out_dir });
  }

  /* ---------- Suivi de la génération ---------- */
  let lastRefresh = 0;
  async function follow(job) {
    try {
      const j = await VC.poll(job, async x => {
        const bar = $('#lvBar'), msg = $('#lvMsg');
        if (bar) bar.style.width = Math.round((x.progress || 0) * 100) + '%';
        if (msg) msg.textContent = x.message || '';
        if (Date.now() - lastRefresh > 2500 && L.lid && VC.S.view === 'live') {
          lastRefresh = Date.now();
          try { const d = await VC.api('/api/live/' + L.lid); if (!L.data || d.analysis && !L.data.analysis) { L.data = d; paint(); } else { L.data = d; paintGrid(); drawGraph(); } } catch (e) { /* suivant */ }
        }
      });
      L.job = null;
      if (j.error) { VC.toast(j.error, 8000); VC.sound('error'); }
      else { VC.toast(VC.t(j.message || 'Terminé'), 5000); VC.sound('done'); }
    } catch (e) { L.job = null; }
    if (VC.S.view === 'live') loadCurrent();
  }

  /* ---------- Grille des clips ---------- */
  function paintGrid() {
    const g = $('#lvGrid'); if (!g || !L.data) return;
    const cl = L.data.clips, done = cl.filter(c => c.state === 'done').length;
    $('#lvCount2').textContent = cl.length ? done + ' / ' + cl.length + ' exportés' : '';
    g.innerHTML = cl.length ? cl.map(c => '<div class="lv-clip ' + (c.state || 'wait') + (c.file ? ' has' : '') + '" data-n="' + c.n + '" title="' + esc(c.error || c.label) + ' · clic pour monter ce clip">' +
      '<div class="lv-th">' + (c.file && (c.state === 'done' || c.state === 'edited') ? '<img loading="lazy" src="/livethumb/' + L.lid + '/' + c.n + '.jpg?v=' + (c.file ? c.file.length : 0) + '" alt="">' : '') +
      '<span class="lv-n">' + c.n + '</span>' + (c.state === 'error' ? '<span class="lv-st err">!</span>' : c.state === 'edited' ? '<span class="lv-st ed">à réexporter</span>' : c.state === 'done' ? '' : '<span class="lv-st">…</span>') +
      (c.edited ? '<span class="lv-ed" title="Retouché dans l\'éditeur">✎</span>' : '') + '<span class="lv-open">Monter</span></div>' +
      '<div class="lv-lab">' + esc(c.label) + '</div></div>').join('')
      : '<div class="lv-empty"><b>Prêt</b><span class="hint">Règle le nombre de clips à gauche, puis « Générer et exporter ». Tu peux laisser tourner : tout se fait seul.</span></div>';
    g.onmouseover = e => { const el = e.target.closest('.lv-clip'); const n = el ? +el.dataset.n : null; if (n !== L.hover) { L.hover = n; drawGraph(); } };
    g.onmouseleave = () => { L.hover = null; drawGraph(); };
    g.onclick = e => { const el = e.target.closest('.lv-clip'); if (!el) return; if (L.job) return VC.toast('Attends la fin de la génération pour monter un clip (ou arrête-la).', 4000); VC.liveEdit(L.lid, +el.dataset.n); };
  }

  /* ---------- Timeline façon DaVinci : pistes V (caméras), A1 (son + énergie), marqueurs de drops ---------- */
  function tc(t, fps) {
    fps = Math.round(fps || 25); const f = Math.floor(t * fps + 1e-6), tot = 3600 * fps + f;
    const p2 = n => String(n).padStart(2, '0');
    return p2(Math.floor(tot / (3600 * fps))) + ':' + p2(Math.floor(tot / (60 * fps)) % 60) + ':' + p2(Math.floor(tot / fps) % 60) + ':' + p2(tot % fps);
  }
  function drawGraph() {
    const cv = $('#lvCanvas'); if (!cv || !L.data) return;
    const tl = L.data.timeline, an = L.data.analysis, cams = tl.cams;
    const HEAD = 96, RUL = 26, TR = 30, AUD = 52, PADB = 6;
    const h = RUL + cams.length * TR + AUD + PADB + 4;
    cv.style.height = h + 'px';
    const dpr = devicePixelRatio || 1, w = cv.clientWidth;
    cv.width = w * dpr; cv.height = h * dpr;
    const g = cv.getContext('2d'); g.scale(dpr, dpr);
    const dur = tl.duration || 1, X = t => HEAD + t / dur * (w - HEAD - 6);
    g.fillStyle = '#1b1b1f'; g.fillRect(0, 0, w, h);
    // règle (timecode)
    g.fillStyle = '#232328'; g.fillRect(HEAD, 0, w - HEAD, RUL);
    g.font = '10px ' + getComputedStyle(document.body).fontFamily; g.textBaseline = 'middle';
    const steps = [5, 10, 15, 30, 60, 120, 300, 600, 900], px = (w - HEAD) / dur;
    const st = steps.find(x => x * px > 90) || 1800;
    for (let t = 0; t <= dur; t += st) {
      const x = X(t); g.fillStyle = '#55565e'; g.fillRect(Math.round(x), RUL - 9, 1, 9);
      g.fillStyle = '#9a9ca6'; g.fillText(tc(t, tl.fps), x + 4, RUL / 2 - 1);
      for (let k = 1; k < 5; k++) { const xx = X(t + st * k / 5); if (xx < w) { g.fillStyle = '#3c3d44'; g.fillRect(Math.round(xx), RUL - 4, 1, 4); } }
    }
    // pistes vidéo : V du haut en haut, V1 en bas (comme DaVinci)
    const order = cams.map((c, k) => k).sort((a, b) => (cams[b].track || b) - (cams[a].track || a));
    order.forEach((k, row) => {
      const c = cams[k], y = RUL + row * TR, rc = RCOL[c.role || 'other'];
      g.fillStyle = row % 2 ? '#1e1e23' : '#202026'; g.fillRect(HEAD, y, w - HEAD, TR);
      g.fillStyle = '#26262c'; g.fillRect(0, y, HEAD - 2, TR - 1);
      g.fillStyle = rc; g.fillRect(0, y, 3, TR - 1);
      g.fillStyle = '#d6d8de'; g.font = '600 11px ' + getComputedStyle(document.body).fontFamily; g.fillText('V' + (c.track || k + 1), 10, y + TR / 2);
      g.fillStyle = rc; g.font = '700 10px ' + getComputedStyle(document.body).fontFamily; g.fillText(RL(c.role || 'other').toUpperCase(), 34, y + TR / 2);
      for (const it of c.clips || []) {
        const x0 = X(it[0]), x1 = X(it[1]), off = c.role === 'off';
        g.fillStyle = off ? '#33363d' : '#3c5f8c'; g.fillRect(x0 + .5, y + 3, Math.max(1, x1 - x0 - 1), TR - 6);
        g.fillStyle = off ? '#3a3d44' : '#5277a8'; g.fillRect(x0 + .5, y + 3, Math.max(1, x1 - x0 - 1), 5);
        if (x1 - x0 > 50) { g.save(); g.beginPath(); g.rect(x0 + 2, y + 3, x1 - x0 - 4, TR - 6); g.clip(); g.fillStyle = 'rgba(255,255,255,.85)'; g.font = '10px ' + getComputedStyle(document.body).fontFamily; g.fillText(it[2], x0 + 5, y + TR / 2 + 3); g.restore(); }
      }
    });
    // piste audio A1 : énergie du set façon forme d'onde
    const ya = RUL + cams.length * TR + 2;
    g.fillStyle = '#26262c'; g.fillRect(0, ya, HEAD - 2, AUD); g.fillStyle = '#4caf6a'; g.fillRect(0, ya, 3, AUD);
    g.fillStyle = '#d6d8de'; g.font = '600 11px ' + getComputedStyle(document.body).fontFamily; g.fillText('A1', 10, ya + AUD / 2);
    g.fillStyle = '#2d5a3a'; g.fillRect(X(0), ya + 2, X(dur) - X(0), AUD - 4);
    if (an && an.curve) {
      const cur = an.curve, n = cur.length, mid = ya + AUD / 2;
      g.fillStyle = '#7fd394'; g.beginPath(); g.moveTo(X(0), mid);
      for (let i = 0; i < n; i++) g.lineTo(X(i / (n - 1) * dur), mid - Math.min(1.2, cur[i]) / 1.2 * (AUD / 2 - 4));
      for (let i = n - 1; i >= 0; i--) g.lineTo(X(i / (n - 1) * dur), mid + Math.min(1.2, cur[i]) / 1.2 * (AUD / 2 - 4));
      g.closePath(); g.fill();
    }
    // clips générés (zone in/out) et plans du clip survolé
    for (const c of L.data.clips || []) {
      const on = L.hover === c.n;
      g.fillStyle = on ? 'rgba(255,255,255,.14)' : c.state === 'done' ? 'rgba(61,220,151,.07)' : 'rgba(255,255,255,.035)';
      g.fillRect(X(c.t0), RUL, Math.max(1, X(c.t1) - X(c.t0)), h - RUL - PADB);
    }
    const hc = (L.data.clips || []).find(c => c.n === L.hover);
    if (hc && hc.shots) {
      for (const sh of hc.shots) {
        const row = order.indexOf(sh[2]); if (row < 0) continue;
        const y = RUL + row * TR, rc = RCOL[cams[sh[2]].role || 'other'];
        g.strokeStyle = rc; g.lineWidth = 2; g.strokeRect(X(sh[0]) + 1, y + 2, Math.max(2, X(sh[1]) - X(sh[0]) - 2), TR - 4);
        g.fillStyle = rc + '55'; g.fillRect(X(sh[0]) + 1, y + 2, Math.max(2, X(sh[1]) - X(sh[0]) - 2), TR - 4);
      }
    }
    // marqueurs (drops) sur la règle, comme les marqueurs DaVinci
    if (an) for (const dd of an.drops) {
      const x = X(dd.t);
      g.fillStyle = 'rgba(255,80,90,.55)'; g.fillRect(Math.round(x), RUL, 1, h - RUL - PADB);
      g.fillStyle = '#ff4f5e'; g.beginPath(); g.moveTo(x - 5, 3); g.lineTo(x + 5, 3); g.lineTo(x + 5, 11); g.lineTo(x, 16); g.lineTo(x - 5, 11); g.closePath(); g.fill();
    }
    cv.ondblclick = async e => {
      const r = cv.getBoundingClientRect(), x = e.clientX - r.left;
      if (x < HEAD) return;
      if (!an) return VC.toast('Lance d\'abord « Générer et exporter » pour analyser le set.', 3500);
      if (L.job) return VC.toast('Attends la fin de la génération (ou arrête-la).', 3500);
      const t = (x - HEAD) / (w - HEAD - 6) * dur;
      try { const res = await VC.api('/api/live/edit/new', { lid: L.lid, t }); VC.liveEdit(L.lid, res.n); } catch (err) { VC.toast(err.message, 5000); }
    };
    cv.onmousemove = e => {
      const r = cv.getBoundingClientRect(), x = e.clientX - r.left;
      if (x < HEAD) return;
      const t = (x - HEAD) / (w - HEAD - 6) * dur, el = $('#lvTc');
      if (el) el.textContent = tc(Math.max(0, t), tl.fps) + (an ? '' : '');
    };
  }
  addEventListener('resize', () => { if (VC.S.view === 'live') drawGraph(); });

  const EQ = '<svg viewBox="0 0 48 48" width="48" height="48"><g fill="currentColor"><rect x="5" y="20" width="5" height="16" rx="2"/><rect x="14" y="10" width="5" height="26" rx="2"/><rect x="23" y="16" width="5" height="20" rx="2"/><rect x="32" y="6" width="5" height="30" rx="2"/><rect x="41" y="22" width="2.5" height="14" rx="1"/></g><rect x="3" y="39" width="42" height="3" rx="1.5" fill="currentColor" opacity=".4"/></svg>';
})();
